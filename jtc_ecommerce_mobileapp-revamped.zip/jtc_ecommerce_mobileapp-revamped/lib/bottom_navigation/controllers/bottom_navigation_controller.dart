import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/favourite/screens/favourite_screen.dart';
import 'package:jtc_ecommerce/home/screens/home_screen.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/auth_singleton.dart';
import 'package:jtc_ecommerce/settings/screens/settings_screen.dart';
import 'package:jtc_ecommerce/utils/app_strings.dart';
import 'package:jtc_ecommerce/wallet/screens/wallet_screen.dart';

class BottomNavgationController extends GetxController {
  RxInt selectedIndex = 0.obs;

  final AuthSingletonUserRole authSingletonUserRole = AuthSingletonUserRole();

  RxString appbar_name = "".obs;

  void changePage(int index) {
    logData(message: "Index: $index");
    selectedIndex.value = index;
    if (selectedIndex.value == 1) {
      // appbar_name.value = "Favourite";
      appbar_name.value = tr('favourite');
    } else if (selectedIndex.value == 2) {
      // appbar_name.value = "Profile";
      appbar_name.value = tr('settingscreen.profile');
    } else if (selectedIndex.value == 3) {
      // appbar_name.value = "Wallet";
      appbar_name.value = tr('wallet');
    }
    update(); //! ============> Trigger a rebuild of the widget
  }

  final List pagesForBusiness = [
    HomeScreen(),
    FavouriteScreen(),
    SettingScreen(),
    WalletScreen(),
  ];

  //! ============> Open Drawer
  // void openDrawer() {
  //   scaffoldKey.currentState?.openDrawer();
  // }

  @override
  void onClose() {
    super.onClose();
  }

  //! ============> Switch Case
  String getTitleForIndex(int index) {
    switch (index) {
      case 0:
        // if (authSingletonUserRole.userRole == UserRole.Business) {
        //   var homeScreenBusinessController = Get.isRegistered()
        //       ? Get.find<HomeScreenBusinessController>()
        //       : Get.put(HomeScreenBusinessController());
        //   homeScreenBusinessController.searchTextEditingController.text = "";
        //   homeScreenBusinessController.onRefresh();
        // } else if (authSingletonUserRole.userRole == UserRole.Guest) {
        // var homeScreenInfluencerController = Get.isRegistered()
        //     ? Get.find<HomeScreenInfluencerController>()
        //     : Get.put(HomeScreenInfluencerController());
        // homeScreenInfluencerController.searchTextEditingController.text = "";
        // homeScreenInfluencerController.onRefreshForNewEvents();
        // homeScreenInfluencerController.onRefreshForInvitedEvents();
        // }
        return AppStrings.HOME_NAV_BAR_ITEM;
      case 1:
        // if (authSingletonUserRole.userRole == UserRole.Business) {
        //   var requestContorller = Get.isRegistered()
        //       ? Get.find<RequestContorller>()
        //       : Get.put(RequestContorller());
        //   requestContorller.searchTextEditingController.text = "";
        //   requestContorller.onRefresh();
        // } else if (authSingletonUserRole.userRole == UserRole.Guest) {
        // var myEventController = Get.isRegistered()
        //     ? Get.find<MyEventController>()
        //     : Get.put(MyEventController());
        // myEventController.onRefresh();
        // }
        return AppStrings.FAVOURITE_NAV_BAR_ITEM;
      case 2:
        return AppStrings.SETTING_NAV_BAR_ITEM;
      case 3:
        return AppStrings.WALLET_NAV_BAR_ITEM;
      default:
        return '';
    }
  }
}
