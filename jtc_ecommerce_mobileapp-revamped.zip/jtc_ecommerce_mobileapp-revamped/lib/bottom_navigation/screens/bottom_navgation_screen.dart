import 'dart:convert';
import 'dart:io';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_barcode_scanner/flutter_barcode_scanner.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/bottom_navigation/controllers/bottom_navigation_controller.dart';
import 'package:jtc_ecommerce/bottom_navigation/screens/components/paynow_popup.dart';
import 'package:jtc_ecommerce/cart/controllers/cart_controller.dart';
import 'package:jtc_ecommerce/favourite/controllers/favourite_controller.dart';
import 'package:jtc_ecommerce/generated/codegen_loader.g.dart';
import 'package:jtc_ecommerce/widgets/custom_app_bar.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/widgets/custom_willpopscope_dialog.dart';
import 'package:jtc_ecommerce/home/controllers/home_controller.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/auth_singleton.dart';
import 'package:jtc_ecommerce/settings/controllers/settings_controller.dart';
import 'package:jtc_ecommerce/splash/controllers/splash_controller.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';
import 'package:jtc_ecommerce/utils/app_strings.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';
import 'package:jtc_ecommerce/utils/constants.dart';
import 'package:jtc_ecommerce/wallet/controllers/wallet_controller.dart';

class BottomNavigationScreen extends StatefulWidget {
  BottomNavigationScreen({super.key});

  @override
  State<BottomNavigationScreen> createState() => _BottomNavigationScreenState();
}

class _BottomNavigationScreenState extends State<BottomNavigationScreen> {
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  final AuthSingletonUserRole _authSingletonUserRole = AuthSingletonUserRole();

  var controller = Get.put(BottomNavgationController());

  var settingController = Get.put(SettingsController());

  // checkForStore() {}

  Widget _qrButton() {
    return GestureDetector(
      onTap: onQrTapped,
      child: Container(
        height: 50.h,
        width: 50.h,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(50.r),
          color: Colors.red,
          border: Border.all(color: Colors.white, width: 4.0)
          
          
        ),
        child: Center(
          child: Image.asset(
            AssetPaths.QR_ICON,
            height: 25.h,
            width: 25.w,
            fit: BoxFit.contain,
            color: Colors.white,
          ), 
        ), 
      ),  
    );
  }

  void onQrTapped() async {
    String barcodeScanRes = await FlutterBarcodeScanner.scanBarcode(
        "#ff6666", tr("cancel_product_text"), true, ScanMode.QR);

    if (barcodeScanRes.isNotEmpty && barcodeScanRes.contains("amount")) {
      try {
        if (barcodeScanRes.startsWith("{")) {
          final barcodeData = jsonDecode(barcodeScanRes);

          logData(message: "Bar Code detected ${barcodeData}");

          if (barcodeData['privateKey'] != null) {
            AppDialogs.showAppDialog(
                context: Constants.navigatorKey.currentContext!,
                child: PaymentConfirmDialog(
                    onSuccvess: () {
                      // Navigator.pop(context);
                    },
                    data: barcodeData));
          } else {
            AppDialogs.showToast(message: tr("scan_failed_could_not_verify"));
          }
        } else {
          AppDialogs.showToast(message: tr("scan_failed_could_not_verify"));
        }
      } catch (e) {
        logData(message: "Error decoding barcode ${e.toString()}");
      }
    } else {
      // AppDialogs.showToast(message: tr("scan_failed"));
    }
  }

  // var cartController = Get.put(CartController());
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // key: g,
      onWillPop: () async {
        return await Get.defaultDialog(
          barrierDismissible: false,
          // title: "Exit",
          title: tr('exit'),
          content: ExitButtonContent(
            onTapYesButton: () {
              exit(0);
            },
          ),
        );
      },
      child: GetBuilder<BottomNavgationController>(builder: (splashController) {
        return Scaffold(
          floatingActionButtonLocation:
              FloatingActionButtonLocation.centerDocked,
          key: scaffoldKey,
          floatingActionButton: _qrButton(),
          backgroundColor: AppColors.RED_GMAIL_COLOR,
          resizeToAvoidBottomInset: false,
          drawerEnableOpenDragGesture: false,
          drawerEdgeDragWidth: 0,
          extendBody: false,
          appBar: controller.selectedIndex == 1 ||
                  controller.selectedIndex == 2 ||
                  controller.selectedIndex == 3
              ? appBarWithTitleAndIcons(
                  titleText1: controller.appbar_name.value,
                  onTap_cart: () => AppNavigation.navigateTo(
                      context, AppRouteName.CART_SCREEN_ROUTE),
                  onTap_notification: () {
                    AppNavigation.navigateTo(
                        context, AppRouteName.NOTIFICATION_SCREEN_ROUTE);
                    settingController.get_Notification_list();
                  },
                )
              : appBarWithLeading(
                  titleText2: "",
                  titleText1: tr('deliver_to_text'),

                  onTitletap: () {
                    // () {
                    AppNavigation.navigateTo(
                      Get.context!,
                      AppRouteName.LOCATION_SCREEN_ROUTE,
                    );
                    // },
                  },
                  widget: InkWell(
                    onTap: () {
                      AppNavigation.navigateTo(
                        Get.context!,
                        AppRouteName.LOCATION_SCREEN_ROUTE,
                      );
                    },
                    child: SizedBox(
                      width: 200.w,
                      child: Obx(
                        () => CustomText(
                          text: Get.find<SplashController>()
                                  .currentUser
                                  .value
                                  ?.address ??
                              "",
                          fontsize: 14.sp,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          color: AppColors.WHITE_COLOR,
                          isLeftAlign: false,
                          align: Alignment.centerLeft,
                        ),
                      ),
                    ),
                  ),
                  onTapNotifications:

                      // () => AppNavigation.navigateTo(
                      //     context, AppRouteName.NOTIFICATION_SCREEN_ROUTE),

                      () {
                    AppNavigation.navigateTo(
                        context, AppRouteName.NOTIFICATION_SCREEN_ROUTE);
                    settingController.get_Notification_list();
                  },
                  // color: cartController.cart_list.isEmpty
                  //     ? Colors.white
                  //     : Colors.red,
                  onTapCart:

                      //   () => AppNavigation.navigateTo(
                      //       context, AppRouteName.CART_SCREEN_ROUTE),
                      // ),

                      () {
                    AppNavigation.navigateTo(
                        context, AppRouteName.CART_SCREEN_ROUTE);
                    CartController.i.get_cart_list();
                  },
                ),
          body: Container(
            width: double.maxFinite,
            height: double.maxFinite,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Color(0xFFFB2F30),
                  Color(0xFFE6262B),
                  Color(0xFFC81925),
                  Color(0xFFB00F1F),
                ],
              ),
            ),
            child: controller.pagesForBusiness[controller.selectedIndex.value],
          ),
          // drawer: const CustomDrawer(),
          bottomNavigationBar: _customNavigationBarBusiness(),

          // floatingActionButtonLocation:
          //     FloatingActionButtonLocation.centerDocked,
          // floatingActionButton:
          //     _authSingletonUserRole.userRole == UserRole.Business
          //         ? floatingActionButton(context: context)
          //         : const SizedBox.shrink(),
        );
      }),
    );
  }

  //! ============> Bottom Navigation Bar Widgets (Business OR Influencer)
  Widget _customNavigationBarBusiness() {
    return Container(
      height: 69.h,
      decoration: BoxDecoration(
        color: Color(0xFFF6F6F6),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5),
            spreadRadius: 7,
            blurRadius: 7,
            offset:
                const Offset(0, 3), //! ============> Changes position of shadow
          ),
        ],
      ),
      child: _influencerNavigationItemWidget(), 
    );
  }

  Widget _influencerNavigationItemWidget() {
    var controller = Get.put(BottomNavgationController());
    return Row(
      children: [
        Obx(
          () => Expanded(
            child: GestureDetector(
              onTap: () {
                var homeScreenInfluencerController = Get.isRegistered()
                    ? Get.find<HomeController>()
                    : Get.put(HomeController());
                // homeScreenInfluencerController
                //     .searchTextEditingController.text = "";
                // homeScreenInfluencerController.onRefreshForNewEvents();
                homeScreenInfluencerController.onRefreshPage();
                controller.changePage(0);
              },
              child: _bottomNavBarItems(
                iconSelected: AssetPaths.HOME_BOTTOM_NAVIGAITON,
                inIndex: 0,
                text: AppStrings.HOME_NAV_BAR_ITEM,
              ),
            ),
          ),
        ),
        Obx(
          () => Expanded(
              child: GestureDetector(
            onTap: () {
              var myEventController = Get.isRegistered()
                  ? Get.find<FavouriteController>()
                  : Get.put(FavouriteController());
              myEventController.onRefreshPage();
              controller.changePage(1);
            },
            child: _bottomNavBarItems(
              iconSelected: AssetPaths.FAV_BOTTOM_NAVIGAITON,
              inIndex: 1,
              text: AppStrings.FAVOURITE_NAV_BAR_ITEM,
            ),
          )),
        ),
        SizedBox(
          width: 20,
        ),
        Obx(
          () => Expanded(
            child: GestureDetector(
              onTap: () => controller.changePage(2),
              child: _bottomNavBarItems(
                iconSelected: AssetPaths.PERSON_BOTTOM_NAVIGAITON,
                inIndex: 2,
                text: AppStrings.SETTING_NAV_BAR_ITEM,
              ),
            ),
          ),
        ),
        Obx(
          () => Expanded(
            child: GestureDetector(
              // onTap: () => controller.changePage(3),
              onTap: () {
                var myEventController = Get.isRegistered()
                    ? Get.find<WalletController>()
                    : Get.put(WalletController());
                myEventController.onRefreshPage();
                controller.changePage(3);
              },
              child: _bottomNavBarItems(
                iconSelected: AssetPaths.WALLET_BOTTOM_NAVIGAITON,
                inIndex: 3,
                text: AppStrings.WALLET_NAV_BAR_ITEM, 
              ),
            ),
          ), 
        ),
      ],
    );
  }

  Widget _bottomNavBarItems({
    required int inIndex,
    required String iconSelected, 
    required String text,
  }) {
    var controller = Get.put(BottomNavgationController());
    return Container( 
      color: AppColors.TRANSPARENT_COLOR, 
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [ 
          Image.asset(iconSelected,
              height: 25.h,
              color: controller.selectedIndex.value == inIndex 
                  ? AppColors.PRIMARY_COLOR
                  : AppColors.GREY_COLOR, 
                  ),
          5.verticalSpace,
          controller.selectedIndex.value == inIndex 
              ? Container(
                  height: 6.h,
                  width: 6.w, 
                  decoration: BoxDecoration(
                    color: AppColors.PRIMARY_COLOR,
                    shape: BoxShape.circle,
                  ),
                )
              : const SizedBox.shrink(),
        ],
      ),
    );
  }
}
