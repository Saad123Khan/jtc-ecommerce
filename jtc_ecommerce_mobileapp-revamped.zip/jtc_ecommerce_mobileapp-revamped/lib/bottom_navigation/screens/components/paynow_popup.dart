import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:jtc_ecommerce/auth/blocs/send_payment_via_qr.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/constants.dart';

class PaymentConfirmDialog extends StatefulWidget {
  final Map<String, dynamic> data;
  final Function()? onSuccvess;

  const PaymentConfirmDialog({super.key, required this.data, this.onSuccvess});

  @override
  State<PaymentConfirmDialog> createState() => _PaymentConfirmDialogState();
}

class _PaymentConfirmDialogState extends State<PaymentConfirmDialog> {
  @override
  Widget build(BuildContext context) {
    final local = context.locale.languageCode.toLowerCase();
    return Dialog(
      insetPadding: EdgeInsets.symmetric(vertical: 50.h, horizontal: 30.w),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(40.r),
      ),
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.WHITE_COLOR,
          borderRadius: BorderRadius.circular(40.r),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(
              height: 20,
            ),
            Align(
              alignment: Alignment.center,
              child: CustomText(
                text: local == "en" ? 'Pay Now' : 'Paga Ahora',
                color: AppColors.PRIMARY_COLOR,
                fontWeight: FontWeight.bold,
                fontsize: 22, // Adjusted title size
              ),
            ),
            SizedBox(height: 20.h), // Adjust spacing
            CustomText(
              text: local == "en"
                  ? 'Are you sure you want to pay \$${widget.data['amount']}?'
                  : '¿Estás seguro de que deseas pagar \$${widget.data['amount']}?',
              color: AppColors.BLACK_COLOR,
              maxLines: 20,
              fontsize: 18, // Adjusted message size
            ),
            SizedBox(height: 30.h),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pop(); // Dismiss dialog
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.GREY_COLOR,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20.r),
                    ),
                  ),
                  child: CustomText(
                    text: local == "en" ? 'Cancel' : 'Cancelar',
                    color: AppColors.WHITE_COLOR,
                    fontsize: 16,
                  ),
                ),
                ElevatedButton(
                  onPressed: () {
                    // Confirm payment logic

                    QRPaymentBloc().qrPayment(
                        context: context,
                        onSucces: () {
                          // widget.onSuccvess?.call();
                        },
                        setProgressBar: () {
                          AppDialogs.progressAlertDialog(context: context);
                        },
                        amount: widget.data['amount'].toString(),
                        privateKey: widget.data['privateKey'].toString());
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.PRIMARY_COLOR,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20.r),
                    ),
                  ),
                  child: CustomText(
                    text: local == "en" ? 'Confirm' : 'Confirmar',
                    color: AppColors.WHITE_COLOR,
                    fontsize: 16,
                  ),
                ),
              ],
            ),

            const SizedBox(
              height: 20,
            ),
          ],
        ),
      ),
    );
  }
}
