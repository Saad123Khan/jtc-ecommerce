// To parse this JSON data, do
//
//     final sendPasswordModel = sendPasswordModelFromJson(jsonString);

import 'dart:convert';

SendPasswordModel sendPasswordModelFromJson(String str) => SendPasswordModel.fromJson(json.decode(str));

String sendPasswordModelToJson(SendPasswordModel data) => json.encode(data.toJson());

class SendPasswordModel {
    String message;

    SendPasswordModel({
        required this.message,
    });

    factory SendPasswordModel.fromJson(Map<String, dynamic> json) => SendPasswordModel(
        message: json["message"],
    );

    Map<String, dynamic> toJson() => {
        "message": message,
    };
}
