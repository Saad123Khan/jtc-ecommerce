import 'dart:convert';

UserResponseModel userResponseModelFromJson(String str) =>
    UserResponseModel.fromJson(json.decode(str));

String userResponseModelToJson(UserResponseModel data) =>
    json.encode(data.toJson());

class UserResponseModel {
  bool status;
  String token;
  String message;
  UserData data;

  UserResponseModel({
    required this.status,
    required this.token,
    required this.message,
    required this.data, 
  });

  factory UserResponseModel.fromJson(Map<String, dynamic> json) =>
      UserResponseModel(
        status: json["status"],
        token: json["token"] != null ? json["token"] : "",
        message: json["message"],
        data: UserData.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "status": status,
        "token": token,
        "message": message,
        "data": data.toJson(),
      };
}

class UserData {
  int id;
  String firstName;
  String lastName;
  String email;
  // DateTime emailVerifiedAt;
  String phoneNo;
  String referalCode;
  int rewardPoints;
  String language;
  String firebaseWebToken;
  String firebaseMobileToken;
  String walletId;
  String address;
  String nearest_address;
  String lat;
  String long;
  String image;
  String imageUrl;
  String provider;
  List<dynamic> media;

  UserData({
    required this.id,
    required this.firstName,
    required this.lastName,
    required this.email,
    required this.phoneNo,
    required this.referalCode,
    required this.rewardPoints,
    required this.language,
    required this.firebaseWebToken,
    required this.firebaseMobileToken,
    required this.walletId,
    required this.address,
    required this.nearest_address,
    required this.lat,
    required this.long,
    required this.image,
    required this.imageUrl,
    required this.media,
    required this.provider,
  });

  factory UserData.fromJson(Map<String, dynamic> json) => UserData(
        id: json["id"],
        firstName: json["first_name"],
        lastName: json["last_name"],
        email: json["email"],
        // emailVerifiedAt: json["email_verified_at"] !=null ? DateTime.parse(json["email_verified_at"]) : DateTime(1011),
        phoneNo: json["phone_no"] != null ? json["phone_no"] : "",
        referalCode: json["referal_code"],
        rewardPoints: json["reward_points"],
        language: json["language"],
        firebaseWebToken: json["firebase_web_token"] != null
            ? json["firebase_web_token"]
            : "",
        firebaseMobileToken: json["firebase_mobile_token"] != null
            ? json["firebase_mobile_token"]
            : "",
        walletId: json["walletId"],
        address: json["address"] != null ? json["address"] : "",
        nearest_address:
            json["nearest_address"] != null ? json["nearest_address"] : "",
        lat: json["lat"] != null ? json["lat"] : "0.0",
        long: json["long"] != null ? json["long"] : "0.0",
        image: json["image"] != null ? json["image"] : "",
        imageUrl: json["image_url"] != null ? json["image_url"] : "",
        media: List<dynamic>.from(json["media"].map((x) => x ?? [])),
        provider: json["provider"],
        //  != null ? json["provider"] : "Default",
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "first_name": firstName,
        "last_name": lastName,
        "email": email,
        "phone_no": phoneNo,
        "referal_code": referalCode,
        "reward_points": rewardPoints,
        "language": language,
        "firebase_web_token": firebaseWebToken,
        "firebase_mobile_token": firebaseMobileToken,
        "walletId": walletId,
        "address": address,
        "nearest_address": nearest_address,
        "lat": lat,
        "long": long,
        "image": image,
        "image_url": imageUrl,
        "media": List<dynamic>.from(media.map((x) => x)),
        "provider": provider,
      };
}
