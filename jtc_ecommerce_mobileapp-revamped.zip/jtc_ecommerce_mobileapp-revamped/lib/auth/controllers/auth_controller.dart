import 'dart:async';

import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/auth/blocs/login_bloc.dart';
import 'package:jtc_ecommerce/auth/blocs/register_bloc.dart';
import 'package:jtc_ecommerce/auth/blocs/resend_otp_bloc.dart';
import 'package:jtc_ecommerce/auth/blocs/resend_otp_notvalid_bloc.dart';
import 'package:jtc_ecommerce/auth/blocs/reset_password_bloc.dart';
import 'package:jtc_ecommerce/auth/blocs/update_profile_bloc.dart';
import 'package:jtc_ecommerce/auth/blocs/verify_otp_bloc.dart';
import 'package:jtc_ecommerce/auth/blocs/verify_otp_bloc_resetpass.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/auth_singleton.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/enums.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:geolocator/geolocator.dart';
import 'package:place_picker/place_picker.dart';

class AuthController extends GetxController {
  ///INSTANCE Singleton

  static AuthController get i => Get.find();
  AuthSingletonUserRole authSingletonUserRole = AuthSingletonUserRole();

  @override
  void onInit() {
    authSingletonUserRole.switchValue = SwitchValue.email;
    startTimer();
    super.onInit();
  }

  @override
  void onClose() {
    _timer?.cancel();
    super.onClose();
  }

  RxInt remainingTime = 60.obs;
  Timer? _timer;
  void startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (remainingTime.value > 0) {
        remainingTime.value--;
      } else {
        _timer?.cancel();
      }
    });
  }

  final Rx<TextEditingController> user_address = TextEditingController().obs;
  //!Login
  TextEditingController email_login = TextEditingController();
  GlobalKey<FormState> loginFormKey = GlobalKey<FormState>();
  // GlobalKey<FormState> resetpassFormKey = GlobalKey<FormState>();

  //==
  TextEditingController number_login = TextEditingController();
  TextEditingController password_login = TextEditingController();
  RxBool show_password_login = true.obs;
  RxBool isEmailSelected = true.obs;
  RxBool isChecked = false.obs;
  RxBool isLoading = false.obs;
  RxBool checkBox = false.obs;

  void loginMethod({required BuildContext context}) {
    LoginBloc().loginBlocMethod(
      userEmail: email_login.text,
      password: password_login.text,
      context: Get.context!,
      setProgressBar: () {
        AppDialogs.progressAlertDialog(context: Get.context!);
      },
    );
  }

  void getLocationAndUpdateProfile(
      {required String address,
      required BuildContext context,
      bool isFromUpdateProfile = false,
      bool isFromOrderSummary = false,
      Function()? onSuccess,
      LatLng? latLng}) async {
    logData(
        message:
            "fullAddress: ${address} latitude: ${latLng?.latitude} longitude: ${latLng?.longitude}");
    isLoading.value = false;
    UpdateProfileBloc().updateProfileBlocMethod(
      context: context,
      nearest_address: nearest_address.value.text,
      current_user_address: address,
      isFromOrderSummary: isFromOrderSummary,
      lat: latLng?.latitude.toString(),
      isFromUpdateProfile: isFromUpdateProfile,
      long: latLng?.longitude.toString(),
      onSuccess: onSuccess,
      setProgressBar: () {
        AppDialogs.progressAlertDialog(context: context);
      },
    );

    // Handle case where user_address is empty
  }

  void clearTextFieldsLogin() {
    email_login.text = "";
    number_login.text = "";
    password_login.text = "";
    password.text = "";
  }

  void clearResetPasswordEmail() {
    email_login.text = "";
    number_login.text = "";
    password_login.text = "";
    password.text = "";
  }

  //!Register
  GlobalKey<FormState> registerFormKey = GlobalKey<FormState>();
  TextEditingController firstName = TextEditingController();
  TextEditingController nearest_address = TextEditingController();
  TextEditingController lastName = TextEditingController();
  // TextEditingController email_register = TextEditingController();
  TextEditingController phoneNo = TextEditingController();
  TextEditingController password = TextEditingController();
  TextEditingController confrim_password = TextEditingController();
  TextEditingController referral_code = TextEditingController();
  RxBool show_password_register = true.obs;
  RxBool show_confirm_password_register = true.obs;
  RxString countryCode = "".obs;

  void registerMethod({required BuildContext context}) {
    RegisterBloc().registerBlocMethod(
      first_name: firstName.text,
      last_name: lastName.text,
      // email: email_register.text,
      email: email_login.text,
      full_phone_no: countryCode + phoneNo.text,
      password: password.text,
      confirm_password: confrim_password.text,
      refer_code: referral_code.text,
      context: Get.context!,
      setProgressBar: () {
        AppDialogs.progressAlertDialog(context: Get.context!);
      },
    );
  }

  void clearTextFieldsRegister() {
    firstName.text = "";
    lastName.text = "";
    // email_register.text = "";
    phoneNo.text = "";
    password.text = "";
    confrim_password.text = "";
    referral_code.text = "";
  }

  void clearTextFieldsOtpVerify() {
    pin_controller.text = "";
  }

  //!Verify OTP
  TextEditingController pin_controller = TextEditingController();
  RxBool when_user_verified = false.obs;
  String tempEmail = "";

  void verifyOtpMethod({required BuildContext context, String? pin_code}) {
    VerifyOtpBloc().verifyOtpBlocMethod(
      // userEmail: email_login.text,
      userEmail: tempEmail,
      code: pin_code ?? "",
      context: Get.context!,
      setProgressBar: () {
        AppDialogs.progressAlertDialog(context: Get.context!);
      },
    );
  }

  void verifyOtpMethodReset(
      {required BuildContext context,
      String? pin_code,
      String? resetemailpass}) {
    VerifyOtpResetBloc().verifyOtpBlocMethod(
      // userEmail: email_login.text,
      userEmail: resetemailpass,
      code: pin_code ?? "",
      context: Get.context!,
      setProgressBar: () {
        AppDialogs.progressAlertDialog(context: Get.context!);
      },
    );
  }

  //!Resend OTP
  void resendOtpMethod({required BuildContext context}) {
    ResendOtpBloc().resendOtpBlocMethod(
      // userEmail: email_login.text,
      userEmail: tempEmail,
      context: Get.context!,
      setProgressBar: () {
        AppDialogs.progressAlertDialog(context: Get.context!);
      },
    );
  }

  //!Resend OTP
  void resendOtpNotValidMethod({required BuildContext context}) {
    ResendOtpNotValidBloc().resendOtpNotValidBlocMethod(
      // userEmail: email_login.text,
      // userEmail: "uk@yopmail.com",
      userEmail: reset_password_email.text,
      context: Get.context!,
      setProgressBar: () {
        AppDialogs.progressAlertDialog(context: Get.context!);
      },
    );
  }

  //!Get User Location

  Future<bool> requestLocationPermission() async {
    var status = await Permission.location.request();
    return status == PermissionStatus.granted;
  }

  Future<Map<String, dynamic>?> getCurrentLocation() async {
    bool permissionGranted = await requestLocationPermission();
    if (!permissionGranted) {
      // Handle case where permission is denied
      return null;
    }

    print("Permission granted: " + permissionGranted.toString());

    Position position = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );
    List<Placemark> placemarks = await placemarkFromCoordinates(
      position.latitude,
      position.longitude,
    );

    String fullAddress =
        '${placemarks.first.street}, ${placemarks.first.locality}, ${placemarks.first.administrativeArea}, ${placemarks.first.country}';
    String latitude = position.latitude.toString();
    String longitude = position.longitude.toString();

    return {
      'fullAddress': fullAddress,
      'latitude': latitude,
      'longitude': longitude,
    };
  }

  void getLocation({required BuildContext context}) async {
    isLoading.value = true;
    Map<String, dynamic>? locationData = await getCurrentLocation();
    if (locationData != null) {
      String fullAddress = locationData['fullAddress'];
      String latitude = locationData['latitude'];
      String longitude = locationData['longitude'];
      logData(
          message:
              "fullAddress: $fullAddress latitude: $latitude longitude: $longitude");
      isLoading.value = false;
      UpdateProfileBloc().updateProfileBlocMethod(
        context: context,
        nearest_address: nearest_address.value.text,
        current_user_address: fullAddress,
        lat: latitude,
        long: longitude,
        setProgressBar: () {
          AppDialogs.progressAlertDialog(context: context);
        },
      );
      // Use the location data as needed
    } else {
      AppDialogs.showToast(message: "Please allow location services");
      isLoading.value = false;
      // Handle case where location permission is denied
    }
  }

  //!Reset Password
  GlobalKey<FormState> resetPasswordFormKey = GlobalKey<FormState>();
  TextEditingController reset_password_email = TextEditingController();
  RxBool show_pinfield = false.obs;

  void sendPasswordMethod({required BuildContext context}) {
    // clearTextFieldsResetPassword();
    // show_pinfield.value = true;
    SendPasswordBloc().sendPasswordBlocMethod(
      context: context,
      userEmail: reset_password_email.text,
      setProgressBar: () {
        AppDialogs.progressAlertDialog(context: context);
      },
    );
  }

  void clearTextFieldsResetPassword() {
    reset_password_email.text = "";
  }

  // void sendPasswordMethod({required BuildContext context}) {
  //   show_pinfield.value = true;
  //   AppDialogs.progressAlertDialog(context: context);
  //   SendPasswordBloc().sendPasswordBlocMethod(
  //     context: context,
  //     userEmail: reset_password_email.text,
  //     setProgressBar: () {
  //       // show_pinfield.value = true;
  //       AppDialogs.progressAlertDialog(context: context);
  //     },
  //     // onSuccess: () {
  //     //   // API call succeeded, show the pin field
  //     //   show_pinfield.value = true;

  //     //   // Close progress dialog
  //     //   Get.back();
  //     // },
  //     // onError: (String errorMessage) {
  //     //   // API call failed, handle error if needed
  //     //   // Close progress dialog
  //     //   Get.back();
  //     // },
  //   );
  // }
}
