import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart' as GetxController;
import 'package:jtc_ecommerce/auth/models/user_model.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/local_storage.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/services/translate_service.dart';
import 'package:jtc_ecommerce/settings/controllers/settings_controller.dart';
import 'package:jtc_ecommerce/splash/controllers/splash_controller.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';
import 'package:http_parser/http_parser.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';

class UpdateProfileBloc {
  FormData? _formData;
  Response? _response;
  VoidCallback? _onSuccess, _onFailure;
  UserResponseModel? _loginResponse;
  UserData? _userData;
  String? deviceToken;

  void updateProfileBlocMethod({
    required BuildContext context,
    required VoidCallback setProgressBar,
    String? current_user_address,
    Function()? onSuccess,
    String? phone_no,
    String? nearest_address,
    String? lat,
    String? long,
    String? first_name,
    String? last_name,
    bool isFromUpdateProfile = false,
    bool isFromOrderSummary = false,
    File? file,
  }) async {
    setProgressBar();

    logData(message: file.toString());

    final Map<String, dynamic> dataMap = {
      "phone_no": phone_no,
      "nearest_address": nearest_address,
      "address": current_user_address,
      "lat": lat,
      "long": long,
      //More
      "first_name": first_name,
      "last_name": last_name
    };

    if (file != null) {
      logData(message: "Image: ${file}");
      final multipartFile = await MultipartFile.fromFile(file.path,
          contentType:
              MediaType("image", file.path.split('.').last.toLowerCase()));

      dataMap['image'] = multipartFile;
    }
    //! ============> Form Data
    _formData = FormData.fromMap(dataMap);

    //! ============> Print Form Data
    log({
      "nearest_address": nearest_address,
      "address": current_user_address,
      "lat": lat,
      "long": long,
      //More
      "first_name": first_name,
      "last_name": last_name,
      //Image
      if (isFromUpdateProfile)
        if (file != null) "image": file
    }.toString());

    //! ============> If Api fails then stop the loader
    _onFailure = () async {
      AppNavigation.navigatorPop(context);

      final message = await _response?.data['message'];

      switch (message) {
        // case "User not found":
        //   AppDialogs.showToast(message: tr(NetworkStrings.USER_NOT_FOUND));
        //   break;

        default:
          if (context.locale.languageCode != "en") {
            final _translatedMessage = await GoogleTranslatorService()
                .translate(text: message, context: context);
            AppDialogs.showToast(message: _translatedMessage);
          } else {
            AppDialogs.showToast(message: message);
          }
      }
    };

    //! ============> Call api
    await _postRequest(
      endPoint: NetworkStrings.UPDATE_PROFILE_ENDPOINT,
      context: GetxController.Get.context!,
    );

    //! ============> Get the login response
    _onSuccess = () {
      AppNavigation.navigatorPop(context);
      _loginResponseMethod(
          context: context,
          isFromUpdateProfile: isFromUpdateProfile,
          isFromOrderSummary: isFromOrderSummary);
      onSuccess?.call();
    };

    //! ============> Validate the response
    _validateResponse();
  }

  //! ============> Post Request
  Future<void> _postRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().postRequest(
      endPoint: endPoint,
      formData: _formData,
      context: context,
      customFailure: true,
      onFailure: _onFailure,
      isHeaderRequire: true,
      isToast: false,
    );
  }

  //! ============> Validate Response
  void _validateResponse() {
    if (_response != null) {
      Network().validateResponse(
        isToast: false,
        response: _response,
        onSuccess: _onSuccess,
        onFailure: _onFailure,
      );
    }
  }

  //! ============> Creating a controller instance to save the user id temp for next verification otp api

  //! ============> Login Response
  void _loginResponseMethod({
    required BuildContext context,
    required bool isFromUpdateProfile,
    bool isFromOrderSummary = false,
  }) async {
    // var authContorller = isFromUpdateProfile
    //     ? GetxController.Get.isRegistered()
    //         ? GetxController.Get.find<SettingsController>()
    //         : GetxController.Get.put(SettingsController())
    //     : GetxController.Get.isRegistered()
    //         ? GetxController.Get.find<AuthController>()
    //         : GetxController.Get.put(AuthController());

    logData(message: _response!.statusCode.toString());
    // try {
    _loginResponse = UserResponseModel.fromJson(_response?.data);
    _userData = _loginResponse?.data;
    if (_loginResponse != null) {
      print(_loginResponse?.message);
      // AppDialogs.showToast(
      //   message: _loginResponse?.message.toString(),
      //   toastLength: Toast.LENGTH_LONG,
      //   timeInSecForIosWeb: 5,
      // );

      if (_loginResponse?.message == 'Profile updated successfully') {
        AppDialogs.showToast(message: tr('profile_updated_sucessfully'));
        GetxController.Get.find<SettingsController>().imagePath.value = null;
      } else {
        // AppDialogs.showToast(message: _loginResponse?.message);
        AppDialogs.showToast(
          message: _loginResponse?.message.toString(),
          toastLength: Toast.LENGTH_LONG,
          timeInSecForIosWeb: 5,
        );
      }

      //! ============> Save User
      try {
        SharedPreference().setUser(
          user: jsonEncode(_loginResponse?.data),
        );
      } catch (e) {
        print('Error saving data to shared preferences: $e');
      }
      var currentSavedUser = SharedPreference().getUser();
      if (currentSavedUser != null) {
        final jsonResponse = jsonDecode(currentSavedUser);
        final UserData? _currentUser = UserData.fromJson(jsonResponse);
        GetxController.Get.find<SplashController>().currentUser.value =
            _currentUser;
      }
      logData(
          message:
              "Saved User: ${GetxController.Get.find<SplashController>().currentUser.value?.email}");
      if (isFromOrderSummary) {
        GetxController.Get.find<SplashController>().update();
        return;
      } else {
        if (isFromUpdateProfile) {
          GetxController.Get.find<SplashController>().update();
          AppNavigation.navigatorPop(context);
        } else {
          AppNavigation.navigateTo(
            context,
            AppRouteName.BOTTOM_NAVIGATION_SCREEN_ROUTE,
          );
        }
      }
    }
  }

  // catch (error) {

  //   AppDialogs.showToast(message: tr(NetworkStrings.SOMETHING_WENT_WRONG));
  // }
  // }
}
