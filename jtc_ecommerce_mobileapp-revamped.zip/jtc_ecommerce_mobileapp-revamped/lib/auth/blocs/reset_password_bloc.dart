import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as GetxController;
import 'package:jtc_ecommerce/auth/controllers/auth_controller.dart';
import 'package:jtc_ecommerce/auth/models/send_password_model.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/services/translate_service.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';

class SendPasswordBloc {
  FormData? _formData;
  Response? _response;
  VoidCallback? _onSuccess, _onFailure;
  SendPasswordModel? _sendPasswordModel;
  // UserData? _userData;
  // String? deviceToken;

  void sendPasswordBlocMethod({
    required BuildContext context,
    String? userEmail,
    required VoidCallback setProgressBar,
  }) async {
    setProgressBar();

    //! ============> Form Data
    _formData = FormData.fromMap({
      "email": userEmail,
    });

    //! ============> Print Form Data
    print({
      "email": userEmail,
    });

    //! ============> If Api fails then stop the loader
    _onFailure = () async {
      AppNavigation.navigatorPop(context);

      print("STATUSSS CODEE ${_response?.statusCode}");
      final message = _response?.data['message'] ?? "";

      print(message);

      switch (message) {
        case "User not found":
          AppDialogs.showToast(message: tr(NetworkStrings.USER_NOT_FOUND));
          break;

        default:
          if (context.locale.languageCode != "en") {
            final _translatedMessage = await GoogleTranslatorService()
                .translate(text: message, context: context);
            AppDialogs.showToast(message: _translatedMessage);
          } else {
            AppDialogs.showToast(message: message);
          }
      }
    };

    //! ============> Call api
    await _postRequest(
      endPoint: NetworkStrings.SEND_PASSWORD_ENDPOINT,
      context: GetxController.Get.context!,
    );

    //! ============> Get the login response
    _onSuccess = () {
      AppNavigation.navigatorPop(context);
      _loginResponseMethod(context: context);
    };

    //! ============> Validate the response
    _validateResponse();
  }

  //! ============> Post Request
  Future<void> _postRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().postRequest(
      endPoint: endPoint,
      formData: _formData,
      context: context,
      customFailure: true,
      onFailure: _onFailure,
      isHeaderRequire: false,
      isToast: true,
    );
  }

  //! ============> Validate Response
  void _validateResponse() {
    if (_response != null) {
      Network().validateResponse(
        isToast: false,
        response: _response,
        onSuccess: _onSuccess,
        onFailure: _onFailure,
      );
    }
  }

  //! ============> Creating a controller instance to save the user id temp for next verification otp api
  var authContorller = GetxController.Get.find<AuthController>();

  //! ============> Login Response
  void _loginResponseMethod(
      {required BuildContext context, String? userEmail}) async {
    try {
      _sendPasswordModel = SendPasswordModel.fromJson(_response?.data);
      if (_sendPasswordModel != null) {
        print(_sendPasswordModel?.message);
        // AppDialogs.showToast(message: _sendPasswordModel?.message);

        if (_sendPasswordModel?.message == 'Password reset OTP sent.') {
          AppDialogs.showToast(message: tr('otp_send_text'));

          AppNavigation.navigateTo(
              context, AppRouteName.VERIFY_OTP_SCREEN_ROUTE_RESET_PASSWORD,
              arguments: {userEmail});
        } else {
          AppDialogs.showToast(message: _sendPasswordModel?.message);
        }

        // authContorller.show_pinfield.value = true;
      }

      //! ============> Navigating the user from send email  to verfication otp screen
    } catch (error) {
      AppDialogs.showToast(message: tr(NetworkStrings.SOMETHING_WENT_WRONG));
    }
  }
}
