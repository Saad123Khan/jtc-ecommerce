import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as GetxController;
import 'package:jtc_ecommerce/auth/controllers/auth_controller.dart';
import 'package:jtc_ecommerce/auth/models/user_model.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/auth_singleton.dart';
import 'package:jtc_ecommerce/services/firebase_messaging_service.dart';
import 'package:jtc_ecommerce/services/local_storage.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/services/translate_service.dart';
import 'package:jtc_ecommerce/splash/controllers/splash_controller.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';
import 'package:jtc_ecommerce/utils/app_strings.dart';

class SocialLoginBloc {
  FormData? _formData;
  Response? _response;
  VoidCallback? _onSuccess, _onFailure;
  UserResponseModel? _loginResponse;
  UserData? _userData;
  String? deviceToken;

  void socialLoginBlocMethod({
    required BuildContext context,
    required VoidCallback setProgressBar,
    String? userEmail,
    String? firstName,
    String? lastName,
    String? provider,
    String? socialToken,
    String? phoneNumber,
    String? countryCode,
  }) async {
    setProgressBar();

    //! ============> Get the device token from firebaseservice class
    deviceToken = await FirebaseMessagingService().getToken();

    //! ============> Form Data
    _formData = FormData.fromMap({
      "access_token": socialToken,
      "provider": provider,
      "device_type": Platform.isIOS ? AppStrings.IOS : AppStrings.ANDROID,
      "device_token": deviceToken ?? '123',
      // "email": userEmail,
      "first_name": firstName,
      "last_name": lastName,
    });

    //! ============> Print Form Data
    print({
      "access_token": socialToken,
      "provider": provider,
      "device_type": Platform.isIOS ? AppStrings.IOS : AppStrings.ANDROID,
      "device_token": deviceToken ?? '123',
      // "email": userEmail,
      "first_name": firstName,
      "last_name": lastName,
    });

    //! ============> If Api fails then stop the loader
     _onFailure = () async {
      AppNavigation.navigatorPop(context);

      print("STATUSSS CODEE ${_response?.statusCode}");
      final message = _response?.data['message'] ?? "";

      switch (message) {
        case "The email has already been taken.":
          AppDialogs.showToast(message: tr(NetworkStrings.USER_NOT_FOUND));
          break;

        default:
          if (context.locale.languageCode != "en") {
            final _translatedMessage = await GoogleTranslatorService()
                .translate(text: message, context: context);
            AppDialogs.showToast(message: _translatedMessage);
          } else {
            AppDialogs.showToast(message: message);
          }
      }
    };
    //! ============> Call api
    await _postRequest(
      endPoint: NetworkStrings.SOCIAL_LOGIN_ENDPOINT,
      context: GetxController.Get.context!,
    );

    //! ============> Get the login response
    _onSuccess = () {
      AppNavigation.navigatorPop(context);
      _responseMethod(context: context, provider: provider, email: userEmail);
    };

    //! ============> Validate the response
    _validateResponse();
  }

  //! ============> Post Request
  Future<void> _postRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().postRequest(
      endPoint: endPoint,
      formData: _formData,
      context: context,
      onFailure: _onFailure,
      isHeaderRequire: false,
      isToast: true,
    );
  }

  //! ============> Validate Response
  void _validateResponse() {
    if (_response != null) {
      Network().validateResponse(
        isToast: false,
        response: _response,
        onSuccess: _onSuccess,
        onFailure: _onFailure,
      );
    }
  }

  //! ============> Creating a controller instance to save the user id temp for next verification otp api
  var authContorller = GetxController.Get.isRegistered()
      ? GetxController.Get.find<AuthController>()
      : GetxController.Get.put(AuthController());
  final AuthSingletonUserRole authSingletonUserRole = AuthSingletonUserRole();

  //! ============> Login Response
  void _responseMethod({
    required BuildContext context,
    String? provider,
    String? email,
  }) async {
    try {
      _loginResponse = UserResponseModel.fromJson(_response?.data);
      _userData = _loginResponse?.data;
      if (_loginResponse != null) {
        if (provider == AppStrings.GOOGLE_SOCIAL_TYPE) {
          // AppDialogs.showToast(message: "Logged in successfully");
          authContorller.authSingletonUserRole.userLoggedInUsingEmail =
              email ?? "";
          _handleBusinessUserRole(context, _loginResponse);
        } else if (provider == AppStrings.PHONE_SOCIAL_TYPE) {
          // AppDialogs.showToast(message: "OTP verified");
          _handleBusinessUserRole(context, _loginResponse);
        } else if (provider == AppStrings.APPLE_SOCIAL_TYPE) {
          // AppDialogs.showToast(message: "Logged in successfully");
          _handleBusinessUserRole(context, _loginResponse);
        }
      }
    } catch (error) {
      logData(message: "error: ${error}");
      AppDialogs.showToast(message: tr(NetworkStrings.SOMETHING_WENT_WRONG));
    }
  }

  //! ============> Handling method for Business Role
  void _handleBusinessUserRole(
      BuildContext context, UserResponseModel? userData) async {
    saveLoginResponseToSharedPrefs(_loginResponse);
    //! ============> if user profile is completed then go the nested if else
    if (_userData?.address == null || _userData?.address == "") {
      AppNavigation.navigateTo(
        context,
        AppRouteName.LOCATION_SCREEN_ROUTE,
      );
    } else {
      AppNavigation.navigateToRemovingAll(
          context, AppRouteName.BOTTOM_NAVIGATION_SCREEN_ROUTE);
    }
  }

  void saveLoginResponseToSharedPrefs(UserResponseModel? _loginResponse) {
    // Save Bearer Token
    SharedPreference().setBearerToken(
      token: _loginResponse?.token,
    );

    // Save User Data
    try {
      SharedPreference().setUser(
        user: jsonEncode(_loginResponse?.data),
      );
    } catch (e) {
      print('Error saving data to shared preferences: $e');
    }

    // Get Bearer Token and log it
    var token = SharedPreference().getBearerToken();
    logData(message: "token: $token");

    // Get the saved user from shared preferences
    var currentSavedUser = SharedPreference().getUser();

    // Check if currentSavedUser is not empty
    if (currentSavedUser != null) {
      // Decode the saved user response
      final jsonResponse = jsonDecode(currentSavedUser);

      // Convert the response into a User object
      final UserData? _currentUser = UserData.fromJson(jsonResponse);

      // Update the current user in SplashController
      GetxController.Get.find<SplashController>().currentUser.value =
          _currentUser;
    }
  }
}
