// import 'package:dio/dio.dart';
// import 'package:flutter/material.dart';
// import 'package:jtc_ecommerce/services/network.dart';
// import 'package:jtc_ecommerce/splash/controllers/splash_controller.dart';
// import 'package:jtc_ecommerce/utils/app_network_strings.dart';
// import 'package:get/get.dart' as GetxController;

// class LogoutBloc {
//   dynamic formData;
//   Response? _response;
//   VoidCallback? _onSuccess, _onFailure;
//   void logoutBlocMethod({
//     required BuildContext context,
//     required VoidCallback setProgressBar,
//     String? userid,
//   }) async {
//     setProgressBar();
//     formData = {
//       'user_id':
//           GetxController.Get.find<SplashController>().currentUser.value?.id,
//     };

//     _onFailure = () {
//       Navigator.pop(context);
//     };

//     await _postRequest(
//         endPoint: NetworkStrings.LOGOUT_ENDPOINT, context: context);

//     _onSuccess = () {
//       Navigator.pop(context);
//       _logoutResponseMethod(context: context);
//     };
//     _validateResponse();
//   }

//   ///----------------------------------- Post Request -----------------------------------
//   Future<void> _postRequest(
//       {required String endPoint, required BuildContext context}) async {
//     _response = await Network().postRequest(
//       endPoint: endPoint,
//       context: context,
//       formData: formData,
//       isToast: false,
//       onFailure: _onFailure,
//       isHeaderRequire: true,
//     );
//   }

//   ///----------------------------------- Validate Response -----------------------------------
//   void _validateResponse() {
//     if (_response != null) {
//       Network().validateResponse(
//           response: _response,
//           onSuccess: _onSuccess,
//           onFailure: _onFailure,
//           isToast: false);
//     }
//   }

//   void _logoutResponseMethod({required BuildContext context}) async {
//     try {
//       if (_response?.statusCode == NetworkStrings.SUCCESS_CODE) {
//         // StaticData.clearAppData();
//         // CustomToast.showToastMessage(
//         //     toastmsg: tr(AppStrings.logoutSuccessfully));
//       }
//     } catch (error) {
//       // CustomToast.showToastMessage(
//       //     toastmsg: tr(NetworkStrings.SOMETHING_WENT_WRONG));
//     }
//   }
// }
