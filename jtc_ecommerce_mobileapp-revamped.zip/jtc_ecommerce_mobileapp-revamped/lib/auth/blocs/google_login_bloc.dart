import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart' as GetxController;
import 'package:jtc_ecommerce/auth/controllers/auth_controller.dart';
import 'package:jtc_ecommerce/auth/models/user_model.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/local_storage.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/services/translate_service.dart';
import 'package:jtc_ecommerce/splash/controllers/splash_controller.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';

class GoogleLoginBloc {
  FormData? _formData;
  Response? _response;
  VoidCallback? _onSuccess, _onFailure;
  UserResponseModel? _loginResponse;
  UserData? _userData;
  String? deviceToken;

  void googleLoginBlocMethod({
    required BuildContext context,
    required VoidCallback setProgressBar,
    String? tokenId,
  }) async {
    setProgressBar();

    //! ============> Form Data
    _formData = FormData.fromMap({
      "token": tokenId,
    });

    //! ============> Print Form Data
    print({
      "token": tokenId,
    });

    //! ============> If Api fails then stop the loader
    _onFailure = () async {
      AppNavigation.navigatorPop(context);

      print("STATUSSS CODEE ${_response?.statusCode}");
      final message = _response?.data['message'] ?? "";

      switch (message) {
        case "The email has already been taken.":
          AppDialogs.showToast(message: tr(NetworkStrings.USER_NOT_FOUND));
          break;

        default:
          if (context.locale.languageCode != "en") {
            final _translatedMessage = await GoogleTranslatorService()
                .translate(text: message, context: context);
            AppDialogs.showToast(message: _translatedMessage);
          } else {
            AppDialogs.showToast(message: message);
          }
      }
    };

    //! ============> Call api
    await _postRequest(
      endPoint: NetworkStrings.SOCIAL_LOGIN_ENDPOINT,
      context: GetxController.Get.context!,
    );

    //! ============> Get the login response
    _onSuccess = () {
      AppNavigation.navigatorPop(context);
      _loginResponseMethod(context: context);
    };

    //! ============> Validate the response
    _validateResponse();
  }

  //! ============> Post Request
  Future<void> _postRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().postRequest(
      endPoint: endPoint,
      formData: _formData,
      context: context,
      onFailure: _onFailure,
      isHeaderRequire: false,
      customFailure: true,
      isToast: false,
    );
  }

  //! ============> Validate Response
  void _validateResponse() {
    if (_response != null) {
      Network().validateResponse(
        isToast: false,
        response: _response,
        onSuccess: _onSuccess,
        onFailure: _onFailure,
      );
    }
  }

  //! ============> Creating a controller instance to save the user id temp for next verification otp api
  var authContorller = GetxController.Get.find<AuthController>();

  //! ============> Login Response
  void _loginResponseMethod(
      {required BuildContext context, String? userEmail}) async {
    try {
      _loginResponse = UserResponseModel.fromJson(_response?.data);
      _userData = _loginResponse?.data;
      if (_loginResponse?.token != null) {
        //! ============> Save the bearer token in shared pref class
        SharedPreference().setBearerToken(
          token: _loginResponse?.token,
        );
      }
      var token = SharedPreference().getBearerToken();
      logData(message: "Saved Token: $token");
      if (_loginResponse != null) {
        authContorller.clearTextFieldsLogin();
        AppDialogs.showToast(
          message: _loginResponse?.message.toString(),
          toastLength: Toast.LENGTH_LONG,
          timeInSecForIosWeb: 5,
        );
        //! ============> Save User
        try {
          SharedPreference().setUser(
            user: jsonEncode(_loginResponse?.data),
          );
        } catch (e) {
          print('Error saving data to shared preferences: $e');
        }
        var currentSavedUser = SharedPreference().getUser();
        if (currentSavedUser != null) {
          final jsonResponse = jsonDecode(currentSavedUser);
          final UserData? _currentUser = UserData.fromJson(jsonResponse);
          GetxController.Get.find<SplashController>().currentUser.value =
              _currentUser;
        }
        logData(message: "Address: ${_userData?.address}");
        if (_userData?.address != "") {
          AppNavigation.navigateTo(
            context,
            AppRouteName.BOTTOM_NAVIGATION_SCREEN_ROUTE,
          );
        } else {
          AppNavigation.navigateTo(
            context,
            AppRouteName.LOCATION_SCREEN_ROUTE,
          );
        }
      }
    } catch (error) {
      AppDialogs.showToast(message: tr(NetworkStrings.SOMETHING_WENT_WRONG));
    }
  }
}
