import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as GetxController;
import 'package:get/get_core/src/get_main.dart';
import 'package:jtc_ecommerce/cart/controllers/cart_controller.dart';
import 'package:jtc_ecommerce/cart/models/add_to_cart_model.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';

class SendTokenToServerBloc {
  Map<String, dynamic>? _formDataMap;
  Response? _response;
  VoidCallback? _onSuccess, _onFailure;

  // AddToCartModel? _addToCartModel;

  void sendTokenToServerBlocMethod({
    // required BuildContext context,
    // required VoidCallback setProgressBar,
    String? device_token,
  }) async {
    // setProgressBar();

    //! ============> Form Data
    _formDataMap = {
      "device_token": device_token,
    };

    //! ============> Print Form Data
    print({
      "device_token": device_token,
    });

    //! ============> If Api fails then stop the loader
    _onFailure = () {
      // AppNavigation.navigatorPop(context);
    };

    //! ============> Call api
    await _postRequest(
      endPoint: NetworkStrings.SEND_TOKEN_TOSERVER,
      context: GetxController.Get.context!,
    );

    //! ============> Get the login response
    _onSuccess = () {
      // AppNavigation.navigatorPop(context);
      _loginResponseMethod(
        // context: context,
      );
    };

    //! ============> Validate the response
    _validateResponse();
  }

  //! ============> Post Request
  Future<void> _postRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().postRequestRawData(
      endPoint: endPoint,
      body: _formDataMap,
      onFailure: _onFailure,
      isHeaderRequire: true,
      context: context,
    );
  }

  //! ============> Validate Response
  void _validateResponse() {
    if (_response != null) {
      Network().validateResponse(
        isToast: false,
        response: _response,
        onSuccess: _onSuccess,
        onFailure: _onFailure,
      );
      logData(message: "Re: ${_response}");
    }
  }

  //! ============> Creating a controller instance to save the user id temp for next verification otp api
  // var authContorller = GetxController.Get.find<AuthController>();

  //! ============> Login Response
  void _loginResponseMethod() async {
    // try {
    // logData(message: "Response: ${_response?.data}");
    // _addToCartModel = AddToCartModel.fromJson(_response?.data);
    // AppDialogs.showToast(message: _addToCartModel?.message);
    // final CartController controller = Get.put(CartController());
    // controller.get_cart_list();
    // if (isFromDetailScreen) {
    //   AppNavigation.navigateToRemovingAll(
    //       context, AppRouteName.BOTTOM_NAVIGATION_SCREEN_ROUTE);
    // } else {
    //   return null;
    // }
    // } catch (error) {
    //   AppDialogs.showToast(message: tr(NetworkStrings.SOMETHING_WENT_WRONG));
    // }
  }
}
