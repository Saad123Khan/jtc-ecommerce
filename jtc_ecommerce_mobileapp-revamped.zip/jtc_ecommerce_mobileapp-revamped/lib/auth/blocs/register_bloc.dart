import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart' as GetxController;
import 'package:jtc_ecommerce/auth/controllers/auth_controller.dart';
import 'package:jtc_ecommerce/auth/models/user_model.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/firebase_messaging_service.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/services/translate_service.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';

class RegisterBloc {
  FormData? _formData;
  Response? _response;
  VoidCallback? _onSuccess, _onFailure;
  UserResponseModel? _loginResponse;
  UserData? _userData;
  String? deviceToken;

  void registerBlocMethod({
    required BuildContext context,
    required VoidCallback setProgressBar,
    String? first_name,
    String? last_name,
    String? email,
    String? full_phone_no,
    String? password,
    String? confirm_password,
    String? refer_code,
  }) async {
    setProgressBar();

    //! ============> Get the device token from firebaseservice class
    deviceToken = await FirebaseMessagingService().getToken();

    //! ============> Form Data
    _formData = FormData.fromMap({
      "first_name": first_name,
      "last_name": last_name,
      "email": email,
      "phone_no": "0${full_phone_no}",
      "password": password,
      "confirm_password": confirm_password,
      // "refer_code": referral ?? "",
      if (refer_code != null && refer_code.isNotEmpty) "refer_code": refer_code,
    });

    //! ============> Print Form Data
    print({
      "first_name": first_name,
      "last_name": last_name,
      "email": email,
      "phone_no": "0${full_phone_no}",
      "password": password,
      "confirm_password": confirm_password,
      // "refer_code": refer_code ?? "",
      if (refer_code != null && refer_code.isNotEmpty) "refer_code": refer_code,
    });

    //! ============> If Api fails then stop the loader
    _onFailure = () async {
      AppNavigation.navigatorPop(context);

      print("STATUSSS CODEE ${_response?.statusCode}");
      final message = _response?.data['message'] ?? "";

      switch (message) {
        case "The email has already been taken.":
          AppDialogs.showToast(message: tr("email_already_taken"));
          break;

        default:
          if (context.locale.languageCode != "en") {
            final _translatedMessage = await GoogleTranslatorService()
                .translate(text: message, context: context);
            AppDialogs.showToast(message: _translatedMessage);
          } else {
            AppDialogs.showToast(message: message);
          }
      }
    };
    //! ============> Call api
    await _postRequest(
      endPoint: NetworkStrings.REGISTER_ENDPOINT,
      context: GetxController.Get.context!,
    );

    //! ============> Get the login response
    _onSuccess = () {
      AppNavigation.navigatorPop(context);
      _loginResponseMethod(context: context);
    };

    //! ============> Validate the response
    _validateResponse();
  }

  //! ============> Post Request
  Future<void> _postRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().postRequest(
      endPoint: endPoint,
      customFailure: true,
      formData: _formData,
      context: context,
      onFailure: _onFailure,
      isHeaderRequire: false,
      isToast: true,
    );
  }

  //! ============> Validate Response
  void _validateResponse() {
    if (_response != null) {
      Network().validateResponse(
        isToast: false,
        response: _response,
        onSuccess: _onSuccess,
        onFailure: _onFailure,
      );
    }
  }

  //! ============> Creating a controller instance to save the user id temp for next verification otp api
  var authContorller = GetxController.Get.find<AuthController>();

  //! ============> Login Response
  void _loginResponseMethod({
    required BuildContext context,
  }) async {
    try {
      logData(message: "_rs: ${_response?.data}");
      _loginResponse = UserResponseModel.fromJson(_response?.data);
      _userData = _loginResponse?.data;
      authContorller.tempEmail = _userData?.email ?? "";
      logData(message: "_userData: ${_userData?.email}");
      if (_loginResponse != null) {
        print(_loginResponse?.message);

        // AppDialogs.showToast(
        //   message: _loginResponse?.message,
        //   toastLength: Toast.LENGTH_LONG,
        //   timeInSecForIosWeb: 5,
        // );

        if (_loginResponse?.message == 'User registered successfully') {
          AppDialogs.showToast(message: tr('registerd_text'));
        } else if (_loginResponse?.message ==
            'The email has already been taken.') {
          AppDialogs.showToast(message: tr('emaail_Already_registered'));
        } else {
          // AppDialogs.showToast(message: _loginResponse?.message);
          AppDialogs.showToast(
            message: _loginResponse?.message,
            toastLength: Toast.LENGTH_LONG,
            timeInSecForIosWeb: 5,
          );
        }

        //! ============> Navigating the user from login to verfication otp screen
        AppNavigation.navigateTo(
          context,
          AppRouteName.VERIFY_OTP_SCREEN_ROUTE,
        );
      }
    } catch (error) {
      AppDialogs.showToast(message: tr(NetworkStrings.SOMETHING_WENT_WRONG));
    }
  }
}
