import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart' as GetxController;
import 'package:jtc_ecommerce/auth/controllers/auth_controller.dart';
import 'package:jtc_ecommerce/auth/models/user_model.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/services/translate_service.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';

class VerifyOtpBloc {
  FormData? _formData;
  Response? _response;
  VoidCallback? _onSuccess, _onFailure;
  UserResponseModel? _loginResponse;
  UserData? _userData;
  String? deviceToken;

  void verifyOtpBlocMethod({
    required BuildContext context,
    required VoidCallback setProgressBar,
    String? userEmail,
    String? code,
  }) async {
    setProgressBar();

    //! ============> Form Data
    _formData = FormData.fromMap({
      "email": userEmail,
      "code": code,
      "type": 1, //Change 1 or 2
    });

    //! ============> Print Form Data
    print({
      "email": userEmail,
      "code": code,
      "type": 1, //Change 1 or 2
    });

    //! ============> If Api fails then stop the loader
   _onFailure = () async {
      AppNavigation.navigatorPop(context);

      print("STATUSSS CODEE ${_response?.statusCode}");
      final message = _response?.data['message'] ?? "";

      switch (message) {
        case "The email has already been taken.":
          AppDialogs.showToast(message: tr(NetworkStrings.USER_NOT_FOUND));
          break;

        default:
          if (context.locale.languageCode != "en") {
            final _translatedMessage = await GoogleTranslatorService()
                .translate(text: message, context: context);
            AppDialogs.showToast(message: _translatedMessage);
          } else {
            AppDialogs.showToast(message: message);
          }
      }
    };

    //! ============> Call api
    await _postRequest(
      endPoint: NetworkStrings.VERIFY_OTP_ENDPOINT,
      context: GetxController.Get.context!,
    );

    //! ============> Get the login response
    _onSuccess = () {
      AppNavigation.navigatorPop(context);
      _loginResponseMethod(context: context);
    };

    //! ============> Validate the response
    _validateResponse();
  }

  //! ============> Post Request
  Future<void> _postRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().postRequest(
      endPoint: endPoint,
      formData: _formData,
      context: context,
      onFailure: _onFailure,
      customFailure: true,
      isHeaderRequire: false,
      isToast: false,
    );
  }

  //! ============> Validate Response
  void _validateResponse() {
    if (_response != null) {
      Network().validateResponse(
        isToast: false,
        response: _response,
        onSuccess: _onSuccess,
        onFailure: _onFailure,
      );
    }
  }

  //! ============> Creating a controller instance to save the user id temp for next verification otp api
  var authContorller = GetxController.Get.find<AuthController>();

  //! ============> Login Response
  void _loginResponseMethod({required BuildContext context}) async {
    try {
      _loginResponse = UserResponseModel.fromJson(_response?.data);
      _userData = _loginResponse?.data;
      //! ============> Saving userid from login response temp in tempSaveuserId
      if (_loginResponse != null) {
       

        print(_loginResponse?.message);
        // AppDialogs.showToast(
        //   message: _loginResponse?.message.toString(),
        //   toastLength: Toast.LENGTH_LONG,
        //   timeInSecForIosWeb: 5,
        // );

        if (_loginResponse?.message == 'User Verified Successfully') {
          AppDialogs.showToast(message: tr('user_verified_text'));
        } else {
          // AppDialogs.showToast(message: _loginResponse?.message);
          AppDialogs.showToast(
            message: _loginResponse?.message.toString(),
            toastLength: Toast.LENGTH_LONG,
            timeInSecForIosWeb: 5,
          );
        }

        authContorller.when_user_verified.value = true;
        //! ============> Navigating the user from login to verfication otp screen
        AppDialogs.showBottomSheetttttt(
          context: context,
          onTap: () {
            AppNavigation.navigateToRemovingAll(
              context,
              AppRouteName.LOGIN_SCREEN_ROUTE,
            );
          },
        );
      }
    } catch (error) {
      AppDialogs.showToast(message: tr(NetworkStrings.SOMETHING_WENT_WRONG));
    }
  }
}
