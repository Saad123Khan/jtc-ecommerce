import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as GetxController;
import 'package:get/get_core/src/get_main.dart';
import 'package:jtc_ecommerce/cart/models/coupon_Code_model.dart';
import 'package:jtc_ecommerce/order_summary/controllers/order_summary_controller.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/services/translate_service.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';

class CouponCodeBloc {
  FormData? _formData;
  Response? _response;
  VoidCallback? _onSuccess, _onFailure;
  CouponCodeModel? _loginResponse;

  void couponCodeBlocMethod({
    required BuildContext context,
    required VoidCallback setProgressBar,
    String? couponCodeText,
  }) async {
    setProgressBar();

    _formData = FormData.fromMap({
      "promo_code": couponCodeText,
    });

    _onFailure = () async {
      // AppNavigation.navigatorPop(context);

      print("STATUSSS CODEE ${_response?.statusCode}");
      final message = _response?.data['message'] ?? "";

      Get.find<OrderSummaryController>().updateToken('');

      Get.find<OrderSummaryController>().promocode.clear();

      switch (message) {
        case "The email has already been taken.":
          AppDialogs.showToast(message: tr(NetworkStrings.USER_NOT_FOUND));
          break;

        default:
          if (context.locale.languageCode != "en" && message != "") {
            final _translatedMessage = await GoogleTranslatorService()
                .translate(text: message, context: context);
            AppDialogs.showToast(message: _translatedMessage);
          } else {
            if (message != "") {
              AppDialogs.showToast(message: message);
            }
          }
      }
    };

    await _postRequest(
      endPoint: NetworkStrings.COUPON_CODE_URL,
      context: GetxController.Get.context!,
    );
    AppNavigation.navigatorPop(context);

    _onSuccess = () {
      print("API call successful.");
      _loginResponseMethod(context: context);
    };

    _validateResponse();
  }

  Future<void> _postRequest({
    required String endPoint,
    required BuildContext context,
  }) async {
    _response = await Network().postRequest(
      endPoint: endPoint,
      formData: _formData,
      context: context,
      onFailure: _onFailure,
      customFailure: true,
      isHeaderRequire: true,
      isToast: true,
    );
    print("Response received: ${_response?.data}");
  }

  void _validateResponse() {
    if (_response != null) {
      if (_response?.statusCode == 200 && _response?.data['success'] == true) {
        _onSuccess?.call();
      } else {
        _onFailure?.call();
      }
    } else {
      _onFailure?.call();
    }
  }

  void _loginResponseMethod({
    required BuildContext context,
  }) async {
    try {
      _loginResponse = CouponCodeModel.fromJson(_response?.data);
      print("Login Response: ${_loginResponse?.message}");
      print("token : ${_loginResponse?.token}");

      // if (_loginResponse?.message == "Coupon applied successfully!") {
      //   AppDialogs.showToast(message: tr('coupon_code_Apply'));

      // }
      if (_response?.statusCode == 200) {
        AppDialogs.showToast(message: tr('coupon_code_Apply'));
      }

      Get.find<OrderSummaryController>()
          .updateToken(_loginResponse?.token.toString() ?? '');

      // Get.find<OrderSummaryController>()

      // else {
      //   AppDialogs.showToast(message: _loginResponse?.message);
      // }
    } catch (error) {
      print("Error in _loginResponseMethod: $error");
      AppDialogs.showToast(message: tr(NetworkStrings.SOMETHING_WENT_WRONG));
    }
  }
}
