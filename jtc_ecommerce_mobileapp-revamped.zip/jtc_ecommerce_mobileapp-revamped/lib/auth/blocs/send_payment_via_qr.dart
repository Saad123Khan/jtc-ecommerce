import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as GetxController;
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/services/translate_service.dart';
import 'package:jtc_ecommerce/splash/controllers/splash_controller.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';

class QRPaymentBloc {
  dynamic _formData;
  Response? _response;
  VoidCallback? _onSuccess, _onFailure;
  String? deviceToken;

  void qrPayment({
    required BuildContext context,
    required VoidCallback setProgressBar,
    required String amount,
    required String privateKey,
    Function()? onSucces,
  }) async {
    setProgressBar();

    //! ============> Form Data
    _formData = {
      "amount": amount,
      "privateKey": privateKey,
      "userId": GetxController.Get.find<SplashController>()
          .currentUser
          .value
          ?.walletId
    };

    // ! ============> If Api fails then stop the loader
    _onFailure = () async {
      AppNavigation.navigatorPop(context);
      AppNavigation.navigatorPop(context);

      print("STATUSSS CODEE ${_response?.statusCode}");
      final message = _response?.data['message'] ?? "";

      print(message);

      switch (message) {
        case "Something went wrong":
          AppDialogs.showToast(
              message: tr(NetworkStrings.INVALID_EMAIL_OR_PASSWORD));
          break;

        default:
          if (context.locale.languageCode != "en") {
            final _translatedMessage = await GoogleTranslatorService()
                .translate(text: message, context: context);
            AppDialogs.showToast(message: _translatedMessage);
          } else {
            AppDialogs.showToast(message: message);
          }
      }
    };

    //! ============> Call api
    await _postRequest(
      endPoint: NetworkStrings.QR_SCAN_ENDPOINT,
      context: GetxController.Get.context!,
    );

    //! ============> Get the login response
    _onSuccess = () {
      AppNavigation.navigatorPop(context);
      // AppNavigation.navigatorPop(context);
      _loginResponseMethod(context: context, onSucces: onSucces);
    };  

    //! ============> Validate the response
    _validateResponse();
  }

  //! ============> Post Request
  Future<void> _postRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().postRequest(
        endPoint: endPoint,
        formData: _formData,
        context: context,
        customFailure: true,
        onFailure: _onFailure,
        isHeaderRequire: true,
        isToast: false,
        isErrorToast: false);
  }

  //! ============> Validate Response
  void _validateResponse() {
    if (_response != null) {
      Network().validateResponse(
        isToast: false,
        response: _response,
        onSuccess: _onSuccess,
        onFailure: _onFailure,
      );
    }
  }

  //! ============> Login Response
  void _loginResponseMethod({required BuildContext context,     Function()? onSucces}) async {
    try {

      
      final message = _response?.data['message'] ?? "";
      if (context.locale.languageCode != "en") {
        final _translatedMessage = await GoogleTranslatorService()
            .translate(text: message, context: context);
        AppDialogs.showToast(message: _translatedMessage);
      } else {
        AppDialogs.showToast(message: message);
      }

      AppNavigation.navigatorPop(context);

      print("success");

      // onSucces?.call();
    } catch (error) {
      AppDialogs.showToast(message: tr(NetworkStrings.SOMETHING_WENT_WRONG));
    }
  }
}
