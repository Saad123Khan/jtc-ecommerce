import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/auth/controllers/auth_controller.dart';
import 'package:jtc_ecommerce/widgets/custom_button.dart';
import 'package:jtc_ecommerce/widgets/custom_pin_code.dart';
import 'package:jtc_ecommerce/widgets/custom_scaffold.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/widgets/custom_text_field.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_fonts.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';
import 'package:jtc_ecommerce/utils/constants.dart';
import 'package:jtc_ecommerce/utils/field_validator.dart';

class ResetPasswordScreen extends StatelessWidget {
  const ResetPasswordScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Get.put(AuthController());
    return CustomScaffold(
      appBarTitle: tr("Reset Password"),
      onTap: () => null,
      isAuthScreen: true,
      child: GetBuilder<AuthController>(builder: (authController) {
        return Scaffold(
            body: Form(
          key: authController.resetPasswordFormKey,
          child: SingleChildScrollView(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        tr('reset_password_screen.email_address'),
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.grey, 
                        ),
                      ),
                      10.verticalSpace,
                      CustomTextField(
                        hintText: tr('reset_password_screen.email_hint'),
                        textEditingController:
                            authController.reset_password_email,
                        prefixIcon: AssetPaths.EMAIL_ICON,
                        validator: (value) => value?.validateEmail,
                        keyboardType: TextInputType.emailAddress,
                        textInputFormattors: [
                          LengthLimitingTextInputFormatter(
                            Constants.EMAIL_MAX_LENGTH,
                          )
                        ],
                      ),
                      25.verticalSpace,
                      authController.show_pinfield.value
                          ? pinField(context: context)
                          : SizedBox.shrink(),
                      40.verticalSpace,
                      CustomButton(
                        buttonColor: AppColors.PRIMARY_COLOR,
                        onTap: () {
                          if (authController
                              .resetPasswordFormKey.currentState!
                              .validate()) {
                            authController.sendPasswordMethod(
                                context: context);
                            authController.reset_password_email.clear();
                          }
                        },
                        buttonText: tr('reset_password_screen.send_password'),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ));
      }),
    );
  }

  Widget pinField({required BuildContext context}) {
    return CustomPinCodeField(
      onChanged: (value) {
        print(value);
      },
      onCompleted: (v) {
        FocusManager.instance.primaryFocus?.unfocus();
      },
    );
  }

  Widget logo_and_heading() {
    return Container(
      width: double.infinity,
      height: 280.h,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(
            'assets/images/logo.png',
          ),
          6.verticalSpace,
          CustomText(
            text: tr('reset_password_screen.reset_password'),
            // fontFamily: AppFonts.robotoMedium,
          ),
          5.verticalSpace,
          SizedBox(
            width: 250.w,
            child: CustomText(
              text: tr('reset_password_screen.reset_password_description'),
              // fontFamily: AppFonts.robotoligth,
              maxLines: 2,
              fontsize: 16.sp,
            ),
          ),
        ],
      ),
    );
  }
}
