import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/auth/controllers/auth_controller.dart';
import 'package:jtc_ecommerce/widgets/custom_button.dart';
import 'package:jtc_ecommerce/widgets/custom_pin_code.dart';
import 'package:jtc_ecommerce/widgets/custom_scaffold.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_fonts.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';
import 'package:jtc_ecommerce/utils/enums.dart';

class VerifyOtpScreenResetPassword extends GetView<AuthController> {
  const VerifyOtpScreenResetPassword({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      appBarTitle: tr("Email Verification"),
      onTap: () => null,
      isAuthScreen: true,
      child: SingleChildScrollView(
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomText(
                  text: controller.authSingletonUserRole.switchValue ==
                          SwitchValue.email
                      ? controller.reset_password_email.text.isNotEmpty
                          ? controller.reset_password_email.text
                          : ''
                      : controller.number_login.text.isNotEmpty
                          ? "+${controller.number_login.text}"
                          : '',
                  color: AppColors.BLACK_COLOR,
                  fontsize: 18.sp,
                ),
              ],
            ),
            20.verticalSpace,
            Padding(
              padding: const EdgeInsets.all(0.0),
              child: pinField(context: context),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  tr('verifyotp.did_not_receive_code'),
                  style: TextStyle(fontSize: 16),
                ),
                const SizedBox(width: 4),
                InkWell(
                  onTap: () {
                    controller.clearTextFieldsOtpVerify();
                    controller.resendOtpNotValidMethod(context: context);
                  },
                  child: Text(
                    tr('verifyotp.resend'),
                    style: TextStyle(
                      color: Color(0xFFE0201C),
                      fontSize: 16,
                      fontFamily: 'Montserrat',
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget pinField({required BuildContext context}) {
    return CustomPinCodeField(
      controller: controller.pin_controller,
      onChanged: (value) {
        print(value);
      },
      onCompleted: (v) {
        FocusManager.instance.primaryFocus?.unfocus();
        logData(message: "v: $v");
        controller.pin_controller.text = v;
        controller.verifyOtpMethodReset(
          context: context,
          resetemailpass: controller.reset_password_email.text,
          pin_code: controller.pin_controller.text,
        );
      },
    );
  }
}
