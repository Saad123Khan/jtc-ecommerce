import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/auth/controllers/auth_controller.dart';
import 'package:jtc_ecommerce/widgets/custom_stack_loading.dart';
import 'package:jtc_ecommerce/widgets/custom_button.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:google_maps_webservice/places.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';
import 'package:jtc_ecommerce/utils/constants.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:easy_localization/easy_localization.dart';

class LocationScreen extends GetView<AuthController> {
  const LocationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Obx(
        () => StackCirularLoaderWidget(
          isLoading: controller.isLoading.value,
          childWidget: Padding(
            padding: const EdgeInsets.all(15.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                20.verticalSpace,
                Align(
                  alignment: Alignment.centerRight,
                  child: GestureDetector(
                    onTap: () {
                      AppNavigation.navigateToRemovingAll(
                          context, AppRouteName.BOTTOM_NAVIGATION_SCREEN_ROUTE);
                    },
                    child: Container(
                      alignment: Alignment.centerRight,
                      margin: EdgeInsets.all(8),
                      padding: EdgeInsets.all(8),
                      width: 70.w,
                      decoration: BoxDecoration(
                          color: Colors.grey[200],
                          borderRadius: BorderRadius.circular(10)),
                      child: CustomText(
                        text: tr('locatonscreen.skip'),
                        fontsize: 16.sp,
                        color: AppColors.BLACK_COLOR,
                        isLeftAlign: false,
                      ),
                    ),
                  ),
                ),
                Spacer(),
                Image.asset('assets/images/Frame.png'),
                30.verticalSpace,
                CustomText(
                  text: tr('locatonscreen.explore_more_stores_based'),
                  color: AppColors.BLACK_COLOR,
                  fontsize: 18.sp,
                ),
                CustomText(
                  text: tr('locatonscreen.on_your_current_location'),
                  color: AppColors.BLACK_COLOR,
                  fontsize: 18.sp,
                ),
                Spacer(),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 40),
                  child: CustomButton(
                    buttonColor: AppColors.PRIMARY_COLOR,
                    onTap: () {
                      controller.getLocation(context: context);
                    },
                    buttonText: tr('locatonscreen.user_current_location'),
                    fontSize: 16.sp,
                  ),
                ),
                30.verticalSpace,
                GestureDetector(
                  onTap: () {
                    AppNavigation.navigateTo(
                      context,
                      AppRouteName.LOCATION_SCREEN_Neareast_ROUTE,
                    );
                  },
                  child: CustomText(
                    text: tr('locatonscreen.enter_manually'),
                    color: AppColors.BLACK_COLOR,
                    fontsize: 16.sp,
                  ),
                ),
                Spacer(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget user_address() {
    return TextField(
      // controller: controller.user_address,
      // readOnly: !_isEditing,
      controller: controller.user_address.value,
      readOnly: true,
      onTap: () async {
        final Prediction? prediction =
            await Constants.addressPicker(Get.context!);
        logData(message: "prediction: ${prediction}");
        if (prediction != null) {
          logData(message: "prediction: ${prediction}");
          controller.user_address.value.text =
              prediction.description.toString();
          logData(message: "message: ${controller.user_address.value.text}");
          // controller.getLatLongFromAddress(controller.address.value.text);
        }
      },
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.grey[200],
        enabledBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Color(0xF3F3F3), width: 0),
          borderRadius: BorderRadius.circular(6.0),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Color(0xF3F3F3), width: 1.5),
          borderRadius: BorderRadius.circular(6.0),
        ),
        isDense: true,
        contentPadding: const EdgeInsets.all(18.0),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(6.0),
        ),
        hintStyle: TextStyle(color: Colors.red),
        prefixIcon: const Padding(
          padding: EdgeInsets.all(8.0),
          child: Icon(
            Icons.location_pin,
            size: 20,
            color: Colors.black,
          ),
        ),
        suffixIcon: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.only(right: 8.0),
              child: GestureDetector(
                onTap: () {},
                child: Text(
                  // 'Edit',
                  tr('locatonscreen.edit'),
                  style: TextStyle(
                    color: Color(0xFFE0201C),
                    fontSize: 14,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w500,
                    decoration: TextDecoration.underline,
                    height: 0,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
