import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:jtc_ecommerce/auth/controllers/auth_controller.dart';
import 'package:jtc_ecommerce/widgets/custom_button.dart';
import 'package:jtc_ecommerce/widgets/custom_scaffold.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/widgets/custom_text_field.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_fonts.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_strings.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';
import 'package:jtc_ecommerce/utils/constants.dart';
import 'package:jtc_ecommerce/utils/field_validator.dart';

class RegisterScreen extends GetView<AuthController> {
  const RegisterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      appBarTitle: "Signup",
      onTap: () => null,
      isAuthScreen: true,
      child: GetBuilder<AuthController>(
        builder: (authController) {
          return Form(
            key: authController.registerFormKey,
            child: ListView(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  child: Text(
                    tr('Registration.name'),
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.grey,
                    ),
                  ),
                ),
                3.verticalSpace,

                ///Name Textfield
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  child: CustomTextField(
                    hintText: tr('Registration.enter_your_name'),
                    prefixIcon: AssetPaths.FNAME_ICON,
                    textEditingController: authController.firstName,
                    validator: (value) =>
                        value?.validateEmpty(tr('Registration.name')),
                    keyboardType: TextInputType.name,
                    textInputFormattors: [
                      LengthLimitingTextInputFormatter(
                        Constants.NAME_MAX_LENGTH,
                      )
                    ],
                  ),
                ),
                20.verticalSpace,

                /// Last Name
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  child: Text(
                    tr('Registration.last_name'),
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.grey,
                    ),
                  ),
                ),
                3.verticalSpace,
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  child: CustomTextField(
                    hintText: tr('Registration.enter_your_last_name'),
                    prefixIcon: AssetPaths.FNAME_ICON,
                    textEditingController: authController.lastName,
                    validator: (value) => value?.validateEmpty(
                      tr('Registration.last_name'),
                    ),
                    keyboardType: TextInputType.name,
                    textInputFormattors: [
                      LengthLimitingTextInputFormatter(
                        Constants.NAME_MAX_LENGTH,
                      )
                    ],
                  ),
                ),
                20.verticalSpace,

                /// Email
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  child: Text(
                    tr('Registration.email'),
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.grey,
                    ),
                  ),
                ),
                3.verticalSpace,
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  child: CustomTextField(
                    hintText: tr('Registration.enter_your_email'),
                    prefixIcon: AssetPaths.EMAIL_ICON,
                    textEditingController: authController.email_login,
                    validator: (value) => value?.validateEmail,
                    keyboardType: TextInputType.emailAddress,
                    textInputFormattors: [
                      LengthLimitingTextInputFormatter(
                        Constants.EMAIL_MAX_LENGTH,
                      )
                    ],
                  ),
                ),

                /// Phone Number textfield
                30.verticalSpace,
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  child: Text(
                    tr('Registration.phone_number'),
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.grey,
                    ),
                  ),
                ),
                3.verticalSpace,

                // ///Country COde Picker
                // Padding(
                //   padding: const EdgeInsets.symmetric(horizontal: 15),
                //   child: IntlPhoneField(
                //     autovalidateMode: AutovalidateMode.always,
                //     controller: controller.phoneNo,
                //     onCountryChanged: (value) {
                //       controller.countryCode.value = value.dialCode.toString();
                //     },
                //     decoration: InputDecoration(
                //       filled: true,
                //       fillColor: Colors.grey[200],
                //       // errorText: "asdasd",
                //       focusedErrorBorder: OutlineInputBorder(
                //         borderSide: const BorderSide(
                //             color: AppColors.RED_GMAIL_COLOR, width: 0),
                //         borderRadius: BorderRadius.circular(6.0),
                //       ),
                //       enabledBorder: OutlineInputBorder(
                //         borderSide:
                //             const BorderSide(color: Color(0xF3F3F3), width: 0),
                //         borderRadius: BorderRadius.circular(6.0),
                //       ),
                //       focusedBorder: OutlineInputBorder(
                //         borderSide: const BorderSide(
                //             color: Color(0xF3F3F3), width: 1.5),
                //         borderRadius: BorderRadius.circular(6.0),
                //       ),
                //       isDense: true,
                //       contentPadding: const EdgeInsets.all(18.0),
                //       border: OutlineInputBorder(
                //         borderRadius: BorderRadius.circular(6.0),
                //       ),
                //       hintText: 'Phone Number',
                //       hintStyle: TextStyle(color: Colors.grey[500]),
                //     ),
                //     initialCountryCode: 'PK',
                //     validator: (value) =>
                //         value?.completeNumber.validatePhoneNumber,
                //     onChanged: (phone) {
                //       print(phone.completeNumber);
                //     },
                //   ),
                // ),

                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  child: IntlPhoneField(
                    autovalidateMode: AutovalidateMode
                        .onUserInteraction, // Change to onUserInteraction
                    controller: controller.phoneNo,
                    onCountryChanged: (value) {
                      controller.countryCode.value = value.dialCode.toString();
                    },
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.grey[200],
                      focusedErrorBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.RED_GMAIL_COLOR, width: 0),
                        borderRadius: BorderRadius.circular(6.0),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide:
                            const BorderSide(color: Color(0xF3F3F3), width: 0),
                        borderRadius: BorderRadius.circular(6.0),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: Color(0xF3F3F3), width: 1.5),
                        borderRadius: BorderRadius.circular(6.0),
                      ),
                      isDense: true,
                      contentPadding: const EdgeInsets.all(18.0),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(6.0),
                      ),
                      hintText: tr('Registration.phone_number'),
                      hintStyle: TextStyle(color: Colors.grey[500]),
                    ),
                    initialCountryCode: 'PK',
                    validator: (value) {
                      if (value == null) {
                        return tr('validators.phoneNumber.emptyPhoneNumber');
                      }
                      return value.completeNumber.validatePhoneNumber;
                    },
                    onChanged: (phone) {
                      print(phone.completeNumber);
                    },
                  ),
                ),
                // Password textfield
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  child: Text(
                    tr('Registration.password'),
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.grey,
                    ),
                  ),
                ),
                3.verticalSpace,
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  child: Obx(
                    () => CustomTextField(
                      hintText: tr('Registration.password'),
                      isObsCure: controller.show_password_register.value,
                      prefixIcon: AssetPaths.PASSWORD_ICON,
                      textEditingController: authController.password,
                      validator: (value) => value?.validateNewPassword,
                      isLogin: true,
                      onIconTap: () {
                        controller.show_password_register.value =
                            !controller.show_password_register.value;
                      },
                    ),
                  ),
                ),
                //Confirm Password textfield
                15.verticalSpace,
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  child: Text(
                    tr('Registration.confirm_password'),
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.grey,
                    ),
                  ),
                ),
                3.verticalSpace,
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  child: Obx(
                    () => CustomTextField(
                      hintText: tr('Registration.confirm_password'),
                      isObsCure:
                          controller.show_confirm_password_register.value,
                      prefixIcon: AssetPaths.PASSWORD_ICON,
                      textEditingController: authController.confrim_password,
                      validator: (value) => value?.validateChangeNewPassword(
                        authController.password.text,
                        authController.confrim_password.text,
                      ),
                      isLogin: true,
                      onIconTap: () {
                        controller.show_confirm_password_register.value =
                            !controller.show_confirm_password_register.value;
                      },
                    ),
                  ),
                ),
                //Refferal
                15.verticalSpace,
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  child: Text(
                    tr('Registration.referral_code'),
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.grey,
                    ),
                  ),
                ),
                3.verticalSpace,
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  child: CustomTextField(
                    hintText: tr('Registration.referral_code'),
                    prefixIcon: AssetPaths.FNAME_ICON,
                    textEditingController: authController.referral_code,
                    // validator: (value) => value?.validateChangeNewPassword(
                    //   authController.password.text,
                    //   authController.confrim_password.text,
                    // ),
                  ),
                ),
                20.verticalSpace,
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      tr('Registration.already_have_account'),
                      style: TextStyle(
                        fontSize: 16,
                      ),
                    ),
                    5.horizontalSpace,
                    InkWell(
                      onTap: () {
                        controller.clearTextFieldsRegister();
                        AppNavigation.navigatorPop(context);
                      },
                      child: Text(
                        tr('Registration.login'),
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.red,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
                30.verticalSpace,
                Obx(
                  () => controller.isLoading.value
                      ? const Center(
                          child: CircularProgressIndicator(),
                        )
                      : Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 15),
                          child: CustomButton(
                            buttonColor: AppColors.PRIMARY_COLOR,
                            buttonText: tr('Registration.sign_up'),
                            onTap: () {
                              FocusManager.instance.primaryFocus?.unfocus();
                              if (controller.registerFormKey.currentState!
                                  .validate()) {
                                // controller.tempEmail = authController.email_login.text;
                                controller.registerMethod(context: context);
                              }
                            },
                          ),
                        ),
                ),

                50.verticalSpace,
              ],
            ),
          );
        },
      ),
      // floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      // floatingActionButton: Obx(
      //   () => controller.isLoading.value
      //       ? const Center(
      //           child: CircularProgressIndicator(),
      //         )
      //       : Padding(
      //           padding: const EdgeInsets.symmetric(horizontal: 15),
      //           child: CustomButton(
      //             buttonColor: AppColors.PRIMARY_COLOR,
      //             buttonText: tr('Registration.sign_up'),
      //             onTap: () {
      //               FocusManager.instance.primaryFocus?.unfocus();
      //               if (controller.registerFormKey.currentState!.validate()) {
      //                 controller.registerMethod(context: context);
      //               }
      //             },
      //           ),
      //         ),
      // ),
    );
  }
}
