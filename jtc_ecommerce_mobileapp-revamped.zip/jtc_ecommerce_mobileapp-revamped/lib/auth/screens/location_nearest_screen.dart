import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:jtc_ecommerce/auth/controllers/auth_controller.dart';
import 'package:jtc_ecommerce/widgets/custom_stack_loading.dart';
import 'package:jtc_ecommerce/widgets/custom_button.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/constants.dart';

class LocationNearestScreen extends GetView<AuthController> {
  LocationNearestScreen({super.key});
  GlobalKey<FormState> formKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Obx(
        () => StackCirularLoaderWidget(
          isLoading: controller.isLoading.value,
          childWidget: Container(
            height: 1.sh,
            child: Padding(
              padding: const EdgeInsets.all(15.0),
              child: Form(
                key: formKey,
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        height: .15.sh,
                      ),
                      // 100.verticalSpace,
                      // Align(
                      //   alignment: Alignment.centerRight,
                      //   child: Container(
                      //     alignment: Alignment.centerRight,
                      //     margin: EdgeInsets.all(8),
                      //     padding: EdgeInsets.all(8),
                      //     width: 70.w,
                      //     decoration: BoxDecoration(
                      //         color: Colors.grey[200],
                      //         borderRadius: BorderRadius.circular(10)),
                      //     child: CustomText(
                      //       text: 'Skip',
                      //       fontsize: 16.sp,
                      //       color: AppColors.BLACK_COLOR,
                      //       isLeftAlign: false,
                      //     ),
                      //   ),
                      // ),
                      // Spacer(),
                      Image.asset('assets/images/Frame.png'),
                      30.verticalSpace,
                      CustomText(
                        text:
                            //  'Explore more stores based',
                            tr('locatonscreen.explore_more_stores_based'),
                        color: AppColors.BLACK_COLOR,
                        fontsize: 18.sp,
                      ),
                      CustomText(
                        text:
                            // 'on your current location',
                            tr('locatonscreen.on_your_current_location'),
                        color: AppColors.BLACK_COLOR,
                        fontsize: 18.sp,
                      ),
                      // Spacer(),
//
                      // Padding(
                      //   padding: EdgeInsets.only(left: 40.0.w, right: 40.0.w),
                      //   child: CustomTextField(
                      //     // validator: (p0) /,
                      //     hintText:

                      //         // "Nearest Address",
                      //         tr('profilesreen.nearest_address'),
                      //     textEditingController: controller.nearest_address,
                      //     prefixIcon: AssetPaths.NEAREASTADDRESS_ICON,
                      //     // prefixIcon: AssetPaths.EMAIL_ICON,
                      //     // validator: (value) => value?.validateEmail,
                      //     keyboardType: TextInputType.text,
                      //     // textInputFormattors: [
                      //     //   LengthLimitingTextInputFormatter(
                      //     //     Constants.EMAIL_MAX_LENGTH,
                      //     //   )
                      //     // ],
                      //   ),
                      // ),
                      15.verticalSpace,
                      Padding(
                        padding: EdgeInsets.only(left: 40.0.w, right: 40.0.w),
                        child: user_address(context),
                      ),
                      20.verticalSpace,

                      // GestureDetector(
                      //   onTap: () {
                      //     controller.getLocationAndUpdateProfile(
                      //       context: context,
                      //       address: controller.user_address.value.text,
                      //     );
                      //   },
                      //   child: CustomText(
                      //     text: 'Enter Manually',
                      //     color: AppColors.BLACK_COLOR,
                      //     fontsize: 16.sp,
                      //   ),
                      // ),

                      Padding(
                        padding: EdgeInsets.only(left: 40.0.w, right: 40.0.w),
                        child: CustomButton(
                          buttonColor: AppColors.PRIMARY_COLOR,
                          onTap: () {
                            if (formKey.currentState!.validate()) {
                              formKey.currentState?.save();
                              controller.getLocationAndUpdateProfile(
                                  context: context,
                                  address: controller.user_address.value.text,
                                  latLng: latLng);
                            }
                          },
                          buttonText:
                              //  'Enter Manually',

                              tr('locatonscreen.enter_manually'),
                          fontSize: 16.sp,
                        ),
                      ),

                      // Spacer(),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  LatLng? latLng;

  Widget user_address(BuildContext context) {
    return TextFormField(
      // controller: controller.user_address,
      // readOnly: !_isEditing,
      controller: controller.user_address.value,
      validator: (value) {
        if (value!.isEmpty) {
          return
              // 'Please enter your address';
              tr('profilesreen.address_text');
        }
        return null;
      },
      readOnly: true,

      onTap: () async {
        // final Prediction? prediction =
        //     await Constants.addressPicker(Get.context!);
        // logData(message: "prediction: ${prediction}");
        // if (prediction != null) {
        //   logData(message: "prediction: ${prediction}");
        //   controller.user_address.value.text =
        //       prediction.description.toString();
        //       // latLng = LatLng(prediction.)
        //   logData(message: "message: ${controller.user_address.value.text}");
        //   // controller.getLatLongFromAddress(controller.address.value.text);
        // }

        final result = await Constants.showPlacePicker(context);

        if (result != null) {
          controller.user_address.value.text = result.formattedAddress ?? "";
          latLng = result.latLng;
        }
      },
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.grey[200],
        enabledBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Color(0xF3F3F3), width: 0),
          borderRadius: BorderRadius.circular(6.0),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Color(0xF3F3F3), width: 1.5),
          borderRadius: BorderRadius.circular(6.0),
        ),
        isDense: true,
        contentPadding: const EdgeInsets.all(18.0),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(6.0),
        ),
        hintStyle: TextStyle(color: Colors.red),
        prefixIcon: const Padding(
          padding: EdgeInsets.all(8.0),
          child: Icon(
            Icons.location_pin,
            size: 20,
            color: Colors.black,
          ),
        ),
        suffixIcon: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.only(right: 8.0),
              child: GestureDetector(
                onTap: () {},
                child: Text(
                  // 'Edit',
                  tr('profilesreen.edit_text'),
                  style: TextStyle(
                    color: Color(0xFFE0201C),
                    fontSize: 14,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w500,
                    decoration: TextDecoration.underline,
                    height: 0,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
