import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/auth/controllers/auth_controller.dart';
import 'package:jtc_ecommerce/widgets/custom_button.dart';
import 'package:jtc_ecommerce/widgets/custom_pin_code.dart';
import 'package:jtc_ecommerce/widgets/custom_scaffold.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_fonts.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';
import 'package:jtc_ecommerce/utils/enums.dart';

class VerifyOtpScreen extends GetView<AuthController> {
  const VerifyOtpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      appBarTitle: "2 Step Verification",
      onTap: () => null,
      isAuthScreen: true,
      child: SingleChildScrollView(
        child: Column(
          children: [
            // Container(
            //   width: double.infinity,
            //   decoration: BoxDecoration(
            //     image: DecorationImage(
            //       image: AssetImage("assets/images/loginbackground_image.png"),
            //       fit: BoxFit.cover,
            //     ),
            //   ),
            //   child: Column(
            //     children: [
            //       const SizedBox(
            //         height: 73,
            //       ),
            //       Center(
            //         child: Image.asset('assets/images/logo.png'),
            //       ),
            //       100.verticalSpace,
            //       controller.authSingletonUserRole.switchValue ==
            //               SwitchValue.email
            //           ? CustomText(
            //               text: tr('verifyotp.email_verification'),
            //               //  tr('email_verification'),
            //               // fontFamily: AppFonts.robotoBold,
            //             )
            //           : CustomText(
            //               text: tr('verifyotp.phone_verification'),
            //               // text: 'phone_verification'.tr(),
            //               // fontFamily: AppFonts.robotoBold,
            //             ),
            //       3.verticalSpace,
            //       controller.authSingletonUserRole.switchValue ==
            //               SwitchValue.email
            //           ? CustomText(
            //               // text: 'sent_code_email'.tr(),
            //               text: tr('verifyotp.sent_code_email') +
            //                   AuthController.i.tempEmail,
            //               maxLines: 3,
            //               fontFamily: AppFonts.defaultFont,
            //               fontsize: 18.sp,
            //             )
            //           : CustomText(
            //               // text: 'sent_code_phone'.tr(),
            //               text: tr('verifyotp.sent_code_phones'),
            //               fontFamily: AppFonts.defaultFont,
            //               fontsize: 18.sp,
            //             ),
            //       10.verticalSpace,
            //     ],
            //   ),
            // ),
            10.verticalSpace,
            // Row(
            //   mainAxisAlignment: MainAxisAlignment.center,
            //   children: [
            //     controller.authSingletonUserRole.switchValue ==
            //             SwitchValue.email
            //         ? CustomText(
            //             text: controller.email_login.text.isNotEmpty
            //                 ? controller.email_login.text
            //                 : 'dfd',
            //             color: AppColors.BLACK_COLOR,
            //             fontsize: 18.sp,
            //           )
            //         : CustomText(
            //             text: controller.number_login.text.isNotEmpty
            //                 ? "+${controller.number_login.text}"
            //                 : '',
            //             color: AppColors.BLACK_COLOR,
            //             fontsize: 18.sp,
            //           ),
            //   ],
            // ),
            50.verticalSpace,
            Text("Email Verification Code", style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.bold),),
            20.verticalSpace,
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5),
              child: pinField(context: context),
            ),
            20.verticalSpace,
            Obx(() {
              return Text(
                "00:" + '${controller.remainingTime.value} secs',
                style: TextStyle(fontSize: 16),
              );
            }),
            20.verticalSpace,

            //Resend
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  // "did_not_receive_code".tr(),
                  tr('verifyotp.did_not_receive_code'),
                  style: TextStyle(
                    fontSize: 16,
                  ),
                ),
                const SizedBox(
                  width: 4,
                ),
                InkWell(
                  onTap: () {
                    controller.resendOtpMethod(context: context);
                  },
                  child: Text(
                    // 'resend'.tr(),
                    tr('verifyotp.resend'),
                    style: TextStyle(
                      color: Color(0xFFE0201C),
                      fontSize: 16,
                      fontFamily: 'Montserrat',
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
            80.verticalSpace,
            Obx(
              () => controller.when_user_verified.value
                  ? Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 15),
                      child: CustomButton(
                        buttonColor: AppColors.PRIMARY_COLOR, 
                        buttonText:
                            // 'continue'.tr(), 
                            tr('verifyotp.continue'),
                        onTap: () {
                          AppDialogs.showBottomSheetttttt( 
                            context: context,
                            onTap: () {
                              AppNavigation.navigateToRemovingAll(
                                  context, AppRouteName.LOGIN_SCREEN_ROUTE);
                            },
                          );
                        },
                      ),
                    )
                  : SizedBox.shrink(),
            ),
          ],
        ),
      ),
    );
  }

  Widget pinField({required BuildContext context}) {
    return CustomPinCodeField(
      controller: controller.pin_controller,
      onChanged: (value) {
        print(value);
      },
      onCompleted: (v) {
        FocusManager.instance.primaryFocus?.unfocus();
        logData(message: "v: $v");
        controller.pin_controller.text = v;
        controller.verifyOtpMethod(
          context: context,
          pin_code: controller.pin_controller.text,
        );
      },
    );
  }
}
