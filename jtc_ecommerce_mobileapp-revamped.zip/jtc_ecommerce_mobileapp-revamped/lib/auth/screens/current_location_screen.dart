import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/auth/controllers/auth_controller.dart';
import 'package:jtc_ecommerce/widgets/custom_stack_loading.dart';
import 'package:jtc_ecommerce/widgets/custom_text_field.dart';
import 'package:jtc_ecommerce/widgets/custom_button.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:google_maps_webservice/places.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';
import 'package:jtc_ecommerce/utils/constants.dart';

class CurrentLocationScreen extends GetView<AuthController> {
  const CurrentLocationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Obx(
        () => StackCirularLoaderWidget(
          isLoading: controller.isLoading.value,
          childWidget: Container(
            height: 1.sh,
            child: Padding(
              padding: const EdgeInsets.all(15.0),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      height: 0.15.sh,
                    ),
                    // 100.verticalSpace,
                    // Align(
                    //   alignment: Alignment.centerRight,
                    //   child: Container(
                    //     alignment: Alignment.centerRight,
                    //     margin: EdgeInsets.all(8),
                    //     padding: EdgeInsets.all(8),
                    //     width: 70.w,
                    //     decoration: BoxDecoration(
                    //         color: Colors.grey[200],
                    //         borderRadius: BorderRadius.circular(10)),
                    //     child: CustomText(
                    //       text: 'Skip',
                    //       fontsize: 16.sp,
                    //       color: AppColors.BLACK_COLOR,
                    //       isLeftAlign: false,
                    //     ),
                    //   ),
                    // ),
                    // Spacer(),
                    Image.asset('assets/images/Frame.png'),
                    30.verticalSpace,
                    CustomText(
                      text: 'Explore more stores based',
                      color: AppColors.BLACK_COLOR,
                      fontsize: 18.sp,
                    ),
                    CustomText(
                      text: 'on your current location',
                      color: AppColors.BLACK_COLOR,
                      fontsize: 18.sp,
                    ),
                    // Spacer(),

                    // Padding(
                    //   padding: EdgeInsets.only(left: 40.0.w, right: 40.0.w),
                    //   child: CustomTextField(
                    //     hintText: "Nearest Address",
                    //     textEditingController: controller.nearest_address,
                    //     prefixIcon: AssetPaths.NEAREASTADDRESS_ICON,
                    //     // prefixIcon: AssetPaths.EMAIL_ICON,
                    //     // validator: (value) => value?.validateEmail,
                    //     keyboardType: TextInputType.text,
                    //     // textInputFormattors: [
                    //     //   LengthLimitingTextInputFormatter(
                    //     //     Constants.EMAIL_MAX_LENGTH,
                    //     //   )
                    //     // ],
                    //   ),
                    // ),
                    // 15.verticalSpace,
                    // Padding(
                    //   padding: EdgeInsets.only(left: 40.0.w, right: 40.0.w),
                    //   child: user_address(),
                    // ),
                    // 20.verticalSpace,

                    // Padding(
                    //   padding: EdgeInsets.only(left: 40.0.w, right: 40.0.w),
                    //   child: CustomButton(
                    //     buttonColor: AppColors.PRIMARY_COLOR,
                    //     onTap: () {
                    //       controller.getLocationAndUpdateProfile(
                    //         context: context,
                    //         address: controller.user_address.value.text,
                    //       );
                    //     },
                    //     buttonText: 'Enter Manually',
                    //     fontSize: 16.sp,
                    //   ),
                    // ),
                    10.verticalSpace,
                    Padding(
                      padding: EdgeInsets.only(left: 40.0.w, right: 40.0.w),
                      child: Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                          'House No/ Nearest Location',
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey,
                          ),
                        ),
                      ),
                    ),
                    15.verticalSpace,
                    Padding(
                      padding: EdgeInsets.only(left: 40.0.w, right: 40.0.w),
                      child: CustomTextField(
                        hintText: "Nearest Location",
                        textEditingController: controller.nearest_address,
                        prefixIcon: AssetPaths.NEAREASTADDRESS_ICON,
                        // prefixIcon: AssetPaths.EMAIL_ICON,
                        // validator: (value) => value?.validateEmail,
                        keyboardType: TextInputType.text,
                        // textInputFormattors: [
                        //   LengthLimitingTextInputFormatter(
                        //     Constants.EMAIL_MAX_LENGTH,
                        //   )
                        // ],
                      ),
                    ),
                    15.verticalSpace,
                    Padding(
                      padding: EdgeInsets.only(left: 40.0.w, right: 40.0.w),
                      child: Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                          'Address',
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey,
                          ),
                        ),
                      ),
                    ),

                    15.verticalSpace,
                    Padding(
                      padding: EdgeInsets.only(left: 40.0.w, right: 40.0.w),
                      child: user_address(),
                    ),
                    20.verticalSpace,

                    Padding(
                      padding: EdgeInsets.only(left: 40.0.w, right: 40.0.w),
                      child: CustomButton(
                        buttonColor: AppColors.PRIMARY_COLOR,
                        onTap: () {
                          // controller.getLocationAndUpdateProfile(
                          //   context: context,
                          //   address: controller.user_address.value.text,
                          // );

                          controller.getLocation(context: context);
                        },
                        buttonText: 'Save & Continue',
                        fontSize: 16.sp,
                      ),
                    ),

                    // Spacer(),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget user_address() {
    return TextField(
      // controller: controller.user_address,
      // readOnly: !_isEditing,
      controller: controller.user_address.value,
      readOnly: true,
      onTap: () async {
        final Prediction? prediction =
            await Constants.addressPicker(Get.context!);
        logData(message: "prediction: ${prediction}");
        if (prediction != null) {
          logData(message: "prediction: ${prediction}");
          controller.user_address.value.text =
              prediction.description.toString();
          logData(message: "message: ${controller.user_address.value.text}");
          // controller.getLatLongFromAddress(controller.address.value.text);
        }
      },
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.grey[200],
        enabledBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Color(0xF3F3F3), width: 0),
          borderRadius: BorderRadius.circular(6.0),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Color(0xF3F3F3), width: 1.5),
          borderRadius: BorderRadius.circular(6.0),
        ),
        isDense: true,
        contentPadding: const EdgeInsets.all(18.0),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(6.0),
        ),
        hintText: 'Address',
        hintStyle: TextStyle(
          color: Colors.grey,
        ),
        prefixIcon: const Padding(
          padding: EdgeInsets.all(8.0),
          child: Icon(
            Icons.location_pin,
            size: 20,
            color: Colors.black,
          ),
        ),
        suffixIcon: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.only(right: 8.0),
              child: GestureDetector(
                onTap: () async {
                  final Prediction? prediction =
                      await Constants.addressPicker(Get.context!);
                  logData(message: "prediction: ${prediction}");
                  if (prediction != null) {
                    logData(message: "prediction: ${prediction}");
                    controller.user_address.value.text =
                        prediction.description.toString();
                    logData(
                        message:
                            "message: ${controller.user_address.value.text}");
                    // controller.getLatLongFromAddress(controller.address.value.text);
                  }
                },
                child: Text(
                  'Edit',
                  style: TextStyle(
                    color: Color(0xFFE0201C),
                    fontSize: 14,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w500,
                    decoration: TextDecoration.underline,
                    height: 0,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
