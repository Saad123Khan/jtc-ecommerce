import 'dart:io';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/auth/blocs/social_login_bloc.dart';
import 'package:jtc_ecommerce/auth/controllers/auth_controller.dart';
import 'package:jtc_ecommerce/widgets/custom_button.dart';
import 'package:jtc_ecommerce/widgets/custom_scaffold.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/widgets/custom_text_field.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/firebase_auth_bloc.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_fonts.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';
import 'package:jtc_ecommerce/utils/constants.dart';
import 'package:jtc_ecommerce/utils/enums.dart';
import 'package:jtc_ecommerce/utils/field_validator.dart';

class LoginScreen extends GetView<AuthController> {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    Get.put(AuthController());
    return CustomScaffold(
      appBarTitle: tr("login_screen.login"),
      onTap: () => null,
      isAuthScreen: true,
      child: GetBuilder<AuthController>(
        builder: (authController) {
          return Form(
            key: authController.loginFormKey,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15),
              child: Column(
                children: [
                  // logo_and_heading(),
                  // 20.verticalSpace,

                  // ElevatedButton(
                  //   onPressed: () {
                  //     context.setLocale(Locale('es'));
                  //   },
                  //   child: Text('Change to Spanish'),
                  // ),
                  // ElevatedButton(
                  //   onPressed: () {
                  //     context.setLocale(Locale('en'));
                  //   },
                  //   child: Text('Change to English'),
                  // ),
                  email_password_toggle(authController),
                  // 20.verticalSpace,
                  // Text(LocaleKeys.hi_text).tr(),
                  // Text('hi_text').tr(),
                  // Text(LocaleKeys.this_should_be_translate).tr(),
                  // SizedBox(height: 20),

                  // Text(LocaleKeys.hi_text.tr()),
                  // Text(LocaleKeys.this_should_be_translate.tr()),
                  20.verticalSpace,
                  Obx(
                    () => authController.isEmailSelected.value == true
                        ? CustomTextField(
                            isLogin: false,
                            suffixIcon : AssetPaths.MAIL_ICON,
                            hintText: tr('login_screen.email_hint'),
                            textEditingController: controller.email_login,
                            // prefixIcon: AssetPaths.EMAIL_ICON,
                            validator: (value) => value?.validateEmail,
                            keyboardType: TextInputType.emailAddress,
                            textInputFormattors: [
                              LengthLimitingTextInputFormatter(
                                Constants.EMAIL_MAX_LENGTH,
                              )
                            ],
                          )
                        : CustomTextField(
                            hintText: "Phone No",
                            textEditingController: controller.number_login,
                            // prefixIcon: AssetPaths.PHONE_ICON_LOGIN,
                            validator: (value) => value?.validatePhoneNumber,
                            keyboardType: TextInputType.phone,
                            textInputFormattors: [
                              LengthLimitingTextInputFormatter(
                                13,
                              )
                            ],
                          ),
                  ),
                  25.verticalSpace,
                  Obx(
                    () => CustomTextField(
                      hintText: tr('login_screen.password_hint'),
                      isObsCure: controller.show_password_login.value,
                      textEditingController: controller.password_login,
                      // prefixIcon: AssetPaths.PASSWORD_ICON,
                      validator: (v) {
                        if (v!.isEmpty || v.length < 6) {
                          return tr('validators.password.invalidPassword_six');
                        }
                        return null;
                      },
                      // validator: (value) => value?.validateNewPassword,
                      isLogin: true,
                      onIconTap: () {
                        controller.show_password_login.value =
                            !controller.show_password_login.value;
                      },
                    ),
                  ),
                  15.verticalSpace,
                  remeber_me_and_forgot(authController, context),
                  30.verticalSpace,
                  CustomButton(
                    fontSize: 16.sp,
                    buttonColor: AppColors.PRIMARY_COLOR,
                    buttonText: 'login_screen.login_text',
                    onTap: () {
                      if (authController.loginFormKey.currentState!
                          .validate()) {
                        authController.loginMethod(context: context);
                      }
                    },
                  ),
                  // 20.verticalSpace,
                  // social_login_circle_icons(context: context),
                  20.verticalSpace,
                  dont_have_account(context: context),
                  20.verticalSpace,
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget dont_have_account({required BuildContext context}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          'login_screen.dont_have_account_signup_text',
          style: TextStyle(
            fontSize: 16,
          ),
        ).tr(),
        5.horizontalSpace,
        InkWell(
          onTap: () {
            controller.authSingletonUserRole.switchValue = SwitchValue.email;
            controller.clearTextFieldsLogin();
            AppNavigation.navigateTo(
                context, AppRouteName.REGISTER_SCREEN_ROUTE);
          },
          child: Text(
            'login_screen.signup_text',
            style: TextStyle(
                fontSize: 16, color: Colors.red, fontWeight: FontWeight.bold),
          ).tr(),
        ),
      ],
    );
  }

  Widget social_login_circle_icons({required BuildContext context}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Platform.isIOS
            ? socialMediaContain(
                Colors.grey,
                'assets/images/apple.png',
              )
            : SizedBox.shrink(),
        Platform.isIOS ? 10.horizontalSpace : SizedBox.shrink(),
        GestureDetector(
          onTap: () {
            // signInController.googleLogin();
            FirebaseAuthBloc().signInWithGoogle(context: context);
          },
          child: socialMediaContain(
            AppColors.PRIMARY_COLOR,
            'assets/images/google.png',
          ),
        ),
        // 10.horizontalSpace,
        // socialMediaContain(
        //   Colors.blue,
        //   'assets/images/fb.png',
        // ),
      ],
    );
  }

  Widget remeber_me_and_forgot(
      AuthController loginController, BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Obx(
              () => Checkbox(
                activeColor: Colors.red,
                checkColor: Colors.white,
                value: loginController.isChecked.value,
                onChanged: (bool? newValue) {
                  loginController.isChecked.value =
                      !loginController.isChecked.value;
                },
              ),
            ),
            Text(
              tr("login_screen.remember_me"),
              style: TextStyle(
                fontSize: 14, 
                fontWeight: FontWeight.w500,
                color: Colors.red,
              ),
            ),
          ],
        ),
        GestureDetector(
          onTap: () {
            // Get.toNamed(RouteConstants.kForgetPassword);
            controller.authSingletonUserRole.switchValue = SwitchValue.email;
            controller.clearTextFieldsLogin();
            AppNavigation.navigateTo(
                context, AppRouteName.RESET_PASSWORD_SCREEN_ROUTE);
          },
          child: Text(
            'login_screen.forget_password_text',
            style: TextStyle(
              fontSize: 14,
              color: Colors.red,
              fontWeight: FontWeight.bold,
            ),
          ).tr(),
        ),
      ],
    );
  }

  Widget email_password_toggle(AuthController loginController) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        // GestureDetector(
        //   onTap: () {
        //     controller.clearTextFieldsLogin();
        //     loginController.isEmailSelected.value = true;
        //     loginController.authSingletonUserRole.switchValue =
        //         SwitchValue.email;
        //   },
        //   child: Obx(
        //     () => Text(
        //       'login_screen.email',
        //       style: TextStyle(
        //         fontSize: 14,
        //         fontFamily: 'Poppins',
        //         fontWeight: FontWeight.w500,
        //         color: loginController.isEmailSelected.value
        //             ? AppColors.PRIMARY_COLOR
        //             : null,
        //       ),
        //     ).tr(),
        //   ),
        // ),
        9.horizontalSpace
        // GestureDetector(
        //   onTap: () {
        //     controller.email_login.text = "";
        //     controller.number_login.text = "";
        //     controller.password_login.text = "";
        //     loginController.isEmailSelected.value = false;
        //     loginController.authSingletonUserRole.switchValue =
        //         SwitchValue.phone;
        //     logData(
        //         message: "message: ${loginController.isEmailSelected.value}");
        //   },
        //   child: Obx(
        //     () => Text(
        //       'Phone',
        //       style: TextStyle(
        //         fontSize: 14,
        //         fontFamily: 'Poppins',
        //         fontWeight: FontWeight.w500,
        //         color: !loginController.isEmailSelected.value
        //             ? AppColors.PRIMARY_COLOR
        //             : AppColors.GREY_COLOR,
        //       ),
        //     ),
        //   ),
        // ),
      ],
    );
  }

  Widget logo_and_heading() {
    return Container(
      width: double.infinity,
      height: 280.h,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(
            'assets/images/logo.png',
            color: Colors.white,
          ),
          6.verticalSpace,
          CustomText(
            text: "login_to_our",
            // fontFamily: AppFonts.robotoligth,
          ),
        ],
      ),
    );
  }

  Widget socialMediaContain(
    Color borderColor,
    String image,
  ) {
    return Container(
      height: 60,
      width: 60,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(120),
        border: Border.all(color: borderColor),
      ),
      child: Image.asset(image),
    );
  }
}
