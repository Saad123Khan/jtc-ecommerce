import "package:easy_localization/easy_localization.dart";
import "package:flutter/material.dart";
import "package:flutter_screenutil/flutter_screenutil.dart";
import "package:jtc_ecommerce/utils/app_colors.dart";
import "package:jtc_ecommerce/utils/app_fonts.dart";

///Custom Button used in App
class CustomButton extends StatelessWidget {
  CustomButton({
    Key? key,
    required this.buttonColor,
    required this.onTap,
    required this.buttonText,
    this.icon,
    this.padding,
    this.height,
    this.containsIcon = false,
    this.fontWeight,
    this.fontFamily,
    this.fontSize = 18,
    this.textColor = Colors.white,
    this.lowerGradientColor,
    this.upperGradientColor,
    this.borderRadius,
    this.withBorderOnly = false,
  }) : super(key: key);
  final Color buttonColor;
  final Color textColor;
  final String buttonText;
  final Function()? onTap;
  final bool containsIcon;
  final String? icon;
  final double fontSize;
  final double? height;
  final double? padding;
  final String? fontFamily;
  final Color? upperGradientColor;
  final Color? lowerGradientColor;
  final double? borderRadius;
  final FontWeight? fontWeight;
  bool withBorderOnly = false;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
        onTap: onTap,
        child: Container(
          height: height ?? 60.h,
          // width: 250.w,
          padding: EdgeInsets.symmetric(horizontal: padding ?? 40).w,
          decoration: withBorderOnly
              ? BoxDecoration(
                  // gradient: upperGradientColor == null || lowerGradientColor == null
                  //     ? null
                  //     : LinearGradient(
                  //         colors: [
                  //           upperGradientColor ?? AppColors.PRIMARY_COLOR,
                  //           lowerGradientColor ?? AppColors.PRIMARY_COLOR,
                  //         ],
                  //         begin: Alignment.topCenter,
                  //         end: Alignment.bottomCenter,
                  //       ),
                  // color: buttonColor,
                  borderRadius: BorderRadius.circular(borderRadius ?? 15.r),
                  border: Border.all(color: AppColors.PRIMARY_COLOR))
              : BoxDecoration(
                  gradient:
                      upperGradientColor == null || lowerGradientColor == null
                          ? null
                          : LinearGradient(
                              colors: [
                                upperGradientColor ?? AppColors.PRIMARY_COLOR,
                                lowerGradientColor ?? AppColors.PRIMARY_COLOR,
                              ],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                            ),
                  color: buttonColor,
                  borderRadius: BorderRadius.circular(borderRadius ?? 15.r),
                ),
          child: containsIcon
              ? Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // SvgPicture.asset(icon),
                    10.horizontalSpace,
                    Text(
                      buttonText,
                      style: TextStyle(
                        color: textColor,
                        fontSize: fontSize.sp,
                        fontFamily: fontFamily,
                        fontWeight: fontWeight,
                      ),
                      // style: AppTextStyles.textStyleSemiBold(
                      //   fontSize: fontSize.sp,
                      //   color: textColor,
                      // ),
                    ).tr(),
                  ],
                )
              : Center(
                  child: Text(
                    buttonText,
                    style: TextStyle(
                      color: textColor,
                      fontSize: fontSize.sp,
                      fontWeight: fontWeight,
                      // fontWeight: FontWeight.w600,
                      fontFamily: fontFamily ?? AppFonts.defaultFont,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis, 
                  ).tr(),
                ),
        ));
  }
}
