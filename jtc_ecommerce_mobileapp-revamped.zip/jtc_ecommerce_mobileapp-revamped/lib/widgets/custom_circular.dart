import 'package:flutter/material.dart';
import 'package:jtc_ecommerce/widgets/custom_extended_image.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_strings.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';

class CircularPic extends StatelessWidget {
  final double diameter;
  final String? image;
  final BoxBorder? border;
  final String imageType;
  final Color bgColor;
  Function()? onTap;
  CircularPic({
    Key? key,
    required this.diameter,
    required this.image,
    this.imageType = AppStrings.IMAGE_TYPE_NETWORK,
    this.bgColor = AppColors.WHITE_COLOR,
    this.border,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: diameter,
      height: diameter,
      decoration: BoxDecoration(
        color: bgColor,
        shape: BoxShape.circle,
        border: border ??
            Border.all(
              color: AppColors.BLACK_COLOR,
            ),
      ),
      child: ClipOval(
        child: CustomExtendedImageWidget(
          onTap: onTap ?? null,
          imagePath: image,
          imageType: imageType,
          fit: BoxFit.cover,
          imagePlaceholder: AssetPaths.USER_IMAGE,
          imageFailedLoading: 'assets/images/settings_icon_bottom.png',
        ),
      ),
    );
  }
}
