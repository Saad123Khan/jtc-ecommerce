import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';

class StackCirularLoaderWidget extends StatelessWidget {
  final Widget childWidget;
  final bool isLoading;
  final Color? backgroundColor;
  const StackCirularLoaderWidget(
      {Key? key,
      required this.childWidget,
      required this.isLoading,
      this.backgroundColor})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        childWidget,
        (isLoading)
            ? Container(
                height: Get.height,
                width: Get.width,
                color: backgroundColor ?? Colors.black45,
                child: const Align(
                  alignment: Alignment.center,
                  child: CircularProgressIndicator(
                    color: AppColors.PRIMARY_COLOR,
                    backgroundColor: AppColors.WHITE_COLOR,
                    strokeWidth: 5.0,
                  ),
                ),
              )
            : Container()
      ],
    );
  }
}
