import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_fonts.dart';

class BusinessTypeDropdown extends StatelessWidget {
  BusinessTypeDropdown({
    required this.selectedValue,
    required this.selectionTypes,
    required this.onChanged,
    this.hintText = '',
    this.labelText = '',
    this.validator,
    this.enabled = true,
  });

  String? selectedValue;
  List<String?> selectionTypes = [];
  Function(String?)? onChanged;
  final String hintText;
  final String labelText;
  String? Function(String?)? validator;
  bool enabled;

  @override
  Widget build(BuildContext context) {
    //! ============> Ensure that selectedValue is valid and exists in selectionTypes
    if (selectedValue != null && !selectionTypes.contains(selectedValue)) {
      selectedValue =
          null; //! ============> Set to null if it doesn't exist in selectionTypes
    }

    return DropdownButtonHideUnderline(
      child: DropdownButtonFormField2(
        iconStyleData: IconStyleData(
          iconEnabledColor: AppColors.BLACK_COLOR,
          iconSize: 28.h,
        ),
        validator: validator,
        items: selectionTypes
            .map(
              (String? item) => DropdownMenuItem<String>(
                value: item,
                child: CustomText(
                  text: item,
                  fontsize: 16.sp,
                  fontFamily: AppFonts.defaultFont,
                  color: AppColors.BLACK_COLOR,
                  isLeftAlign: true,
                ),
              ),
            )
            .toList(),
        value: selectedValue,
        isDense: true,
        isExpanded: true,
        onChanged: onChanged,
        decoration: InputDecoration(
          contentPadding: selectedValue != null
              ? EdgeInsets.only(left: 0, right: 15.w, bottom: 15.h, top: 15.h)
              : EdgeInsets.all(12.r),
          filled: true,
          fillColor: Color(0xFFF6F6F6),
          prefixIconConstraints: const BoxConstraints(
            minWidth: 10,
            minHeight: 10,
          ),
          suffixIconConstraints: const BoxConstraints(
            minWidth: 10,
            minHeight: 10,
          ),
          hintText: hintText,
          hintStyle: TextStyle(
            color: Color(0xFF666666),
            fontSize: 17.sp,
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5.r),
            borderSide: BorderSide(
              color: AppColors.GREY_COLOR,
              width: 1.0,
              style: BorderStyle.solid,
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5.r),
            borderSide: BorderSide(
              color: Color(0xFFE4E4E4),
              width: 1.0,
              style: BorderStyle.solid,
            ),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5.r),
            borderSide: BorderSide(
              color: Color(0xFFE4E4E4),
              width: 1.0,
              style: BorderStyle.solid,
            ),
          ),
        ),
        dropdownStyleData: DropdownStyleData(
          decoration: const BoxDecoration(
            borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(10),
              bottomRight: Radius.circular(10),
            ),
            color: AppColors.WHITE_COLOR,
          ),
          scrollbarTheme: ScrollbarThemeData(
            thickness: MaterialStateProperty.all<double>(6),
            thumbVisibility: MaterialStateProperty.all<bool>(true),
          ),
        ),
        menuItemStyleData: const MenuItemStyleData(
          height: 40,
        ),
      ),
    );
  }
}
