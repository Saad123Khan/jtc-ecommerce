import 'package:flutter/material.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';
//Base class which will be used to show an image and text when there is no item available in the cart and history cart, So instead of
//showing usual UI we will disable total amount and button to restrict user to go further and make unnecessary actions.

class NoDataPage extends StatelessWidget {
  final String text;
  final String imgPath;
  final double? height;
  final double? width;
  final double? spaceImageAndText;
  final double? fontSize;

  const NoDataPage({
    Key? key,
    required this.text,
    this.fontSize,
    this.height,
    this.width,
    this.spaceImageAndText,
    this.imgPath = AssetPaths.EMPTY_LIST_PLACEHOLDER,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Image.asset(
          imgPath,
          height: height ?? MediaQuery.of(context).size.height * 0.12,
          width: width ?? MediaQuery.of(context).size.width * 0.12,
        ),
        SizedBox(
          height:
              spaceImageAndText ?? MediaQuery.of(context).size.height * 0.01,
        ),
        Text(
          text,
          style: TextStyle(
            fontSize: fontSize ?? MediaQuery.of(context).size.height * 0.0250,
            // color: Theme.of(context).disabledColor,
            color: AppColors.BLACK_COLOR,
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}
