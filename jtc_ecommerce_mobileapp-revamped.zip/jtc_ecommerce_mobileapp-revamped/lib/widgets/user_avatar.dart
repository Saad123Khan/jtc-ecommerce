import "package:flutter/material.dart";
import "package:flutter_screenutil/flutter_screenutil.dart";
import 'package:jtc_ecommerce/widgets/custom_circular.dart';
import "package:jtc_ecommerce/utils/app_colors.dart";

class UserAvatar extends StatelessWidget {
  const UserAvatar({
    super.key,
    required this.radius,
    required this.userImage,
    this.hasActiveIcon = false,
    this.hasWhiteColor = false,
    this.borderColor,
    this.isNetworkImage = false,
  });
  final double radius;
  final String userImage;
  final bool hasActiveIcon;
  final bool hasWhiteColor;
  final Color? borderColor;
  final bool isNetworkImage;
  @override
  Widget build(BuildContext context) {
    print("Custom Circle: $userImage");
    return Stack(
      children: [
        CircularPic(
          diameter: radius.sp * 2,
          image: userImage,
          border: Border.all(
            color: hasWhiteColor
                ? AppColors.BLACK_COLOR
                : borderColor ?? AppColors.RED_GMAIL_COLOR,
          ),
        ),
        hasActiveIcon
            ? Positioned(
                bottom: 0,
                right: 0,
                child: Container(
                  padding: const EdgeInsets.all(4).r,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppColors.RED_GMAIL_COLOR,
                    border: Border.all(
                      color: AppColors.RED_GMAIL_COLOR,
                    ),
                  ),
                ),
              )
            : const SizedBox()
      ],
    );
  }
}
