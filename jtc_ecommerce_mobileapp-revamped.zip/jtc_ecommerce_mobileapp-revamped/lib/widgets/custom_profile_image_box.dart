import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:jtc_ecommerce/widgets/custom_extended_image.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';
import 'package:jtc_ecommerce/utils/constants.dart';

class CustomEditProfileImageWidget extends StatelessWidget {
  String? imagePath, imageType, assetImagePath;
  VoidCallback? onUploadImageTap, onViewImage;
  Color? borderColor;
  bool updatingProfile;
  bool show_change_picture;

  CustomEditProfileImageWidget({
    this.imagePath,
    this.imageType,
    this.onUploadImageTap,
    this.onViewImage,
    this.borderColor = AppColors.WHITE_COLOR,
    this.assetImagePath = AssetPaths.FNAME_ICON,
    this.updatingProfile = false,
    this.show_change_picture = false,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      // alignment: Alignment.bottomCenter,
      children: [
        _userProfileImageWidget(),
        show_change_picture ? _uploadImageContainerWidget() : SizedBox.shrink(),
      ],
    );
  }

  Widget _userProfileImageWidget() {
    print(imageType);
    return Container(
      height: 160,
      // color: Colors.white,
      child: Stack(
        alignment: Alignment.center,
        children: [
          GestureDetector(
            onTap: onViewImage,
            child: Container(
              width: 120,
              height: 120,
              decoration: BoxDecoration(
                color: AppColors.APP_GREY_COLOR,
                shape: BoxShape.circle,
              ),
              child: ClipOval(
                child: imagePath != null
                    ? imageType == "file"
                        ? Constants.fadeNetworkImage(
                            imagePath: imagePath!,
                            // updatingProfile:
                            //     updatingProfile, //! ============> Set to true or false based on your logic
                          )
                        : CustomExtendedImageWidget(
                            imagePath: imagePath,
                            imageType: 'network',
                            imagePlaceholder: 'assets/images/no_image.png')
                    : Image.asset(
                        AssetPaths.USER_IMAGE,
                        fit: BoxFit.contain,
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _uploadImageContainerWidget() {
    return Positioned(
      right: 5,
      bottom: 20,
      child: GestureDetector(
        onTap: onUploadImageTap,
        // child: Container(
        //   width: 50.w,
        //   height: 50.h,
        //   margin: EdgeInsets.only(bottom: 8.h),
        //   decoration: BoxDecoration(
        //       color: AppColors.PRIMARY_COLOR,
        //       shape: BoxShape.circle,
        //       border: Border.all(color: AppColors.WHITE_COLOR, width: 3.0)),
        //   child: Center(
        //     child: Image.asset(
        //       // AssetPaths.FNAME_ICON,
        //       "assets/images/edit_icon.png",
        //       height: 30.h,
        //       // width: 14.0,
        //       // scale: 4.5.sp,
        //       fit: BoxFit.fill,
        //       // color: AppColors.WHITE_COLOR,
        //     ),
        //   ),
        // ),
        child: Container(
          height: 30.h,
          width: 30.w,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.white,
            border: Border.all(
              color: Colors.grey,
              width: 2.0,
            ),
          ),
          child: Icon(
            Icons.camera_alt,
            color: Colors.grey,
            size: 18.sp,
          ),
        ),
      ),
    );
  }
}
