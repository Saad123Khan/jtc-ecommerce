import "dart:ui";
import "package:easy_localization/easy_localization.dart";
import "package:flutter/material.dart";
import "package:jtc_ecommerce/utils/app_colors.dart";
import "package:jtc_ecommerce/utils/app_fonts.dart";

class CustomText extends StatelessWidget {
  String? text;
  final Color? color;
  final FontWeight? fontWeight;
  final double? fontsize;
  AlignmentGeometry? align;
  TextAlign? textAlign;
  List<FontFeature>? fontFeatures;
  final int? maxLines;
  bool isLeftAlign;
  TextDecoration? textDecoration;
  String? fontFamily;
  TextOverflow? overflow;
  double? height;
  CustomText({
    Key? key,
    this.height,
    this.text,
    this.color,
    this.fontWeight,
    this.textAlign,
    this.fontsize,
    this.fontFeatures,
    this.maxLines,
    this.align,
    this.isLeftAlign = false,
    this.textDecoration,
    this.fontFamily,
    this.overflow,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: align ??
          (isLeftAlign == true ? Alignment.centerLeft : Alignment.center),
      child: Text(
        textAlign: isLeftAlign == false ? TextAlign.center : null,
        maxLines: maxLines,
        // overflow:
        //     maxLines != null ? TextOverflow.ellipsis : TextOverflow.visible,
        text ?? " ",
        style: TextStyle(
          fontFeatures: fontFeatures,
          height: height ?? 1.5,
          fontSize: fontsize ?? 22,
          color: color ?? AppColors.WHITE_COLOR,
          fontWeight: fontWeight ?? FontWeight.normal,
          decoration: textDecoration,
          fontFamily: fontFamily ?? AppFonts.defaultFont,
          overflow: overflow ?? TextOverflow.ellipsis,
        ),
      ).tr(),
    );
  }
}
