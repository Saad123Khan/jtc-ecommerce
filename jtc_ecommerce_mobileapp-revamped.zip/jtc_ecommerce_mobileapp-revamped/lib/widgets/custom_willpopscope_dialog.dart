import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:jtc_ecommerce/widgets/custom_button.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';

class ExitButtonContent extends StatelessWidget {
  ExitButtonContent({
    super.key,
    this.descriptionText,
    this.onTapYesButton,
  });

  String? descriptionText;
  Function()? onTapYesButton;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          color: AppColors.TRANSPARENT_COLOR,
          borderRadius: BorderRadius.circular(5.sp)),
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 5.sp),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            CustomText(
              text: descriptionText ?? tr('ExitButtonContent.description'),

              // "Are sure, You want to close?",
              isLeftAlign: false,
              fontsize: 14.sp,
              color: AppColors.BLACK_COLOR,
            ),
            10.verticalSpace,
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Expanded(
                  child: CustomButton(
                    height: 40.h,
                    buttonColor: AppColors.PRIMARY_COLOR,
                    onTap: onTapYesButton,
                    buttonText:

                        // "Yes",
                        tr('ExitButtonContent.yes'),
                  ),
                ),
                7.horizontalSpace,
                Expanded(
                  child: CustomButton(
                    height: 40.h,
                    buttonColor: AppColors.PRIMARY_COLOR,
                    onTap: () {
                      AppNavigation.navigatorPop(context);
                    },
                    buttonText:
                        // "No",
                        tr('ExitButtonContent.no'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
