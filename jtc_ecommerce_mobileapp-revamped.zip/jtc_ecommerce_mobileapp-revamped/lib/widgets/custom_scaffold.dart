import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

///
/// Custom Scaffold - To use all over the app except Home Screen
///
class CustomScaffold extends StatelessWidget {
  final String appBarTitle;
  final Widget child;
  final VoidCallback onTap;
  final bool isAuthScreen;
  final bool isFavoriteIcon;
  final Widget? child2;

  const CustomScaffold({
    Key? key,
    required this.appBarTitle,
    required this.child,
    required this.onTap,
    this.isAuthScreen = false,
    this.isFavoriteIcon = false,
    this.child2,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset : true,  
      body: SingleChildScrollView( 
        child: Container(
          height: MediaQuery.sizeOf(context).height,  
          width: MediaQuery.sizeOf(context).width,
          child: Stack(  
            children: [
              Container(
                height: isAuthScreen 
                    ? MediaQuery.sizeOf(context).height * 0.3 
                    : MediaQuery.sizeOf(context).height * .2, 
                decoration: BoxDecoration( 
                  image: DecorationImage(
                    image: AssetImage("assets/revamped/splashLogo.png"), 
                    fit: BoxFit.cover, 
                  ),
                ),
                child: Padding( 
                  padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
                  child: Row(
                    children: [
                      isAuthScreen 
                          ? 45.horizontalSpace
                          : GestureDetector(
                              onTap: onTap, 
                              child: Container(
                                height: 36.h,
                                width: 36.w,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(18.r),
                                  color: Colors.white,
                                ),
                                child: Center(
                                  child: Padding(
                                    padding: EdgeInsets.only(left: 5.w),
                                    child: Icon(
                                      Icons.arrow_back_ios,
                                      color: Colors.red,
                                      size: 18.sp,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            isAuthScreen
                                ? Image.asset(
                                    "assets/images/logo.png",
                                    color: Colors.white,
                                  )
                                : SizedBox.shrink(),
                            isAuthScreen ? 10.verticalSpace : SizedBox.shrink(),
                            Text(
                              "" + "${appBarTitle}",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 20.sp,
                                fontWeight: FontWeight.bold,
                              ),
                              textAlign: TextAlign.center,  
                            ),  
                          ], 
                        ),
                      ), 
                      isFavoriteIcon ? child2! : 36.horizontalSpace,
                      
                    ],
                  ),
                ),
              ),
              Positioned(
                top: isAuthScreen
                    ? MediaQuery.sizeOf(context).height * 0.3 - 28
                    : MediaQuery.sizeOf(context).height * .2 - 28,
                left: 0,
                right: 0,
                child: Container(
                  height: isAuthScreen
                      ? MediaQuery.sizeOf(context).height * 0.8 + 28
                      : MediaQuery.sizeOf(context).height * .8 + 28,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(28.r),
                      topRight: Radius.circular(28.r),
                    ),
                  ),
                  child: Padding(
                    padding:
                        EdgeInsets.symmetric(vertical: 20.h, horizontal: 20.w),
                    child: child,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

///
/// Custom Scaffold - To use only in Bottom Nav Options
///
 
class CustomScaffoldHome extends StatelessWidget { 
  const CustomScaffoldHome({
    Key? key,
    required this.child, 
    required this.didShowLocation, 
    required this.didShowStoreLocator, 
    required this.onNotificationPress,
    required this.onCartPress, 
    required this.onStorePress,
  }) : super(key: key); 

  final Widget child;
  final bool didShowLocation; 
  final bool didShowStoreLocator;
  final VoidCallback onStorePress;
  final VoidCallback onNotificationPress; 
  final VoidCallback onCartPress;
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: MediaQuery.sizeOf(context).height,
        width: MediaQuery.sizeOf(context).width,
        child: Stack(
          children: [
            Container(
              height: MediaQuery.sizeOf(context).height * .2,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("assets/revamped/splashLogo.png"),
                  fit: BoxFit.cover,
                ),
              ),
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
                child: Row(
                  children: [],
                ),
              ),
            ),
            Positioned(
              top: MediaQuery.sizeOf(context).height * .2 - 28,
              left: 0,
              right: 0,
              child: Container(
                height: MediaQuery.sizeOf(context).height * .8 + 28,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(28.r),
                    topRight: Radius.circular(28.r),
                  ),
                ),
                child: Padding(
                  padding:
                      EdgeInsets.symmetric(vertical: 20.h, horizontal: 20.w),
                  child: child,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
