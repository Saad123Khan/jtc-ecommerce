import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_fonts.dart';

class RichTextWidget extends StatelessWidget {
  final String? text, subText;
  final Color? subTextColor;
  final double? fontSizeText;
  final double? fontSizeSubText;
  final VoidCallback? onSubTextPress;

  RichTextWidget(
      {this.text,
      this.subText,
      this.onSubTextPress,
      this.subTextColor,
      this.fontSizeText,
      this.fontSizeSubText,
      s});

  @override
  Widget build(BuildContext context) {
    return RichText(
      text: TextSpan(
        text: text,
        style: TextStyle(
            color: AppColors.BLACK_COLOR,
            // fontWeight: FontWeight.w500,
            fontFamily: AppFonts.defaultFont,
            fontSize: fontSizeText ?? 16),
        children: <TextSpan>[
          TextSpan(
            recognizer: TapGestureRecognizer()..onTap = onSubTextPress,
            text: subText,
            style: TextStyle(
              color: subTextColor ?? AppColors.BLACK_COLOR,
              // fontWeight: FontWeight.bold,
              fontSize: fontSizeSubText ?? 16,
              decoration:
                  subTextColor == null ? TextDecoration.underline : null,
            ),
          ),
        ],
      ),
    );
  }
}
