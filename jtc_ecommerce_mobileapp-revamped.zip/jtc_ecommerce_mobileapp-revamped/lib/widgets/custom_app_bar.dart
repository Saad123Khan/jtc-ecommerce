import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/cart/controllers/cart_controller.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/splash/screens/components/store_setup_dialog.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';
import 'package:jtc_ecommerce/utils/constants.dart';

// final CartController cartController = Get.put(CartController());
PreferredSize appBarWithLeading(
    {Function()? onTap_notification,
    Function()? onTap_cart,
    required String titleText1,
    required String titleText2,
    void Function()? onTapNotifications,
    Widget? widget,
    void Function()? onTapCart,
    Function()? onTitletap}) {
  return PreferredSize(
    preferredSize: Size.fromHeight(100.h),
    child: Container(
      height: 200.h,
      decoration: BoxDecoration(
        color: Colors.grey[100],
        image: DecorationImage(
          image: AssetImage("assets/revamped/splashLogo.png"),
          fit: BoxFit.cover,
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center ,
        children: [ 
          30.verticalSpace,
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  10.horizontalSpace,
                  Container(
                    height: 25.h,
                    width: 25.w,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(25.r),
                        color: Colors.white),
                    child: Icon(
                      Icons.location_on,
                      color: Colors.red,
                    ),
                  ),
                  5.horizontalSpace,
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          CustomText(
                            text: titleText1,
                            fontsize: 10.sp,
                            color: AppColors.WHITE_COLOR,
                            isLeftAlign: false,
                            align: Alignment.centerLeft,
                          ),
                          Icon(
                            Icons.arrow_drop_down_sharp,
                            color: AppColors.WHITE_COLOR,
                            size: 15.sp,
                          ),
                        ],
                      ),
                      if (widget != null) widget,
                    ],
                  ),
                ],
              ),
              // Padding(
              //   padding: EdgeInsets.only(left: 10.h),
              //   child: Column(
              //     crossAxisAlignment: CrossAxisAlignment.start,
              //     mainAxisAlignment: MainAxisAlignment.center,
              //     children: [
              //       GestureDetector(
              //         onTap: onTitletap,
              //         child: Row(
              //           children: [
              //             CustomText(
              //               text: titleText1,
              //               fontsize: 11.sp,
              //               color: AppColors.WHITE_COLOR,
              //               isLeftAlign: false,
              //               align: Alignment.centerLeft,
              //             ),
              //             Icon(
              //               Icons.arrow_drop_down_sharp,
              //               color: AppColors.WHITE_COLOR,
              //               size: 18.sp,
              //             ),
              //           ],
              //         ),
              //       ),
          
              //     ],
              //   ),
              // ),
              Spacer(),
              GestureDetector(
                onTap: () {
                  AppDialogs.showAppDialog(
                    context: Constants.navigatorKey.currentContext!,
                    child: StoreSetupDialog(
                      isFromEdit: true,
                    ),
                  );
                },
                child: Container(
                  height: 30.h,
                  width: 30.w,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30.r),
                    border: Border.all(color: Colors.white),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(4),
                    child: Image.asset(
                      AssetPaths.STORE_ICONM,
                      color: AppColors.WHITE_COLOR,
                    ),
                  ),
                ),
              ),
              10.horizontalSpace,
              GestureDetector(
                onTap: onTapNotifications,
                child: Container(
                  height: 30.h,
                  width: 30.w,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30.r),
                    border: Border.all(color: Colors.white),
                  ),
                  child: Icon(
                    Icons.notifications_active,
                    color: Colors.white,
                  ),
                ),
              ),
              10.horizontalSpace,
              _cartIcon(
                icon_name: AssetPaths.CART_ICON_BOTTOM_NAVIGAITON,
                onTap: onTapCart,
                color: AppColors.TRANSPARENT_COLOR,
                iconColor: AppColors.BLACK_COLOR,
                margin: EdgeInsets.only(right: 8),
              ),
            ],
          ),
        ],
      ),
    ),
  );
}

AppBar appBarNormal({
  Function()? onTap_back,
  required String titleText,
}) {
  return AppBar(
    toolbarHeight: 70.0,
    backgroundColor: Colors.grey[100],
    elevation: 0,
    centerTitle: true,
    leading: GestureDetector(
      onTap: onTap_back,
      child: Icon(
        Icons.arrow_back_ios_new,
        color: AppColors.BLACK_COLOR,
      ),
    ),
    title: Text(
      titleText,
      style: TextStyle(
        color: AppColors.BLACK_COLOR,
        fontSize: 18.sp,
      ),
    ),
  );
}

AppBar appBarNormalCart({
  Function()? onTap_back,
  required String titleText,
  Function()? onTap_cart,
}) {
  return AppBar(
    toolbarHeight: 70.0,
    backgroundColor: Colors.grey[100],
    elevation: 0,
    centerTitle: true,
    leading: GestureDetector(
      onTap: onTap_back,
      child: Icon(
        Icons.arrow_back_ios_new,
        color: AppColors.BLACK_COLOR,
      ),
    ),
    title: Text(
      titleText,
      style: TextStyle(
        color: AppColors.BLACK_COLOR,
        fontSize: 18.sp,
      ),
    ),
    actions: [
      GestureDetector(
        onTap: onTap_cart,
        child: Padding(
            // padding: const EdgeInsets.only(top: 20, bottom: 20, left: 30),
            padding: EdgeInsets.symmetric(horizontal: 10),
            child: Icon(Icons.delete, size: 30, color: AppColors.PRIMARY_COLOR)

            // appbar_action_button(
            //   icon_name: AssetPaths.CART_ICON_BOTTOM_NAVIGAITON,
            //   onTap: onTap_cart,
            // ),
            ),
      ),
    ],
  );
}

PreferredSize appBarWithTitleAndIcons({
  Function()? onTap_notification,
  Function()? onTap_cart,
  required String titleText1,
}) {
  return PreferredSize(
    preferredSize: Size.fromHeight(90.h),
    child: Container(
      height: 200.h,
      decoration: BoxDecoration(
        color: Colors.grey[100],
        image: DecorationImage(
          image: AssetImage("assets/revamped/splashLogo.png"),
          fit: BoxFit.cover,
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          30.verticalSpace,
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              
              Padding(
                padding: EdgeInsets.only(left: 25.w),
                child: CustomText(
                  text: titleText1,
                  fontsize: 20.sp,
                  color: AppColors.WHITE_COLOR,
                  isLeftAlign: false,
                  align: Alignment.centerLeft,
                ),
              ),
              Row(
                children: [
                  GestureDetector(
                    onTap: () {
                      AppDialogs.showAppDialog(
                        context: Constants.navigatorKey.currentContext!,
                        child: StoreSetupDialog(
                          isFromEdit: true,
                        ),
                      );
                    },
                    child: Container(
                      height: 30.h,
                      width: 30.w,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30.r),
                        border: Border.all(color: Colors.white),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(4),
                        child: Image.asset(
                          AssetPaths.STORE_ICONM,
                          color: AppColors.WHITE_COLOR,
                        ),
                      ),
                    ),
                  ),
                  10.horizontalSpace,
                  GestureDetector(
                    onTap: onTap_notification,
                    child: Container(
                      height: 30.h,
                      width: 30.w,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30.r),
                        border: Border.all(color: Colors.white),
                      ),
                      child: Icon(
                        Icons.notifications_active,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  10.horizontalSpace,
                  // Padding(
                  //   padding: const EdgeInsets.only(top: 30, bottom: 0),
                  //   child: _cartIcon(
                  //     icon_name: AssetPaths.CART_ICON_BOTTOM_NAVIGAITON,
                  //     color: AppColors.TRANSPARENT_COLOR,
                  //     iconColor: AppColors.WHITE_COLOR,
                  //     onTap: onTap_cart,
                  //   ),
                  // ),
                ],
              ),
            ],
          ),
        ],
      ),
    ),
  );
}

Container appbar_action_button(
    {required String icon_name,
    required Color color,
    required Color iconColor,
    required void Function()? onTap,
    EdgeInsetsGeometry? margin}) {
  return Container(
    width: 40.w,
    height: 40.h,
    decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(30.r),
        border: Border.all(color: Colors.white)),
    margin: margin ?? EdgeInsets.only(right: 10.w, bottom: 5.h),
    child: InkWell(
      onTap: onTap,
      child: Image.asset(
        icon_name,
        // color: AppColors.GREY_COLOR,
        color: Colors.white,
        height: 15.h,
        width: 15.w,
      ),
    ),
  );
}

Widget _cartIcon({
  required String icon_name,
  required Color color,
  required Color iconColor,
  required void Function()? onTap,
  EdgeInsetsGeometry? margin,
}) {
  return Stack(
    children: [
      Container(
        height: 30.h,
        width: 30.w,
        decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(30.r),
            border: Border.all(color: Colors.white)),
        margin: margin ?? EdgeInsets.only(right: 10.w, bottom: 5.h),
        child: InkWell(
          onTap: onTap,
          child: Image.asset(
            icon_name,
            // color: AppColors.GREY_COLOR,
            color: Colors.white,
          ),
        ),
      ),
      Positioned(
        top: -5,
        right: 10,
        child: Obx(
          () => Text(
            CartController.i.cart_list.length > 99
                ? "99+"
                : CartController.i.cart_list.length.toString(),
            style: TextStyle(
                color: AppColors.WHITE_COLOR,
                fontSize: 12.sp,
                fontWeight: FontWeight.bold),
          ),
        ),
      )
    ],
  );
}
