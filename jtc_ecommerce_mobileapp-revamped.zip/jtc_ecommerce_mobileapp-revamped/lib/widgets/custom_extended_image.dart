import 'dart:io';
import 'package:extended_image/extended_image.dart';
import 'package:flutter/material.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_strings.dart';
import 'package:shimmer/shimmer.dart';

class CustomExtendedImageWidget extends StatelessWidget {
  final String? imagePath, imageType;
  final String imagePlaceholder;
  final BoxFit? fit;
  final Color? placeholderColor, imageColor;
  final VoidCallback? onTap;
  final String? imageFailedLoading;

  CustomExtendedImageWidget(
      {this.imagePath,
      this.imageType,
      required this.imagePlaceholder,
      this.imageColor,
      this.placeholderColor,
      this.imageFailedLoading,
      this.fit,
      this.onTap});

  @override
  Widget build(BuildContext context) {
    return imagePath != null && imageType == AppStrings.IMAGE_TYPE_FILE
        ? GestureDetector(
            onTap: onTap,
            child: ExtendedImage.file(
              File(imagePath!),
              fit: fit ?? BoxFit.cover,
              color: imageColor,
              loadStateChanged: (state) {
                switch (state.extendedImageLoadState) {
                  case LoadState.loading:
                    return Image.asset(
                      imagePlaceholder,
                      fit: fit ?? BoxFit.cover,
                      color: placeholderColor,
                    );

                  case LoadState.failed:
                    return Image.asset(
                      imagePlaceholder,
                      fit: fit ?? BoxFit.cover,
                      color: placeholderColor,
                    );
                  case LoadState.completed:
                    // TODO: Handle this case.
                    break;
                }
                return null;
              },
              //cancelToken: cancellationToken,
            ),
          )
        : imagePath != null && imageType == AppStrings.IMAGE_TYPE_NETWORK
            ? GestureDetector(
                onTap: onTap,
                child: ExtendedImage.network(
                  imagePath!,
                  fit: fit ?? BoxFit.cover,
                  color: imageColor,
                  loadStateChanged: (state) {
                    print("LOAD STATE ${state.extendedImageLoadState}");
                    switch (state.extendedImageLoadState) {
                      case LoadState.loading:
                        return Shimmer.fromColors(
                          baseColor: AppColors.GREY_COLOR.withOpacity(.1),
                          highlightColor: AppColors.GREY_COLOR_SHADE_100,
                          child: Container(
                            color: AppColors.WHITE_COLOR,
                          ),
                        );

                      case LoadState.failed:
                        return Center(
                          child: Image.asset(
                            // imagePlaceholder,
                          imageFailedLoading ??   "assets/images/no_image.png" ,
                            fit: BoxFit.contain,
                            color: placeholderColor,
                            height: 45,
                            width: 45,
                          ),
                        );
                      case LoadState.completed:
                        
                        break;
                    }
                    return null;
                  },
                  //cancelToken: cancellationToken,
                ),
              )
            : imagePath != null && imageType == AppStrings.IMAGE_TYPE_ASSET
                ? GestureDetector(
                    onTap: onTap,
                    child: ExtendedImage.asset(
                      imagePath!,
                      color: imageColor,
                      fit: fit ?? BoxFit.cover,
                      loadStateChanged: (state) {
                        switch (state.extendedImageLoadState) {
                          case LoadState.loading:
                            return Image.asset(
                              imagePlaceholder,
                              fit: fit ?? BoxFit.cover,
                              color: placeholderColor,
                            );

                          case LoadState.failed:
                            return Image.asset(
                              imagePlaceholder,
                              fit: fit ?? BoxFit.cover,
                              color: placeholderColor,
                            );
                          case LoadState.completed:
                            // TODO: Handle this case.
                            break;
                        }
                        return null;
                      },
                      //cancelToken: cancellationToken,
                    ),
                  )
                : Image.asset(
                    imagePlaceholder,
                    fit: fit ?? BoxFit.cover,
                    color: placeholderColor,
                  );
  }
}
