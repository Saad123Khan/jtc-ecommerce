import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/enums.dart';
import 'package:shimmer/shimmer.dart';

class CustomShimmer extends StatelessWidget {
  final ShimmerType shimmerType;
  CustomShimmer({
    Key? key,
    required this.shimmerType,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Widget childWidget;
    if (shimmerType == ShimmerType.food_category_skeleton) {
      childWidget = food_category_skeleton();
    } else if (shimmerType == ShimmerType.food_category_wise_skeleton) {
      childWidget = food_category_wise_skeleton();
    } else if (shimmerType == ShimmerType.food_detail) {
      childWidget = eventDetailPageSkeleton();
    } else if (shimmerType == ShimmerType.favourite_list) {
      childWidget = food_category_wise_skeleton();
    } else {
      childWidget = Container();
    }
    return Shimmer.fromColors(
      baseColor: Colors.grey[300]!,
      highlightColor: Colors.grey[100]!,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: childWidget,
      ),
    );
  }

  Widget food_category_skeleton() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        20.verticalSpace,
        Container(
          width: 80.w,
          height: 80.h,
          decoration: BoxDecoration(
            color: Colors.grey[300],
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      ],
    );
  }

  Widget food_category_wise_skeleton() {
    return Container(
      width: 150.w,
      height: 150.h,
      decoration: BoxDecoration(
        color: Colors.grey[300],
        borderRadius: BorderRadius.circular(10),
      ),
    );
  }

  Widget visionBoardListViewSkeleton() {
    return Padding(
      padding: EdgeInsets.zero,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      height: 18,
                      width: 100,
                      color: Colors.grey[300],
                    ),
                    Spacer(),
                    Container(
                      width: 18,
                      height: 18,
                      color: Colors.grey[300],
                    ),
                  ],
                ),
                SizedBox(height: 10),
                Container(
                  width: double.infinity,
                  height: 60,
                  color: Colors.grey[300],
                ),
                SizedBox(height: 10),
                Row(
                  children: [
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: Colors.grey[300],
                      ),
                    ),
                    SizedBox(width: 10),
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: Colors.grey[300],
                      ),
                    ),
                    SizedBox(width: 10),
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: Colors.grey[300],
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget eventDetailPageSkeleton() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                // Replace this with shimmer placeholder for image
                Container(
                  height: 200, // Set your desired height
                  color: Colors.grey[300], // Placeholder color
                ),
                SizedBox(height: 10),
                Row(
                  children: [
                    Container(
                      width: 18,
                      height: 18,
                      color: Colors.grey[300], // Placeholder color
                    ),
                    SizedBox(width: 10),
                    Expanded(
                      child: Container(
                        height: 18,
                        color: Colors.grey[300], // Placeholder color
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 10),
                Row(
                  children: [
                    Container(
                      width: 200,
                      height: 18,
                      color: Colors.grey[300],
                    ),
                  ],
                ),
                SizedBox(height: 10),
                Row(
                  children: [
                    Container(
                      width: 18,
                      height: 18,
                      color: Colors.grey[300], // Placeholder color
                    ),
                    SizedBox(width: 10),
                    Expanded(
                      child: Container(
                        height: 18,
                        color: Colors.grey[300], // Placeholder color
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 10),
                // Replace this with shimmer placeholder for button
                Container(
                  width: double.infinity,
                  height: 80,
                  color: Colors.grey[300], // Placeholder color
                ),
                10.verticalSpace,
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      width: 150,
                      height: 30,
                      color: Colors.grey[300], // Placeholder color
                    ),
                    Container(
                      width: 60,
                      height: 60,
                      color: Colors.grey[300], // Placeholder color
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 150,
                      height: 20,
                      color: Colors.grey[300], // Placeholder color
                    ),
                    10.verticalSpace,
                    Container(
                      height: 50,
                      color: Colors.grey[300], // Placeholder color
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget quotesListSkeleton() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          height: 200,
          width: double.maxFinite,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(15),
          ),
        ),
        20.verticalSpace,
        Container(
          height: 20,
          width: 60,
          margin: EdgeInsets.only(left: 10),
          decoration: BoxDecoration(
            color: Colors.white,
          ),
        ),
        20.verticalSpace,
        Container(
          height: 40,
          margin: EdgeInsets.only(left: 10),
          decoration: BoxDecoration(
            color: Colors.white,
          ),
        ),
      ],
    );
  }

  Widget smallProfileViewSkeleton() {
    return Column(
      children: [
        10.verticalSpace,
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              width: 120, // Adjust width as needed for the shimmer effect
              height: 20, // Adjust height as needed for the shimmer effect
              color: Colors.white, // Color of shimmering text container
            ),
            Container(
              width: 120, // Adjust width as needed for the shimmer effect
              height: 20, // Adjust height as needed for the shimmer effect
              color: Colors.white, // Color of shimmering star icon container
            ),
          ],
        ),
        10.verticalSpace,
        Divider(
          thickness: 1.5,
          color: AppColors.GREY_COLOR,
        ),
      ],
    );
  }

  Widget getFaqsSkeleton() {
    return Container(
      height: 150,
      width: double.maxFinite,
      decoration: BoxDecoration(
        color: AppColors.GREY_COLOR,
        borderRadius: BorderRadius.circular(10.r),
      ),
    );
  }

  Widget reviewRatingPageSkeleton() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Center(
          child: Container(
            width: 150, // Adjust width as needed for the shimmer effect
            height: 30, // Adjust height as needed for the shimmer effect
            color: Colors.white, // Color of shimmering text container
          ),
        ),
        10.verticalSpace,
        Center(
          child: Container(
            width: 80,
            height: 40,
            color: Colors.white,
          ),
        ),
        10.verticalSpace,
        Center(
          child: Container(
            width: 150,
            height: 30,
            color: Colors.white, // Color of shimmering text container
          ),
        ),
        10.verticalSpace,
        Center(
          child: Container(
            width: 200, // Adjust width as needed for the shimmer effect
            height: 30, // Adjust height as needed for the shimmer effect
            color: Colors.white, // Color of shimmering text container
          ),
        ),
        10.verticalSpace,
        Divider(
          thickness: 2,
        ),
        10.verticalSpace,
        ...List.generate(
          3,
          (index) => Column(
            children: [
              Container(
                padding: EdgeInsets.all(8.0),
                decoration: BoxDecoration(
                    border: Border.all(color: AppColors.RED_GMAIL_COLOR),
                    borderRadius: BorderRadius.circular(10.r)),
                child: Column(
                  children: [
                    Row(
                      children: [
                        CircleAvatar(
                          radius: 25,
                        ),
                        10.horizontalSpace,
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 120,
                              height: 20,
                              color: Colors.white,
                            ),
                            10.verticalSpace,
                            Row(
                              children: [
                                Container(
                                  width: 80,
                                  height: 20,
                                  color: Colors.white,
                                ),
                                10.horizontalSpace,
                                Container(
                                  width: 20,
                                  height: 20,
                                  color: Colors.white,
                                ),
                              ],
                            ),
                          ],
                        ),
                        Spacer(),
                        Container(
                          width: 10,
                          height: 35,
                          color: Colors.white,
                        ),
                      ],
                    ),
                    20.verticalSpace,
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 200,
                          height: 20,
                          margin: EdgeInsets.only(left: 10),
                          color: Colors.white,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              10.verticalSpace,
            ],
          ),
        ),
      ],
    );
  }

  Widget chatListSkeleton() {
    return Padding(
      padding: EdgeInsets.only(bottom: 12.0),
      child: Shimmer.fromColors(
        baseColor: Colors.grey[300]!,
        highlightColor: Colors.grey[100]!,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            singleMessgeChatShimmerBody(),
          ],
        ),
      ),
    );
  }

  Widget singleMessgeChatShimmerBody() {
    return Column(
      children: [
        ...List.generate(
          6,
          (index) {
            if (index.isOdd) {
              return Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Container(
                          width: 80,
                          height: 20,
                          color: Colors.white,
                          margin: EdgeInsets.only(right: 10),
                        ),
                        10.verticalSpace,
                        Container(
                          width: Get.width / 2,
                          height: 40,
                          margin: EdgeInsets.only(right: 10),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        10.verticalSpace,
                        Container(
                          width: 80,
                          height: 20,
                          color: Colors.white,
                          margin: EdgeInsets.only(right: 10),
                        ),
                      ],
                    ),
                  ),
                  10.verticalSpace,
                  CircleAvatar(
                    radius: 30,
                  ),
                ],
              );
            } else {
              // Handle even index (if needed)
              return Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 30,
                  ),
                  10.verticalSpace,
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Container(
                          width: 80,
                          height: 20,
                          color: Colors.white,
                          margin: EdgeInsets.only(left: 10),
                        ),
                        10.verticalSpace,
                        Container(
                          width: Get.width / 2,
                          height: 40,
                          margin: EdgeInsets.only(left: 10),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        10.verticalSpace,
                        Container(
                          width: 80,
                          height: 20,
                          color: Colors.white,
                          margin: EdgeInsets.only(left: 10),
                        ),
                      ],
                    ),
                  ),
                ],
              );
            }
          },
        )
      ],
    );
  }

  Widget notificationListPageSkeleton() {
    return Container(
      height: 120,
      width: double.maxFinite,
      decoration: BoxDecoration(
        color: AppColors.GREY_COLOR,
        borderRadius: BorderRadius.circular(10.r),
      ),
    );
  }
}
