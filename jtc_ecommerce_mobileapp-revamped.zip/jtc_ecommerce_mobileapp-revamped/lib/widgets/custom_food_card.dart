import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/widgets/custom_extended_image.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';

class CustomFoodCard extends StatelessWidget {
  CustomFoodCard({
    super.key,
    this.width,
    this.badgePadding,
    this.prodcutName,
    this.productToken,
    this.totalPrice,
    this.productImage,
    this.isFavourite = false,
    this.onTapFav,
    this.onTapAddToCart,
    required this.prodcutDescription,
  });

  final double? width;
  final double? badgePadding;
  final String? prodcutName;
  final String? productToken;
  final String? totalPrice;
  final String? productImage;
  final String? prodcutDescription;
  bool isFavourite;
  Function()? onTapFav;
  Function()? onTapAddToCart;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(8.0),
      // width: 220.w,
      width: width ?? 220.w,
      decoration: BoxDecoration(
        color: Color(0xFFF6F6F6),
        // color: Colors.redAccent,
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Stack(
            children: [
              food_image_container(),
              Positioned(
                right: 15.w,
                child: token_badge(
                    icon: AssetPaths.LOGO,
                    // tokens: '100',
                    tokens: productToken ?? ""),
              )
            ],
          ),
          10.verticalSpace,
          //1st
          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 14.0,
              vertical: 5.0,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    // "CAPPUCCINO",
                    prodcutName ?? "",
                    maxLines: 1,
                    style: TextStyle(
                      color: AppColors.RED_GMAIL_COLOR,
                      overflow: TextOverflow.ellipsis,
                      // fontSize: 16.sp,
                      fontSize: 18.sp,
                      fontWeight: FontWeight.normal,
                    ),
                  ),
                ),
                heart_icon(),
              ],
            ),
          ),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14.0, vertical: 1),
            child: SizedBox(
              // width: 80,
              child: Text(
                // "CAPPUCCINO",
                prodcutDescription ?? "",
                maxLines: 2,
                style: TextStyle(
                  color: AppColors.GREY_COLOR,
                  overflow: TextOverflow.ellipsis,
                  // fontSize: 16.sp,
                  fontSize: 14.sp,
                ),
              ),
            ),
          ),
          10.verticalSpace,
          //2nd
          Padding(
            padding: EdgeInsets.symmetric(
              horizontal: 14.0,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Container(
                      height: 25.h,
                      width: 25.w,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(40.r),
                        color: Color(0xFFE6262B),
                      ),
                      child: Center(
                        child: Text(
                          "\$",
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                    Text(
                      " $totalPrice",
                      style: TextStyle(
                          color: AppColors.RED_GMAIL_COLOR,
                          fontSize: 16.sp,
                          fontWeight: FontWeight.bold),
                    ),
                  ],
                ),

                // Inserting a Horizontal Divider (line)
                Expanded(
                  child: Container(
                    margin: EdgeInsets.symmetric(
                        horizontal: 10.0), // Adjusts the spacing
                    height: 1.0, // Height of the horizontal line
                    color: Colors.grey[300], // Color of the line
                  ),
                ),

                GestureDetector(
                  onTap: onTapAddToCart,
                  child: Container(
                    height: 25.h,
                    width: 25.w,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(40.r),
                      color: Color(0xFFE6262B),
                    ),
                    child: Center(
                      child: Padding(
                        padding: const EdgeInsets.all(4.0),
                        child: Image.asset(
                          AssetPaths.CART_ICON_BOTTOM_NAVIGAITON,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          10.verticalSpace,
          //Button

          // 5.verticalSpace,
        ],
      ),
    );
  }

  Container token_badge({
    required String icon,
    double? icon_height,
    required String tokens,
    Color? color,
    double? horizontal,
  }) {
    return Container(
      //saad
      // height: badgeHeigth ?? 30.h,
      // width: badgeWidth ?? 60.w,
      width: 80.w,
      padding: EdgeInsets.all(badgePadding ?? 4),
      decoration: BoxDecoration(
        color: Color(0xFFB41317),
        borderRadius: BorderRadius.only(
            bottomLeft: Radius.circular(12.r),
            bottomRight: Radius.circular(12.r)),
      ),
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: horizontal ?? 6.0),
        child: Center(
          child: Row(
            children: [
              Image.asset(
                icon,
                height: icon_height ?? 8.h,
                color: AppColors.WHITE_COLOR,
              ),
              2.horizontalSpace,
              Text(
                tokens,
                style: TextStyle(color: AppColors.WHITE_COLOR),
              )
            ],
          ),
        ),
      ),
    );
  }

  Container food_image_container() {
    return Container(
      height: 135.h,
      width: Get.width,
      decoration: BoxDecoration(
        color: Colors.white,
        // color: Colors.greenAccent,
        borderRadius: BorderRadius.circular(15),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(15),
        child: CustomExtendedImageWidget(
          imagePath: productImage,
          imageType: "network",
          fit: BoxFit.cover,
          imagePlaceholder: "assets/images/no_image.png",
        ),
      ),
    );
  }

  Widget heart_icon() {
    return GestureDetector(
      onTap: onTapFav,
      child: isFavourite
          ? Container(
              height: 22.h,
              width: 22.w,
              decoration: BoxDecoration(
                  border: Border.all(color: Colors.red),
                  borderRadius: BorderRadius.circular(22.r)),
              child: Padding(
                padding: const EdgeInsets.all(4.0),
                child: Image.asset(
                  AssetPaths.FILLED_HEART_ICON,
                  scale: 2.5.sp,
                  color: AppColors.PRIMARY_COLOR,
                ),
              ),
            )
          : Container(
              // margin: EdgeInsets.all(12),
              height: 22.h,
              width: 22.w,

              decoration: BoxDecoration(
                  border: Border.all(color: Colors.red),
                  borderRadius: BorderRadius.circular(22.r)),
              child: Image.asset(
                AssetPaths.HEART_ICON,
                scale: 1.5.sp,
                color: AppColors.PRIMARY_COLOR,
              ),
            ),
    );
  }
}
