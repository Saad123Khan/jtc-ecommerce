import 'dart:developer';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';

class StripeService {
  static CardDetails? _cardDetails;
  static TokenData? _tokenData;
  static Future<String?>? stripeToken(
      {String? cardNumber, int? expMonth, int? expYear, String? cvc}) async {
    String? cardToken;
    try {
      _cardDetails = CardDetails(
        number: cardNumber.toString(),
        // expirationMonth: int.parse(expMonth ?? "0"),
        // expirationYear: int.parse(expYea r ?? "0"),
        expirationMonth: expMonth,
        expirationYear: expYear,
        cvc: cvc ?? "",
      );
      logData(message: "_card: ${_cardDetails?.toJson().toString()}");
      Stripe.instance.dangerouslyUpdateCardDetails(_cardDetails!);
      _tokenData = await Stripe.instance
          .createToken(const CreateTokenParams.card(params: CardTokenParams()));
      print("Token Data: $_tokenData");
      cardToken = _tokenData?.id.toString();
    } on StripeException catch (ex) {
      // Get.back();
      AppDialogs.showToast(message: ex.error.message ?? "");
      log(ex.error.message.toString());
    } catch (ex) {
      log(ex.toString());
      // Get.back();
      AppDialogs.showToast(message: ex.toString());
    }
    return cardToken;
  }
}
