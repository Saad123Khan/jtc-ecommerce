import 'dart:developer';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
// import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:jtc_ecommerce/auth/blocs/social_login_bloc.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_strings.dart';
import 'package:sign_in_with_apple/sign_in_with_apple.dart';
import 'package:get/get.dart' as GetxController;
// import 'package:recovery_rtg_hybrid/common/auth/blocs/social_login_bloc.dart';
// import 'package:recovery_rtg_hybrid/common/auth/routing_arguments/otp_arguments.dart';
// import 'package:recovery_rtg_hybrid/utils/app_dialogs.dart';
// import 'package:recovery_rtg_hybrid/utils/app_navigation.dart';
// import 'package:recovery_rtg_hybrid/utils/app_route_name.dart';
// import 'package:recovery_rtg_hybrid/utils/app_strings.dart';
// import 'package:recovery_rtg_hybrid/utils/extension.dart';
// import 'package:sign_in_with_apple/sign_in_with_apple.dart';

class FirebaseAuthBloc {
  FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  UserCredential? _userCredential;
  User? _user;
  SocialLoginBloc _socialLoginBloc = SocialLoginBloc();
  // String? _facebookUserName;

  ///-------------------- Google Sign In -------------------- ///
  Future<void> signInWithGoogle({required BuildContext context}) async {
    try {
      GoogleSignIn _googleSignIn = GoogleSignIn(
        scopes: ['email'],
      );
      GoogleSignInAccount? _googleSignInAccount = await _googleSignIn.signIn();
      if (_googleSignInAccount != null) {
        await _googleSignIn.signOut();
        String? displayName = _googleSignInAccount.displayName;
        if (displayName != null) {
          List<String> nameParts = displayName.split(' ');
          String firstName = nameParts[0];
          String lastName =
              nameParts.length > 1 ? nameParts.sublist(1).join(' ') : '';
          log("First name: $firstName");
          log("Last name: $lastName");
          log("Social id: ${_googleSignInAccount.id}");
          log("Social email: ${_googleSignInAccount.email}");
          _socialLoginMethod(
            context: context,
            firstName: firstName,
            lastName: lastName,
            email: _googleSignInAccount.email,
            socialToken: _googleSignInAccount.id,
            socialType: AppStrings.GOOGLE_SOCIAL_TYPE,
          );
        }
      }
    } catch (error) {
      log(error.toString());
      AppDialogs.showToast(message: error.toString());
    }
  }

  //!new

  // Future<void> signInWithGoogle({required BuildContext context}) async {
  //   try {
  //     GoogleSignIn _googleSignIn = GoogleSignIn(
  //       scopes: ['email', 'profile'],
  //     );
  //     GoogleSignInAccount? _googleSignInAccount = await _googleSignIn.signIn();
  //     if (_googleSignInAccount != null) {
  //       String? displayName = _googleSignInAccount.displayName;

  //       GoogleSignInAuthentication googleAuth =
  //           await _googleSignInAccount.authentication;
  //       String? accessToken = googleAuth.accessToken;
  //       String? idToken = googleAuth.idToken;

  //       // print(accessToken);
  //       print(idToken);
  //       // print(_googleSignIn.currentUser?.displayName);

  //       if (idToken != null) {
  //         GoogleLoginBloc().googleLoginBlocMethod(
  //           context: context,
  //           tokenId: idToken,
  //           setProgressBar: () {
  //             AppDialogs.progressAlertDialog(context: context);
  //           },
  //         );
  //       }
  //     }
  //   } catch (error) {
  //     print(error.toString());
  //     AppDialogs.showToast(message: error.toString());
  //     // Rest of your error handling...
  //   }
  // }

  ///-------------------- Facebook Sign In -------------------- ///
  // Future<void> signInWithFacebook({required BuildContext context}) async {
  //   try {
  //     final LoginResult result = await FacebookAuth.instance.login(
  //       permissions: ['public_profile', 'email'],
  //     );
  //     if (result.status == LoginStatus.success) {
  //       // log("Graph response body" + graphResponse.body.toString());
  //       Map<String, dynamic> facebookUserData =
  //           await FacebookAuth.instance.getUserData();
  //       await FacebookAuth.instance.logOut();
  //       if (facebookUserData != null) {
  //         log("Facebook User Data:${facebookUserData.toString()}");
  //         _facebookUserName = facebookUserData["name"];
  //         _socialLoginMethod(
  //             context: context,
  //             firstName: _facebookUserName?.splitName()[0],
  //             lastName: _facebookUserName?.splitName()[1],
  //             email: facebookUserData["email"],
  //             socialToken: facebookUserData["id"],
  //             socialType: AppStrings.FACEBOOK_SOCIAL_TYPE);
  //       }
  //     } else if (result.status == LoginStatus.failed) {
  //       AppDialogs.showToast(message: result.message.toString());
  //       //print(result.message.toString());
  //     } else if (result.status == LoginStatus.cancelled) {
  //       AppDialogs.showToast(message: result.message.toString());
  //       //print(result.message.toString());
  //     }
  //   } catch (error) {
  //     // print(error.toString());
  //     AppDialogs.showToast(message: error.toString());
  //   }
  // }

  ///-------------------- Apple Sign In -------------------- ///
  Future<void> signInWithApple({required BuildContext context}) async {
    try {
      final credential = await SignInWithApple.getAppleIDCredential(
        scopes: [
          AppleIDAuthorizationScopes.email,
          AppleIDAuthorizationScopes.fullName,
        ],
      );
      if (credential != null) {
        _socialLoginMethod(
            context: context,
            firstName: credential.givenName,
            lastName: credential.familyName,
            email: credential.email,
            socialToken: credential.userIdentifier,
            socialType: AppStrings.APPLE_SOCIAL_TYPE);
      }
    } catch (error) {
      AppDialogs.showToast(message: error.toString());
    }
  }

  ///-------------------- Sign In Phone -------------------- ///
  Future<void> signInWithPhone(
      {required BuildContext context,
      required String countryCode,
      required String phoneNumber,
      required VoidCallback setProgressBar,
      required VoidCallback cancelProgressBar}) async {
    try {
      // final authController = GetxController.Get.find<AuthController>();
      // setProgressBar();
      // FirebaseAuth.instance.verifyPhoneNumber(
      //     phoneNumber: countryCode + phoneNumber,
      //     timeout: Duration(seconds: 60),
      //     verificationCompleted: (AuthCredential authCredential) async {},
      //     verificationFailed: (FirebaseAuthException authException) {
      //       if (authException.code == AppStrings.INVALID_PHONE_NUMBER) {
      //         cancelProgressBar();
      //         AppDialogs.showToast(
      //             message: AppStrings.INVALID_PHONE_NUMBER_MESSAGE);
      //       } else {
      //         cancelProgressBar();
      //         AppDialogs.showToast(message: authException.message);
      //       }
      //     },
      //     codeSent: (String verificationId, int? forceResendingToken) {
      //       cancelProgressBar();
      //       // authController.phoneController.text = "";
      //       Get.find<AuthController>().verificationId =
      //           verificationId.toString();
      //       AppNavigation.navigateTo(
      //         context,
      //         AppRouteName.OTP_VERIFICATION_SCREEN,
      //       );
      //     },
      //     codeAutoRetrievalTimeout: (String verificationId) {});
    } catch (error) {
      log("error");
      cancelProgressBar();
      AppDialogs.showToast(message: error.toString());
    }
  }

  ///-------------------- Verify Phone No -------------------- ///
  Future<void> verifyPhoneCode(
      {required BuildContext context,
      String? countryCode,
      String? phoneNo,
      required String verificationId,
      required String verificationCode}) async {
    try {
      AuthCredential _credential = PhoneAuthProvider.credential(
          verificationId: verificationId, smsCode: verificationCode);
      _userCredential = await _firebaseAuth.signInWithCredential(_credential);
      _user = _userCredential?.user;
      if (_user != null) {
        await _firebaseUserSignOut();
        _socialLoginMethod(
          context: context,
          phoneNo: phoneNo,
          countryCode: countryCode,
          socialToken: _user?.uid,
          socialType: AppStrings.PHONE_SOCIAL_TYPE,
        );
      }
    } catch (error) {
      AppDialogs.showToast(message: error.toString());
    }
  }

  ///-------------------- Resend Code for Phone No -------------------- ///
  Future<void> resendPhoneCode(
      {required BuildContext context,
      required String countryCode,
      required String phoneNumber,
      required ValueChanged<String?> getVerificationId,
      required VoidCallback setProgressBar,
      required VoidCallback cancelProgressBar}) async {
    setProgressBar();
    try {
      _firebaseAuth.verifyPhoneNumber(
          phoneNumber: countryCode + phoneNumber,
          timeout: Duration(seconds: 60),
          verificationCompleted: (AuthCredential authCredential) async {},
          verificationFailed: (FirebaseAuthException authException) {
            cancelProgressBar();
            AppDialogs.showToast(message: authException.message);
          },
          codeSent: (String verificationId, int? forceResendingToken) {
            cancelProgressBar();
            getVerificationId(verificationId);
          },
          codeAutoRetrievalTimeout: (String verificationId) {
            log(verificationId.toString());
          });
    } catch (error) {
      cancelProgressBar();
      AppDialogs.showToast(message: error.toString());
    }
  }

  ///-------------------- Sign out from firebase -------------------- ///
  Future<void> _firebaseUserSignOut() async {
    await _firebaseAuth.signOut();
  }

  ///-------------------- Social Login API -------------------- ///
  void _socialLoginMethod({
    required BuildContext context,
    String? firstName,
    String? lastName,
    String? email,
    String? phoneNo,
    String? countryCode,
    String? socialToken,
    String? socialType,
  }) {
    log("First Name:${firstName}");
    log("Last Name:${lastName}");
    log("Email :${email}");
    log("Phone No:${phoneNo}");
    log("Country Code:${countryCode}");
    log("Social token:${socialToken}");
    log("Social type:${socialType}");
    _socialLoginBloc.socialLoginBlocMethod(
        context: context,
        provider: socialType,
        socialToken: socialToken,
        firstName: firstName ?? "",
        lastName: lastName ?? "",
        userEmail: email,
        phoneNumber: phoneNo,
        countryCode: countryCode,
        setProgressBar: () {
          AppDialogs.progressAlertDialog(context: context);
        });
  }
}
