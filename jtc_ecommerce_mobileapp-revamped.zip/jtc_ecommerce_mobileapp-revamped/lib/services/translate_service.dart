import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:translator/translator.dart';

class GoogleTranslatorService {
  // Private constructor
  GoogleTranslatorService._privateConstructor();

  // The single instance of the class
  static final GoogleTranslatorService _instance =
      GoogleTranslatorService._privateConstructor();

  // Factory constructor to return the same instance
  factory GoogleTranslatorService() {
    return _instance;
  }

  GoogleTranslator _googleTranslator = GoogleTranslator();

  // Method to translate text from English to Spanish

  Future<String> translate(
      {required String text, required BuildContext context}) async {
    try {
      final Translation translation = await _googleTranslator.translate(text,
          to: context.locale.languageCode); 
      return translation.text;
    } catch (error) {
      return '';
    }
  }
}
