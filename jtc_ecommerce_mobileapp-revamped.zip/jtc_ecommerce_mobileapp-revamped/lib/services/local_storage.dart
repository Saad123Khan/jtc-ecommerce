import 'package:jtc_ecommerce/utils/app_strings.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SharedPreference {
  static SharedPreference? _sharedPreferenceHelper;
  static SharedPreferences? _sharedPreferences;

  SharedPreference._createInstance();

  factory SharedPreference() {
    if (_sharedPreferenceHelper == null) {
      _sharedPreferenceHelper = SharedPreference._createInstance();
    }
    return _sharedPreferenceHelper!;
  }

  Future<SharedPreferences> get sharedPreference async {
    if (_sharedPreferences == null) {
      _sharedPreferences = await SharedPreferences.getInstance();
    }
    return _sharedPreferences!;
  }

  void clear() {
    _sharedPreferences!.clear();
    SharedPreference().setViewOnBoardingScreen(viewOnBoarding: true);
  }

  //! ============> Bearer Token
  void setBearerToken({String? token}) {
    _sharedPreferences!.setString(AppStrings.BEARER_TOKEN_KEY, token ?? "");
  }

  String? getBearerToken() {
    return _sharedPreferences!.getString(AppStrings.BEARER_TOKEN_KEY);
  }

  //! ============> Bearer Token
  void setStore({String? token}) {
    _sharedPreferences!.setString(AppStrings.STORE_KEY, token ?? "");
  }

  String? getStore() {
    return _sharedPreferences!.getString(AppStrings.STORE_KEY);
  }

  //! ============> User
  void setUser({String? user}) {
    _sharedPreferences!.setString(AppStrings.CURRENT_USER_DATA_KEY, user ?? "");
  }

  String? getUser() {
    return _sharedPreferences!.getString(AppStrings.CURRENT_USER_DATA_KEY);
  }

  void setViewOnBoardingScreen({bool? viewOnBoarding}) {
    _sharedPreferences?.setBool(
        AppStrings.VIEW_ONBOARDING_DATA_KEY, viewOnBoarding!);
  }

  bool? getViewOnBoardingScreen() {
    return _sharedPreferences?.getBool(AppStrings.VIEW_ONBOARDING_DATA_KEY);
  }

  //! ============> Notification Message Id
  void setNotificationMessageId({String? messageId}) {
    _sharedPreferences!
        .setString(AppStrings.NOTIFICATION_MESSAGE_ID_KEY, messageId ?? "");
  }

  String? getNotificationMessageId() {
    return _sharedPreferences!
        .getString(AppStrings.NOTIFICATION_MESSAGE_ID_KEY);
  }

  void setLanguage({required String languageCode}) async {
    await _sharedPreferences!.setString(AppStrings.LANGUAGE_KEY, languageCode);
  }

  String? getLanguage() {
    return _sharedPreferences!.getString(AppStrings.LANGUAGE_KEY);
  }
}
