import 'dart:developer';
import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as Getx;
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/auth_singleton.dart';
import 'package:jtc_ecommerce/services/connectivity_manager.dart';
import 'package:jtc_ecommerce/services/local_storage.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';
import 'package:jtc_ecommerce/utils/constants.dart';
import 'package:pretty_dio_logger/pretty_dio_logger.dart';

import '../utils/enums.dart';

class Network {
  static Dio? _dio;
  static CancelToken? _cancelRequestToken;

  static Network? _network;

  static ConnectivityManager? _connectivityManager;

  Network._createInstance();

  factory Network() {
    //! ============> factory with constructor, return some value
    if (_network == null) {
      _network = Network
          ._createInstance(); //! ============> This is executed only once, singleton object

      _dio = _getDio();
      _dio?.interceptors.add(PrettyDioLogger(
        requestHeader: true,
        requestBody: true,
        responseBody: true,
        responseHeader: false,
        error: true,
        compact: true,
        maxWidth: 90,
        enabled: kDebugMode,
      ));
      _cancelRequestToken = _getCancelToken();

      _connectivityManager = ConnectivityManager();
    }
    return _network!;
  }

  static Dio _getDio() {
    // BaseOptions options = new BaseOptions(
    //   connectTimeout: 20000,
    // );
    return _dio ??= Dio();
  }

  static CancelToken _getCancelToken() {
    return _cancelRequestToken ??= CancelToken();
  }

  ////////////////// Get Request /////////////////////////
  Future<Response?> getRequest(
      {required BuildContext context,
      required String endPoint,
      Map<String, dynamic>? queryParameters,
      VoidCallback? onFailure,
      bool isToast = true,
      bool isErrorToast = true,
      bool customFailure = false,
      int connectTimeOut = 20000,
      required bool isHeaderRequire}) async {
    Response? response;
    logData(message: "endPoint: ${endPoint}");
    if (await _connectivityManager!.isInternetConnected()) {
      try {
        _dio?.options.connectTimeout = Duration(seconds: 60);
        response = await _dio!.get(NetworkStrings.API_BASE_URL + endPoint,
            queryParameters: queryParameters,
            cancelToken: _cancelRequestToken,
            options: Options(
              headers: _setHeader(isHeaderRequire: isHeaderRequire),
              sendTimeout: Duration(seconds: connectTimeOut),
              receiveTimeout: Duration(seconds: connectTimeOut),
            ));
        //print(response);
        // logData(message: "Response of Get: $response");
      } on DioError catch (e) {
        log("Error:${e.response.toString()}");
        response = e.response;
        if (!customFailure) {
          _validateException(
              response: e.response,
              context: context,
              message: e.message,
              onFailure: onFailure,
              isToast: isToast,
              isErrorToast: isErrorToast);
        } else {
          return response;
        }
      }
    } else {
      _noInternetConnection(onFailure: onFailure);
    }

    return response;
  }

  ////////////////// Post Request /////////////////////////
  Future<Response?> postRequest({
    required BuildContext context,
    required String endPoint,
    dynamic formData,
    VoidCallback? onFailure,
    bool customFailure = false,
    bool isToast = true,
    int connectTimeOut = 60,
    bool isErrorToast = true,
    required bool isHeaderRequire,
  }) async {
    Response? response;
    logData(message: "URL: ${NetworkStrings.API_BASE_URL + endPoint}");
    if (await _connectivityManager!.isInternetConnected()) {
      try {
        _dio?.options.connectTimeout = Duration(seconds: connectTimeOut);
        response = await _dio?.post(
          NetworkStrings.API_BASE_URL + endPoint,
          data: formData,
          cancelToken: _cancelRequestToken,
          options: Options(
            // contentType: 'multipart/form-data',
            headers: _setHeader(isHeaderRequire: isHeaderRequire),
            sendTimeout: Duration(seconds: connectTimeOut),
            receiveTimeout: Duration(seconds: connectTimeOut),
          ),
        );
        logData(message: "Network Response: ${response}");
      } on DioError catch (e) {
        logData(message: "e: ${e}");
        response = e.response;
        if (!customFailure) {
          _validateException(
              response: e.response,
              context: context,
              message: e.message,
              onFailure: onFailure,
              isToast: isToast,
              isErrorToast: isErrorToast);
        } else {
          return response;
        }
      }
    } else {
      _noInternetConnection(onFailure: onFailure);
    }
    return response;
  }

  ////////////////// Post Request Raw Data /////////////////////////
  Future<Response?> postRequestRawData({
    required String endPoint,
    Map<String, dynamic>? body,
    VoidCallback? onFailure,
    bool isToast = true,
    bool customFailure = false,
    int connectTimeOut = 60,
    bool isErrorToast = true,
    required bool isHeaderRequire,
    required BuildContext context,
  }) async {
    Response? response;

    if (await _connectivityManager!.isInternetConnected()) {
      try {
        _dio?.options.connectTimeout = Duration(seconds: connectTimeOut);
        response = await _dio!.post(
          NetworkStrings.API_BASE_URL + endPoint,
          data: body,
          cancelToken: _cancelRequestToken,
          options: Options(
            headers: _setHeader(isHeaderRequire: isHeaderRequire),
            sendTimeout: Duration(seconds: connectTimeOut),
            receiveTimeout: Duration(seconds: connectTimeOut),
          ),
        );
        // logData(message: "Response: ${response}");
        logData(message: "Response: ${response.data}");
      } on DioError catch (e) {
        //   response=e.response;
        logData(message: "e: ${e}");
        response = e.response;
        if (!customFailure) {
          _validateException(
              response: e.response,
              context: context,
              message: e.message,
              onFailure: onFailure,
              isToast: isToast,
              isErrorToast: isErrorToast);
        } else {
          return response;
        }
        print("$endPoint Dio: " + e.message.toString());
      }
    } else {
      _noInternetConnection(
        onFailure: onFailure,
        // isErrorToast: isErrorToast,
      );
    }
    return response;
  }

  ////////////////// Put Request /////////////////////////
  Future<Response?> putRequest(
      {required BuildContext context,
      required String endPoint,
      Map<String, dynamic>? queryParameters,
      VoidCallback? onFailure,
      bool isToast = true,
      bool customFailure = false,
      int connectTimeOut = 60,
      bool isErrorToast = true,
      required bool isHeaderRequire}) async {
    Response? response;

    if (await _connectivityManager!.isInternetConnected()) {
      try {
        _dio?.options.connectTimeout = Duration(seconds: connectTimeOut);
        response = await _dio!.put(NetworkStrings.API_BASE_URL + endPoint,
            queryParameters: queryParameters,
            cancelToken: _cancelRequestToken,
            options: Options(
                headers: _setHeader(isHeaderRequire: isHeaderRequire),
                sendTimeout: Duration(seconds: connectTimeOut),
                receiveTimeout: Duration(seconds: connectTimeOut)));
        //print(response);
      } on DioError catch (e) {
        logData(message: "e: ${e}");
        response = e.response;
        if (!customFailure) {
          _validateException(
              response: e.response,
              context: context,
              message: e.message,
              onFailure: onFailure,
              isToast: isToast,
              isErrorToast: isErrorToast);
        } else {
          return response;
        }
      }
    } else {
      _noInternetConnection(onFailure: onFailure);
    }

    return response;
  }

  ////////////////// Delete Request /////////////////////////
  Future<Response?> deleteRequest(
      {required BuildContext context,
      required String endPoint,
      Map<String, dynamic>? queryParameters,
      bool customFailure = false,
      VoidCallback? onFailure,
      bool isToast = true,
      int connectTimeOut = 60,
      bool isErrorToast = true,
      required bool isHeaderRequire}) async {
    Response? response;
    if (await _connectivityManager!.isInternetConnected()) {
      try {
        _dio?.options.connectTimeout = Duration(seconds: connectTimeOut);
        response = await _dio!.delete(NetworkStrings.API_BASE_URL + endPoint,
            queryParameters: queryParameters,
            cancelToken: _cancelRequestToken,
            options: Options(
                headers: _setHeader(isHeaderRequire: isHeaderRequire),
                sendTimeout: Duration(seconds: connectTimeOut),
                receiveTimeout: Duration(seconds: connectTimeOut)));
        print(response.toString());
      } on DioError catch (e) {
        response = e.response;
        if (!customFailure) {
          _validateException(
              response: e.response,
              context: context,
              message: e.message,
              onFailure: onFailure,
              isToast: isToast,
              isErrorToast: isErrorToast);
        } else {
          return response;
        }
      }
    } else {
      _noInternetConnection(onFailure: onFailure);
    }
    return response;
  }

  ////////////////// Set Header /////////////////////
  _setHeader({required bool isHeaderRequire}) {
    if (isHeaderRequire == true) {
      String token = SharedPreference().getBearerToken() ?? "";
      logData(message: "Token: $token");
      return {
        'Accept': NetworkStrings.ACCEPT,
        'Authorization': "Bearer $token",
      };
    } else {
      return {
        'Accept': NetworkStrings.ACCEPT,
      };
    }
  }

////////////////// Validate Response /////////////////////
  void validateResponse({
    context,
    Response? response,
    VoidCallback? onSuccess,
    VoidCallback? onFailure,
    bool isToast = true,
  }) {
    var validateResponseData = response?.data;

    if (validateResponseData != null) {
      isToast
          ? AppDialogs.showToast(message: validateResponseData['message'] ?? "")
          : null;

      if (response!.statusCode == NetworkStrings.SUCCESS_CODE) {
        if (validateResponseData['status'] == true) {
          if (onSuccess != null) {
            onSuccess();
          }
        } else {
          if (onFailure != null) {
            onFailure();
          }
        }
      } else if (response.statusCode == 401) {
        // Handle 401 Unauthenticated error here
        final authSingletonUserRole = AuthSingletonUserRole();

        authSingletonUserRole.userLoggedInUsingEmail = "";
        authSingletonUserRole.userLoggedInUsingPhone = "";
        authSingletonUserRole.countryCode = "";
        authSingletonUserRole.countryNumCode = "";
        authSingletonUserRole.switchValue = SwitchValue.none;
        SharedPreference().clear();

        AppNavigation.navigateToRemovingAll(
          Constants.navigatorKey.currentContext!,
          AppRouteName.LOGIN_SCREEN_ROUTE,
        );
      } else if (response.statusCode == 500) {
        // Handle 500 Server Error here
        AppDialogs.showToast(message: tr(NetworkStrings.NO_INTERNET));
        // : null;

        if (onFailure != null) {
          onFailure();
        }
      } else {
        if (onFailure != null) {
          onFailure();
        }
        // log(response.statusCode.toString());
      }
    }
  }

// ////////////////// Clear Local Storage and Navigate to Login Screen /////////////////////
// void clearLocalStorageAndNavigateToLoginScreen() {
//   // Clear local storage here
//   SharedPreference().clear();

//   // Navigate to login screen
//   AppNavigation.navigateTo(
//     context,
//     AppRouteName.LOGIN_SCREEN_ROUTE,
//   );
// }
  ////////////////// Stripe Validate Response /////////////////////
  void stripeValidateResponse(
      {Response? response, VoidCallback? onSuccess, VoidCallback? onFailure}) {
    var validateResponseData = response?.data;

    if (validateResponseData != null) {
      if (response!.statusCode == NetworkStrings.SUCCESS_CODE) {
        if (onSuccess != null) {
          onSuccess();
        }
      } else {
        if (onFailure != null) {
          onFailure();
        }
        //log(response.statusCode.toString());
      }
    }
  }

  ////////////////// Validate Response /////////////////////
  void validateGifResponse(
      {Response? response, VoidCallback? onSuccess, VoidCallback? onFailure}) {
    var validateResponseData = response?.data;

    if (validateResponseData != null) {
      if (response!.statusCode == NetworkStrings.SUCCESS_CODE) {
        if (onSuccess != null) {
          onSuccess();
        }
      }
    } else {
      if (onFailure != null) {
        onFailure();
      }
      //log(response!.statusCode!.toString());
    }
  }

  ////////////////// Validate Exception /////////////////////
  void _validateException(
      {required BuildContext context,
      Response? response,
      String? message,
      bool normalRequest = true,
      bool isToast = true,
      bool isErrorToast = true,
      VoidCallback? onFailure}) {
    if (onFailure != null) {
      onFailure();
    }

    if (response?.statusCode == 422) {
      if (response?.data["message"] != null) {
        AppDialogs.showToast(message: response?.data["message"]);
        return;
      }
    }

    if (response?.statusCode == NetworkStrings.CARD_ERROR_CODE) {
      AppDialogs.showToast(
          message: response?.data["error"]["message"] != null
              ? response?.data["error"]["message"]
              : NetworkStrings.INVALID_CARD_ERROR);
    } else if (response?.statusCode == NetworkStrings.BAD_REQUEST_CODE) {
      //to check normal api or stripe bad request time
      if (normalRequest == true) {
        //for normal api request error
        isToast
            ? AppDialogs.showToast(message: response?.data["message"] ?? "")
            : null;
      } else {
        //for stripe bad request error
        AppDialogs.showToast(
            message: response?.data["error"]["message"] != null
                ? response?.data["error"]["message"]
                : NetworkStrings.INVALID_BANK_ACCOUNT_DETAILS_ERROR);
      }
    } else if (response?.statusCode == NetworkStrings.FORBIDDEN_CODE) {
      //to check normal api or stripe bad request error
      AppDialogs.showToast(message: response?.data["message"] ?? "");
    } else if (response?.statusCode == NetworkStrings.Unprocessable_CODE) {
      // AppDialogs.showToast(message: response?.data["message"] ?? "");
      // if (Getx.Get.currentRoute == AppRouteName.LOGIN_SCREEN_ROUTE) {
      //   // AppNavigation.navigateTo(context, AppRouteName.VERIFY_OTP_SCREEN_ROUTE);
      //   // Getx.Get.find<AuthController>().ver
      // } else {
      //   AppDialogs.showToast(message: response?.data["message"] ?? "");
      // }
    } else if (response?.statusCode == 404) {
      //to check normal api or stripe bad request error
      AppDialogs.showToast(message: response?.data["message"] ?? "");
    } else {
      isErrorToast
          ? AppDialogs.showToast(
              message: response?.statusMessage ?? message.toString())
          : null;
    }
    if (response?.statusCode == NetworkStrings.UNAUTHORIZED_CODE) {
      //NEW
      // final AuthSingletonUserRole _authSingletonUserRole =
      //     AuthSingletonUserRole();
      // _authSingletonUserRole.userLoggedInUsingEmail = "";
      // _authSingletonUserRole.userLoggedInUsingPhone = "";
      // _authSingletonUserRole.countryCode = "";
      // _authSingletonUserRole.countryNumCode = "";
      // _authSingletonUserRole.switchValue = SwitchValue.none;
      // context.setLocale(Locale("en"));
      // // Getx.Get.find<LanguageController>().setSelectedLocale(Locale("en"));
      // Getx.Get.updateLocale(Locale("en"));
      // SharedPreference().clear();
      // AppNavigation.navigateToRemovingAll(
      //   context,
      //   AppRouteName.SOCIAL_LOGIN_SCREEN_ROUTE,
      // );
      final authSingletonUserRole = AuthSingletonUserRole();

      authSingletonUserRole.userLoggedInUsingEmail = "";
      authSingletonUserRole.userLoggedInUsingPhone = "";
      authSingletonUserRole.countryCode = "";
      authSingletonUserRole.countryNumCode = "";
      authSingletonUserRole.switchValue = SwitchValue.none;
      SharedPreference().clear();

      AppNavigation.navigateToRemovingAll(
        context,
        AppRouteName.LOGIN_SCREEN_ROUTE,
      );

      //OLD
      // AuthSingletonUserRole().userRole = UserRole.Default;
      // StaticData.clearAppDataMethod();
      /*    AppNavigation.navigateToRemovingAll(context, PreLoginScreen());
      SharedPreference().clear();

      Provider.of<UserProvider>(context,listen: false).setCurrentUser(user: null);*/
    }
  }

  ////////////////// No Internet Connection /////////////////////
  void _noInternetConnection({VoidCallback? onFailure}) {
    if (onFailure != null) {
      onFailure();
    }
    AppDialogs.showToast(message: tr(NetworkStrings.NO_INTERNET));
  }

// ////////////////// On TimeOut /////////////////////
  // void _onTimeOut({String? message, onFailure}) {
  //   if (onFailure != null) {
  //     onFailure();
  //   }
  //   AppDialogs.showToast(message: message);
  // }
}
