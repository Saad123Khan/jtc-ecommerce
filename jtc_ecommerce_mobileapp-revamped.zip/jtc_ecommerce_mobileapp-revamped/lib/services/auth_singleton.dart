
//Saving the selected value whether its Business OR Influencer for runtime.
import 'package:jtc_ecommerce/utils/enums.dart';

class AuthSingletonUserRole {
  static final AuthSingletonUserRole _singleton =
      AuthSingletonUserRole._internal();

  factory AuthSingletonUserRole() {
    return _singleton;
  }

  AuthSingletonUserRole._internal();

  SwitchValue? switchValue;

  String userLoggedInUsingEmail = '';
  String userLoggedInUsingPhone = '';

  //+1
  String countryCode = '';
  //US
  String countryNumCode = '';

}
