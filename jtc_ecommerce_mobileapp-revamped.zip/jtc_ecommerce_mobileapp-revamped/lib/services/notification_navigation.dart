import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/auth/models/user_model.dart';
import 'package:jtc_ecommerce/home/controllers/home_controller.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/auth_singleton.dart';
import 'package:jtc_ecommerce/services/local_storage.dart';
import 'package:jtc_ecommerce/settings/controllers/settings_controller.dart';
import 'package:jtc_ecommerce/splash/controllers/splash_controller.dart';
import 'package:jtc_ecommerce/splash/screens/components/store_setup_dialog.dart';
import 'package:jtc_ecommerce/splash/screens/model/store_list_model.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';
import 'package:jtc_ecommerce/utils/app_strings.dart';
import 'package:jtc_ecommerce/utils/constants.dart';

class NotificationNavigationClass {
  // UserProvider? _userProvider;
  // UserCompleteProfile? _userProvider;

  void notificationMethod(
      {required BuildContext context,
      Map<String, dynamic>? notificationData,
      String? pushNotificationType}) async {
    _setUserSession(context: context);
    _setNotificationCount(pushNotificationType: pushNotificationType);

    if (notificationData != null) {
      print("data is " + notificationData.toString());
      print("data type is " + notificationData["type"].toString());
      if (pushNotificationType == AppStrings.KILLED_NOTIFICATION) {
        await Future.delayed(
          Duration(seconds: 2),
        );

        AppNavigation.navigateToRemovingAll(
            context, AppRouteName.BOTTOM_NAVIGATION_SCREEN_ROUTE);

        handleNotification(
          context: context,
          notificationData: notificationData,
          type: notificationData["type"].toString(),
        );
      } else {
        handleNotification(
          context: context,
          notificationData: notificationData,
          type: notificationData["type"].toString(),
        );
      }
    } else {
      clearAppDataMethod(context: context);
    }
  }

  void checkUserSessionMethod({required BuildContext context}) {
    logData(message: "is user saved in shared preference?");
    final userJson = SharedPreference().getUser();
    final token = SharedPreference().getBearerToken();
    logData(message: "Token: $token");
    logData(message: "Saved User: ${userJson}");
    if (token != null && userJson != null) {
      final jsonResponse = jsonDecode(userJson);
      final UserData? _currentUser = UserData.fromJson(jsonResponse);
      logData(message: "_currentUser: ${_currentUser?.email}");
      if (_currentUser != null) {
        Get.find<SplashController>().currentUser.value = _currentUser;

        print( Get.find<SplashController>().currentUser.value?.image);
        // final storeId = SharedPreference().getStore();
        // if (storeId != null) {
        //   HomeController.i.selectedStore.value =
        //       StoreData(id: int.parse(storeId));

        // } else {
        //   AppDialogs.showAppDialog(
        //       context: Constants.navigatorKey.currentContext!,
        //       child: StoreSetupDialog());
        // }

        AppNavigation.navigateToRemovingAll(
          context,
          AppRouteName.BOTTOM_NAVIGATION_SCREEN_ROUTE,
        );

        return;
      } else {
        AppNavigation.navigateToRemovingAll(
          context,
          AppRouteName.LOGIN_SCREEN_ROUTE,
        );
      }
    } else {
      AppNavigation.navigateToRemovingAll(
        context,
        AppRouteName.LOGIN_SCREEN_ROUTE,
      );
    }
  }

  void _setUserSession({required BuildContext context}) {
    print('Set User Session');
    if (SharedPreference().getUser() != null) {
      print('Setting Role');
      final userJson = SharedPreference().getUser();
      final jsonResponse = jsonDecode(userJson!);
      final UserData? _currentUser = UserData.fromJson(jsonResponse);
      Get.find<SplashController>().currentUser.value = _currentUser;
    }
  }

  //go to home method
  void _chatNavigationMethod(
      {required BuildContext context,
      String? name,
      String? id,
      String? isBlock}) {}

  void clearAppDataMethod({required BuildContext context}) {
    String? languageType;
    if (SharedPreference().getViewOnBoardingScreen() == null) {
      // AppNavigation.navigateReplacement(context, OnBoardingScreen());
    } else {
      print(
          "before clear key is " + SharedPreference().getLanguage().toString());
      AppNavigation.navigateToRemovingAll(
          context, AppRouteName.LOGIN_SCREEN_ROUTE);
      SharedPreference().clear();
    }
  }

  void _setNotificationCount({String? pushNotificationType}) {
    if (pushNotificationType == AppStrings.BACKGROUND_NOTIFICATION) {}
  }

  void handleNotification({
    required String type,
    required Map<String, dynamic> notificationData,
    required BuildContext context,
  }) {
    AuthSingletonUserRole authSingletonUserRole = AuthSingletonUserRole();
    logData(message: "type: ${type} notificationData: ${notificationData}");
    switch (type) {
      //! =====> For Guest App Navigation
      //! =====> Jab Venue Khud se Cancel Invitation Karega kisi Guest ka tu jab yeh notification us user k pass jaegi, Tu hum us guest ko wo event dekhaeingay.
      case "invite_event_cancelled":
        // if (Get.currentRoute == AppRouteName.EVENT_DETAIL_FOR_GUEST_SCREEN) {
        //   authSingletonUserRole.guestEventDetailPage =
        //       GuestEventDetailPage.NewEventDetail;
        //   Get.find<EventDetailForGuestController>().eventIndexId =
        //       notificationData['event_id'].toString();
        //   Get.find<EventDetailForGuestController>().handleEventDetails();
        // } else {
        //   authSingletonUserRole.guestEventDetailPage =
        //       GuestEventDetailPage.NewEventDetail;
        //   AppNavigation.navigateTo(
        //     context,
        //     AppRouteName.EVENT_DETAIL_FOR_GUEST_SCREEN,
        //     arguments: {
        //       "eventId": notificationData['event_id'].toString(),
        //     },
        //   );
        // }
        break;
      //! =====> For Guest App Navigation
      //! =====> Jab Venue kisi guest ko invite karega, tu hum guest ko us event ki detail me le jaeingay takay wo waha se event invitation accept kar sakay
      case "invite_event":
        // if (Get.currentRoute == AppRouteName.EVENT_DETAIL_FOR_GUEST_SCREEN) {
        //   authSingletonUserRole.guestEventDetailPage =
        //       GuestEventDetailPage.InvitedEventDetail;
        //   Get.find<EventDetailForGuestController>().eventIndexId =
        //       notificationData['event_id'].toString();
        //   Get.find<EventDetailForGuestController>().handleEventDetails();
        // } else {
        //   authSingletonUserRole.guestEventDetailPage =
        //       GuestEventDetailPage.InvitedEventDetail;
        //   AppNavigation.navigateTo(
        //     context,
        //     AppRouteName.EVENT_DETAIL_FOR_GUEST_SCREEN,
        //     arguments: {
        //       "eventId": notificationData['event_id'].toString(),
        //     },
        //   );
        // }
        break;
      //! =====> For Guest App Navigation
      //! =====> Jab Venue User ki di hoi request accept karlega, Tu hum us user ko us event ki detail me behj dein gay.
      case "event_join_request_accepted":
        // if (Get.currentRoute == AppRouteName.EVENT_DETAIL_FOR_GUEST_SCREEN) {
        //   authSingletonUserRole.guestEventDetailPage =
        //       GuestEventDetailPage.MyEventDetail;
        //   Get.find<EventHistoryDetailForGuestController>().eventIndexId =
        //       notificationData['event_id'].toString();
        //   Get.find<EventHistoryDetailForGuestController>().handleEventDetails();
        // } else {
        //   authSingletonUserRole.guestEventDetailPage =
        //       GuestEventDetailPage.MyEventDetail;
        //   AppNavigation.navigateTo(
        //     context,
        //     AppRouteName.EVENT_DETAIL_FOR_GUEST_SCREEN,
        //     arguments: {
        //       "eventId": notificationData['event_id'].toString(),
        //     },
        //   );
        // }
        break;
      //! =====> For Guest App Navigation
      //! =====> Jab Venue User ki di hoi request cancel kardega, Tu hum us user ko us event ki detail me behj dein gay. so he/she can join again.
      case "event_join_request_rejected":
        // if (Get.currentRoute == AppRouteName.EVENT_DETAIL_FOR_GUEST_SCREEN) {
        //   authSingletonUserRole.guestEventDetailPage =
        //       GuestEventDetailPage.NewEventDetail;
        //   Get.find<EventDetailForGuestController>().eventIndexId =
        //       notificationData['event_id'].toString();
        //   Get.find<EventDetailForGuestController>().handleEventDetails();
        // } else {
        //   authSingletonUserRole.guestEventDetailPage =
        //       GuestEventDetailPage.NewEventDetail;
        //   AppNavigation.navigateTo(
        //     context,
        //     AppRouteName.EVENT_DETAIL_FOR_GUEST_SCREEN,
        //     arguments: {
        //       "eventId": notificationData['event_id'].toString(),
        //     },
        //   );
        // }
        break;
      case "event_completed":
        // if (Get.currentRoute ==
        //     AppRouteName.HISTORY_EVENT_DETAIL_FOR_GUEST_SCREEN) {
        //   Get.find<EventHistoryDetailForGuestController>().eventIndexId =
        //       notificationData['event_id'].toString();
        //   Get.find<EventHistoryDetailForGuestController>().handleEventDetails();
        // } else {
        //   AppNavigation.navigateTo(
        //     context,
        //     AppRouteName.HISTORY_EVENT_DETAIL_FOR_GUEST_SCREEN,
        //     arguments: {
        //       "eventId": notificationData['event_id'].toString(),
        //     },
        //   );
        // }
        break;
      case "event_started":
        // if (Get.currentRoute ==
        //     AppRouteName.HISTORY_EVENT_DETAIL_FOR_GUEST_SCREEN) {
        //   Get.find<EventHistoryDetailForGuestController>().eventIndexId =
        //       notificationData['event_id'].toString();
        //   Get.find<EventHistoryDetailForGuestController>().handleEventDetails();
        // } else {
        //   AppNavigation.navigateTo(
        //     context,
        //     AppRouteName.HISTORY_EVENT_DETAIL_FOR_GUEST_SCREEN,
        //     arguments: {
        //       "eventId": notificationData['event_id'].toString(),
        //     },
        //   );
        // }
        break;
      case "event_attendance":
        // if (Get.currentRoute ==
        //     AppRouteName.HISTORY_EVENT_DETAIL_FOR_GUEST_SCREEN) {
        //   Get.find<EventHistoryDetailForGuestController>().eventIndexId =
        //       notificationData['event_id'].toString();
        //   Get.find<EventHistoryDetailForGuestController>().handleEventDetails();
        // } else {
        //   AppNavigation.navigateTo(
        //     context,
        //     AppRouteName.HISTORY_EVENT_DETAIL_FOR_GUEST_SCREEN,
        //     arguments: {
        //       "eventId": notificationData['event_id'].toString(),
        //     },
        //   );
        // }
        break;
      case "rating":
        // if (authSingletonUserRole.userRole == UserRole.Guest) {
        //   var splashController = Get.isRegistered()
        //       ? Get.find<SplashController>()
        //       : Get.put(SplashController());
        //   if (Get.currentRoute == AppRouteName.REVIEW_SCREEN) {
        //     Get.find<ReviewController>().userId =
        //         splashController.currentUser.value?.id.toString();
        //     Get.find<ReviewController>().userProfileViewMethod();
        //   } else {
        //     var splashController = Get.isRegistered()
        //         ? Get.find<SplashController>()
        //         : Get.put(SplashController());
        //     if (splashController.currentUser.value != null) {
        //       AppNavigation.navigateTo(
        //         context,
        //         AppRouteName.REVIEW_SCREEN,
        //         arguments: {
        //           "userId": splashController.currentUser.value?.id.toString(),
        //         },
        //       );
        //     } else {
        //       AppNavigation.navigateToRemovingAll(
        //           context, AppRouteName.LOGIN_SCREEN_ROUTE);
        //     }
        //   }
        // }
        break;
      //! ====> Event Delete karne pe ussi venue k pass notificaiton gir rahi hai
      case "event_deleted":
        // AppDialogs.showToast(
        //   message: "${notificationData['body'].toString()}",
        //   timeInSecForIosWeb: 3,
        // );
        break;
      case "chat":
        // if (Get.currentRoute == AppRouteName.CHAT_WITH_ADMIN) {
        // } else {
        //   AppNavigation.navigateTo(
        //     context,
        //     AppRouteName.CHAT_WITH_ADMIN,
        //   );
        // }
        break;
      //! ======> For Venue App Navigation
      //! ====> Jab Guest invitation accept karega venue ka dia hua, tu venue k pass notify hoga that this guest has accepted your invitation
      case "invite_event_accepted":
        // if (Get.currentRoute == AppRouteName.EVENT_DETAIL_FOR_BUSINESS_SCREEN) {
        //   authSingletonUserRole.businessEventDetailPage =
        //       BusinessEventDetailPage.HomeMyEventDetail;
        //   Get.find<EventDetailForBusinessController>().eventIndexId =
        //       notificationData['event_id'].toString();
        //   Get.find<EventDetailForBusinessController>().handleEventDetails();
        // } else {
        //   authSingletonUserRole.businessEventDetailPage =
        //       BusinessEventDetailPage.HomeMyEventDetail;
        //   AppNavigation.navigateTo(
        //     context,
        //     AppRouteName.EVENT_DETAIL_FOR_BUSINESS_SCREEN,
        //     arguments: {
        //       "eventId": notificationData['event_id'].toString(),
        //     },
        //   );
        // }
        break;
      //! ======> For Venue App Navigation
      //! ====> Jab Guest khud apni di hui join request ko khud hi cancel kardega tu, hum venue ko notify karein gay k he/she has cancelled the request.
      case "event_join_request_cancelled":
        // if (Get.currentRoute == AppRouteName.EVENT_DETAIL_FOR_BUSINESS_SCREEN) {
        //   authSingletonUserRole.businessEventDetailPage =
        //       BusinessEventDetailPage.HomeMyEventDetail;
        //   Get.find<EventDetailForBusinessController>().eventIndexId =
        //       notificationData['event_id'].toString();
        //   Get.find<EventDetailForBusinessController>().handleEventDetails();
        // } else {
        //   authSingletonUserRole.businessEventDetailPage =
        //       BusinessEventDetailPage.HomeMyEventDetail;
        //   AppNavigation.navigateTo(
        //     context,
        //     AppRouteName.EVENT_DETAIL_FOR_BUSINESS_SCREEN,
        //     arguments: {
        //       "eventId": notificationData['event_id'].toString(),
        //     },
        //   );
        // }
        break;
      //! ======> For Venue App Navigation
      //! ======> Jab Koi Guest us event ki request karega jis venue wale ne wo event post kia hai tu yeh notification jaegi us venue wale k pass or wo wale event ki detail open karwae gi takay wo guest ki request accept karle
      case "event_join_request":
        // if (Get.currentRoute == AppRouteName.EVENT_DETAIL_FOR_BUSINESS_SCREEN) {
        //   authSingletonUserRole.businessEventDetailPage =
        //       BusinessEventDetailPage.RequestMyEventDetail;
        //   Get.find<EventDetailForBusinessController>().eventIndexId =
        //       notificationData['event_id'].toString();
        //   Get.find<EventDetailForBusinessController>().handleEventDetails();
        // } else {
        //   authSingletonUserRole.businessEventDetailPage =
        //       BusinessEventDetailPage.RequestMyEventDetail;
        //   AppNavigation.navigateTo(
        //     context,
        //     AppRouteName.EVENT_DETAIL_FOR_BUSINESS_SCREEN,
        //     arguments: {
        //       "eventId": notificationData['event_id'].toString(),
        //     },
        //   );
        // }
        break;
      //!account_aproved
      case "account_aproved":
        if (Get.currentRoute == AppRouteName.LOGIN_SCREEN_ROUTE) {
          SharedPreference().clear();
        } else {
          SharedPreference().clear();
          AppNavigation.navigateToRemovingAll(
            context,
            AppRouteName.LOGIN_SCREEN_ROUTE,
          );
        }
        break;
      default:
        if (Get.currentRoute == AppRouteName.NOTIFICATION_SCREEN_ROUTE) {
          final isRegistered = Get.isRegistered<SettingsController>();
          if (isRegistered) {
            Get.find<SettingsController>().get_Notification_list();
          } else {
            Get.put(SettingsController()).get_Notification_list();
          }
        } else {
          AppNavigation.navigateTo(
            context,
            AppRouteName.NOTIFICATION_SCREEN_ROUTE,
          );
        }
        break;
    }
  }
}
