import 'dart:async';

import 'package:carousel_slider/carousel_slider.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/auth/controllers/auth_controller.dart';
import 'package:jtc_ecommerce/cart/controllers/cart_controller.dart';
import 'package:jtc_ecommerce/favourite/blocs/post_favourite_bloc.dart';
import 'package:jtc_ecommerce/widgets/custom_extended_image.dart';
import 'package:jtc_ecommerce/widgets/custom_food_card.dart';
import 'package:jtc_ecommerce/widgets/custom_shimmer.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/widgets/custom_text_field.dart';
import 'package:jtc_ecommerce/widgets/no_data_found.dart';
import 'package:jtc_ecommerce/home/controllers/home_controller.dart';
import 'package:jtc_ecommerce/home/screens/components/addpopup_dialog.dart';
import 'package:jtc_ecommerce/home/screens/components/discount_timer_widget.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/local_storage.dart';
import 'package:jtc_ecommerce/splash/screens/components/store_setup_dialog.dart';
import 'package:jtc_ecommerce/splash/screens/model/store_list_model.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';
import 'package:jtc_ecommerce/utils/constants.dart';
import 'package:jtc_ecommerce/utils/enums.dart';

class HomeScreen extends StatefulWidget {
  HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  TextEditingController searchController = TextEditingController();

  Timer? _timer;
  Duration _duration = Duration(hours: 1);

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      checkStoreSetup();
      HomeController.i.isSearching.value = false;
      AuthController.i.clearTextFieldsLogin();
    });

    searchController.addListener(() {
      HomeController.i
          .searchProducts(searchController.text.trim().toLowerCase());
    });
    _startTimer();
    super.initState();
  }

  checkStoreSetup() {
    final storeId = SharedPreference().getStore();
    if (storeId != null) {
      HomeController.i.selectedStore.value = StoreData(id: int.parse(storeId));
      HomeController.i.loadHomeApis();
      _startTimer();
      CartController.i.get_cart_list();
    } else {
      AppDialogs.showAppDialog(
          context: Constants.navigatorKey.currentContext!,
          child: StoreSetupDialog());
    }
  }

  @override
  void dispose() {
    _timer!.cancel();
    super.dispose();
  }

// Format Duration to display as HH:MM:SS
  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final hours = twoDigits(duration.inHours);
    final minutes = twoDigits(duration.inMinutes.remainder(60));
    final seconds = twoDigits(duration.inSeconds.remainder(60));
    return "$hours:$minutes:$seconds";
  }

  void _startTimer() {
    // Cancel any existing timer
    _timer?.cancel();

    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (_duration.inSeconds == 0) {
        // Stop the timer when countdown reaches zero
        timer.cancel();
      } else {
        setState(() {
          _duration -= Duration(seconds: 1);
        });
      }
    });
  }

  Widget JTCTokenTimer() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12.0),
      child: Container(
        height: 80.h,
        width: double.infinity,
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
        decoration: BoxDecoration(
            border: Border.all(color: Colors.red),
            borderRadius: BorderRadius.circular(12.r),
            color: Color(0xFFFFF5F5)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Get Free JTC Token",
                  style: TextStyle(color: Colors.red, fontSize: 16.sp),
                ),
                Text(
                  "On All Products",
                  style: TextStyle(color: Colors.black, fontSize: 14.sp),
                )
              ],
            ),
            Container(
              height: 25.h,
              width: 60.w,
              padding: EdgeInsets.all(5.0),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.red),
                borderRadius: BorderRadius.circular(18.r),
                color: Color(0xFFFFE2E2),
              ),
              child: Center(
                  child: Text(
                _formatDuration(_duration),
                style: TextStyle(fontSize: 10.sp),
              )),
            )
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: RefreshIndicator(
        onRefresh: () async {
          HomeController.i.onRefreshPage();
        },
        color: AppColors.PRIMARY_COLOR,
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 20.h),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(24.r),
                topRight: Radius.circular(24.r),
              )),
          child: SingleChildScrollView(
            child: Obx(
              () => Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  slider(),
                  slider_dots(),
                  8.verticalSpace,
                  JTCTokenTimer(),
                  10.verticalSpace,
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: CustomTextField(
                      hintText: tr('search_text'),
                      suffixIcon: AssetPaths.SEARCH,
                      textEditingController: searchController,
                      onIconTap: () {
                        // controller.show_password_login.value =
                        //     !controller.show_password_login.value;
                      },
                    ),
                  ),
                  8.verticalSpace,
                  HomeController.i.isSearching.value
                      ? SizedBox.shrink()
                      : AnimatedContainer(
                          duration: Duration(seconds: 1),
                          margin: EdgeInsets.only(left: 10.w),
                          child: Text(
                            // 'FOOD CATEGORY',
                            tr('food_category'),
                            style: TextStyle(
                              // color: Color(0xFF3D3D3D),
                              // fontSize: 16.sp,
                              // fontFamily: 'Poppins',
                              // fontWeight: FontWeight.w600,

                              color: AppColors.BLACK_COLOR,
                              // isLeftAlign: true,
                              // fontsize: 20.sp,
                              fontSize: 20.sp,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                  10.verticalSpace,
                  HomeController.i.isSearching.value
                      ? SizedBox.shrink()
                      : AnimatedContainer(
                          duration: Duration(seconds: 1),
                          height: 120.h,
                          // margin: EdgeInsets.only(left: 10.w),
                          child: _buildFoodCategoriesListView(),
                        ),
                  HomeController.i.isSearching.value
                      ? _buildSearchView()
                      : _buildFoodCategoriesListViewProduct(),
                  HomeController.i.isSearching.value
                      ? SizedBox(
                          height: Get.height / 3,
                        )
                      : SizedBox.shrink()
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  _buildSearchView() {
    return SizedBox(
      width: 1.sw,
      child: HomeController.i.searchedProducts.isEmpty
          ? Center(
              child: CustomText(
                text: "data_not_found",
                color: AppColors.GREY_COLOR,
              ),
            )
          : GetBuilder<HomeController>(builder: (c) {
              return ListView.builder(
                  shrinkWrap: true,
                  itemCount: HomeController.i.searchedProducts.length,
                  physics: NeverScrollableScrollPhysics(),
                  itemBuilder: (context, index) {
                    final product = HomeController.i.searchedProducts[index];
                    return Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 10),
                      child: CustomFoodCard(
                        prodcutName: context.locale.languageCode == 'es'
                            ? product.nameSp ?? ''
                            : product.nameEn ?? '',
                        productToken:
                            product.smallTokenPrice.toStringAsFixed(0),
                        totalPrice: product.smallPrice.toStringAsFixed(2),
                        productImage: product.images!.isNotEmpty
                            ? product.images![0].toString()
                            : "",
                        prodcutDescription: context.locale.languageCode == 'es'
                            ? product.descriptionSp ?? ''
                            : product.descriptionEn ?? '',
                        onTapFav: () {
                          logData(message: "1");
                          PostFavouriteBloc().postFavouriteBlocMethod(
                            context: context,
                            isFav: false,
                            product: product,
                            product_id: product.id.toString(),
                            setProgressBar: () {
                              AppDialogs.progressAlertDialog(context: context);
                            },
                          );
                        },
                        onTapAddToCart: () {
                          logData(message: "sad");

                          AppDialogs.showAppDialog(
                              context: context,
                              child: AddonPopUp(product: product));
                        },
                        isFavourite: product.isFavourite,
                      ),
                    );
                  });
            }),
    );
  }

  Widget _buildFoodCategoriesListViewProduct() {
    return Obx(
      () => HomeController.i.isLoading.value
          ? Column(
              children: List.generate(
                  HomeController.i.food_category_list_product.length, (index) {
                return CustomShimmer(
                  shimmerType: ShimmerType.food_category_skeleton,
                );
              }),
            )
          : HomeController.i.food_category_list_product
                  .every((element) => element.products.isEmpty)
              ? NoDataPage(text: "No Products Available")
              : Container(
                  child: ListView.builder(
                    shrinkWrap: true,
                    scrollDirection: Axis.vertical,
                    physics: NeverScrollableScrollPhysics(),
                    itemCount:
                        HomeController.i.food_category_list_product.length,
                    itemBuilder: (context, index) {
                      return _buildCategoryWidget(index);
                    },
                  ),
                ),
    );
  }

  Widget _buildCategoryWidget(int index) {
    var category = HomeController.i.food_category_list_product[index];

    if (category.products.isEmpty) {
      return SizedBox();
      //  NoDataPage(
      //   height: 50.h,
      //   text: "No Product Found",
      //   fontSize: 12.sp,
      // );
    }

    return Padding(
      padding: const EdgeInsets.only(left: 10.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomText(
            text:

                // category.name.toUpperCase(),
                context.locale.languageCode == 'es'
                    ? category.nameSp ?? ''
                    : category.nameEn ?? '',
            color: AppColors.BLACK_COLOR,
            isLeftAlign: true,
            fontsize: 20.sp,
            fontWeight: FontWeight.bold,
            // fontFamily: AppFonts.robotoMedium,
          ),
          10.verticalSpace,
          Obx(
            () => HomeController.i.isLoading.value
                ? Row(
                    children: List.generate(3, (index) {
                      return CustomShimmer(
                        shimmerType: ShimmerType.food_category_skeleton,
                      );
                    }),
                  )
                : GetBuilder<HomeController>(builder: (
                    c,
                  ) {
                    return Container(
                      height: 290.h,
                      child: ListView.separated(
                        scrollDirection: Axis.horizontal,
                        itemCount: category.products.length,
                        itemBuilder: (BuildContext context, int index) {
                          var product = category.products[index];
                          return GestureDetector(
                            onTap: () => AppNavigation.navigateTo(
                              context,
                              AppRouteName.PRODUCT_DETAIL_SCREEN_ROUTE,
                              arguments: {
                                "product_id": product.id.toString(),
                              },
                            ),
                            child: CustomFoodCard(
                              prodcutName: context.locale.languageCode == 'es'
                                  ? product.nameSp ?? ''
                                  : product.nameEn ?? '',
                              productToken:
                                  product.smallTokenPrice.toStringAsFixed(0),
                              totalPrice: product.smallPrice.toStringAsFixed(2),
                              productImage: product.images!.isNotEmpty
                                  ? product.images![0].toString()
                                  : "",
                              prodcutDescription:
                                  context.locale.languageCode == 'es'
                                      ? product.descriptionSp ?? ''
                                      : product.descriptionEn ?? '',
                              onTapFav: () {
                                logData(message: "1");
                                PostFavouriteBloc().postFavouriteBlocMethod(
                                  context: context,
                                  isFav: false,
                                  product: product,
                                  product_id: product.id.toString(),
                                  setProgressBar: () {
                                    AppDialogs.progressAlertDialog(
                                        context: context);
                                  },
                                );
                              },
                              onTapAddToCart: () {
                                logData(message: "sad");

                                AppDialogs.showAppDialog(
                                    context: context,
                                    child: AddonPopUp(product: product));
                              },
                              isFavourite: product.isFavourite,
                            ),
                          );
                        },
                        separatorBuilder: (BuildContext context, int index) {
                          return 10.horizontalSpace;
                        },
                      ),
                    );
                  }),
          ),
          20.verticalSpace,
        ],
      ),
    );
  }

  Widget _buildFoodCategoriesListView() {
    return Obx(
      () => !HomeController.i.isLoading.value &&
              HomeController.i.food_category_list_product.isEmpty
          ? NoDataPage(
              height: 50.h,
              text: tr('foodcategoryscreen.no_category_found'),
              fontSize: 16.sp,
            )
          : Container(
              width: double.infinity,
              height: 100.h,
              padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 0.h),
              // height: MediaQuery.sizeOf(context).height * 0.01,

              decoration: BoxDecoration(
                  color: Colors.grey,
                  borderRadius: BorderRadius.circular(16.r),
                  image: DecorationImage(
                    image: AssetImage("assets/revamped/splashLogo.png"),
                    fit: BoxFit.cover,
                  )),
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                physics: AlwaysScrollableScrollPhysics(
                  parent: BouncingScrollPhysics(),
                ),
                controller: HomeController.i.scrollController,
                itemCount: HomeController.i.food_category_list_product.length +
                    (HomeController.i.isLoading.value ? 1 : 0),
                itemBuilder: (context, index) {
                  if (index <
                      HomeController.i.food_category_list_product.length) {
                    return GetBuilder<HomeController>(
                      builder: (homeScreenInfluencerController) {
                        return HomeController
                                .i
                                .food_category_list_product[index]
                                .products
                                .isEmpty
                            ? SizedBox()
                            : food_category_card(
                                context: context,
                                image: HomeController
                                    .i.food_category_list_product[index].image,
                                category_name: context.locale.languageCode ==
                                        'es'
                                    ? HomeController
                                            .i
                                            .food_category_list_product[index]
                                            .nameSp ??
                                        ''
                                    : HomeController
                                            .i
                                            .food_category_list_product[index]
                                            .nameEn ??
                                        '',

                                // controller.food_category_list_product[index].name,
                                onTap: () {
                                  AppNavigation.navigateTo(
                                    context,
                                    AppRouteName
                                        .FOOD_CATEGORIES_LIST_SCREEN_ROUTE,
                                    arguments: {
                                      "food_category_id": HomeController.i
                                          .food_category_list_product[index].id
                                          .toString(),
                                    },
                                  );
                                },
                              );
                      },
                    );
                  } else {
                    if (HomeController.i.isLoading.value) {
                      return Row(
                        children: List.generate(5, (index) {
                          return CustomShimmer(
                            shimmerType: ShimmerType.food_category_skeleton,
                          );
                        }),
                      );
                    } else {
                      return Container();
                    }
                  }
                },
              ),
            ),
    );
  }

  Widget food_category_card({
    required BuildContext context,
    required String image,
    required String category_name,
    void Function()? onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 100.w,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
              width: 50.h,
              height: MediaQuery.of(context).size.height * 0.1,
              decoration: BoxDecoration(
                color: Color(0xFFF7F7F7),
                shape: BoxShape.circle, // Shape changed to circular
                border: Border.all(
                  width: 1,
                  color: Colors.white,
                  // color: Color(0xFFE0201C),
                ),
              ),
              child: Center(
                child: ClipOval(
                  // ClipOval for circular clipping
                  child: SizedBox(
                    width: 50.h, // Adjust the size according to the circle
                    height: 50.w, // Adjust the size according to the circle
                    child: CustomExtendedImageWidget(
                      imagePath: image,
                      imageType: "network",
                      fit: BoxFit.cover,
                      imagePlaceholder: AssetPaths.USER_IMAGE,
                    ),
                  ),
                ),
              ),
            ),
            CustomText(
              text: category_name,
              maxLines: 1,
              // isLeftAlign: true,
              // color: Color(0xFFE0201C),
              color: Colors.white,
              fontsize: 12.sp,
              // fontFamily: AppFonts.robotoligth,
            ),
          ],
        ),
      ),
    );
  }

  Row slider_dots() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        ...List.generate(
            HomeController.i.sliders.length,
            (index) => Container(
                height: 5.h,
                width: 5.w,
                child: Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: Obx(
                    () => Container(
                      // margin: EdgeInsets.only(right: 5),

                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color:
                            index == HomeController.i.currentSliderIndex.value
                                ? Color(0xffE0201C)
                                : Color(0xffD9D9D9),
                      ),
                    ),
                  ),
                )))
      ],
    );
  }

  Stack slider() {
    return Stack(
      children: [
        AnimatedContainer(
          duration: Duration(seconds: 1),
          curve: Curves.easeIn,
          height: 220.h,
          width: double.infinity,
          child: Opacity(
            opacity: 0.79,
            child: CarouselSlider(
              items: HomeController.i.sliders,
              options: CarouselOptions(
                viewportFraction: 0.94,
                initialPage: 0,
                enableInfiniteScroll: true,
                reverse: false,
                autoPlay: true,
                onPageChanged: (index, reason) {
                  HomeController.i.currentSliderIndex.value = index;
                },
                autoPlayInterval: const Duration(seconds: 3),
                autoPlayAnimationDuration: const Duration(milliseconds: 800),
                autoPlayCurve: Curves.fastOutSlowIn,
                enlargeCenterPage: true,
                enlargeFactor: 0.9,
                // onPageChanged: (){},
                scrollDirection: Axis.horizontal,
              ),
            ),
          ),
        ),
        Obx(() {
          final bannerWIthDiscount = HomeController.i.bannerList
              .where((p0) => p0.discount > 0)
              .firstOrNull;
          return bannerWIthDiscount != null
              ? Positioned(
                  // top: 40,
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: StoreCountdownTimer(
                    discount: double.parse(
                        HomeController.i.bannerList.first.discount.toString()),
                    closingTime: HomeController.i.bannerList.first.closingTime
                        .toString(),
                  ),
                )
              : SizedBox();
        }),
        // Positioned(
        //   top: 50,
        //   right: 0,
        //   left: 0,
        //   child: Obx(() => Center(
        //       child: HomeController.i.showButton.value
        //           ?

        //           // Text(
        //           //     controller.formattedTime.value,
        //           //     style: TextStyle(
        //           //       fontSize: 20,
        //           //       fontWeight: FontWeight.bold,
        //           //     ),
        //           //   )

        //           Column(
        //               children: [
        //                 Obx(
        //                   () => Text(
        //                     // '50% DISCOUNT',
        //                     '${HomeController.i.bannerList[0].discount.toString()}% DISCOUNT OFFER',
        //                     textAlign: TextAlign.center,
        //                     style: TextStyle(
        //                       color: Color(0xFFFFDBDD),
        //                       fontSize: 20,
        //                       fontFamily: 'Poppins',
        //                       fontWeight: FontWeight.w700,
        //                     ),
        //                   ),
        //                 ),
        //                 // Row(
        //                 //   mainAxisAlignment: MainAxisAlignment.center,
        //                 //   children: [
        //                 //     Text(
        //                 //       'Opening${controller.bannerList[0].openingTime}  -',
        //                 //       style: TextStyle(color: Colors.white),
        //                 //     ),
        //                 //     Text(
        //                 //       '  closing${controller.bannerList[0].openingTime}',
        //                 //       style: TextStyle(color: Colors.white),
        //                 //     ),
        //                 //   ],
        //                 // ),
        //                 Text(
        //                   HomeController.i.formattedTime.value,
        //                   textAlign: TextAlign.center,
        //                   style: TextStyle(
        //                     color: Colors.white,
        //                     fontSize: 40,
        //                     fontFamily: 'Poppins',
        //                     fontWeight: FontWeight.w500,
        //                   ),
        //                 ),
        //                 Text(
        //                   // 'IN ALL PRODUCTS',
        //                   // '${controller.bannerList[0].address}',
        //                   "On all Products",
        //                   textAlign: TextAlign.center,
        //                   style: TextStyle(
        //                     color: Colors.white,
        //                     fontSize: 14,
        //                     fontFamily: 'Poppins',
        //                     fontWeight: FontWeight.w500,
        //                   ),
        //                 )
        //                 // Text(
        //                 //   // 'IN ALL PRODUCTS',
        //                 //   '${controller.bannerList[0].address}',
        //                 //   textAlign: TextAlign.center,
        //                 //   style: TextStyle(
        //                 //     color: Colors.white,
        //                 //     fontSize: 14,
        //                 //     fontFamily: 'Poppins',
        //                 //     fontWeight: FontWeight.w500,
        //                 //   ),
        //                 // )
        //               ],
        //             )
        //           : Column(
        //               children: [
        //                 Text(
        //                   // controller.formattedTime.value,
        //                   '',
        //                   textAlign: TextAlign.center,
        //                   style: TextStyle(
        //                     color: Colors.white,
        //                     fontSize: 20,
        //                     fontFamily: 'Poppins',
        //                     fontWeight: FontWeight.w500,
        //                   ),
        //                 ),
        //               ],
        //             ))),
        // ),
      ],
    );
  }
}
