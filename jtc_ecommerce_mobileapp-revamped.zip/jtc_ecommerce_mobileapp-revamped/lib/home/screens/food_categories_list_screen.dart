import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/cart/blocs/add_to_cart_bloc.dart';
import 'package:jtc_ecommerce/favourite/blocs/post_favourite_bloc.dart';
import 'package:jtc_ecommerce/widgets/custom_app_bar.dart';
import 'package:jtc_ecommerce/widgets/custom_food_card.dart';
import 'package:jtc_ecommerce/widgets/custom_scaffold.dart';
import 'package:jtc_ecommerce/widgets/custom_shimmer.dart';
import 'package:jtc_ecommerce/widgets/no_data_found.dart';
import 'package:jtc_ecommerce/home/controllers/food_categories_list_controller.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';
import 'package:jtc_ecommerce/utils/enums.dart';

class FoodCategoriesListScreen extends StatefulWidget {
  FoodCategoriesListScreen({super.key});

  @override
  State<FoodCategoriesListScreen> createState() =>
      _FoodCategoriesListScreenState();
}

class _FoodCategoriesListScreenState extends State<FoodCategoriesListScreen> {
  // var controller = Get.put(FoodCategoriesListController());

  late FoodCategoriesListController controller;

  @override
  void initState() {
    Get.delete<FoodCategoriesListController>();
    controller = Get.put(FoodCategoriesListController());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      appBarTitle: tr('foodcategoryscreen.title'),
      onTap: () => AppNavigation.navigatorPop(context),
      child: Obx(
        () => controller.isLoading.value 
            ? Center(
                child: SingleChildScrollView(
                  physics: AlwaysScrollableScrollPhysics(),
                  child: Wrap(
                    spacing: 10,
                    runSpacing: 20,
                    runAlignment: WrapAlignment.center,
                    children: [
                      for (int i = 0; i < 12; i++)
                        CustomShimmer(
                          shimmerType: ShimmerType.food_category_wise_skeleton,
                        ),
                    ],
                  ),
                ),
              )
            : !controller.isLoading.value &&
                    controller.singleProductModel.isEmpty
                ? SizedBox(
                    width: Get.width,
                    child: SingleChildScrollView(
                      physics: AlwaysScrollableScrollPhysics(
                        parent: BouncingScrollPhysics(),
                      ),
                      child: Container(
                        height: Get.height / 1.3,
                        child: NoDataPage(
                          text: tr('foodcategoryscreen.no_category_found'),
                          fontSize: 18.sp,
                        ),
                      ),
                    ),
                  )
                : RefreshIndicator(
                    onRefresh: () async {
                      controller.onRefreshPage();
                    },
                    color: AppColors.PRIMARY_COLOR,
                    child: SingleChildScrollView(
                      physics: AlwaysScrollableScrollPhysics(),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          GetBuilder<FoodCategoriesListController>(
                              builder: (c) {
                            return GridView.builder(
                              physics: NeverScrollableScrollPhysics(),
                              shrinkWrap: true,
                              gridDelegate:
                                  const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 2,
                                crossAxisSpacing: 1.0,
                                childAspectRatio: 0.6,
                              ),
                              itemCount: controller.singleProductModel.length,
                              itemBuilder: (BuildContext context, int index) {
                                logData(
                                    message:
                                        "FAV: ${controller.singleProductModel[index].isFavorite}");
                                return Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: GestureDetector(
                                    onTap: () {
                                      AppNavigation.navigateTo(
                                        context,
                                        AppRouteName
                                            .PRODUCT_DETAIL_SCREEN_ROUTE,
                                        arguments: {
                                          "product_id": controller
                                              .singleProductModel[index].id
                                              .toString(),
                                        },
                                      );
                                    },
                                    child: CustomFoodCard(
                                      // width: 170.w,
                                      badgePadding: 0,
                                      onTapAddToCart: () {
                                        logData(message: "sad");
                                        AddToCartBloc().addToCartBlocMethod(
                                          context: context,

                                          // product_id: product_id,
                                          product_id: controller
                                              .singleProductModel[index].id
                                              .toString(),

                                          addons: [],
                                          quantity: 1,
                                          message: "",
                                          isFromDetailScreen: false,
                                          setProgressBar: () {
                                            AppDialogs.progressAlertDialog(
                                                context: context);
                                          },
                                        );
                                      },
                                      // prodcutName: controller
                                      //     .singleProductModel[index].name,

                                      prodcutName:
                                          // product.description.toString(),
                                          context.locale.languageCode == 'es'
                                              ? controller
                                                      .singleProductModel[index]
                                                      .nameSp ??
                                                  ''
                                              : controller
                                                      .singleProductModel[index]
                                                      .nameEn ??
                                                  '',
                                      productToken: controller
                                          .singleProductModel[index]
                                          .smallTokenPrice
                                          .toString(),

                                      // prodcutDescription: controller
                                      //     .singleProductModel[index].description
                                      //     .toString(),

                                      prodcutDescription:
                                          context.locale.languageCode == 'es'
                                              ? controller
                                                      .singleProductModel[index]
                                                      .descriptionSp ??
                                                  ''
                                              : controller
                                                      .singleProductModel[index]
                                                      .descriptionEn ??
                                                  '',
                                      // totalPrice: controller
                                      //     .singleProductModel[index].totalPrice,
                                      totalPrice: controller
                                          .singleProductModel[index].small
                                          .toStringAsFixed(2),
                                      productImage: controller
                                              .singleProductModel[index]
                                              .images
                                              .isNotEmpty
                                          ? controller.singleProductModel[index]
                                              .images[0]
                                              .toString()
                                          : "",
                                      onTapFav: () {
                                        logData(message: "1");
                                        PostFavouriteBloc()
                                            .postFavouriteBlocMethod(
                                          context: context,
                                          isFromCats: true,
                                          singleProductModel: controller
                                              .singleProductModel[index],
                                          product_id: controller
                                              .singleProductModel[index].id
                                              .toString(),
                                          setProgressBar: () {
                                            AppDialogs.progressAlertDialog(
                                                context: context);
                                          },
                                        );
                                      },
                                      isFavourite: controller
                                          .singleProductModel[index].isFavorite,
                                    ),
                                  ),
                                );
                              },
                            );
                          }),
                        ],
                      ),
                    ),
                  ),
      ),
    );
  }
}
