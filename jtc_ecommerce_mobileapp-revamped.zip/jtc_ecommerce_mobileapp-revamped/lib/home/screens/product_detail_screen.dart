import 'package:carousel_slider/carousel_slider.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/favourite/blocs/post_favourite_bloc.dart';
import 'package:jtc_ecommerce/widgets/custom_button.dart';
import 'package:jtc_ecommerce/widgets/custom_extended_image.dart';
import 'package:jtc_ecommerce/widgets/custom_scaffold.dart';
import 'package:jtc_ecommerce/widgets/custom_shimmer.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/widgets/custom_text_field.dart';
import 'package:jtc_ecommerce/home/controllers/product_detail_controller.dart';
import 'package:jtc_ecommerce/home/models/single_product_model.dart';
import 'package:jtc_ecommerce/home/screens/components/photoviewer.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_fonts.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_strings.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';
import 'package:jtc_ecommerce/utils/enums.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

import '../../enum/media_type.dart';

class ProductDetailScreen extends StatefulWidget {
  ProductDetailScreen({super.key});

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  var controller = Get.put(ProductDetailController());
  PageController? _pageController;
  int _currentPage = 0;

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
    _pageController?.addListener(() {
      setState(() {
        _currentPage = _pageController!.page!.round();
      });
    });
  }

  @override
  void dispose() {
    _pageController!.dispose();
    super.dispose();
  }

  Widget _buildCarouselItem(Color color, String title) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 10.0),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24.r),
          color: color,
        ),
        alignment: Alignment.center,
        child: Text(
          title,
          style: TextStyle(color: Colors.white, fontSize: 24),
        ),
      ),
    );
  }

  // Widget _buildDotIndicator() {
  //   return Row(
  //     mainAxisAlignment: MainAxisAlignment.center,
  //     children: List.generate(3, (index) {
  //       return AnimatedContainer(
  //         duration: Duration(milliseconds: 300),
  //         margin: EdgeInsets.symmetric(horizontal: 4),
  //         width: 8,
  //         height: 8,
  //         decoration: BoxDecoration(
  //           color: _currentPage == index ? Colors.red : Colors.grey,
  //           shape: BoxShape.circle,
  //         ),
  //       );
  //     }),
  //   );
  // }

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      appBarTitle: "",
      onTap: () => AppNavigation.navigatorPop(
        context,
      ),
      isFavoriteIcon: true,
      child2: GetBuilder<ProductDetailController>(builder: (c) {
        return Obx(
          () => Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5),
              child: GestureDetector(
                onTap: () {
                  PostFavouriteBloc().postFavouriteBlocMethod(
                    context: context,
                    singleProductModel: controller.singleProductModel.value,
                    isFav: controller.singleProductModel.value?.isFavorite ??
                        false,
                    // product_id: product.id.toString(),
                    product_id:
                        controller.singleProductModel.value?.id.toString(),
                    setProgressBar: () {
                      AppDialogs.progressAlertDialog(context: context);
                    },
                  );
                },
                child: Container(
                    height: 30.h,
                    width: 30.w,
                    // padding: EdgeInsets.all(5.0),
                    decoration: BoxDecoration(
                        // border: Border.all(color: Colors.white),
                        borderRadius: BorderRadius.circular(30.r),
                        color: Colors.white),
                    child: Icon(
                      Icons.favorite,
                      color: (controller.singleProductModel.value?.isFavorite ??
                              false)
                          ? AppColors.RED_GMAIL_COLOR
                          : AppColors.GREY_COLOR,
                    )),
              )),
        );
      }),
      child: Obx(
        () => controller.isLoading.value
            ? Padding(
                padding: const EdgeInsets.all(16.0),
                child: CustomShimmer(
                  shimmerType: ShimmerType.food_detail,
                ),
              )
            : SingleChildScrollView(
                physics: AlwaysScrollableScrollPhysics(
                  parent: BouncingScrollPhysics(),
                ),
                child: Column(
                  children: [
                    //Upper Part
                    // Stack(
                    //   children: [
                    //     //Top Image
                    //     Container(
                    //       height: 260.h,
                    //       width: Get.width,
                    //       decoration: BoxDecoration(
                    //         color: AppColors.GREY_COLOR,
                    //         borderRadius: BorderRadius.only(
                    //           bottomLeft: Radius.circular(10),
                    //           bottomRight: Radius.circular(10),
                    //         ),
                    //       ),
                    //       child: ClipRRect(
                    //         borderRadius: BorderRadius.only(
                    //           bottomLeft: Radius.circular(10),
                    //           bottomRight: Radius.circular(10),
                    //         ),
                    //         child: CustomExtendedImageWidget(
                    //           imagePath: controller.product_image.value,
                    //           imageType: AppStrings.IMAGE_NETWORK_TYPE,
                    //           fit: BoxFit.cover,
                    //           imagePlaceholder:
                    //               AssetPaths.EMPTY_IMAGE_VENUE_PLACEHOLDER,
                    //         ),
                    //       ),
                    //     ),
                    //     //back arrow
                    //     Positioned(
                    //       top: 10,
                    //       left: 20,
                    //       child: flying_icons_with_box(
                    //         icon_path: AssetPaths.BACK_ICON_DETAIL,
                    //         onTap: () => AppNavigation.navigatorPop(context),
                    //       ),
                    //     ),
                    //     //heat icon
                    //     Positioned(
                    //       top: 10,
                    //       right: 20,
                    //       child: GetBuilder<ProductDetailController>(
                    //           builder: (c) {
                    //         return flying_icons_with_box(
                    //             icon_path: AssetPaths.HEART_ICON_DETAIL,
                    //             colors: controller
                    //                     .singleProductModel.value!.isFavorite
                    //                 ? AppColors.PRIMARY_COLOR
                    //                 : null,
                    //             onTap: () => PostFavouriteBloc()
                    //                     .postFavouriteBlocMethod(
                    //                   context: context,
                    //                   singleProductModel:
                    //                       controller.singleProductModel.value,
                    //                   isFav: controller.singleProductModel
                    //                           .value?.isFavorite ??
                    //                       false,
                    //                   // product_id: product.id.toString(),
                    //                   product_id: controller
                    //                       .singleProductModel.value?.id
                    //                       .toString(),
                    //                   setProgressBar: () {
                    //                     AppDialogs.progressAlertDialog(
                    //                         context: context);
                    //                   },
                    //                 ));
                    //       }),
                    //     ),
                    //   ],
                    // ),

                    _mediaPostsWidget(),
                    // Column(
                    //   children: [
                    //     Container(
                    //       height: 200,
                    //       decoration: BoxDecoration(
                    //         borderRadius: BorderRadius.circular(24.r),
                    //       ),
                    //       width: double.infinity,
                    //       child: PageView(
                    //         controller: _pageController,
                    //         children: [
                    //           _buildCarouselItem(Colors.red, "Slide 1"),
                    //           _buildCarouselItem(Colors.blue, "Slide 2"),
                    //           _buildCarouselItem(Colors.green, "Slide 3"),
                    //         ],
                    //       ),
                    //     ),
                    //     SizedBox(height: 20),
                    //     SmoothPageIndicator(
                    //       controller: _pageController!,
                    //       count: 3,
                    //       effect: ExpandingDotsEffect(
                    //           dotHeight: 10.h, dotWidth: 10.h),
                    //       onDotClicked: (index) {},
                    //     )
                    //   ],
                    // ),
                    10.verticalSpace,
                    Stack(
                      children: [
                        Container(
                          padding: EdgeInsets.all(10.0),
                          // height: MediaQuery.sizeOf(context).height * 0.55,
                          width: double.infinity,
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey),
                            color: Color(0xFFF6F6F6),
                            borderRadius: BorderRadius.circular(16.r),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              30.verticalSpace,
                              Text(
                                context.locale.languageCode == 'es'
                                    ?
                                    // 'nameSp'
                                    "${controller.singleProductModel.value?.nameSp}"
                                            .toUpperCase() ??
                                        ''
                                    :
                                    // 'nameEn'

                                    "${controller.singleProductModel.value?.nameEn}"
                                            .toUpperCase() ??
                                        '',
                                style: TextStyle(
                                    color: Colors.red, fontSize: 18.sp),
                              ),
                              Text(
                                context.locale.languageCode == 'es'
                                    ? "${controller.singleProductModel.value?.descriptionSp}"
                                            .toUpperCase() ??
                                        ''
                                    :
                                    // 'nameEn'

                                    "${controller.singleProductModel.value?.descriptionEn}"
                                            .toUpperCase() ??
                                        '',
                                maxLines: 100,
                                style: TextStyle(color: Colors.grey),
                              ),
                              10.verticalSpace,
                              if (controller.singleProductModel.value
                                          ?.productAddons !=
                                      null &&
                                  controller.singleProductModel.value!
                                      .productAddons.isNotEmpty)
                                CustomText(
                                  // text: "Addons",
                                  text: tr('addons_text'),
                                  isLeftAlign: true,

                                  color: Colors.red,
                                  fontsize: 18,
                                ),
                              // SizedBox(height: 15),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  ...List.generate(
                                    // controller.singleProductModel.value?.productAddons.length ??
                                    controller.singleProductModel.value
                                            ?.productAddons.length ??
                                        0,
                                    (index) => _buildAddonOptions(
                                      productItemScreenList: controller
                                          .singleProductModel
                                          .value!
                                          .productAddons[index],
                                      currentIndex: index,
                                    ),
                                  ),
                                  //
                                  controller.singleProductModel.value
                                              ?.isVariantCheck ==
                                          1
                                      ? Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            CustomText(
                                              // text: "Variations",
                                              text: tr('variations_text'),
                                              isLeftAlign: true,
                                              color: Colors.red,
                                              fontsize: 18,
                                            ),
                                            SizedBox(
                                              height: 10,
                                            ),
                                            Row(
                                              children: [
                                                Expanded(
                                                  child: GestureDetector(
                                                    onTap: () {
                                                      print(
                                                          "${controller.selectedSize.value}");
                                                      controller.selectedSize
                                                              .value =
                                                          "small"; // Update selectedSize
                                                    },
                                                    child: Container(
                                                      height: 40.h,
                                                      decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(8.r),
                                                        color: controller
                                                                    .selectedSize
                                                                    .value ==
                                                                "small"
                                                            ? Colors.black
                                                            : Colors.grey,
                                                      ),
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .symmetric(
                                                                horizontal: 5),
                                                        child: Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .center,
                                                          children: [
                                                            Text(
                                                              // "Small: ",
                                                              tr('small_text'),
                                                              style: TextStyle(
                                                                  fontSize:
                                                                      10.sp,
                                                                  // fontFamily:
                                                                  //     AppFonts.robotoMedium,
                                                                  color: Colors
                                                                      .white),
                                                            ),
                                                            Text(
                                                              "\$${controller.singleProductModel.value!.small.toString()}",
                                                              style: TextStyle(
                                                                  fontSize:
                                                                      10.sp,
                                                                  color: Colors
                                                                      .white),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                10.horizontalSpace,
                                                Expanded(
                                                  child: GestureDetector(
                                                    onTap: () {
                                                      print(
                                                          "\$${controller.selectedSize.value}");
                                                      controller.selectedSize
                                                              .value =
                                                          "medium"; // Update selectedSize
                                                    },
                                                    child: Obx(
                                                      () => Container(
                                                        height: 40.h,
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      8.r),
                                                          color: controller
                                                                      .selectedSize
                                                                      .value ==
                                                                  "medium"
                                                              ? Colors.black
                                                              : Colors.grey,
                                                        ),
                                                        child: Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                  .symmetric(
                                                                  horizontal:
                                                                      5),
                                                          child: Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .center,
                                                            children: [
                                                              Text(
                                                                // "Medium: ".tr,
                                                                tr('medium_text'),
                                                                style:
                                                                    TextStyle(
                                                                  fontSize:
                                                                      10.sp,

                                                                  // fontFamily:
                                                                  //     AppFonts.robotoMedium,
                                                                  // color: Colors.black,
                                                                  color: Colors
                                                                      .white,
                                                                ),
                                                              ),
                                                              Text(
                                                                "\$${controller.singleProductModel.value!.medium.toString()}",
                                                                style:
                                                                    TextStyle(
                                                                  fontSize:
                                                                      10.sp,

                                                                  // fontFamily:
                                                                  //     AppFonts.robotoMedium,
                                                                  // color: Colors.black,

                                                                  color: Colors
                                                                      .white,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                10.horizontalSpace,
                                                Expanded(
                                                  child: GestureDetector(
                                                    onTap: () {
                                                      print(
                                                          "${controller.selectedSize.value}");
                                                      controller.selectedSize
                                                              .value =
                                                          "large"; // Update selectedSize
                                                    },
                                                    child: Obx(
                                                      () => Container(
                                                        height: 40.h,
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      8.r),
                                                          color: controller
                                                                      .selectedSize
                                                                      .value ==
                                                                  "large"
                                                              ? Colors.black
                                                              : Colors.grey,
                                                        ),
                                                        child: Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                  .symmetric(
                                                                  horizontal:
                                                                      5),
                                                          child: Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .center,
                                                            children: [
                                                              Text(
                                                                // "Large: ".tr,
                                                                tr('large_text'),
                                                                style:
                                                                    TextStyle(
                                                                  fontSize:
                                                                      10.sp,
                                                                  color: Colors
                                                                      .white,
                                                                ),
                                                              ),
                                                              Text(
                                                                "\$${controller.singleProductModel.value!.large.toString()}",
                                                                style:
                                                                    TextStyle(
                                                                  fontSize:
                                                                      10.sp,

                                                                  // fontFamily:
                                                                  //     AppFonts.robotoMedium,
                                                                  // color: Colors.black,
                                                                  color: Colors
                                                                      .white,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        )
                                      : Text(""),

                                  20.verticalSpace,
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        children: [
                                          CustomText(
                                            // text: "Total".tr,
                                            text: tr('total_text'),

                                            color: AppColors.RED_GMAIL_COLOR,
                                            fontsize: 22.sp,
                                            isLeftAlign: true,
                                          ),
                                          CustomText(
                                            text:
                                                ": \$${controller.getTotalPriceFiat().toStringAsFixed(2)}",
                                            color: AppColors.BLACK_COLOR,
                                            fontsize: 22.sp,
                                            isLeftAlign: true,
                                            // fontFamily: AppFonts.robotoBold,
                                          ),
                                        ],
                                      ),
                                      //
                                      Container(
                                        height: 40.h,
                                        decoration: BoxDecoration(
                                            // color: Colors.white,
                                            borderRadius:
                                                BorderRadius.circular(8.r),
                                            border:
                                                Border.all(color: Colors.grey)),
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 4),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceEvenly,
                                            children: [
                                              IconButton(
                                                onPressed: controller.decrement,
                                                icon: Icon(Icons.remove),
                                                iconSize: 14,
                                              ),
                                              VerticalDivider(
                                                color: Colors.grey,
                                                thickness: 1,
                                                // width: 1,
                                              ),
                                              Obx(
                                                () => Padding(
                                                  padding: const EdgeInsets
                                                      .symmetric(horizontal: 3),
                                                  child: CustomText(
                                                    text: controller
                                                        .quantity.value
                                                        .toString(),
                                                    color:
                                                        AppColors.BLACK_COLOR,
                                                    fontsize: 14.sp,
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                                ),
                                              ),
                                              VerticalDivider(
                                                color: Colors.grey,
                                                thickness: 1,
                                                width: 10,
                                              ),
                                              IconButton(
                                                onPressed: controller.increment,
                                                icon: Icon(Icons.add),
                                                iconSize: 14,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  20.verticalSpace,
                                ],
                              ),
                            ],
                          ),
                        ),
                        Positioned(
                          right: 20.w,
                          child: SizedBox(
                            child: token_badge(
                              icon: AssetPaths.LOGO,
                              tokens:
                                  "${controller.getTotalPriceToken().toStringAsFixed(0)}",
                              icon_height: 12.h,
                            ),
                          ),
                        ),
                      ],
                    ),

                    30.verticalSpace,
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10.0),
                      child: CustomButton(
                        height: 70.h,
                        borderRadius: 10.0,
                        buttonColor: AppColors.PRIMARY_COLOR,
                        onTap: () {
                          //Call API for Add to cart
                          controller.addProductInCartMethod(
                            context: context,
                            quantity: controller.quantity.toInt(),
                          );
                        },
                        buttonText: tr('add_tocart_details'),
                        // buttonText: "ADD TO CART".tr,
                      ),
                    ),
                    20.verticalSpace,
                  ],
                ),
              ),
      ),
    );
  }

  Widget _buildAddonOptions({
    required ProductAddons productItemScreenList,
    required int currentIndex,
  }) {
    final addonName =
        controller.singleProductModel.value!.productAddons[currentIndex];
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          CustomText(
            text: addonName.addonName?.toUpperCase(),
            isLeftAlign: true,
            color: Colors.grey[600],
            // maxLines: 10,
            fontsize: 14.sp,
          ),
          SizedBox(height: 15),
          Row(
            children: List.generate(
                controller.singleProductModel.value!.productAddons[currentIndex]
                    .addonItems!.length, (index) {
              final addonitemcontent = controller.singleProductModel.value!
                  .productAddons[currentIndex].addonItems![index];
              return GestureDetector(
                  onTap: () {
                    controller.changeAddons(
                        addonitemcontent,
                        controller.singleProductModel.value!
                            .productAddons[currentIndex].addonId
                            .toString());
                    // setState(() {});
                    // print(controller.selectedIndex);
                    // if (controller.selectedIndex[currentIndex] == index) {
                    //   controller.selectedIndex[currentIndex] = -1;
                    // } else {
                    //   controller.selectedIndex[currentIndex] = index;
                    // }
                    // controller.updateSelectedChildIds(
                    //   parentId: controller.singleProductModel.value
                    //           ?.productAddons[currentIndex].addonId ??
                    //       0,
                    //   childId: controller
                    //           .singleProductModel
                    //           .value
                    //           ?.productAddons[currentIndex]
                    //           .addonItems![index]
                    //           .itemId ??
                    //       0,
                    //   childPrice: controller
                    //           .singleProductModel
                    //           .value
                    //           ?.productAddons[currentIndex]
                    //           .addonItems![index]
                    //           .itemPrice!
                    //           .toDouble() ??
                    //       0,
                    // );
                  },
                  child: AnimatedContainer(
                    height: 40.h,
                    duration: Duration(milliseconds: 500),
                    padding: EdgeInsets.symmetric(
                        horizontal: 16, vertical: 10), // Padding for the chip
                    margin: EdgeInsets.only(right: 10), // Margin between chips
                    decoration: BoxDecoration(
                      color: controller.selectedAddons
                              .contains(addonitemcontent)
                          ? Colors.black // Background color when selected
                          : Colors.grey, // Background color when not selected
                      borderRadius:
                          BorderRadius.circular(8.r), // Rounded corners
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CustomText(
                          text: addonitemcontent.itemName!.toUpperCase(),
                          color: Colors.white, // Text color
                          fontsize: 9.sp,
                          isLeftAlign: false,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        SizedBox(width: 5), // Space between the two texts
                        CustomText(
                          text:
                              "\$${addonitemcontent.itemPrice.toStringAsFixed(2)}", // Format the price to 2 decimal places
                          color: Colors.white, // Text color
                          fontsize: 9.sp,
                          maxLines: 1,
                          fontWeight: FontWeight.bold,
                          isLeftAlign: false,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ));
            }),
          ),
          SizedBox(height: 30),
        ],
      ),
    );
  }

  Widget _descriptionField({
    String? validatorString,
    TextEditingController? descriptionTextController,
    List<TextInputFormatter>? textInputFormattors,
  }) {
    return CustomTextField(
      hintText: tr('add_notes_text'),
      hintTextColor: AppColors.BLACK_COLOR,
      fontSize: 16.sp,
      filled: true,
      textInputFormattors: textInputFormattors,
      textEditingController: descriptionTextController,
      validator: (value) => validatorString,
      keyboardType: TextInputType.text,
      isMultiLine: true,
      maxLines: 3,
      onChanged: (value) {},
    );
  }

  Container options_sizes({required String sizes}) {
    return Container(
      height: 70.h,
      width: 120.w,
      margin: EdgeInsets.only(right: 10.w),
      decoration: BoxDecoration(
        color: Colors.grey[200],
        borderRadius: BorderRadius.circular(15),
      ),
      child: CustomText(
        text: sizes,
        isLeftAlign: false,
        align: Alignment.center,
        color: AppColors.BLACK_COLOR,
        fontsize: 16.sp,
      ),
    );
  }

  Container token_badge({
    required String icon,
    double? icon_height,
    required String tokens,
    Color? color,
    double? horizontal,
  }) {
    return Container(
      height: 40.h,
      // width: 80.w,
      decoration: BoxDecoration(
        color: color ?? Colors.red,
        borderRadius: BorderRadius.only(
            bottomLeft: Radius.circular(12.r),
            bottomRight: Radius.circular(12.r)),
      ),
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: horizontal ?? 10.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset(
              icon,
              height: icon_height ?? 8.h,
              color: AppColors.WHITE_COLOR,
            ),
            4.horizontalSpace,
            Text(
              tokens,
              style: TextStyle(
                fontSize: 14.sp,
                color: AppColors.WHITE_COLOR,
                // fontWeight: FontWeight.w500
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget flying_icons_with_box({
    required String icon_path,
    void Function()? onTap,
    Color? colors,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 30,
        width: 40,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.8),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 3),
          child: Image.asset(
            icon_path,
            color: colors ?? AppColors.GREY_COLOR,
          ),
        ),
      ),
    );
  }

  Widget _mediaPostsWidget() {
  return Obx(
    () => Padding(
      padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 10),
      child: Column(
        children: [
          if (controller.mediaPosts.isEmpty)
            Image.asset('assets/images/no_image.png'),
          if (controller.mediaPosts.isNotEmpty) ...[
            Container(
              height: 200.h, 
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24.r),
              ),
              width: double.infinity,
              child: PageView.builder(
                controller: _pageController,
                itemCount: controller.mediaPosts.length,
                onPageChanged: (index) {
                  setState(() {
                    _currentIndex = index;
                  });
                },
                itemBuilder: (context, index) {
                  return _mediaPostItem(controller.mediaPosts[index], isThumbnail: true);
                },
              ),
            ),
            SizedBox(height: 20),
            SmoothPageIndicator(
              controller: _pageController!,
              count: controller.mediaPosts.length,
              effect: ExpandingDotsEffect(
                dotHeight: 5.h,
                dotColor: Colors.red ,
                dotWidth: 5.h,
              ),
              onDotClicked: (index) {
                _pageController!.animateToPage(
                  index,
                  duration: Duration(milliseconds: 300),
                  curve: Curves.easeIn,
                );
              }, 
            ),
          ],
          SizedBox(height: 10),
        ],
      ),
    ),
  );
}


  int _currentIndex = 0;

  Widget _buildPageIndicator(int itemCount) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(
        itemCount,
        (index) => AnimatedContainer(
          duration: Duration(milliseconds: 200),
          margin: const EdgeInsets.symmetric(horizontal: 4.0),
          width: _currentIndex == index ? 18.0 : 10.0,
          height: 8.0,
          decoration: BoxDecoration(
            color: _currentIndex == index ? Colors.red : Colors.grey,
            borderRadius: BorderRadius.circular(4.0),
          ),
        ),
      ),
    );
  }

  Widget _mediaPostItem(Post post, {bool isThumbnail = false}) {
    return GestureDetector(
      onTap: () => _handleMediaTap(post),
      child: Stack(
        children: [
          Container(
            margin: EdgeInsets.only(right: 10.w),
            height: .25.sh,
            width: 1.sw,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(15),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: CustomExtendedImageWidget(
                // borderRadius: BorderRadius.circular(15),
                // imagePath: post.mediaType == MediaType.image
                //     ? (post.url ?? "")
                //     : (post.thumbnail ?? ""),
                imagePath: post.url,
                imagePlaceholder: 'assets/images/no-image.png',
                imageType: AppStrings.IMAGE_TYPE_NETWORK,
                fit: BoxFit.cover,
              ),
            ),
          ),
          // Positioned.fill(
          //   child: Container(
          //     margin: EdgeInsets.only(right: 10.w),
          //     decoration: BoxDecoration(
          //       borderRadius: BorderRadius.circular(15),
          //       color: AppColors.BLACK_COLOR.withOpacity(.4),
          //     ),
          //   ),
          // ),
          // if (post.mediaType == MediaType.video)
          //   Positioned.fill(
          //     child: Center(
          //       child: Image.asset(
          //         AssetPaths.EMPTY_LIST_PLACEHOLDER,
          //         scale: isThumbnail ? 4 : 3,
          //       ),
          //     ),
          //   ),
        ],
      ),
    );
  }

  void _handleMediaTap(Post post) {
    if (post.mediaType == MediaType.video) {
      // AppNavigator.push(context, VideoScreen(url: post.url ?? ""));
    } else {
      final tappedIndex = controller.mediaPosts
          .indexWhere((element) => element.url == post.url);
      // AppNavigator.push(
      //   context,
      //   CustomPhotoViewer(
      //     isMulti: true,
      //     startIndex: tappedIndex,
      //     images: mediaPosts
      //         .where((element) => element.mediaType == MediaType.image)
      //         .map((e) => e.url!)
      //         .toList(),
      //   ),
      // );

      Navigator.push(
          context,
          MaterialPageRoute(
            builder: (c) => CustomPhotoViewer(
              isMulti: true,
              startIndex: tappedIndex,
              images: controller.mediaPosts
                  .where((element) => element.mediaType == MediaType.image)
                  .map((e) => e.url!)
                  .toList(),
            ),
          ));
    }
  }
}

class CustomSlider extends StatelessWidget {
  final double value;
  final double totalValue;
  final Color backgroundColor;
  final Color fillColor;
  final double height;
  final double borderRadius;

  const CustomSlider({
    Key? key,
    required this.value,
    required this.totalValue,
    this.backgroundColor = Colors.grey,
    this.fillColor = const Color(0xFFBA2835),
    this.height = 10.0,
    this.borderRadius = 5.0,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Ensure the value is within the totalValue
    final double clampedValue = value.clamp(0, totalValue);

    // Calculate the fill percentage
    final double fillPercentage = clampedValue / totalValue;

    return Container(
      width: double.infinity,
      height: height,
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(borderRadius),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(borderRadius),
        child: Stack(
          children: [
            // Fill the current value
            Container(
              width: fillPercentage * MediaQuery.of(context).size.width,
              height: height,
              color: fillColor,
            ),
          ],
        ),
      ),
    );
  }
}
