import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'dart:async';

import 'package:jtc_ecommerce/utils/app_colors.dart';

class StoreCountdownTimer extends StatefulWidget {
  final String closingTime;
  final double discount;

  const StoreCountdownTimer({
    Key? key,
    required this.closingTime,
    required this.discount,
  }) : super(key: key);

  @override
  _StoreCountdownTimerState createState() => _StoreCountdownTimerState();
}

class _StoreCountdownTimerState extends State<StoreCountdownTimer> {
  late Duration _remainingTime;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _startCountdown();
  }

  void _startCountdown() {
    final now = DateTime.now();
    final closingDateTime = _parseTime(widget.closingTime);

    _remainingTime = closingDateTime.difference(now);

    if (_remainingTime.isNegative) {
      _remainingTime = Duration.zero;
    }

    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        _remainingTime = _remainingTime - Duration(seconds: 1);
        if (_remainingTime.isNegative) {
          _remainingTime = Duration.zero;
          timer.cancel();
        }
      });
    });
  }

  DateTime _parseTime(String time) {
    final now = DateTime.now();
    final format = RegExp(r'(\d+):(\d+) (AM|PM)');
    final match = format.firstMatch(time);

    if (match != null) {
      int hour = int.parse(match.group(1)!);
      final minute = int.parse(match.group(2)!);
      final period = match.group(3)!;

      if (period == 'PM' && hour != 12) {
        hour += 12;
      } else if (period == 'AM' && hour == 12) {
        hour = 0;
      }

      return DateTime(now.year, now.month, now.day, hour, minute);
    } else {
      throw FormatException('Invalid time format');
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.discount == 0 || _remainingTime.isNegative) {
      return SizedBox.shrink();
    }

    return Container(
      padding: EdgeInsets.all(5),
      margin: EdgeInsets.symmetric(horizontal: 25),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: AppColors.WHITE_COLOR),
          boxShadow: [
            BoxShadow(
                offset: Offset(2, 2),
                blurRadius: 4,
                spreadRadius: 2,
                color: AppColors.GREY_COLOR)
          ],
          color: Color(0xFF941512)),
      child: Column(
        children: [
          CustomText(
            text: widget.discount.toString() + "% " + tr('discount'),
            fontsize: 18.sp,
            fontWeight: FontWeight.w600,
          ),
          Text(
            '${_remainingTime.inHours.toString().padLeft(2, '0')}:${(_remainingTime.inMinutes % 60).toString().padLeft(2, '0')}:${(_remainingTime.inSeconds % 60).toString().padLeft(2, '0')} ' +
                tr('remaining').toLowerCase(),
            style: TextStyle(
                fontSize: 12.sp,
                color: Colors.white,
                fontWeight: FontWeight.w900,
                letterSpacing: 2),
          ),
        ],
      ),
    );
  }
}
