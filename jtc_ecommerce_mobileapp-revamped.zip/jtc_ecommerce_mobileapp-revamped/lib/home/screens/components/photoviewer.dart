import 'package:extended_image/extended_image.dart';
import 'package:flutter/material.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';

class CustomPhotoViewer extends StatefulWidget {
  const CustomPhotoViewer({
    Key? key,
    this.photoViewerGallery,
    this.isMulti = false,
    this.images,
    this.startIndex = 0, // Added startIndex parameter
  })  : assert(!isMulti || images != null,
            'If isMulti is true, images must not be null.'),
        super(key: key);

  final String? photoViewerGallery;
  final bool isMulti;
  final List<String>? images;
  final int startIndex; // Added startIndex parameter

  @override
  State<CustomPhotoViewer> createState() => _CustomPhotoViewerState();
}

class _CustomPhotoViewerState extends State<CustomPhotoViewer>
    with TickerProviderStateMixin {
  late ExtendedPageController _pageController;

  @override
  void initState() {
    super.initState();
    _pageController = ExtendedPageController(
        initialPage: widget.startIndex); // Initialize with startIndex
  }

  @override
  Widget build(BuildContext context) {
    AnimationController _animationController = AnimationController(
        duration: const Duration(milliseconds: 200), vsync: this);
    Function() animationListener = () {};
    Animation? _animation;

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        leading: InkWell(
          onTap: () {
            AppNavigation.navigatorPop(context);
          },
          child: Image.asset(
            AssetPaths.BACK_ICON_DETAIL,
            scale: 2.5,
            color: AppColors.WHITE_COLOR,
          ),
        ),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        child: widget.isMulti
            ? ExtendedImageGesturePageView.builder(
                controller: _pageController, // Pass the controller
                itemCount: widget.images?.length ?? 0,
                itemBuilder: (context, index) {
                  return ExtendedImage.network(
                    widget.images![index],
                    fit: BoxFit.contain,
                    mode: ExtendedImageMode.gesture,
                    initGestureConfigHandler: (state) {
                      return GestureConfig(
                        minScale: 0.9,
                        animationMinScale: 0.7,
                        maxScale: 3.0,
                        animationMaxScale: 3.5,
                        speed: 1.0,
                        inertialSpeed: 100.0,
                        initialScale: 1.0,
                        inPageView: false,
                        initialAlignment: InitialAlignment.center,
                      );
                    },
                    onDoubleTap: (ExtendedImageGestureState state) {
                      var pointerDownPosition = state.pointerDownPosition;
                      double begin = state.gestureDetails!.totalScale!;
                      double end;

                      _animation?.removeListener(animationListener);
                      _animationController.stop();
                      _animationController.reset();

                      if (begin == 1) {
                        end = 1.5;
                      } else {
                        end = 1;
                      }
                      animationListener = () {
                        state.handleDoubleTap(
                            scale: _animation!.value,
                            doubleTapPosition: pointerDownPosition);
                      };
                      _animation = _animationController
                          .drive(Tween<double>(begin: begin, end: end));

                      _animation!.addListener(animationListener);

                      _animationController.forward();
                    },
                  );
                })
            : ExtendedImage.network(
                widget.photoViewerGallery ?? "",
                fit: BoxFit.contain,
                mode: ExtendedImageMode.gesture,
                initGestureConfigHandler: (state) {
                  return GestureConfig(
                    minScale: 0.9,
                    animationMinScale: 0.7,
                    maxScale: 3.0,
                    animationMaxScale: 3.5,
                    speed: 1.0,
                    inertialSpeed: 100.0,
                    initialScale: 1.0,
                    inPageView: false,
                    initialAlignment: InitialAlignment.center,
                  );
                },
                onDoubleTap: (ExtendedImageGestureState state) {
                  var pointerDownPosition = state.pointerDownPosition;
                  double begin = state.gestureDetails!.totalScale!;
                  double end;

                  _animation?.removeListener(animationListener);
                  _animationController.stop();
                  _animationController.reset();

                  if (begin == 1) {
                    end = 1.5;
                  } else {
                    end = 1;
                  }
                  animationListener = () {
                    state.handleDoubleTap(
                        scale: _animation!.value,
                        doubleTapPosition: pointerDownPosition);
                  };
                  _animation = _animationController
                      .drive(Tween<double>(begin: begin, end: end));

                  _animation!.addListener(animationListener);

                  _animationController.forward();
                },
              ),
      ),
    );
  }
}
