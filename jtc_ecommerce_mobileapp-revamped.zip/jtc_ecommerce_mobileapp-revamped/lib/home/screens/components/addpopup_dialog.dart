import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:jtc_ecommerce/cart/blocs/add_to_cart_bloc.dart';
import 'package:jtc_ecommerce/enum/variant.dart';
import 'package:jtc_ecommerce/widgets/custom_button.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';

import '../../models/get_food_categories_model_product.dart';

class AddonPopUp extends StatefulWidget {
  const AddonPopUp({super.key, required this.product});
  final Product product;

  @override
  State<AddonPopUp> createState() => _AddonPopUpState();
}

class _AddonPopUpState extends State<AddonPopUp> {
  Variant? selectedVariant = Variant.small;
  bool isVraintAvaiable = false;

  int quantity = 1;
  List<AddonItem> selectedAddons = [];

  @override
  void initState() {
    isVraintAvaiable = widget.product.isVariantCheck == 1 ? true : false;
    print(isVraintAvaiable);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Material(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        child: Container(
          padding: EdgeInsets.all(12),
          decoration: BoxDecoration(
              color: AppColors.WHITE_COLOR,
              borderRadius: BorderRadius.circular(12)),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Align(
                alignment: Alignment.topRight,
                child: IconButton(
                    onPressed: () {
                      AppNavigation.navigatorPop(context);
                    },
                    icon: Icon(Icons.close)),
              ),
              if (isVraintAvaiable) ...[
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomText(
                      // text: "Variations",
                      text: 'variations_text',
                      isLeftAlign: true,
                      color: AppColors.RED_GMAIL_COLOR,
                      fontsize: 18.sp,
                    ),
                  ],
                ),
                10.verticalSpace,
                Wrap(
                  spacing: 1,
                  children: [
                    ..._buildVariantButton(),
                  ],
                ),
                10.verticalSpace,
              ],
              if (widget.product.addons != null &&
                  widget.product.addons!.isNotEmpty) ...[
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomText(
                      text: 'addons_text',
                      color: AppColors.RED_GMAIL_COLOR,
                      fontsize: 18.sp,
                      isLeftAlign: true,
                    ),
                  ],
                ),
                8.verticalSpace,
                ..._addons(),
              ],
              20.verticalSpace,
              _quantity(),
              20.verticalSpace,
              CustomButton(
                  buttonColor: AppColors.PRIMARY_COLOR,
                  onTap: () {
                    //        {
                    //   "addon_id": entry.key,
                    //   // "addon_items_id": [entry.value],
                    //   "addon_items_id": entry.value,
                    // }

                    AddToCartBloc().addToCartBlocMethod(
                        context: context,
                        isFromDetailScreen: false,
                        quantity: quantity,
                        variation:
                            isVraintAvaiable == true ? getVariant() : null,
                        onSuccess: () {
                          AppNavigation.navigatorPop(context);
                        },
                        addons: selectedAddons.isNotEmpty
                            ? selectedAddons
                                .map((selection) => {
                                      "addon_id": selection.parentId,
                                      "addon_items_id": selection.itemId,
                                    })
                                .toList()
                            : [],
                        product_id: widget.product.id.toString(),
                        setProgressBar: () {
                          AppDialogs.progressAlertDialog(context: context);
                        });
                  },
                  buttonText: 'add_tocart_details')
            ],
          ),

          // height: 300,
        ),
      ),
    );
  }

  String? getVariant() {
    switch (selectedVariant) {
      case null:
      case Variant.small:
        return Variant.small.name.toString();
      case Variant.medium:
        return Variant.medium.name.toString();
      case Variant.large:
        return Variant.large.name.toString();
    }
  }

  _quantity() {
    return Container(
      height: MediaQuery.sizeOf(context).height * 0.05,
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.grey[200],
        borderRadius: BorderRadius.circular(10),
      ),
      child: Center(
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Decrement Button
            InkWell(
              onTap: () {
                if (quantity > 1) {
                  quantity--;
                  setState(() {});
                }
                // AddToCartBloc().addToCartBlocMethod(
                //   context: context,
                //   product_id: cartList?.productId.toString(),
                //   addons: [],
                //   cart_id: cartList?.id.toString(),
                //   quantity: cartList!.quantity! + 1,
                //   message: cartList?.message,
                //   isFromDetailScreen: false,
                //   setProgressBar: () {
                //     AppDialogs.progressAlertDialog(context: context);
                //   },
                // );
                // CartController.i..incrementCartItemQuantity(index);
              },
              child: Container(
                padding: const EdgeInsets.all(8.0),
                child: Icon(
                  Icons.remove,
                  size: 20.sp,
                  color: AppColors.BLACK_COLOR,
                ),
              ),
            ),
            // Quantity Text
            10.horizontalSpace,
            Flexible(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: Text(
                  quantity.toString(),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.bold,
                    color: AppColors.BLACK_COLOR,
                  ),
                ),
              ),
            ),
            // Increment Button
            10.horizontalSpace,
            InkWell(
              onTap: () {
                // if (cartList!.quantity! > 1) {
                //   AddToCartBloc().addToCartBlocMethod(
                //     context: context,
                //     cart_id: cartList!.id.toString(),
                //     product_id: cartList!.productId.toString(),
                //     addons: [],
                //     quantity: cartList!.quantity! - 1,
                //     message: cartList!.message,
                //     isFromDetailScreen: false,
                //     setProgressBar: () {
                //       AppDialogs.progressAlertDialog(context: context);
                //     },
                //   );
                //   CartController.i.decrementCartItemQuantity(index);
                // }

                int value = quantity;
                // int value = int.tryParse(quantity.value) ?? 0;
                int limit =
                    int.tryParse(widget.product.quantityLimit ?? "") ?? 0;
                logData(message: "Limit: $limit Value: $value");
                if (value < limit) {
                  quantity = (value + 1);

                  setState(() {});
                } else {
                  AppDialogs.showToast(message: "Quantity Exceeds");
                }
              },
              child: Container(
                padding: const EdgeInsets.all(8.0),
                child: Icon(
                  Icons.add,
                  size: 20.sp,
                  color: AppColors.BLACK_COLOR,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildVariantButton() {
    return Variant.values
        .map((e) => GestureDetector(
              onTap: () {
                setState(() {
                  selectedVariant = e;
                });
              },
              child: IntrinsicWidth(
                child: Container(
                  margin: EdgeInsets.only(right: 10, bottom: 5),
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    border: selectedVariant == e
                        ? Border.all(color: Colors.black)
                        : Border.all(color: Colors.grey),
                    color: selectedVariant == e ? Colors.black : Colors.grey,
                  ),
                  child: Row(
                    // mainAxisSize: MainAxisSize.min,
                    children: [
                      CustomText(
                        text: e.name,
                        fontsize: 11.sp,
                        color: AppColors.WHITE_COLOR,
                      ),
                      5.horizontalSpace,
                      CustomText(
                        text: "\$" + _getVariantPrice(e),
                        color: AppColors.WHITE_COLOR,
                        fontsize: 11.sp,
                      )
                    ],
                  ),
                ),
              ),
            ))
        .toList();
  }

  List<Widget> _addons() {
    return widget.product.addons!
        .map((e) => Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomText(
                  text: e.addonName,
                  fontsize: 12.sp,
                  color: AppColors.GREY_COLOR,
                  isLeftAlign: true,
                ),
                5.verticalSpace,
                Wrap(
                  children: e.addonItems
                      .map(
                        (addon) => GestureDetector(
                          onTap: () {
                            addon.parentId = e.addonId.toString();
                            if (selectedAddons.contains(addon)) {
                              selectedAddons.remove(addon);
                              print("Removed");
                            } else {
                              selectedAddons.add(addon);
                              print("Added");
                            }
                            setState(() {});
                          },
                          child: IntrinsicWidth(
                            child: Container(
                              margin: EdgeInsets.only(right: 10),
                              padding: EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 5),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(5),
                                border: selectedAddons.contains(addon)
                                    ? Border.all(color: Colors.black)
                                    : Border.all(color: Colors.grey),
                                color: selectedAddons.contains(addon)
                                    ? Colors.black
                                    : Colors.grey,
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  CustomText(
                                    text: addon.itemName,
                                    fontsize: 11.sp,
                                    color: Colors.white,
                                  ),
                                  5.horizontalSpace,
                                  CustomText(
                                    text: "\$" + addon.itemPrice.toString(),
                                    color: Colors.white,
                                    fontsize: 10.sp,
                                  )
                                ],
                              ),
                            ),
                          ),
                        ),
                      )
                      .toList(),
                )
              ],
            ))
        .toList();
  }

  String _getVariantPrice(Variant variant) {
    switch (variant) {
      case Variant.small:
        return widget.product.smallPrice.toStringAsFixed(2);
      case Variant.medium:
        return widget.product.mediumPrice.toStringAsFixed(2);
      case Variant.large:
        return widget.product.largePrice.toStringAsFixed(2);
    }
  }
}
