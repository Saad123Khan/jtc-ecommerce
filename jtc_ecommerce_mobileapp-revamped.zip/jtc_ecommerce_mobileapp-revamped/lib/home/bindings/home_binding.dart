import 'package:get/get.dart';
import 'package:jtc_ecommerce/home/controllers/home_controller.dart';
import 'package:jtc_ecommerce/home/controllers/product_detail_controller.dart';

class HomeBinding extends Bindings{
  @override
  void dependencies() {
    Get.lazyPut(() => HomeController());
    Get.lazyPut(() => ProductDetailController());
    
  }
}