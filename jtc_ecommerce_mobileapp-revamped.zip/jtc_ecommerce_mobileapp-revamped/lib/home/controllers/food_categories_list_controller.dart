import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/home/blocs/food_categories_list_bloc.dart';
import 'package:jtc_ecommerce/home/models/single_product_model.dart';

import '../models/get_food_categories_model_product.dart';
import 'home_controller.dart';

class FoodCategoriesListController extends GetxController {
  String food_category_id = "";
  static FoodCategoriesListController get i => Get.find();

  @override
  void onInit() {
    if (Get.arguments != null) {
      food_category_id = Get.arguments['food_category_id'];
      get_food_category_list();
    }
    //  isLoading.value = true;

    super.onInit();
  }

  RxList<SingleProductModel> singleProductModel = <SingleProductModel>[].obs;

  RxBool isLoading = false.obs;

  // ScrollController scrollController = ScrollController();

  Future<void> get_food_category_list() async {
    try {
      isLoading.value = true;
      print("getttttt foood category lisssssssssst");
      await FoodCategriesListBloc().getFoodCategriesListBlocModel(
        food_category_id: food_category_id,
        context: Get.context!,
      );
      print("getttttt foood category lisssssssssst");
      print("getttttt foood categor++++++++++y lisssssssssst");
      if (FoodCategriesListBloc().contentTypeResponse != null) {
        singleProductModel.addAll(
          List.from(FoodCategriesListBloc().contentTypeResponse),
        );
        print("getttttt: ${singleProductModel.length}");
        print("getttttt: ${singleProductModel[0].name}");
      }
    } catch (e) {
    } finally {
      isLoading.value = false;
    }
  }

  bool isFetching = false;
  onRefreshPage() async {
    FocusManager.instance.primaryFocus?.unfocus();
    if (isFetching) {
      // If already fetching, ignore this call
      return;
    }
    isFetching = true;
    //Clear the listings
    singleProductModel.value = [];
    // Fetch new data
    await get_food_category_list(); // Replace with your API call
    // Once fetch is complete, reset the flag
    isFetching = false;
  }

  void toggleFav(SingleProductModel product, bool isFav) {
    // Toggle the favorite status of the product
    product.isFavorite = isFav;

    // Find the category that contains the product
    final FoodCategoriesModelDataProductList? filteredCategory = HomeController
        .i.food_category_list_product
        .firstWhereOrNull((category) {
      return category.products
          .any((productItem) => productItem.id == product.id);
    });

    // If the category is found, update the product's favorite status within the category
    if (filteredCategory != null) {
      // Find the product within the category
      for (final productItem in filteredCategory.products) {
        if (productItem.id == product.id) {
          // Update the product's favorite status in the category
          // productItem.isFavourite = !product.isFavorite;
          HomeController.i.toggleFav(productItem, isFav);
          break; // Break the loop once the product is found and updated
        }
      }
    }

    ///ALSEO IN FOOD CATEGORIES SCREEN

    // Update the controller's state and UI
    update();
  }
}
