
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/cart/blocs/add_to_cart_bloc.dart';
import 'package:jtc_ecommerce/cart/blocs/add_to_cart_varient_bloc.dart';
import 'package:jtc_ecommerce/enum/media_type.dart';
import 'package:jtc_ecommerce/enum/variant.dart';
import 'package:jtc_ecommerce/home/blocs/single_product_detail_bloc.dart';
import 'package:jtc_ecommerce/home/controllers/home_controller.dart';
import 'package:jtc_ecommerce/home/models/get_food_categories_model_product.dart';
import 'package:jtc_ecommerce/home/models/single_product_model.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';

class ProductDetailController extends GetxController {
  static ProductDetailController get i => Get.find();
  // List<String> option_size_list = ["Small", "Medium", "Large", "Extra Large"];
  // List<String> option_temperature_list = ["HOT", "ICED"];
  // List<String> option_milk_list = ["Regular", "Skimmed"];
  // List<String> option_addons_list = ["Moose It", "Oreo"];
  RxList<Post> mediaPosts = <Post>[].obs;

  Variant? selectedVariant = Variant.small;
  RxBool isVraintAvaiable = false.obs;

  // var selectedValue = 1.obs;
  // var selectedValues = <int>[].obs;
  // List<String> addons_list = [];
  String? product_id;
  RxString selectedSize = "small".obs;
  RxList<AddonItems> selectedAddons = <AddonItems>[].obs;

  double _getVariantPriceFiat() {
    switch (selectedSize.value) {
      case 'small':
        return singleProductModel.value?.small ?? 0.0;
      case 'medium':
        return singleProductModel.value?.medium ?? 0.0;
      case 'large':
        return singleProductModel.value?.large ?? 0.0;
    }
    return 0.0;
  }

  double _getVariantPriceToken() {
    switch (selectedSize.value) {
      case 'small':
        return singleProductModel.value?.smallTokenPrice ?? 0.0;
      case 'medium':
        return singleProductModel.value?.mediumTokenPrice ?? 0.0;
      case 'large':
        return singleProductModel.value?.largeTokenPrice ?? 0.0;
    }
    return 0.0;
  }

  double getTotalPriceFiat() {
    double total = 0.0;

    print("PRODUCT PRICE ${singleProductModel.value?.productPrice}");
    print("IS VARIANT AVAIABLE ${isVraintAvaiable.value}");

    if (isVraintAvaiable.value) {
      // Calculate the price of the selected variant multiplied by the quantity
      final variantTotalAndQuantity = _getVariantPriceFiat() * quantity.value;
      total += variantTotalAndQuantity;
    } else {
      // Calculate the total price of the selected variant multiplied by the quantity
      final variantTotalAndQuantity =
          (singleProductModel.value?.smallPrice ?? 0) * quantity.value;
      total += variantTotalAndQuantity;
    }

    // Calculate the total price of the selected addons
    final addonTotal =
        selectedAddons.fold(0.0, (sum, element) => sum + element.itemPrice);
    total += addonTotal;

    return total;
  }

  double getTotalPriceToken() {
    double total = 0.0;

    // print("PRODUCT PRICE ${singleProductModel.value?.productPrice}");
    // print("IS VARIANT AVAIABLE ${isVraintAvaiable.value}");

    if (isVraintAvaiable.value) {
      // Calculate the price of the selected variant multiplied by the quantity
      final variantTotalAndQuantity = _getVariantPriceToken() * quantity.value;
      total += variantTotalAndQuantity;
    } else {
      // Calculate the total price of the selected variant multiplied by the quantity
      final variantTotalAndQuantity =
          (singleProductModel.value?.smallTokenPrice ?? 0) * quantity.value;
      total += variantTotalAndQuantity;
    }

    // Calculate the total price of the selected addons
    final addonTotal =
        selectedAddons.fold(0.0, (sum, element) => sum + element.itemPrice);
    total += addonTotal;

    return total;
  }

  @override
  void onInit() {
    if (Get.arguments != null) {
      product_id = Get.arguments['product_id'];
      logData(message: "product_id: $product_id");
      getProductDetails(product_id: product_id ?? "");
    }
    super.onInit();
  }

  // double get totalAddonPrice {
  //   // Calculate the total addon price based on your logic
  //   double total = addonPrices.values.fold(0.0, (a, b) => a + b);
  //   return total;
  // }

  double get actualPrice {
    double totalAddonPrice = addonPrices.values.fold(0.0, (a, b) => a + b);
    // double productPrice = double.parse(singleProductModel.value?.largePrice ?? '0');
    double productPrice;

    switch (selectedSize.value.toLowerCase()) {
      case 'small':
        productPrice =
            double.parse(singleProductModel.value?.small.toString() ?? '0');
        break;
      case 'medium':
        productPrice =
            double.parse(singleProductModel.value?.medium.toString() ?? '0');
        break;
      case 'large':
        productPrice =
            double.parse(singleProductModel.value?.large.toString() ?? '0');
        break;
      // case 'extra large':
      //   productPrice =
      //       double.parse(singleProductModel.value?.extraLargePrice ?? '0');
      //   break;
      default:
        productPrice = 1;
        // double.parse(singleProductModel.value?.smallPrice ?? '0');
        break;
    }
    return totalAddonPrice + productPrice;
  }

  double get actualTokenPrice {
    double totalAddonPrice = addonPrices.values.fold(0.0, (a, b) => a + b);
    // double productPrice = double.parse(singleProductModel.value?.largePrice ?? '0');
    double productPrice;
    print(selectedSize.value);

    switch (selectedSize.value.toLowerCase()) {
      case 'small':
        productPrice = double.parse(
            singleProductModel.value?.smallTokenPrice.toString() ?? '0');
        break;
      case 'medium':
        productPrice = double.parse(
            singleProductModel.value?.mediumTokenPrice.toString() ?? '0');
        break;
      case 'large':
        productPrice = double.parse(
            singleProductModel.value?.largeTokenPrice.toString() ?? '0');
        break;
      // case 'extra large':
      //   productPrice =
      //       double.parse(singleProductModel.value?.extraLargePrice ?? '0');
      //   break;
      default:
        productPrice = singleProductModel.value?.smallTokenPrice ?? 0;
        break;
    }
    return totalAddonPrice + productPrice;
  }

  Future<void> getProductDetails({required String product_id}) async {
    try {
      isLoading.value = true;
      await GetSingleProductDetailBloc().getSingleProductDetailBlocMethod(
        context: Get.context!,
        product_id: product_id,
      );
      if (singleProductModel.value != null) {
        isVraintAvaiable.value =
            singleProductModel.value?.isVariantCheck == 1 ? true : false;
        // initMediaPosts();
      }
    } catch (e) {
      // print()
    } finally {
      isLoading.value = false;
    }
  }

  initMediaPosts() {
    // mediaPosts.clear();
    final store = singleProductModel.value;
    if (store != null && store.images.isNotEmpty) {
      store.imageUrl.forEach((element) {
        mediaPosts.add(Post(
          mediaType: MediaType.image,
          url: element,
          thumbnail: element,
        ));

        print(element);
      });

      // if (mounted) {
      //   setState(() {});
      // }
    } else {
      mediaPosts = <Post>[].obs;
    }

    log(
      "LENGHT "+  mediaPosts.length.toString());
  }

  RxBool isLoading = false.obs;
  RxString product_image = "".obs;
  Rxn<SingleProductModel> singleProductModel = Rxn(null);

  var quantity = 1.obs;

  void increment() {
    int value = quantity.value ?? 0;
    // int value = int.tryParse(quantity.value) ?? 0;
    int limit =
        int.tryParse(singleProductModel.value?.quantityLimit ?? "") ?? 0;
    logData(message: "Limit: $limit Value: $value");
    if (value < limit) {
      quantity.value = (value + 1);
    } else {
      AppDialogs.showToast(message: "Quantity Exceeds");
    }
  }

  void decrement() {
    int value = quantity.value;
    // int value = int.tryParse(quantity.value) ?? 0;
    if (value > 1) {
      quantity.value = (value - 1);
    }
  }

  TextEditingController addNote = TextEditingController();

  //For Color
  Map<int, int> selectedIndex = {};

  List<Map<String, dynamic>> addonss = [];
  Map<int, int> lastSelectedChildInfo = {};
  Map<int, double> addonPrices = {};

  double totalPrice = 0;
  double finalTotal = 0;

  // void updateSelectedChildIds({
  //   required int parentId,
  //   required int childId,
  //   required double childPrice,
  // }) {
  //   print(parentId);
  //   if (lastSelectedChildInfo.containsKey(parentId)) {
  //     if (lastSelectedChildInfo[parentId] == childId) {
  //       lastSelectedChildInfo.remove(parentId);

  //       addonPrices.remove(parentId);
  //     } else {
  //       lastSelectedChildInfo[parentId] = childId;
  //       addonPrices[parentId] = childPrice;
  //     }
  //   } else {
  //     lastSelectedChildInfo[parentId] = childId;
  //     addonPrices[parentId] = childPrice;
  //   }
  //   List<Map<String, dynamic>> addons = lastSelectedChildInfo.entries
  //       .map((entry) => {
  //             "addon_id": entry.key,
  //             // "addon_items_id": [entry.value],
  //             "addon_items_id": entry.value,
  //           })
  //       .toList();
  //   double totalAddonPrice = addonPrices.values.fold(0.0, (a, b) => a + b);
  //   print("Total Addon Price: $totalAddonPrice");
  //   addonss = addons;
  //   // finalTotal = totalPrice + totalAddonPrice;
  //   // print("totla price ${totalPrice}");
  //   print(lastSelectedChildInfo);
  //   print(addonss);
  // }

  void addProductInCartMethod({
    required BuildContext context,
    required int quantity,
  }) {
    singleProductModel.value!.isVariantCheck == 1
        ? AddToCartVarientBloc().addToCartVarientBlocMethod(
            context: context,
            product_id: product_id,
            addons: selectedAddons.isNotEmpty
                ? selectedAddons
                    .map((selection) => {
                          "addon_id": selection.parentId,
                          "addon_items_id": selection.itemId,
                        })
                    .toList()
                : [],
            quantity: quantity,
            message: addNote.text.isNotEmpty ? addNote.text : "",
            product_variation: selectedSize.value,
            setProgressBar: () {
              AppDialogs.progressAlertDialog(context: context);
            },
          )
        : AddToCartBloc().addToCartBlocMethod(
            context: context,
            product_id: product_id,
            addons: selectedAddons.isNotEmpty
                ? selectedAddons
                    .map((selection) => {
                          "addon_id": selection.parentId,
                          "addon_items_id": selection.itemId,
                        })
                    .toList()
                : [],
            quantity: quantity,
            message: addNote.text.isNotEmpty ? addNote.text : "",
            setProgressBar: () {
              AppDialogs.progressAlertDialog(context: context);
            },
          );
  }

  void changeAddons(
    AddonItems addON,
    String parentId,
  ) {
    addON.parentId = parentId;
    if (selectedAddons.contains(addON)) {
      selectedAddons.remove(addON);
    } else {
      selectedAddons.add(addON);
    }

    update();
  }

  void toggleFav(SingleProductModel product, bool isFav) {
    // Toggle the favorite status of the product
    product.isFavorite = isFav;

    // Find the category that contains the product
    final FoodCategoriesModelDataProductList? filteredCategory = HomeController
        .i.food_category_list_product
        .firstWhereOrNull((category) {
      return category.products
          .any((productItem) => productItem.id == product.id);
    });

    // If the category is found, update the product's favorite status within the category
    if (filteredCategory != null) {
      // Find the product within the category
      for (final productItem in filteredCategory.products) {
        if (productItem.id == product.id) {
          // Update the product's favorite status in the category
          // productItem.isFavourite = !product.isFavorite;
          HomeController.i.toggleFav(productItem, isFav);
          break; // Break the loop once the product is found and updated
        }
      }
    }

    update();
  }
}

extension on List<FoodCategoriesModelDataProductList> {
  // Define an extension method to add `firstWhereOrNull` for convenience
  FoodCategoriesModelDataProductList? firstWhereOrNull(
      bool Function(FoodCategoriesModelDataProductList) test) {
    try {
      return this.firstWhere(test);
    } catch (e) {
      return null;
    }
  }
}
