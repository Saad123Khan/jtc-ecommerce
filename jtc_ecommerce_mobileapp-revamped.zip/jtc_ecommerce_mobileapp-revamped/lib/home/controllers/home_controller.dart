import 'dart:async';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/auth/blocs/get_profile_bloc.dart';
import 'package:jtc_ecommerce/home/blocs/banner_bloc.dart';
import 'package:jtc_ecommerce/home/blocs/food_categories_list_by_hardcoded_id_1_bloc.dart';
import 'package:jtc_ecommerce/home/blocs/food_categories_list_by_hardcoded_id_2_bloc.dart';
import 'package:jtc_ecommerce/home/blocs/food_categories_list_by_hardcoded_id_3_bloc.dart';
import 'package:jtc_ecommerce/home/blocs/food_categories_list_by_hardcoded_id_4_bloc.dart';
import 'package:jtc_ecommerce/home/blocs/food_categories_list_by_hardcoded_id_5_bloc.dart';
import 'package:jtc_ecommerce/home/blocs/get_all_category_product_bloc.dart';
import 'package:jtc_ecommerce/home/blocs/get_all_product_bloc.dart';
import 'package:jtc_ecommerce/home/models/get_banner_model.dart';
import 'package:jtc_ecommerce/home/models/get_food_categories_model.dart';
import 'package:jtc_ecommerce/home/models/get_food_categories_model_product.dart';
import 'package:jtc_ecommerce/home/models/single_product_model.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/splash/screens/model/store_list_model.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/constants.dart';
import 'package:geolocator/geolocator.dart';

class HomeController extends GetxController {
  //START

  RxBool loadingStores = false.obs;
  Rxn<StoreListModel> storeListModel = Rxn<StoreListModel>();

  Rxn<StoreData> selectedStore = Rxn<StoreData>();

  RxList<Result> bannerList = <Result>[].obs;

  static HomeController get i => Get.find();

  Future<void> get_banner() async {
    try {
      isLoading.value = true;
      await BannerBloc().bannerBlocModel(
        context: Get.context!,
      );
      if (BannerBloc().contentTypeResponse != null) {
        bannerList.addAll(
          List.from(BannerBloc().contentTypeResponse),
        );
      }
    } catch (e) {
    } finally {
      isLoading.value = false;
    }
  }

  //1st Category
  RxList<SingleProductModel> singleProductModel = <SingleProductModel>[].obs;

  Future<void> get_food_category_list_by_id_1() async {
    try {
      isLoading.value = true;
      await FoodCategriesListByHardcodedId1Bloc()
          .getFoodCategriesListByHardcodedId1BlocMethod(
        context: Get.context!,
      );
      if (FoodCategriesListByHardcodedId1Bloc().contentTypeResponse != null) {
        singleProductModel.addAll(
          List.from(FoodCategriesListByHardcodedId1Bloc().contentTypeResponse),
        );
      }
      logData(
          message:
              "get_food_category_list_by_id_1: ${singleProductModel.length}");
    } catch (e) {
    } finally {
      isLoading.value = false;
    }
  }

  //2nd Category
  RxList<SingleProductModel> singleProductModel2 = <SingleProductModel>[].obs;

  Future<void> get_food_category_list_by_id_2() async {
    try {
      isLoading.value = true;
      await FoodCategriesListByHardcodedId2Bloc()
          .getFoodCategriesListByHardcodedId2BlocMethod(
        context: Get.context!,
      );
      if (FoodCategriesListByHardcodedId2Bloc().contentTypeResponse != null) {
        singleProductModel2.addAll(
          List.from(FoodCategriesListByHardcodedId2Bloc().contentTypeResponse),
        );
      }
      logData(
          message:
              "get_food_category_list_by_id_2: ${singleProductModel2.length}");
    } catch (e) {
    } finally {
      isLoading.value = false;
    }
  }

  //3rd Category
  RxList<SingleProductModel> singleProductModel3 = <SingleProductModel>[].obs;

  Future<void> get_food_category_list_by_id_3() async {
    try {
      isLoading.value = true;
      await FoodCategriesListByHardcodedId3Bloc()
          .getFoodCategriesListByHardcodedId3BlocMethod(
        context: Get.context!,
      );
      if (FoodCategriesListByHardcodedId3Bloc().contentTypeResponse != null) {
        singleProductModel3.addAll(
          List.from(FoodCategriesListByHardcodedId3Bloc().contentTypeResponse),
        );
      }
      logData(
          message:
              "get_food_category_list_by_id_3: ${singleProductModel3.length}");
    } catch (e) {
    } finally {
      isLoading.value = false;
    }
  }

  //4th Category
  RxList<SingleProductModel> singleProductModel4 = <SingleProductModel>[].obs;

  Future<void> get_food_category_list_by_id_4() async {
    try {
      isLoading.value = true;
      await FoodCategriesListByHardcodedId4Bloc()
          .getFoodCategriesListByHardcodedId4BlocMethod(
        context: Get.context!,
      );
      if (FoodCategriesListByHardcodedId4Bloc().contentTypeResponse != null) {
        singleProductModel4.addAll(
          List.from(FoodCategriesListByHardcodedId4Bloc().contentTypeResponse),
        );
      }
      logData(
          message:
              "get_food_category_list_by_id_4: ${singleProductModel3.length}");
    } catch (e) {
    } finally {
      isLoading.value = false;
    }
  }

  //5th Category
  RxList<SingleProductModel> singleProductModel5 = <SingleProductModel>[].obs;

  Future<void> get_food_category_list_by_id_5() async {
    try {
      isLoading.value = true;
      await FoodCategriesListByHardcodedId5Bloc()
          .getFoodCategriesListByHardcodedId5BlocMethod(
        context: Get.context!,
      );
      if (FoodCategriesListByHardcodedId5Bloc().contentTypeResponse != null) {
        singleProductModel5.addAll(
          List.from(FoodCategriesListByHardcodedId5Bloc().contentTypeResponse),
        );
      }
      logData(
          message:
              "get_food_category_list_by_id_5: ${singleProductModel3.length}");
    } catch (e) {
    } finally {
      isLoading.value = false;
    }
  }

  //END
  @override
  void onInit() async {
    // await get_food_category_list_by_id_1();
    // await get_food_category_list_by_id_2();
    // await get_food_category_list_by_id_3();
    // await get_food_category_list_by_id_4();
    // await get_food_category_list_by_id_5();
    // Timer.periodic(Duration(seconds: 1), (timer) {
    //   if (bannerList.isNotEmpty) {
    //     updateTime(
    //       bannerList[0].openingTime,
    //       bannerList[0].closingTime,
    //     );
    //   }
    // });
    super.onInit();
  }

  loadHomeApis() async {
    await GetUserProfileBloc().getUserProfileBlocMethod(
        context: Constants.navigatorKey.currentContext!,
        setProgressBar: () {
          Get.find<HomeController>().isLoading.value = true;
        });
    await get_banner();
    await get_food_category_product();

    // ]);
  }

  RxList<FoodCategoriesModelDataList> food_category_list =
      <FoodCategoriesModelDataList>[].obs;
  RxBool isLoading = false.obs;
  ScrollController scrollController = ScrollController();

  Future<void> get_food_category() async {
    try {
      isLoading.value = true;
      await GetFoodCategoriesBloc().getFoodCategoriesBlocModel(
        context: Get.context!,
      );

      if (GetFoodCategoriesBloc().contentTypeResponse != null) {
        food_category_list.addAll(
          List.from(GetFoodCategoriesBloc().contentTypeResponse),
        );
      }
    } catch (e) {
    } finally {
      isLoading.value = false;
    }
  }

  RxList<FoodCategoriesModelDataProductList> food_category_list_product =
      <FoodCategoriesModelDataProductList>[].obs;

  Future<void> get_food_category_product() async {
    try {
      isLoading.value = true;
      await GetFoodAllCategoriesProductBloc()
          .getFoodAllCategoriesProductBlocModel(
        context: Get.context!,
      );

      if (GetFoodAllCategoriesProductBloc().contentTypeResponse != null) {
        food_category_list_product.addAll(
          List.from(GetFoodAllCategoriesProductBloc().contentTypeResponse),
        );
      }
    } catch (e) {
    } finally {
      isLoading.value = false;
    }
  }

  bool isFetching = false;
  onRefreshPage() async {
    FocusManager.instance.primaryFocus?.unfocus();
    if (isFetching) {
      // If already fetching, ignore this call
      return;
    }
    isFetching = true;
    //Clear the listings
    // await get_banner();
    // await get_food_category_product();
    await GetUserProfileBloc().getUserProfileBlocMethod(
        context: Constants.navigatorKey.currentContext!,
        setProgressBar: () {
          Get.find<HomeController>().isLoading.value = true;
        });
    food_category_list_product.value = [];
    await get_food_category_product();
    // food_category_list.value = [];
    // singleProductModel.value = [];
    // singleProductModel2.value = [];
    // singleProductModel3.value = [];
    // singleProductModel4.value = [];
    // singleProductModel5.value = [];
    // Fetch new data
    // await get_food_category(); // Replace with your API call
    // await get_food_category_list_by_id_1();
    // await get_food_category_list_by_id_2();
    // await get_food_category_list_by_id_3();
    // await get_food_category_list_by_id_4();
    // await get_food_category_list_by_id_5();
    // Once fetch is complete, reset the flag
    isFetching = false;
  }

  //UI Part Stuff
  final currentSliderIndex = 0.obs;

  final sliders = [
    Image(image: AssetImage('assets/images/home/slider3.png')),
    Image(image: AssetImage('assets/images/home/slider3.png')),
    Image(image: AssetImage('assets/images/home/slider3.png')),
    Image(image: AssetImage('assets/images/home/slider3.png')),
  ];

  RxBool showButton = false.obs;
  RxString formattedTime = ''.obs;

  void updateTime(String openingTime, String closingTime) {
    DateTime currentTime = DateTime.now();

    // Parse opening time and closing time from the API response
    List<String> openingParts = openingTime.split(' ');
    List<String> closingParts = closingTime.split(' ');

    List<int> openingTimeParts = openingParts[0]
        .split(':')
        .map((String part) => int.parse(part))
        .toList();
    List<int> closingTimeParts = closingParts[0]
        .split(':')
        .map((String part) => int.parse(part))
        .toList();

    DateTime startTime = DateTime(
      currentTime.year,
      currentTime.month,
      currentTime.day,
      openingTimeParts[0],
      openingTimeParts[1],
    );

    DateTime endTime = DateTime(
      currentTime.year,
      currentTime.month,
      currentTime.day,
      closingTimeParts[0],
      closingTimeParts[1],
    );

    if (currentTime.isAfter(startTime) && currentTime.isBefore(endTime)) {
      showButton.value = true;
      Duration remainingDuration = endTime.difference(currentTime);

      int hours = remainingDuration.inHours.remainder(60);
      int minutes = remainingDuration.inMinutes.remainder(60);
      int seconds = remainingDuration.inSeconds.remainder(60);
      formattedTime.value =
          '${hours.toString().padLeft(2, '0')} : ${minutes.toString().padLeft(2, '0')} : ${seconds.toString().padLeft(2, '0')}';

      printCurrentTimeBackwards(currentTime, startTime);
    } else {
      showButton.value = false;
      formattedTime.value = 'Out of Time';
    }
  }

  void printCurrentTimeBackwards(DateTime currentTime, DateTime startTime) {
    while (currentTime.isAfter(startTime)) {
      print(
          'current time   ${DateFormat('yyyy-MM-dd HH:mm:ss.S').format(currentTime)}');
      currentTime = currentTime.subtract(Duration(seconds: 1));
    }
  }

  ///Fav Un Fav Local

  void toggleFav(Product product, bool isFav) {
    product.isFavourite = isFav;
    update();
  }

  @override
  void onClose() {
    scrollController.dispose();
    super.onClose();
  }

  Future<Position?> getCurrentLocation() async {
    final isLocationOn = await Geolocator.isLocationServiceEnabled();
    if (!isLocationOn) {
      AppDialogs.showToast(message: tr("please_enable_location"));
      return null;
    }

    final permission = await Geolocator.checkPermission();

    print(permission.name.toString());

    if (permission == LocationPermission.always ||
        permission == LocationPermission.whileInUse) {
      return Geolocator.getCurrentPosition();
    } else if (permission == LocationPermission.deniedForever) {
      AppDialogs.showToast(message: tr("please_enable_location"));
      return null;
    } else if (permission == LocationPermission.denied) {
      print("DENIED M AAGYA");
      final loc = await Geolocator.requestPermission();

      if (loc == LocationPermission.always ||
          loc == LocationPermission.whileInUse) {
        AppDialogs.showToast(message: tr("please_enable_location"));
        return Geolocator.getCurrentPosition();
      } else if (loc == LocationPermission.denied) {
        await Geolocator.requestPermission();
        getCurrentLocation();
      }

      return null;
    }

    return null;
  }

  RxBool isSearching = false.obs;

  RxList<Product> searchedProducts = <Product>[].obs;
  searchProducts(
    String searchQuery,
  ) { 
    if (searchQuery.isNotEmpty) {
      isSearching.value = true;
      searchedProducts.value = food_category_list_product
          .expand((element) => element.products) // Flatten the list of products
          .where((p) =>
              p.nameEn
                  .toString()
                  .toLowerCase()
                  .contains(searchQuery.toLowerCase()) ||
              p.nameSp.toString().toLowerCase().contains(searchQuery
                  .toLowerCase())) // Filter products based on the search query
          .toList(); // Convert the result back to a list
    } else {
      isSearching.value = false;
      searchedProducts.value = [];
    }
  }

  double checkDistanceInMeters(
    double lat1,
    double lon1,
    double lat2,
    double lon2,
  ) {
    final distance = Geolocator.distanceBetween(lat1, lon1, lat2, lon2);
    return distance;
  }
}
