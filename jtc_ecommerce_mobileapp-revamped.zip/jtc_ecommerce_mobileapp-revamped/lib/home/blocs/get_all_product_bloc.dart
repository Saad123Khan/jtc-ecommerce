import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as Getx;
import 'package:jtc_ecommerce/home/controllers/home_controller.dart';
import 'package:jtc_ecommerce/home/models/get_food_categories_model.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';

class GetFoodCategoriesBloc {
  Map<String, dynamic>? _queryParameters;
  Response? _response;
  VoidCallback? _onSuccess;
  dynamic contentTypeResponse;
  GetFoodCategoriesModel? _getFoodCategoriesModel;

  ////////////////////////// Terms and Condition And Privacy Policy //////////////////////////////////
  Future<void> getFoodCategoriesBlocModel({
    required BuildContext context,
  }) async {
    await _getRequest(
      endPoint: NetworkStrings.GET_FOOD_CATEGORIES_ENDPOINT,
      context: context,
    );

    _onSuccess = () {
      contentTypeResponse = _response?.data;
    };

    _validateResponse();

    return contentTypeResponse;
  }

  // Get Request
  Future<void> _getRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().getRequest(
      context: context,
      endPoint: endPoint,
      queryParameters: _queryParameters,
      isToast: false,
      isHeaderRequire: true,
    );
  }

  void _validateResponse() {
    var controller = Getx.Get.find<HomeController>();

    try {
      _getFoodCategoriesModel =
          GetFoodCategoriesModel.fromJson(_response?.data);
      logData(message: "_getGoalModel: ${_getFoodCategoriesModel?.data}");

      List<FoodCategoriesModelDataList> updatedList =
          List.from(controller.food_category_list);
      updatedList.addAll(_getFoodCategoriesModel?.data.data ?? []);

      controller.food_category_list.assignAll(updatedList);
      logData(message: "goalList: ${controller.food_category_list.length}");

      Network().validateResponse(
        response: _response,
        onSuccess: _onSuccess,
        isToast: false,
      );
    } catch (error, stackTrace) {
      print("Error in _validateResponse: $error");
      print("Stack Trace: $stackTrace");
    }
  }
}
