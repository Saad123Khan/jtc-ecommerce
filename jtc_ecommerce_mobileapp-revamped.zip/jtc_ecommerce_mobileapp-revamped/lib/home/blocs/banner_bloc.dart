import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as Getx;
import 'package:jtc_ecommerce/home/controllers/home_controller.dart';
import 'package:jtc_ecommerce/home/models/get_banner_model.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';

class BannerBloc {
  // Map<String, dynamic>? _queryParameters;
  Response? _response;
  VoidCallback? _onSuccess;
  dynamic contentTypeResponse;
  BannerModel? _getProductByCategoryModel;

  ////////////////////////// Terms and Condition And Privacy Policy //////////////////////////////////
  Future<void> bannerBlocModel({
    // required String food_category_id,
    required BuildContext context,
  }) async {
    await _getRequest(
      endPoint: NetworkStrings.STORE_DISCOUNT_BANNER,
      context: context,
    );

    _onSuccess = () {
      contentTypeResponse = _response?.data;
      _validateResponse();
    };

    _validateResponse();

    return contentTypeResponse;
  }

  // Get Request
  Future<void> _getRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().getRequest(
      context: context,
      endPoint: endPoint,
      customFailure: true,

      // queryParameters: _queryParameters,
      isToast: false,
      isHeaderRequire: true,
    );
  }

  // validate(BuildContext context) {
  //   Network().validateResponse(
  //     response: _response,
  //     onFailure: () async {
  //       print("STATUSSS CODEE ${_response?.statusCode}");
  //       final message = _response?.data['message'] ?? "";

  //       switch (message) {
  //         case "Invalid Email or Password":
  //           AppDialogs.showToast(
  //               message: tr(NetworkStrings.INVALID_EMAIL_OR_PASSWORD));
  //           break;

  //         default:
  //           if (context.locale.languageCode != "en") {
  //             final _translatedMessage = await GoogleTranslatorService()
  //                 .translate(text: message, context: context);
  //             AppDialogs.showToast(message: _translatedMessage);
  //           } else {
  //             AppDialogs.showToast(message: message);
  //           }
  //       }
  //     },
  //     onSuccess: _onSuccess,
  //     isToast: false,
  //   );
  // }

  void _validateResponse() {
    var homeController = Getx.Get.find<HomeController>();

    try {
      if (_response?.statusCode == 200) {
        _getProductByCategoryModel = BannerModel.fromJson(_response?.data);
        logData(
            message: "_getGoalModel: ${_getProductByCategoryModel?.results}");
        //1

        List<Result> updatedListForHome =
            List<Result>.from(homeController.bannerList);
        //2
        updatedListForHome.addAll(_getProductByCategoryModel?.results ?? []);
        //3
        homeController.bannerList.assignAll(updatedListForHome);
        logData(
            message: "goalList For home: ${homeController.bannerList.length}");
      } else {
        logData(
            message: "Error in _validateResponse: ${_response?.statusCode}");
        // AppDialogs.showToast(message: tr(NetworkStrings.SOMETHING_WENT_WRONG));
      }
    } catch (error, stackTrace) {
      print("Error in _validateResponse: $error");
      print("Stack Trace: $stackTrace");
    }
  }
}
