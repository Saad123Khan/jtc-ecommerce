import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as Getx;
import 'package:jtc_ecommerce/home/controllers/home_controller.dart';
import 'package:jtc_ecommerce/home/models/get_product_by_category_model.dart';
import 'package:jtc_ecommerce/home/models/single_product_model.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';

class FoodCategriesListByHardcodedId4Bloc {
  Map<String, dynamic>? _queryParameters;
  Response? _response;
  VoidCallback? _onSuccess;
  dynamic contentTypeResponse;
  GetProductByCategoryModel? _getProductByCategoryModel;

  ////////////////////////// Terms and Condition And Privacy Policy //////////////////////////////////
  Future<void> getFoodCategriesListByHardcodedId4BlocMethod({
    required BuildContext context,
  }) async {
    await _getRequest(
      endPoint: NetworkStrings.GET_FOOD_CATEGORIES_LIST_ENDPOINT +
          "11" +
          "&store_id=${HomeController.i.selectedStore.value?.id}",
      context: context,
    );

    _onSuccess = () {
      contentTypeResponse = _response?.data;
    };

    _validateResponse();

    return contentTypeResponse;
  }

  // Get Request
  Future<void> _getRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().getRequest(
      context: context,
      endPoint: endPoint,
      queryParameters: _queryParameters,
      isToast: false,
      isHeaderRequire: true,
    );
  }

  void _validateResponse() {
    var homeController = Getx.Get.find<HomeController>();

    try {
      _getProductByCategoryModel =
          GetProductByCategoryModel.fromJson(_response?.data);
      logData(
          message:
              "_getGoalModel: ${_getProductByCategoryModel?.data.products}");
      //1

      List<SingleProductModel> updatedListForHome =
          List.from(homeController.singleProductModel4);
      //2
      updatedListForHome = _getProductByCategoryModel?.data.products ?? [];
      //3
      homeController.singleProductModel.value = updatedListForHome;
      logData(
          message:
              "goalList For home: ${homeController.singleProductModel4.length}");
      Network().validateResponse(
        response: _response,
        onSuccess: _onSuccess,
        isToast: false,
      );
    } catch (error, stackTrace) {
      print("Error in _validateResponse: $error");
      print("Stack Trace: $stackTrace");
    }
  }
}
