import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as Getx;
import 'package:get/get_core/src/get_main.dart';
import 'package:jtc_ecommerce/home/controllers/home_controller.dart';
import 'package:jtc_ecommerce/home/models/get_food_categories_model.dart';
import 'package:jtc_ecommerce/home/models/get_food_categories_model_product.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/splash/controllers/splash_controller.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';

class GetFoodAllCategoriesProductBloc {
  Map<String, dynamic>? _queryParameters;
  Response? _response;
  VoidCallback? _onSuccess;
  dynamic contentTypeResponse;
  GetFoodCategoriesModelProduct? _getFoodCategoriesModel;

  ////////////////////////// Terms and Condition And Privacy Policy //////////////////////////////////
  Future<void> getFoodAllCategoriesProductBlocModel({
    required BuildContext context,
  }) async {
    var userId = Get.find<SplashController>().currentUser.value?.id;
    await _getRequest(
      endPoint:
          "${NetworkStrings.GET_FOOD_CATEGORIES_PRODUCT_ENDPOINT}?userId=${userId}&store_id=${HomeController.i.selectedStore.value?.id}",
      // endPoint: NetworkStrings.GET_FOOD_CATEGORIES_PRODUCT_ENDPOINT,
      context: context,
    );

    _onSuccess = () {
      contentTypeResponse = _response?.data;
    };

    _validateResponse();

    return contentTypeResponse;
  }

  // Get Request
  Future<void> _getRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().getRequest(
      context: context,
      endPoint: endPoint,
      queryParameters: _queryParameters,
      isToast: false,
      isHeaderRequire: true,
    );
  }

  void _validateResponse() {
    var controller = Getx.Get.find<HomeController>();

    try {
      _getFoodCategoriesModel =
          GetFoodCategoriesModelProduct.fromJson(_response?.data);
      logData(
          message:
              "CATEGORYYY WISE PRODUCTTT: ${_getFoodCategoriesModel?.data}");

      // List<FoodCategoriesModelDataProductList> updatedList =controller.food_category_list_product;
      // updatedList.addAll();

      controller.food_category_list_product.value = _getFoodCategoriesModel?.data ?? [];
      logData(
          message:
              "food_category_list_product: ${controller.food_category_list_product.length}");

      Network().validateResponse(
        response: _response,
        onSuccess: _onSuccess,
        isToast: false,
      );
    } catch (error, stackTrace) {
      print("Error in _validateResponse: $error");
      print("Stack Trace: $stackTrace");
    }
  }
}
