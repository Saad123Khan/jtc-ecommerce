import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as Getx;
import 'package:jtc_ecommerce/home/controllers/product_detail_controller.dart';
import 'package:jtc_ecommerce/home/models/single_product_detail_model.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';

class GetSingleProductDetailBloc {
  Map<String, dynamic>? _queryParameters;
  Response? _response;
  VoidCallback? _onSuccess;
  dynamic contentTypeResponse;
  SingleProductDetailModel? _singleProductDetailModel;

  ////////////////////////// Terms and Condition And Privacy Policy //////////////////////////////////
  Future<void> getSingleProductDetailBlocMethod({
    required BuildContext context,
    required String product_id,
  }) async {
    await _getRequest(
      endPoint: NetworkStrings.GET_SINGLE_PRODUCT_DETAIL_ENDPOINT + product_id,
      context: context,
    );

    _onSuccess = () {
      contentTypeResponse = _response?.data;
    };

    _validateResponse();

    return contentTypeResponse;
  }

  // Get Request
  Future<void> _getRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().getRequest(
      context: context,
      endPoint: endPoint,
      queryParameters: _queryParameters,
      isToast: false,
      isHeaderRequire: true,
    );
  }

  void _validateResponse() {
    var controller = Getx.Get.find<ProductDetailController>();
    // try {
    _singleProductDetailModel =
        SingleProductDetailModel.fromJson(_response?.data);
    controller.singleProductModel.value =
        _singleProductDetailModel?.data.product;
    // var product_data = _singleProductDetailModel?.data.product;
    controller.initMediaPosts();

    // print("api callllllllllllll");
    // logData(
    //     message:
    //         "ISFAV DETAIL: ${controller.singleProductModel.value!.isFavorite}");
    // if (product_data!.imageUrl != null) {
    // if (product_data.imageUrl.length > 0) {
    //   controller.product_image.value = product_data?.imageUrl.length != null
    //       ? product_data?.imageUrl.first ?? ""
    //       : "";
    // // }
    // }
    print("api callllllllllllll");
    Network().validateResponse(
      response: _response,
      onSuccess: _onSuccess,
      isToast: false,
    );
    // } catch (error, stackTrace) {
    //   print("Error in _validateResponse: $error");
    //   print("Stack Trace: $stackTrace");
    // }
  }
}
