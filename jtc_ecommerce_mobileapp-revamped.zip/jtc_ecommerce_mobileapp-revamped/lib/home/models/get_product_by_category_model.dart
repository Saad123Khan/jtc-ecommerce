import 'dart:convert';

import 'package:jtc_ecommerce/home/models/single_product_model.dart';

GetProductByCategoryModel getProductByCategoryModelFromJson(String str) =>
    GetProductByCategoryModel.fromJson(json.decode(str));

String getProductByCategoryModelToJson(GetProductByCategoryModel data) =>
    json.encode(data.toJson());

class GetProductByCategoryModel {
  bool status;
  GetProductByCategoryData data;

  GetProductByCategoryModel({
    required this.status,
    required this.data,
  });

  factory GetProductByCategoryModel.fromJson(Map<String, dynamic> json) =>
      GetProductByCategoryModel(
        status: json["status"],
        data: GetProductByCategoryData.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "status": status,
        "data": data.toJson(),
      };
}

class GetProductByCategoryData {
  int id;
  String name;
  DateTime createdAt;
  DateTime updatedAt;
  String imageUrl;
  List<SingleProductModel> products;
  // List<Media> media;

  GetProductByCategoryData({
    required this.id,
    required this.name,
    required this.createdAt,
    required this.updatedAt,
    required this.imageUrl,
    required this.products,
    // required this.media,
  });

  factory GetProductByCategoryData.fromJson(Map<String, dynamic> json) =>
      GetProductByCategoryData(
        id: json["id"],
        name: json["name"] ?? '',
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        imageUrl: json["image_url"],
        products: List<SingleProductModel>.from(
            json["products"].map((x) => SingleProductModel.fromJson(x))),
        // media: List<Media>.from(json["media"].map((x) => Media.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "image_url": imageUrl,
        "products": List<dynamic>.from(products.map((x) => x.toJson())),
        // "media": List<dynamic>.from(media.map((x) => x.toJson())),
      };
}

// class Media {
//     int id;
//     ModelType modelType;
//     int modelId;
//     String uuid;
//     CollectionName collectionName;
//     String name;
//     String fileName;
//     MimeType mimeType;
//     Disk disk;
//     Disk conversionsDisk;
//     int size;
//     List<dynamic> manipulations;
//     List<dynamic> customProperties;
//     List<dynamic> generatedConversions;
//     List<dynamic> responsiveImages;
//     int orderColumn;
//     DateTime createdAt;
//     DateTime updatedAt;
//     String originalUrl;
//     String previewUrl;

//     Media({
//         required this.id,
//         required this.modelType,
//         required this.modelId,
//         required this.uuid,
//         required this.collectionName,
//         required this.name,
//         required this.fileName,
//         required this.mimeType,
//         required this.disk,
//         required this.conversionsDisk,
//         required this.size,
//         required this.manipulations,
//         required this.customProperties,
//         required this.generatedConversions,
//         required this.responsiveImages,
//         required this.orderColumn,
//         required this.createdAt,
//         required this.updatedAt,
//         required this.originalUrl,
//         required this.previewUrl,
//     });

//     factory Media.fromJson(Map<String, dynamic> json) => Media(
//         id: json["id"],
//         modelType: modelTypeValues.map[json["model_type"]]!,
//         modelId: json["model_id"],
//         uuid: json["uuid"],
//         collectionName: collectionNameValues.map[json["collection_name"]]!,
//         name: json["name"],
//         fileName: json["file_name"],
//         mimeType: mimeTypeValues.map[json["mime_type"]]!,
//         disk: diskValues.map[json["disk"]]!,
//         conversionsDisk: diskValues.map[json["conversions_disk"]]!,
//         size: json["size"],
//         manipulations: List<dynamic>.from(json["manipulations"].map((x) => x)),
//         customProperties: List<dynamic>.from(json["custom_properties"].map((x) => x)),
//         generatedConversions: List<dynamic>.from(json["generated_conversions"].map((x) => x)),
//         responsiveImages: List<dynamic>.from(json["responsive_images"].map((x) => x)),
//         orderColumn: json["order_column"],
//         createdAt: DateTime.parse(json["created_at"]),
//         updatedAt: DateTime.parse(json["updated_at"]),
//         originalUrl: json["original_url"],
//         previewUrl: json["preview_url"],
//     );

//     Map<String, dynamic> toJson() => {
//         "id": id,
//         "model_type": modelTypeValues.reverse[modelType],
//         "model_id": modelId,
//         "uuid": uuid,
//         "collection_name": collectionNameValues.reverse[collectionName],
//         "name": name,
//         "file_name": fileName,
//         "mime_type": mimeTypeValues.reverse[mimeType],
//         "disk": diskValues.reverse[disk],
//         "conversions_disk": diskValues.reverse[conversionsDisk],
//         "size": size,
//         "manipulations": List<dynamic>.from(manipulations.map((x) => x)),
//         "custom_properties": List<dynamic>.from(customProperties.map((x) => x)),
//         "generated_conversions": List<dynamic>.from(generatedConversions.map((x) => x)),
//         "responsive_images": List<dynamic>.from(responsiveImages.map((x) => x)),
//         "order_column": orderColumn,
//         "created_at": createdAt.toIso8601String(),
//         "updated_at": updatedAt.toIso8601String(),
//         "original_url": originalUrl,
//         "preview_url": previewUrl,
//     };
// }

// enum CollectionName {
//     PRODUCT,
//     PRODUCT_CATEGORY
// }

// final collectionNameValues = EnumValues({
//     "product": CollectionName.PRODUCT,
//     "product_category": CollectionName.PRODUCT_CATEGORY
// });

// enum Disk {
//     PUBLIC
// }

// final diskValues = EnumValues({
//     "public": Disk.PUBLIC
// });

// enum MimeType {
//     IMAGE_JPEG,
//     IMAGE_PNG
// }

// final mimeTypeValues = EnumValues({
//     "image/jpeg": MimeType.IMAGE_JPEG,
//     "image/png": MimeType.IMAGE_PNG
// });

// enum ModelType {
//     APP_MODELS_PRODUCT,
//     APP_MODELS_PRODUCT_CATEGORY
// }

// final modelTypeValues = EnumValues({
//     "App\\Models\\Product": ModelType.APP_MODELS_PRODUCT,
//     "App\\Models\\ProductCategory": ModelType.APP_MODELS_PRODUCT_CATEGORY
// });

// class ProCategoury {
//     int id;
//     String name;
//     String code;
//     int barcodeSymbol;
//     int productCategoryId;
//     int productSubcategoryId;
//     int brandId;
//     int productCost;
//     String? makingTime;
//     double productPrice;
//     String productUnit;
//     String saleUnit;
//     String purchaseUnit;
//     String stockAlert;
//     String? quantityLimit;
//     double? orderTax;
//     String taxType;
//     String? notes;
//     DateTime createdAt;
//     DateTime updatedAt;
//     int? orderCreateBy;
//     String? description;
//     String productInvesters;
//     int productJtcToken;
//     String totalPrice;
//     int totalJtcToken;
//     String profitMargin;
//     int withoutTaxToken;
//     List<String> imageUrl;
//     String barcodeImageUrl;
//     List<Media> media;

//     ProCategoury({
//         required this.id,
//         required this.name,
//         required this.code,
//         required this.barcodeSymbol,
//         required this.productCategoryId,
//         required this.productSubcategoryId,
//         required this.brandId,
//         required this.productCost,
//         required this.makingTime,
//         required this.productPrice,
//         required this.productUnit,
//         required this.saleUnit,
//         required this.purchaseUnit,
//         required this.stockAlert,
//         required this.quantityLimit,
//         required this.orderTax,
//         required this.taxType,
//         required this.notes,
//         required this.createdAt,
//         required this.updatedAt,
//         required this.orderCreateBy,
//         required this.description,
//         required this.productInvesters,
//         required this.productJtcToken,
//         required this.totalPrice,
//         required this.totalJtcToken,
//         required this.profitMargin,
//         required this.withoutTaxToken,
//         required this.imageUrl,
//         required this.barcodeImageUrl,
//         required this.media,
//     });

//     factory ProCategoury.fromJson(Map<String, dynamic> json) => ProCategoury(
//         id: json["id"],
//         name: json["name"],
//         code: json["code"],
//         barcodeSymbol: json["barcode_symbol"],
//         productCategoryId: json["product_category_id"],
//         productSubcategoryId: json["product_subcategory_id"],
//         brandId: json["brand_id"],
//         productCost: json["product_cost"],
//         makingTime: json["making_time"],
//         productPrice: json["product_price"]?.toDouble(),
//         productUnit: json["product_unit"],
//         saleUnit: json["sale_unit"],
//         purchaseUnit: json["purchase_unit"],
//         stockAlert: json["stock_alert"],
//         quantityLimit: json["quantity_limit"],
//         orderTax: json["order_tax"]?.toDouble(),
//         taxType: json["tax_type"],
//         notes: json["notes"],
//         createdAt: DateTime.parse(json["created_at"]),
//         updatedAt: DateTime.parse(json["updated_at"]),
//         orderCreateBy: json["order_create_by"],
//         description: json["description"],
//         productInvesters: json["product_investers"],
//         productJtcToken: json["product_jtcToken"],
//         totalPrice: json["total_price"],
//         totalJtcToken: json["total_jtcToken"],
//         profitMargin: json["profit_margin"],
//         withoutTaxToken: json["withoutTax_token"],
//         imageUrl: List<String>.from(json["image_url"].map((x) => x)),
//         barcodeImageUrl: json["barcode_image_url"],
//         media: List<Media>.from(json["media"].map((x) => Media.fromJson(x))),
//     );

//     Map<String, dynamic> toJson() => {
//         "id": id,
//         "name": name,
//         "code": code,
//         "barcode_symbol": barcodeSymbol,
//         "product_category_id": productCategoryId,
//         "product_subcategory_id": productSubcategoryId,
//         "brand_id": brandId,
//         "product_cost": productCost,
//         "making_time": makingTime,
//         "product_price": productPrice,
//         "product_unit": productUnit,
//         "sale_unit": saleUnit,
//         "purchase_unit": purchaseUnit,
//         "stock_alert": stockAlert,
//         "quantity_limit": quantityLimit,
//         "order_tax": orderTax,
//         "tax_type": taxType,
//         "notes": notes,
//         "created_at": createdAt.toIso8601String(),
//         "updated_at": updatedAt.toIso8601String(),
//         "order_create_by": orderCreateBy,
//         "description": description,
//         "product_investers": productInvesters,
//         "product_jtcToken": productJtcToken,
//         "total_price": totalPrice,
//         "total_jtcToken": totalJtcToken,
//         "profit_margin": profitMargin,
//         "withoutTax_token": withoutTaxToken,
//         "image_url": List<dynamic>.from(imageUrl.map((x) => x)),
//         "barcode_image_url": barcodeImageUrl,
//         "media": List<dynamic>.from(media.map((x) => x.toJson())),
//     };
// }

// class EnumValues<T> {
//     Map<String, T> map;
//     late Map<T, String> reverseMap;

//     EnumValues(this.map);

//     Map<T, String> get reverse {
//         reverseMap = map.map((k, v) => MapEntry(v, k));
//         return reverseMap;
//     }
// }
