// To parse this JSON data, do
//
//     final foodCategoriesModel = foodCategoriesModelFromJson(jsonString);

import 'dart:convert';

GetFoodCategoriesModel foodCategoriesModelFromJson(String str) =>
    GetFoodCategoriesModel.fromJson(json.decode(str));

String foodCategoriesModelToJson(GetFoodCategoriesModel data) =>
    json.encode(data.toJson());

class GetFoodCategoriesModel {
  bool status;
  FoodCategoriesModelData data;

  GetFoodCategoriesModel({
    required this.status,
    required this.data,
  });

  factory GetFoodCategoriesModel.fromJson(Map<String, dynamic> json) =>
      GetFoodCategoriesModel(
        status: json["status"],
        data: FoodCategoriesModelData.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "status": status,
        "data": data.toJson(),
      };
}

class FoodCategoriesModelData {
  // int currentPage;
  List<FoodCategoriesModelDataList> data;
  // String firstPageUrl;
  // int from;
  // int lastPage;
  // String lastPageUrl;
  // // List<Link> links;
  // String nextPageUrl;
  // String path;
  // int perPage;
  // dynamic prevPageUrl;
  // int to;
  // int total;

  FoodCategoriesModelData({
    // required this.currentPage,
    required this.data,
    // required this.firstPageUrl,
    // required this.from,
    // required this.lastPage,
    // required this.lastPageUrl,
    // required this.links,
    // required this.nextPageUrl,
    // required this.path,
    // required this.perPage,
    // required this.prevPageUrl,
    // required this.to,
    // required this.total,
  });

  factory FoodCategoriesModelData.fromJson(Map<String, dynamic> json) =>
      FoodCategoriesModelData(
        // currentPage: json["current_page"],
        data: List<FoodCategoriesModelDataList>.from(
            json["data"].map((x) => FoodCategoriesModelDataList.fromJson(x))),
        // firstPageUrl: json["first_page_url"],
        // from: json["from"],
        // lastPage: json["last_page"],
        // lastPageUrl: json["last_page_url"],
        // // links: List<Link>.from(json["links"].map((x) => Link.fromJson(x))),
        // nextPageUrl: json["next_page_url"],
        // path: json["path"],
        // perPage: json["per_page"],
        // prevPageUrl: json["prev_page_url"],
        // to: json["to"],
        // total: json["total"],
      );

  Map<String, dynamic> toJson() => {
        // "current_page": currentPage,
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
        // "first_page_url": firstPageUrl,
        // "from": from,
        // "last_page": lastPage,
        // "last_page_url": lastPageUrl,
        // "links": List<dynamic>.from(links.map((x) => x.toJson())),
        // "next_page_url": nextPageUrl,
        // "path": path,
        // "per_page": perPage,
        // "prev_page_url": prevPageUrl,
        // "to": to,
        // "total": total,
      };
}

class FoodCategoriesModelDataList {
  int id;
  String name;
  // DateTime createdAt;
  // DateTime updatedAt;
  // int productsCount;
  String imageUrl;
  // List<Media> media;

  FoodCategoriesModelDataList({
    required this.id,
    required this.name,
    // required this.createdAt,
    // required this.updatedAt,
    // required this.productsCount,
    required this.imageUrl,
    // required this.media,
  });

  factory FoodCategoriesModelDataList.fromJson(Map<String, dynamic> json) =>
      FoodCategoriesModelDataList(
        id: json["id"],
        name: json["name"],
        // createdAt: DateTime.parse(json["created_at"]),
        // updatedAt: DateTime.parse(json["updated_at"]),
        // productsCount: json["products_count"],
        imageUrl: json["image_url"],
        // media: List<Media>.from(json["media"].map((x) => Media.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        // "created_at": createdAt.toIso8601String(),
        // "updated_at": updatedAt.toIso8601String(),
        // "products_count": productsCount,
        "image_url": imageUrl,
        // "media": List<dynamic>.from(media.map((x) => x.toJson())),
      };
}

// class Media {
//   int id;
//   String modelType;
//   int modelId;
//   String uuid;
//   String collectionName;
//   String name;
//   String fileName;
//   String mimeType;
//   String disk;
//   String conversionsDisk;
//   int size;
//   List<dynamic> manipulations;
//   List<dynamic> customProperties;
//   List<dynamic> generatedConversions;
//   List<dynamic> responsiveImages;
//   int orderColumn;
//   DateTime createdAt;
//   DateTime updatedAt;
//   String originalUrl;
//   String previewUrl;

//   Media({
//     required this.id,
//     required this.modelType,
//     required this.modelId,
//     required this.uuid,
//     required this.collectionName,
//     required this.name,
//     required this.fileName,
//     required this.mimeType,
//     required this.disk,
//     required this.conversionsDisk,
//     required this.size,
//     required this.manipulations,
//     required this.customProperties,
//     required this.generatedConversions,
//     required this.responsiveImages,
//     required this.orderColumn,
//     required this.createdAt,
//     required this.updatedAt,
//     required this.originalUrl,
//     required this.previewUrl,
//   });

//   factory Media.fromJson(Map<String, dynamic> json) => Media(
//         id: json["id"],
//         modelType: json["model_type"],
//         modelId: json["model_id"],
//         uuid: json["uuid"],
//         collectionName: json["collection_name"],
//         name: json["name"],
//         fileName: json["file_name"],
//         mimeType: json["mime_type"],
//         disk: json["disk"],
//         conversionsDisk: json["conversions_disk"],
//         size: json["size"],
//         manipulations: List<dynamic>.from(json["manipulations"].map((x) => x)),
//         customProperties:
//             List<dynamic>.from(json["custom_properties"].map((x) => x)),
//         generatedConversions:
//             List<dynamic>.from(json["generated_conversions"].map((x) => x)),
//         responsiveImages:
//             List<dynamic>.from(json["responsive_images"].map((x) => x)),
//         orderColumn: json["order_column"],
//         createdAt: DateTime.parse(json["created_at"]),
//         updatedAt: DateTime.parse(json["updated_at"]),
//         originalUrl: json["original_url"],
//         previewUrl: json["preview_url"],
//       );

//   Map<String, dynamic> toJson() => {
//         "id": id,
//         "model_type": modelType,
//         "model_id": modelId,
//         "uuid": uuid,
//         "collection_name": collectionName,
//         "name": name,
//         "file_name": fileName,
//         "mime_type": mimeType,
//         "disk": disk,
//         "conversions_disk": conversionsDisk,
//         "size": size,
//         "manipulations": List<dynamic>.from(manipulations.map((x) => x)),
//         "custom_properties": List<dynamic>.from(customProperties.map((x) => x)),
//         "generated_conversions":
//             List<dynamic>.from(generatedConversions.map((x) => x)),
//         "responsive_images": List<dynamic>.from(responsiveImages.map((x) => x)),
//         "order_column": orderColumn,
//         "created_at": createdAt.toIso8601String(),
//         "updated_at": updatedAt.toIso8601String(),
//         "original_url": originalUrl,
//         "preview_url": previewUrl,
//       };
// }

// class Link {
//   String? url;
//   String label;
//   bool active;

//   Link({
//     required this.url,
//     required this.label,
//     required this.active,
//   });

//   factory Link.fromJson(Map<String, dynamic> json) => Link(
//         url: json["url"],
//         label: json["label"],
//         active: json["active"],
//       );

//   Map<String, dynamic> toJson() => {
//         "url": url,
//         "label": label,
//         "active": active,
//       };
// }
