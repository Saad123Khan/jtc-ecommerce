// To parse this JSON data, do
//
//     final singleProductModel = singleProductModelFromJson(jsonString);

import 'dart:convert';

SingleProductModel singleProductModelFromJson(String str) =>
    SingleProductModel.fromJson(json.decode(str));

String singleProductModelToJson(SingleProductModel data) =>
    json.encode(data.toJson());

class SingleProductModel {
  // // int id;
  // // String name;
  // // String code;
  // // int productCategoryId;
  // // int productSubcategoryId;
  // // int brandId;
  // // String productCost;
  // // String productPrice;
  // // String productUnit;
  // // String saleUnit;
  // // String purchaseUnit;
  // // String stockAlert;
  // // String quantityLimit;
  // // // int makingTime;
  // // // String orderTax;
  // // // String taxType;
  // // String notes;
  // // String description;
  List<String> images;
  // // // String productCategoryName;
  // // // String productSubcategoryName;
  // // // String brandName;
  // // // String barcodeImageUrl;
  // // // int barcodeSymbol;
  // // // DateTime createdAt;
  // // // String orderCreateBy;
  // // // ProductUnitName productUnitName;
  // // EUnitName purchaseUnitName;
  // // EUnitName saleUnitName;
  // // Stock stock;
  List<ProductAddons> productAddons;
  //  List<ProductAddons> productAddons;

  // // List<Warehouse> warehouse;
  // // String barcodeUrl;
  // // int inStock;
  // // String review;
  // RxBool isFavourite;
  // // int favouriteCount;
  // // String profitMargin;
  // // String productInvesters;
  // // int productJtcToken;
  // int id;
  // String name;
  // String code;
  // int barcodeSymbol;
  // int productCategoryId;
  // int productSubcategoryId;
  // int brandId;
  // String productCost;
  // String? makingTime;
  // String productPrice;
  // String productUnit;
  // String saleUnit;
  // String purchaseUnit;
  // String stockAlert;
  // String? quantityLimit;
  // String? orderTax;
  // String taxType;
  // String? notes;
  // DateTime createdAt;
  // DateTime updatedAt;
  // dynamic orderCreateBy;
  // String? description;
  // String productInvesters;
  // int productJtcToken;
  // String totalPrice;
  // int totalJtcToken;
  // String profitMargin;
  // int withoutTaxToken;
  // List<String> imageUrl;
  // String barcodeImageUrl;
  // // List<Media> media;

  dynamic id;
  dynamic name;


  dynamic code;
  dynamic barcodeSymbol;
  dynamic productCategoryId;
  dynamic productSubcategoryId;
  dynamic brandId;
  dynamic productCost;
  dynamic makingTime;
  double productPrice = 0.0;
  dynamic productUnit;
  dynamic saleUnit;
  dynamic purchaseUnit;
  dynamic stockAlert;
  dynamic quantityLimit;
  dynamic orderTax;
  dynamic taxType;
  dynamic notes;
  dynamic createdAt;
  dynamic updatedAt;
  dynamic orderCreateBy;
  dynamic description;

  dynamic productInvesters;
  dynamic productJtcToken;
  dynamic totalPrice;
  dynamic totalJtcToken;
  dynamic profitMargin;
  dynamic withoutTaxToken;
  // List<Addon> addons;
  bool isFavorite;
  List<String> imageUrl;
  dynamic barcodeImageUrl;
  int  isVariantCheck;
  double smallPrice = 0.0;
  double mediumPrice = 0.0;
  double largePrice = 0.0;
  double smallToken;
  double mediumToken;
  double largeToken;
  double small;
  double medium;
  double large;
  double smallTokenPrice;
  double mediumTokenPrice;
  double largeTokenPrice;
  dynamic isDeleted;

  dynamic nameEn;
  dynamic nameSp;

  dynamic descriptionEn;
  dynamic descriptionSp;

  // List<Media> media;

  SingleProductModel({
    // // required this.id,
    // // required this.name,
    // // required this.code,
    // // required this.productCategoryId,
    // // required this.productSubcategoryId,
    // // required this.brandId,
    // // required this.productCost,
    // // required this.productPrice,
    // // required this.productUnit,
    // // required this.saleUnit,
    // // required this.purchaseUnit,
    // // required this.stockAlert,
    // // required this.quantityLimit,
    // // // required this.makingTime,
    // // // required this.orderTax,
    // // // required this.taxType,
    // // required this.notes,
    // // required this.description,
    required this.images,
    // // // required this.productCategoryName,
    // // // required this.productSubcategoryName,
    // // // required this.brandName,
    // // // required this.barcodeImageUrl,
    // // // required this.barcodeSymbol,
    // // // required this.createdAt,
    // // // required this.orderCreateBy,
    // // // required this.productUnitName,
    // // required this.purchaseUnitName,
    // // required this.saleUnitName,
    // // required this.stock,
    required this.productAddons,

    // // required this.warehouse,
    // // required this.barcodeUrl,
    // // required this.inStock,
    // // required this.review,
    // required this.isFavourite,
    // // required this.favouriteCount,
    // // required this.profitMargin,
    // // required this.productInvesters,
    // // required this.productJtcToken,
    // required this.id,
    // required this.name,
    // required this.code,
    // required this.barcodeSymbol,
    // required this.productCategoryId,
    // required this.productSubcategoryId,
    // required this.brandId,
    // required this.productCost,
    // required this.makingTime,
    // required this.productPrice,
    // required this.productUnit,
    // required this.saleUnit,
    // required this.purchaseUnit,
    // required this.stockAlert,
    // required this.quantityLimit,
    // required this.orderTax,
    // required this.taxType,
    // required this.notes,
    // required this.createdAt,
    // required this.updatedAt,
    // required this.orderCreateBy,
    // required this.description,
    // required this.productInvesters,
    // required this.productJtcToken,
    // required this.totalPrice,
    // required this.totalJtcToken,
    // required this.profitMargin,
    // required this.withoutTaxToken,
    // required this.imageUrl,
    // required this.barcodeImageUrl,
    // // required this.media,
    required this.id,
    required this.name,
    required this.code,
    required this.barcodeSymbol,
    required this.productCategoryId,
    required this.productSubcategoryId,
    required this.brandId,
    required this.productCost,
    required this.makingTime,
     this.productPrice = 0.0,
    required this.productUnit,
    required this.saleUnit,
    required this.purchaseUnit,
    required this.stockAlert,
    required this.quantityLimit,
    required this.orderTax,
    required this.taxType,
    required this.notes,
    required this.createdAt,
    required this.updatedAt,
    required this.orderCreateBy,
    required this.description,
    required this.productInvesters,
    required this.productJtcToken,
    required this.totalPrice,
    required this.totalJtcToken,
    required this.profitMargin,
    required this.withoutTaxToken,
    // required this.addons,
    required this.isFavorite,
    required this.imageUrl,
    required this.barcodeImageUrl,
    // required this.media,
    required this.isVariantCheck,
    required this.smallPrice,
    required this.mediumPrice,
    required this.largePrice,
    required this.smallToken,
    required this.mediumToken,
    required this.largeToken,
    required this.small,
    required this.medium,
    required this.large,
    required this.smallTokenPrice,
    required this.mediumTokenPrice,
    required this.largeTokenPrice,
    required this.isDeleted,
    required this.nameEn,
    required this.nameSp,
    required this.descriptionEn,
    required this.descriptionSp,
  });

  factory SingleProductModel.fromJson(Map<String, dynamic> json) =>
      SingleProductModel(
        nameEn: json["name_en"],
        nameSp: json["name_sp"],
        descriptionEn: json["description_en"],
        descriptionSp: json["description_sp"],
        // // id: json["id"],
        // // name: json["name"],
        // // code: json["code"],
        // // productCategoryId: json["product_category_id"],
        // // productSubcategoryId: json["product_subcategory_id"],
        // // brandId: json["brand_id"],
        // // productCost: json["product_cost"],
        // // productPrice: json["product_price"],
        // // productUnit: json["product_unit"],
        // // saleUnit: json["sale_unit"],
        // // purchaseUnit: json["purchase_unit"],
        // // stockAlert: json["stock_alert"] != null ? json["stock_alert"] : "",
        // // quantityLimit:
        // //     json["quantity_limit"] != null ? json["quantity_limit"] : "",
        // // // makingTime: json["making_time"],
        // // // orderTax: json["order_tax"],
        // // // taxType: json["tax_type"],
        // // notes: json["notes"] != null ? json["notes"] : "",
        // // description: json["description"] != null ? json["description"] : "",
        images: json["images"] != null
            ? List<String>.from(json["images"].map((x) => x))
            : [],
        // // // productCategoryName: json["product_category_name"],
        // // // productSubcategoryName: json["product_subcategory_name"],
        // // // brandName: json["brand_name"],
        // // // barcodeImageUrl: json["barcode_image_url"],
        // // // barcodeSymbol: json["barcode_symbol"],
        // // // createdAt: DateTime.parse(json["created_at"]),
        // // // orderCreateBy: json["order_create_by"],
        // // // productUnitName: ProductUnitName.fromJson(json["product_unit_name"]),
        // // purchaseUnitName: EUnitName.fromJson(json["purchase_unit_name"]),
        // // saleUnitName: EUnitName.fromJson(json["sale_unit_name"]),
        // // stock: Stock.fromJson(json["stock"]),
        productAddons: json["product_addons"] != null ?  List<ProductAddons>.from(
            json["product_addons"].map((x) => ProductAddons.fromJson(x))): [],

        // // warehouse: List<Warehouse>.from(
        // //     json["warehouse"].map((x) => Warehouse.fromJson(x))),
        // // barcodeUrl: json["barcode_url"],
        // // inStock: json["in_stock"],
        // // review: json["review"],
        // isFavourite: RxBool(json["is_favourite"]),
        // // favouriteCount: json["favourite_count"],
        // // profitMargin: json["profit_margin"],
        // // productInvesters: json["product_investers"],
        // // productJtcToken: json["product_jtcToken"],
        // id: json["id"],
        // name: json["name"],
        // code: json["code"],
        // barcodeSymbol: json["barcode_symbol"],
        // productCategoryId: json["product_category_id"],
        // productSubcategoryId: json["product_subcategory_id"],
        // brandId: json["brand_id"],
        // productCost: json["product_cost"],
        // makingTime: json["making_time"],
        // productPrice: json["product_price"],
        // productUnit: json["product_unit"],
        // saleUnit: json["sale_unit"],
        // purchaseUnit: json["purchase_unit"],
        // stockAlert: json["stock_alert"],
        // quantityLimit: json["quantity_limit"],
        // orderTax: json["order_tax"],
        // taxType: json["tax_type"],
        // notes: json["notes"],
        // createdAt: DateTime.parse(json["created_at"]),
        // updatedAt: DateTime.parse(json["updated_at"]),
        // orderCreateBy: json["order_create_by"],
        // description: json["description"],
        // productInvesters: json["product_investers"], 
        // productJtcToken: json["product_jtcToken"],
        // totalPrice: json["total_price"],
        // totalJtcToken: json["total_jtcToken"],
        // profitMargin: json["profit_margin"],
        // withoutTaxToken: json["withoutTax_token"],
        // imageUrl: List<String>.from(json["image_url"].map((x) => x)),
        // barcodeImageUrl: json["barcode_image_url"],
        // media: List<Media>.from(json["media"].map((x) => Media.fromJson(x))),

        id: json["id"],
        name: json["name"],
        code: json["code"],
        barcodeSymbol: json["barcode_symbol"],
        productCategoryId: json["product_category_id"],
        productSubcategoryId: json["product_subcategory_id"],
        brandId: json["brand_id"],
        productCost: json["product_cost"],
        makingTime: json["making_time"],
        productPrice: json["product_price"] != null ? double.parse(json["product_price"].toString()): 0.0,
        productUnit: json["product_unit"],
        saleUnit: json["sale_unit"],
        purchaseUnit: json["purchase_unit"],
        stockAlert: json["stock_alert"],
        quantityLimit: json["quantity_limit"],
        orderTax: json["order_tax"],
        taxType: json["tax_type"],
        notes: json["notes"],
        createdAt: json["created_at"],
        updatedAt: json["updated_at"],
        orderCreateBy: json["order_create_by"],
        description: json["description"],
        productInvesters: json["product_investers"],
        productJtcToken: json["product_jtcToken"],
        totalPrice: json["total_price"],
        totalJtcToken: json["total_jtcToken"],
        profitMargin: json["profit_margin"],
        withoutTaxToken: json["withoutTax_token"],
        // addons: List<Addon>.from(json["addons"].map((x) => Addon.fromJson(x))),
        isFavorite: json["is_favourite"] ?? false,
        imageUrl: List<String>.from(json["image_url"].map((x) => x)),
        barcodeImageUrl: json["barcode_image_url"],
        // media: List<Media>.from(json["media"].map((x) => Media.fromJson(x))),
        isVariantCheck: json["is_variant_check"],
        smallPrice: json["small_price"] != null ? double.parse(json['small_price'].toString()) : 0.0,
        mediumPrice: json["medium_price"] != null ? double.parse(json['medium_price'].toString()): 0.0,
        largePrice: json["large_price"] != null ? double.parse(json['large_price'].toString()) : 0.0,
        smallToken: json["small_token"] != null ? double.parse(json['small_token'].toString()): 0 ,
        mediumToken: json["medium_token"] != null ? double.parse(json['medium_token'].toString()): 0,
        largeToken: json["large_token"] != null ? double.parse(json['large_token'].toString()): 0,
        small: json["small"] != null ? double.parse(json['small'].toString()): 0.0,
        medium: json["medium"] != null ? double.parse(json['medium'].toString()): 0.0,
        large: json["large"] != null ? double.parse(json['large'].toString()): 0.0 ,
        smallTokenPrice: json["small_token_price"] != null ? double.parse(json['small_token_price'].toString()): 0,
        mediumTokenPrice: json["medium_token_price"] != null ? double.parse(json['medium_token_price'].toString()): 0,
        largeTokenPrice: json["large_token_price"] != null ? double.parse(json['large_token_price'].toString()): 0,
        isDeleted: json["is_deleted"],
      );

  Map<String, dynamic> toJson() => {
        "nameEn": nameEn,
        "nameSp": nameSp,
        "descriptionEn": descriptionEn,
        "descriptionSp": descriptionSp,

        // // "id": id,
        // // "name": name,
        // // "code": code,
        // // "product_category_id": productCategoryId,
        // // "product_subcategory_id": productSubcategoryId,
        // // "brand_id": brandId,
        // // "product_cost": productCost,
        // // "product_price": productPrice,
        // // "product_unit": productUnit,
        // // "sale_unit": saleUnit,
        // // "purchase_unit": purchaseUnit,
        // // "stock_alert": stockAlert,
        // // "quantity_limit": quantityLimit,
        // // // "making_time": makingTime,
        // // // "order_tax": orderTax,
        // // // "tax_type": taxType,
        // // "notes": notes,
        // // "description": description,
        "images": List<dynamic>.from(images.map((x) => x)),
        // // // "product_category_name": productCategoryName,
        // // // "product_subcategory_name": productSubcategoryName,
        // // // "brand_name": brandName,
        // // // "barcode_image_url": barcodeImageUrl,
        // // // "barcode_symbol": barcodeSymbol,
        // // // "created_at": createdAt.toIso8601String(),
        // // // "order_create_by": orderCreateBy,
        // // // "product_unit_name": productUnitName.toJson(),
        // // "purchase_unit_name": purchaseUnitName.toJson(),
        // // "sale_unit_name": saleUnitName.toJson(),
        // // "stock": stock.toJson(),
        "product_addons": productAddons.isNotEmpty
            ? List<dynamic>.from(productAddons.map((x) => x.toJson()))
            : null,
        // // "warehouse": List<dynamic>.from(warehouse.map((x) => x.toJson())),
        // // "barcode_url": barcodeUrl,
        // // "in_stock": inStock,
        // // "review": review,
        // "is_favourite": isFavourite,
        // // "favourite_count": favouriteCount,
        // // "profit_margin": profitMargin,
        // // "product_investers": productInvesters,
        // // "product_jtcToken": productJtcToken,
        // "id": id,
        // "name": name,
        // "code": code,
        // "barcode_symbol": barcodeSymbol,
        // "product_category_id": productCategoryId,
        // "product_subcategory_id": productSubcategoryId,
        // "brand_id": brandId,
        // "product_cost": productCost,
        // "making_time": makingTime,
        // "product_price": productPrice,
        // "product_unit": productUnit,
        // "sale_unit": saleUnit,
        // "purchase_unit": purchaseUnit,
        // "stock_alert": stockAlert,
        // "quantity_limit": quantityLimit,
        // "order_tax": orderTax,
        // "tax_type": taxType,
        // "notes": notes,
        // "created_at": createdAt.toIso8601String(),
        // "updated_at": updatedAt.toIso8601String(),
        // "order_create_by": orderCreateBy,
        // "description": description,
        // "product_investers": productInvesters,
        // "product_jtcToken": productJtcToken,
        // "total_price": totalPrice,
        // "total_jtcToken": totalJtcToken,
        // "profit_margin": profitMargin,
        // "withoutTax_token": withoutTaxToken,
        // "image_url": List<dynamic>.from(imageUrl.map((x) => x)),
        // "barcode_image_url": barcodeImageUrl,
        // // "media": List<dynamic>.from(media.map((x) => x.toJson())),
        "id": id,
        "name": name,
        "code": code,
        "barcode_symbol": barcodeSymbol,
        "product_category_id": productCategoryId,
        "product_subcategory_id": productSubcategoryId,
        "brand_id": brandId,
        "product_cost": productCost,
        "making_time": makingTime,
        "product_price": productPrice,
        "product_unit": productUnit,
        "sale_unit": saleUnit,
        "purchase_unit": purchaseUnit,
        "stock_alert": stockAlert,
        "quantity_limit": quantityLimit,
        "order_tax": orderTax,
        "tax_type": taxType,
        "notes": notes,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "order_create_by": orderCreateBy,
        "description": description,
        "product_investers": productInvesters,
        "product_jtcToken": productJtcToken,
        "total_price": totalPrice,
        "total_jtcToken": totalJtcToken,
        "profit_margin": profitMargin,
        "withoutTax_token": withoutTaxToken,
        // "addons": List<dynamic>.from(addons.map((x) => x.toJson())),
        "is_favorite": isFavorite,
        "image_url": List<dynamic>.from(imageUrl.map((x) => x)),
        "barcode_image_url": barcodeImageUrl,
        // "media": List<dynamic>.from(media.map((x) => x.toJson())),
        "is_variant_check": isVariantCheck,
        "small_price": smallPrice,
        "medium_price": mediumPrice,
        "large_price": largePrice,
        "small_token": smallToken,
        "medium_token": mediumToken,
        "large_token": largeToken,
        "small": small,
        "medium": medium,
        "large": large,
        "small_token_price": smallTokenPrice,
        "medium_token_price": mediumTokenPrice,
        "large_token_price": largeTokenPrice,
        "is_deleted": isDeleted,
      };
}

class ProductAddons {
  dynamic? addonName;
  dynamic? addonId;
  List<AddonItems>? addonItems;

  ProductAddons({this.addonName, this.addonId, this.addonItems});

  ProductAddons.fromJson(Map<String, dynamic> json) {
    addonName = json['addon_name'];
    addonId = json['addon_id'];
    if (json['addon_items'] != null) {
      addonItems = <AddonItems>[];
      json['addon_items'].forEach((v) {
        addonItems!.add(new AddonItems.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['addon_name'] = this.addonName;
    data['addon_id'] = this.addonId;
    if (this.addonItems != null) {
      data['addon_items'] = this.addonItems!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class AddonItems {
  dynamic itemId;
  dynamic itemName;
  double itemPrice = 0.0;
  dynamic itemToken;

  String? parentId;

  AddonItems({this.itemId, this.itemName, this.itemPrice = 0.0, this.itemToken, this.parentId});

  AddonItems.fromJson(Map<String, dynamic> json) {
    itemId = json['item_id'];
    itemName = json['item_name'];
    itemPrice = json['item_price'] != null ? double.parse(json['item_price'].toString()): 0.0; 
    itemToken = json['item_token'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['item_id'] = this.itemId;
    data['item_name'] = this.itemName;
    data['item_price'] = this.itemPrice;
    data['item_token'] = this.itemToken;
    data['parent_id']= this.parentId;
    return data;
  }
}

// class Media {
//   dynamic id;
//   dynamic modelType;
//   dynamic modelId;
//   dynamic uuid;
//   dynamic collectionName;
//   dynamic name;
//   dynamic fileName;
//   dynamic mimeType;
//   dynamic disk;
//   dynamic conversionsDisk;
//   dynamic size;
//   List<dynamic> manipulations;
//   List<dynamic> customProperties;
//   List<dynamic> generatedConversions;
//   List<dynamic> responsiveImages;
//   dynamic orderColumn;
//   dynamic createdAt;
//   dynamic updatedAt;
//   dynamic originalUrl;
//   dynamic previewUrl;

//   Media({
//     required this.id,
//     required this.modelType,
//     required this.modelId,
//     required this.uuid,
//     required this.collectionName,
//     required this.name,
//     required this.fileName,
//     required this.mimeType,
//     required this.disk,
//     required this.conversionsDisk,
//     required this.size,
//     required this.manipulations,
//     required this.customProperties,
//     required this.generatedConversions,
//     required this.responsiveImages,
//     required this.orderColumn,
//     required this.createdAt,
//     required this.updatedAt,
//     required this.originalUrl,
//     required this.previewUrl,
//   });

//   factory Media.fromJson(Map<String, dynamic> json) => Media(
//         id: json["id"],
//         modelType: json["model_type"],
//         modelId: json["model_id"],
//         uuid: json["uuid"],
//         collectionName: json["collection_name"],
//         name: json["name"],
//         fileName: json["file_name"],
//         mimeType: json["mime_type"],
//         disk: json["disk"],
//         conversionsDisk: json["conversions_disk"],
//         size: json["size"],
//         manipulations: List<dynamic>.from(json["manipulations"].map((x) => x)),
//         customProperties:
//             List<dynamic>.from(json["custom_properties"].map((x) => x)),
//         generatedConversions:
//             List<dynamic>.from(json["generated_conversions"].map((x) => x)),
//         responsiveImages:
//             List<dynamic>.from(json["responsive_images"].map((x) => x)),
//         orderColumn: json["order_column"],
//         createdAt: DateTime.parse(json["created_at"]),
//         updatedAt: DateTime.parse(json["updated_at"]),
//         originalUrl: json["original_url"],
//         previewUrl: json["preview_url"],
//       );

//   Map<String, dynamic> toJson() => {
//         "id": id,
//         "model_type": modelType,
//         "model_id": modelId,
//         "uuid": uuid,
//         "collection_name": collectionName,
//         "name": name,
//         "file_name": fileName,
//         "mime_type": mimeType,
//         "disk": disk,
//         "conversions_disk": conversionsDisk,
//         "size": size,
//         "manipulations": List<dynamic>.from(manipulations.map((x) => x)),
//         "custom_properties": List<dynamic>.from(customProperties.map((x) => x)),
//         "generated_conversions":
//             List<dynamic>.from(generatedConversions.map((x) => x)),
//         "responsive_images": List<dynamic>.from(responsiveImages.map((x) => x)),
//         "order_column": orderColumn,
//         "created_at": createdAt.toIso8601String(),
//         "updated_at": updatedAt.toIso8601String(),
//         "original_url": originalUrl,
//         "preview_url": previewUrl,
//       };
// }



// class AddonItem {
//   int itemId;
//   String itemName;
//   int itemPrice;
//   int itemToken;
//   bool isSelected;

//   AddonItem({
//     required this.itemId,
//     required this.itemName,
//     required this.itemPrice,
//     required this.itemToken,
//     required this.isSelected,
//   });

//   factory AddonItem.fromJson(Map<String, dynamic> json) => AddonItem(
//         itemId: json["item_id"],
//         itemName: json["item_name"],
//         itemPrice: json["item_price"],
//         itemToken: json["item_token"],
//         isSelected: json["isSelected"] != null ? json["isSelected"] : false,
//       );

//   Map<String, dynamic> toJson() => {
//         "item_id": itemId,
//         "item_name": itemName,
//         "item_price": itemPrice,
//         "item_token": itemToken,
//       };
// }

// class ProductUnitName {
//   int id;
//   String name;
//   int isDefault;
//   DateTime createdAt;
//   DateTime updatedAt;

//   ProductUnitName({
//     required this.id,
//     required this.name,
//     required this.isDefault,
//     required this.createdAt,
//     required this.updatedAt,
//   });

//   factory ProductUnitName.fromJson(Map<String, dynamic> json) =>
//       ProductUnitName(
//         id: json["id"],
//         name: json["name"],
//         isDefault: json["is_default"],
//         createdAt: DateTime.parse(json["created_at"]),
//         updatedAt: DateTime.parse(json["updated_at"]),
//       );

//   Map<String, dynamic> toJson() => {
//         "id": id,
//         "name": name,
//         "is_default": isDefault,
//         "created_at": createdAt.toIso8601String(),
//         "updated_at": updatedAt.toIso8601String(),
//       };
// }

// class EUnitName {
//   int id;
//   String name;
//   String shortName;
//   int baseUnit;
//   DateTime createdAt;
//   DateTime updatedAt;

//   EUnitName({
//     required this.id,
//     required this.name,
//     required this.shortName,
//     required this.baseUnit,
//     required this.createdAt,
//     required this.updatedAt,
//   });

//   factory EUnitName.fromJson(Map<String, dynamic> json) => EUnitName(
//         id: json["id"],
//         name: json["name"],
//         shortName: json["short_name"],
//         baseUnit: json["base_unit"],
//         createdAt: DateTime.parse(json["created_at"]),
//         updatedAt: DateTime.parse(json["updated_at"]),
//       );

//   Map<String, dynamic> toJson() => {
//         "id": id,
//         "name": name,
//         "short_name": shortName,
//         "base_unit": baseUnit,
//         "created_at": createdAt.toIso8601String(),
//         "updated_at": updatedAt.toIso8601String(),
//       };
// }

// class Stock {
//   int id;
//   int warehouseId;
//   int productId;
//   int quantity;
//   DateTime createdAt;
//   DateTime updatedAt;
//   int alert;

//   Stock({
//     required this.id,
//     required this.warehouseId,
//     required this.productId,
//     required this.quantity,
//     required this.createdAt,
//     required this.updatedAt,
//     required this.alert,
//   });

//   factory Stock.fromJson(Map<String, dynamic> json) => Stock(
//         id: json["id"],
//         warehouseId: json["warehouse_id"],
//         productId: json["product_id"],
//         quantity: json["quantity"],
//         createdAt: DateTime.parse(json["created_at"]),
//         updatedAt: DateTime.parse(json["updated_at"]),
//         alert: json["alert"],
//       );

//   Map<String, dynamic> toJson() => {
//         "id": id,
//         "warehouse_id": warehouseId,
//         "product_id": productId,
//         "quantity": quantity,
//         "created_at": createdAt.toIso8601String(),
//         "updated_at": updatedAt.toIso8601String(),
//         "alert": alert,
//       };
// }

// class Warehouse {
//   int totalQuantity;
//   String name;

//   Warehouse({
//     required this.totalQuantity,
//     required this.name,
//   });

//   factory Warehouse.fromJson(Map<String, dynamic> json) => Warehouse(
//         totalQuantity: json["total_quantity"],
//         name: json["name"],
//       );

//   Map<String, dynamic> toJson() => {
//         "total_quantity": totalQuantity,
//         "name": name,
//       };
// }



// // import 'dart:convert';

// // SingleProductModel singleProductModelFromJson(String str) =>
// //     SingleProductModel.fromJson(json.decode(str));

// // String singleProductModelToJson(SingleProductModel data) =>
// //     json.encode(data.toJson());

// // class SingleProductModel {
// //   int id;
// //   String name;
// //   String code;
// //   int barcodeSymbol;
// //   int productCategoryId;
// //   int productSubcategoryId;
// //   int brandId;
// //   // int productCost;
// //   // String makingTime;
// //   String productCost;
// //   String productPrice;
// //   // int productPrice;
// //   String productUnit;
// //   String saleUnit;
// //   String purchaseUnit;
// //   // String stockAlert;
// //   String quantityLimit;
// //   dynamic orderTax;
// //   String taxType;
// //   String notes;
// //   // DateTime createdAt;
// //   // DateTime updatedAt;
// //   // dynamic orderCreateBy;
// //   String description;
// //   String productInvesters;
// //   int productJtcToken;
// //   String totalPrice;
// //   int totalJtcToken;
// //   String profitMargin;
// //   int withoutTaxToken;
// //   List<String> imageUrl;
// //   String barcodeImageUrl;
// //   // List<SingleProductMediaMedia> media;

// //   SingleProductModel({
// //     required this.id,
// //     required this.name,
// //     required this.code,
// //     required this.barcodeSymbol,
// //     required this.productCategoryId,
// //     required this.productSubcategoryId,
// //     required this.brandId,
// //     // required this.productCost,
// //     // required this.makingTime,
// //     // required this.productPrice,
// //     required this.productCost,
// //     required this.productPrice,
// //     required this.productUnit,
// //     required this.saleUnit,
// //     required this.purchaseUnit,
// //     // required this.stockAlert,
// //     required this.quantityLimit,
// //     required this.orderTax,
// //     required this.taxType,
// //     required this.notes,
// //     // required this.createdAt,
// //     // required this.updatedAt,
// //     // required this.orderCreateBy,
// //     required this.description,
// //     required this.productInvesters,
// //     required this.productJtcToken,
// //     required this.totalPrice,
// //     required this.totalJtcToken,
// //     required this.profitMargin,
// //     required this.withoutTaxToken,
// //     required this.imageUrl,
// //     required this.barcodeImageUrl,
// //     // required this.media,
// //   });

// //   factory SingleProductModel.fromJson(Map<String, dynamic> json) =>
// //       SingleProductModel(
// //         id: json["id"] != null ? json["id"] : "",
// //         name: json["name"],
// //         code: json["code"],
// //         barcodeSymbol: json["barcode_symbol"],
// //         productCategoryId: json["product_category_id"],
// //         productSubcategoryId: json["product_subcategory_id"],
// //         brandId: json["brand_id"],
// //         // productCost: json["product_cost"],
// //         productCost: json["product_cost"],
// //         productPrice: json["product_price"],
// //         // makingTime: json["making_time"] != null ? json["making_time"] : "",
// //         // productPrice: json["product_price"],
// //         productUnit: json["product_unit"],
// //         saleUnit: json["sale_unit"],
// //         purchaseUnit: json["purchase_unit"],
// //         // stockAlert: json["stock_alert"],
// //         quantityLimit:
// //             json["quantity_limit"] != null ? json["quantity_limit"] : "",
// //         orderTax: json["order_tax"],
// //         taxType: json["tax_type"],
// //         notes: json["notes"] != null ? json["notes"] : "",
// //         // createdAt: DateTime.parse(json["created_at"]),
// //         // updatedAt: DateTime.parse(json["updated_at"]),
// //         // orderCreateBy: json["order_create_by"],
// //         description: json["description"] != null ? json["description"] : "",
// //         productInvesters: json["product_investers"],
// //         productJtcToken: json["product_jtcToken"],
// //         totalPrice: json["total_price"] != null ? json["total_price"] : "",
// //         totalJtcToken:
// //             json["total_jtcToken"] != null ? json["total_jtcToken"] : 0,
// //         profitMargin: json["profit_margin"],
// //         withoutTaxToken:
// //             json["withoutTax_token"] != null ? json["withoutTax_token"] : 0,
// //         imageUrl: List<String>.from(json["image_url"].map((x) => x)),
// //         barcodeImageUrl: json["barcode_image_url"],
// //         // media: List<SingleProductMediaMedia>.from(
// //         //     json["media"].map((x) => SingleProductMediaMedia.fromJson(x))),
// //       );

// //   Map<String, dynamic> toJson() => {
// //         "id": id,
// //         "name": name,
// //         "code": code,
// //         "barcode_symbol": barcodeSymbol,
// //         "product_category_id": productCategoryId,
// //         "product_subcategory_id": productSubcategoryId,
// //         "brand_id": brandId,
// //         // "product_cost": productCost,
// //         // "making_time": makingTime,
// //         // "product_price": productPrice,
// //         "product_unit": productUnit,
// //         "sale_unit": saleUnit,
// //         "purchase_unit": purchaseUnit,
// //         // "stock_alert": stockAlert,
// //         "quantity_limit": quantityLimit,
// //         "order_tax": orderTax,
// //         "tax_type": taxType,
// //         "notes": notes,
// //         // "created_at": createdAt.toIso8601String(),
// //         // "updated_at": updatedAt.toIso8601String(),
// //         // "order_create_by": orderCreateBy,
// //         "description": description,
// //         "product_investers": productInvesters,
// //         "product_jtcToken": productJtcToken,
// //         "total_price": totalPrice,
// //         "total_jtcToken": totalJtcToken,
// //         "profit_margin": profitMargin,
// //         "withoutTax_token": withoutTaxToken,
// //         "image_url": List<dynamic>.from(imageUrl.map((x) => x)),
// //         "barcode_image_url": barcodeImageUrl,
// //         // "media": List<dynamic>.from(media.map((x) => x.toJson())),
// //       };
// // }

// // class SingleProductMediaMedia {
// //   int id;
// //   String modelType;
// //   int modelId;
// //   String uuid;
// //   String collectionName;
// //   String name;
// //   String fileName;
// //   String mimeType;
// //   String disk;
// //   String conversionsDisk;
// //   int size;
// //   List<dynamic> manipulations;
// //   List<dynamic> customProperties;
// //   List<dynamic> generatedConversions;
// //   List<dynamic> responsiveImages;
// //   int orderColumn;
// //   DateTime createdAt;
// //   DateTime updatedAt;
// //   String originalUrl;
// //   String previewUrl;

// //   SingleProductMediaMedia({
// //     required this.id,
// //     required this.modelType,
// //     required this.modelId,
// //     required this.uuid,
// //     required this.collectionName,
// //     required this.name,
// //     required this.fileName,
// //     required this.mimeType,
// //     required this.disk,
// //     required this.conversionsDisk,
// //     required this.size,
// //     required this.manipulations,
// //     required this.customProperties,
// //     required this.generatedConversions,
// //     required this.responsiveImages,
// //     required this.orderColumn,
// //     required this.createdAt,
// //     required this.updatedAt,
// //     required this.originalUrl,
// //     required this.previewUrl,
// //   });

// //   factory SingleProductMediaMedia.fromJson(Map<String, dynamic> json) =>
// //       SingleProductMediaMedia(
// //         id: json["id"],
// //         modelType: json["model_type"],
// //         modelId: json["model_id"],
// //         uuid: json["uuid"],
// //         collectionName: json["collection_name"],
// //         name: json["name"],
// //         fileName: json["file_name"],
// //         mimeType: json["mime_type"],
// //         disk: json["disk"],
// //         conversionsDisk: json["conversions_disk"],
// //         size: json["size"],
// //         manipulations: List<dynamic>.from(json["manipulations"].map((x) => x)),
// //         customProperties:
// //             List<dynamic>.from(json["custom_properties"].map((x) => x)),
// //         generatedConversions:
// //             List<dynamic>.from(json["generated_conversions"].map((x) => x)),
// //         responsiveImages:
// //             List<dynamic>.from(json["responsive_images"].map((x) => x)),
// //         orderColumn: json["order_column"],
// //         createdAt: DateTime.parse(json["created_at"]),
// //         updatedAt: DateTime.parse(json["updated_at"]),
// //         originalUrl: json["original_url"],
// //         previewUrl: json["preview_url"],
// //       );

// //   Map<String, dynamic> toJson() => {
// //         "id": id,
// //         "model_type": modelType,
// //         "model_id": modelId,
// //         "uuid": uuid,
// //         "collection_name": collectionName,
// //         "name": name,
// //         "file_name": fileName,
// //         "mime_type": mimeType,
// //         "disk": disk,
// //         "conversions_disk": conversionsDisk,
// //         "size": size,
// //         "manipulations": List<dynamic>.from(manipulations.map((x) => x)),
// //         "custom_properties": List<dynamic>.from(customProperties.map((x) => x)),
// //         "generated_conversions":
// //             List<dynamic>.from(generatedConversions.map((x) => x)),
// //         "responsive_images": List<dynamic>.from(responsiveImages.map((x) => x)),
// //         "order_column": orderColumn,
// //         "created_at": createdAt.toIso8601String(),
// //         "updated_at": updatedAt.toIso8601String(),
// //         "original_url": originalUrl,
// //         "preview_url": previewUrl,
// //       };
// // }
