// To parse this JSON data, do
//
//     final singleProductDetailModel = singleProductDetailModelFromJson(jsonString);

import 'dart:convert';

import 'package:jtc_ecommerce/home/models/single_product_model.dart';

SingleProductDetailModel singleProductDetailModelFromJson(String str) =>
    SingleProductDetailModel.fromJson(json.decode(str));

String singleProductDetailModelToJson(SingleProductDetailModel data) =>
    json.encode(data.toJson());

class SingleProductDetailModel {
  bool status;
  String message;
  Data data;

  SingleProductDetailModel({
    required this.status,
    required this.message,
    required this.data,
  });

  factory SingleProductDetailModel.fromJson(Map<String, dynamic> json) =>
      SingleProductDetailModel(
        status: json["status"],
        message: json["message"],
        data: Data.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "status": status,
        "message": message,
        "data": data.toJson(),
      };
}

class Data {
  SingleProductModel product;

  Data({
    required this.product,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        product: SingleProductModel.fromJson(json["product"]),
      );

  Map<String, dynamic> toJson() => {
        "product": product.toJson(),
      };
}
