// To parse this JSON data, do
//
//     final bannerModel = bannerModelFromJson(jsonString);

import 'dart:convert';

BannerModel bannerModelFromJson(String str) => BannerModel.fromJson(json.decode(str));

String bannerModelToJson(BannerModel data) => json.encode(data.toJson());

class BannerModel {
    List<Result> results;

    BannerModel({
        required this.results,
    });

    factory BannerModel.fromJson(Map<String, dynamic> json) => BannerModel(
        results: List<Result>.from(json["results"].map((x) => Result.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "results": List<dynamic>.from(results.map((x) => x.toJson())),
    };
}

class Result {
    dynamic storeName;
    dynamic address;
    dynamic openingTime;
    dynamic closingTime;
    dynamic discount;

    Result({
        required this.storeName,
        required this.address,
        required this.openingTime,
        required this.closingTime,
        required this.discount,
    });

    factory Result.fromJson(Map<String, dynamic> json) => Result(
        storeName: json["StoreName"],
        address: json["Address"],
        openingTime: json["OpeningTime"],
        closingTime: json["ClosingTime"],
        discount: json["Discount"],
    );

    Map<String, dynamic> toJson() => {
        "StoreName": storeName,
        "Address": address,
        "OpeningTime": openingTime,
        "ClosingTime": closingTime,
        "Discount": discount,
    };
}
