// To parse this JSON data, do
//
//     final getFoodCategoriesModelProduct = getFoodCategoriesModelProductFromJson(jsonString);

import 'dart:convert';

GetFoodCategoriesModelProduct getFoodCategoriesModelProductFromJson(
        String str) =>
    GetFoodCategoriesModelProduct.fromJson(json.decode(str));

String getFoodCategoriesModelProductToJson(
        GetFoodCategoriesModelProduct data) =>
    json.encode(data.toJson());

class GetFoodCategoriesModelProduct {
  bool status;
  List<FoodCategoriesModelDataProductList> data;
  String message;

  GetFoodCategoriesModelProduct({
    required this.status,
    required this.data,
    required this.message,
  });

  factory GetFoodCategoriesModelProduct.fromJson(Map<String, dynamic> json) =>
      GetFoodCategoriesModelProduct(
        status: json["status"],
        data: List<FoodCategoriesModelDataProductList>.from(json["data"]
            .map((x) => FoodCategoriesModelDataProductList.fromJson(x))),
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "status": status,
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
        "message": message,
      };
}

class FoodCategoriesModelDataProductList {
  dynamic id;
  dynamic name;
  dynamic nameEn;
  dynamic nameSp;
  DateTime createdAt;
  DateTime updatedAt;
  List<Product> products;
  dynamic image;
  dynamic imageUrl;
  List<Media> media;

  FoodCategoriesModelDataProductList({
    required this.id,
    required this.name,
    required this.nameEn,
    required this.nameSp,
    required this.createdAt,
    required this.updatedAt,
    required this.products,
    required this.image,
    required this.imageUrl,
    required this.media,
  });

  factory FoodCategoriesModelDataProductList.fromJson(
          Map<String, dynamic> json) =>
      FoodCategoriesModelDataProductList(
        id: json["id"],
        name: json["name"],
        nameEn: json["name_en"],
        nameSp: json["name_sp"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        products: List<Product>.from(
            json["products"].map((x) => Product.fromJson(x))),
        image: json["image"],
        imageUrl: json["image_url"],
        media: List<Media>.from(json["media"].map((x) => Media.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "nameEn": nameEn,
        "nameSp": nameSp,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "products": List<dynamic>.from(products.map((x) => x.toJson())),
        "image": image,
        "image_url": imageUrl,
        "media": List<dynamic>.from(media.map((x) => x.toJson())),
      };
}

class Media {
  dynamic id;
  ModelType modelType;
  dynamic modelId;
  dynamic uuid;
  CollectionName collectionName;
  dynamic name;
  dynamic fileName;
  MimeType mimeType;
  Disk disk;
  Disk conversionsDisk;
  dynamic size;
  List<dynamic> manipulations;
  List<dynamic> customProperties;
  List<dynamic> generatedConversions;
  List<dynamic> responsiveImages;
  dynamic orderColumn;
  DateTime createdAt;
  DateTime updatedAt;
  dynamic originalUrl;
  dynamic previewUrl;

  Media({
    required this.id,
    required this.modelType,
    required this.modelId,
    required this.uuid,
    required this.collectionName,
    required this.name,
    required this.fileName,
    required this.mimeType,
    required this.disk,
    required this.conversionsDisk,
    required this.size,
    required this.manipulations,
    required this.customProperties,
    required this.generatedConversions,
    required this.responsiveImages,
    required this.orderColumn,
    required this.createdAt,
    required this.updatedAt,
    required this.originalUrl,
    required this.previewUrl,
  });

  factory Media.fromJson(Map<String, dynamic> json) => Media(
        id: json["id"],
        modelType: modelTypeValues.map[json["model_type"]]!,
        modelId: json["model_id"],
        uuid: json["uuid"],
        collectionName: collectionNameValues.map[json["collection_name"]]!,
        name: json["name"],
        fileName: json["file_name"],
        mimeType: mimeTypeValues.map[json["mime_type"]]!,
        disk: diskValues.map[json["disk"]]!,
        conversionsDisk: diskValues.map[json["conversions_disk"]]!,
        size: json["size"],
        manipulations: List<dynamic>.from(json["manipulations"].map((x) => x)),
        customProperties:
            List<dynamic>.from(json["custom_properties"].map((x) => x)),
        generatedConversions:
            List<dynamic>.from(json["generated_conversions"].map((x) => x)),
        responsiveImages:
            List<dynamic>.from(json["responsive_images"].map((x) => x)),
        orderColumn: json["order_column"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        originalUrl: json["original_url"],
        previewUrl: json["preview_url"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "model_type": modelTypeValues.reverse[modelType],
        "model_id": modelId,
        "uuid": uuid,
        "collection_name": collectionNameValues.reverse[collectionName],
        "name": name,
        "file_name": fileName,
        "mime_type": mimeTypeValues.reverse[mimeType],
        "disk": diskValues.reverse[disk],
        "conversions_disk": diskValues.reverse[conversionsDisk],
        "size": size,
        "manipulations": List<dynamic>.from(manipulations.map((x) => x)),
        "custom_properties": List<dynamic>.from(customProperties.map((x) => x)),
        "generated_conversions":
            List<dynamic>.from(generatedConversions.map((x) => x)),
        "responsive_images": List<dynamic>.from(responsiveImages.map((x) => x)),
        "order_column": orderColumn,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "original_url": originalUrl,
        "preview_url": previewUrl,
      };
}

enum CollectionName { PRODUCT, PRODUCT_CATEGORY }

final collectionNameValues = EnumValues({
  "product": CollectionName.PRODUCT,
  "product_category": CollectionName.PRODUCT_CATEGORY
});

enum Disk { PUBLIC }

final diskValues = EnumValues({"public": Disk.PUBLIC});

enum MimeType { IMAGE_JPEG, IMAGE_PNG }

final mimeTypeValues = EnumValues(
    {"image/jpeg": MimeType.IMAGE_JPEG, "image/png": MimeType.IMAGE_PNG});

enum ModelType { APP_MODELS_PRODUCT, APP_MODELS_PRODUCT_CATEGORY }

final modelTypeValues = EnumValues({
  "App\\Models\\Product": ModelType.APP_MODELS_PRODUCT,
  "App\\Models\\ProductCategory": ModelType.APP_MODELS_PRODUCT_CATEGORY
});

class Product {
  dynamic id;
  dynamic name;
  dynamic code;
  dynamic barcodeSymbol;
  dynamic productCategoryId;
  dynamic productSubcategoryId;
  dynamic brandId;
  dynamic productCost;
  dynamic makingTime;
  dynamic productPrice;
  dynamic productUnit;
  dynamic? saleUnit;
  dynamic purchaseUnit;
  dynamic? stockAlert;
  dynamic? quantityLimit;
  dynamic orderTax;
  dynamic taxType;
  dynamic? notes;
  DateTime createdAt;
  DateTime updatedAt;
  dynamic orderCreateBy;
  dynamic description;
  dynamic productInvesters;
  dynamic productJtcToken;
  dynamic totalPrice;
  dynamic totalJtcToken;
  dynamic profitMargin;
  dynamic withoutTaxToken;
  dynamic productJtcTokenMargin;
  dynamic productJtcTokenInvestors;
  double smallPrice = 0.0;
  double mediumPrice = 0.0;
  double largePrice = 0.0;
  dynamic smallToken = 0.0;
  dynamic mediumToken;
  dynamic largeToken;
  dynamic isVariantCheck;
  List<Addon>? addons;
  bool isFavourite;
  List<String>? images;
  List<String> imageUrl;
  dynamic barcodeImageUrl;
  List<Media> media;
  double smallTokenPrice = 0.0;
  double mediumTokenPrice = 0.0;
  double largeTokenPrice = 0.0;
  int isDeleted;

  dynamic nameEn;
  dynamic nameSp;
  dynamic descriptionEn;
  dynamic descriptionSp;

  Product({
    required this.id,
    required this.name,
    required this.code,
    required this.barcodeSymbol,
    required this.productCategoryId,
    required this.productSubcategoryId,
    required this.brandId,
    required this.productCost,
    required this.makingTime,
    required this.productPrice,
    required this.productUnit,
    required this.saleUnit,
    required this.purchaseUnit,
    required this.stockAlert,
    required this.quantityLimit,
    required this.orderTax,
    required this.taxType,
    required this.notes,
    required this.createdAt,
    required this.updatedAt,
    required this.orderCreateBy,
    required this.description,
    required this.productInvesters,
    required this.productJtcToken,
    required this.totalPrice,
    required this.totalJtcToken,
    required this.profitMargin,
    required this.withoutTaxToken,
    required this.productJtcTokenMargin,
    required this.productJtcTokenInvestors,
    required this.smallPrice,
    required this.mediumPrice,
    required this.largePrice,
    required this.smallToken,
    required this.mediumToken,
    required this.largeToken,
    required this.isVariantCheck,
    this.addons,
    required this.isFavourite,
    this.images,
    required this.imageUrl,
    required this.barcodeImageUrl,
    required this.media,
    required this.smallTokenPrice,
    required this.mediumTokenPrice,
    required this.largeTokenPrice,
    required this.isDeleted,
    required this.nameEn,
    required this.nameSp,
    required this.descriptionEn,
    required this.descriptionSp,
  });

  factory Product.fromJson(Map<String, dynamic> json) => Product(
        id: json["id"],
        name: json["name"],
        nameEn: json["name_en"],
        nameSp: json["name_sp"],
        descriptionEn: json["description_en"],
        descriptionSp: json["description_sp"],
        code: json["code"],
        barcodeSymbol: json["barcode_symbol"],
        productCategoryId: json["product_category_id"],
        productSubcategoryId: json["product_subcategory_id"],
        brandId: json["brand_id"],
        productCost: json["product_cost"],
        makingTime: json["making_time"],
        productPrice: json["product_price"],
        productUnit: json["product_unit"],
        saleUnit: json["sale_unit"],
        purchaseUnit: json["purchase_unit"],
        stockAlert: json["stock_alert"],
        quantityLimit: json["quantity_limit"],
        orderTax: json["order_tax"],
        taxType: json["tax_type"],
        notes: json["notes"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        orderCreateBy: json["order_create_by"],
        description: json["description"],
        productInvesters: json["product_investers"],
        productJtcToken: json["product_jtcToken"],
        totalPrice: json["total_price"],
        totalJtcToken: json["total_jtcToken"],
        profitMargin: json["profit_margin"],
        withoutTaxToken: json["withoutTax_token"],
        productJtcTokenMargin: json["product_jtcToken_margin"],
        productJtcTokenInvestors: json["product_jtcToken_investors"],
        smallPrice: json["small"] != null
            ? double.parse(json["small"].toString())
            : 0.0,
        mediumPrice: json["medium"] != null
            ? double.parse(json["medium"].toString())
            : 0.0,
        largePrice: json["large"] != null
            ? double.parse(json["large"].toString())
            : 0.0,
        smallToken: json["small_token"],
        mediumToken: json["medium_token"],
        largeToken: json["large_token"],
        isVariantCheck: json["is_variant_check"],
        addons: json["addons"] == null
            ? []
            : List<Addon>.from(json["addons"]!.map((x) => Addon.fromJson(x))),
        isFavourite: json["is_favourite"] ?? false,
        images: json["images"] == null
            ? []
            : List<String>.from(json["images"]!.map((x) => x)),
        imageUrl: List<String>.from(json["image_url"].map((x) => x)),
        barcodeImageUrl: json["barcode_image_url"],
        media: List<Media>.from(json["media"].map((x) => Media.fromJson(x))),
        smallTokenPrice: json["small_token_price"] != null
            ? double.parse(json['small_token_price'].toString())
            : 0.0,
        mediumTokenPrice: json["medium_token_price"] != null
            ? double.parse(json['medium_token_price'].toString())
            : 0.0,
        largeTokenPrice: json["large_token_price"] != null
            ? double.parse(json['large_token_price'].toString())
            : 0.0,
        isDeleted: json["is_deleted"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "code": code,
        "barcode_symbol": barcodeSymbol,
        "product_category_id": productCategoryId,
        "product_subcategory_id": productSubcategoryId,
        "brand_id": brandId,
        "product_cost": productCost,
        "making_time": makingTime,
        "product_price": productPrice,
        "product_unit": productUnit,
        "sale_unit": saleUnit,
        "purchase_unit": purchaseUnit,
        "stock_alert": stockAlert,
        "quantity_limit": quantityLimit,
        "order_tax": orderTax,
        "tax_type": taxType,
        "notes": notes,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "order_create_by": orderCreateBy,
        "description": description,
        "product_investers": productInvesters,
        "product_jtcToken": productJtcToken,
        "total_price": totalPrice,
        "total_jtcToken": totalJtcToken,
        "profit_margin": profitMargin,
        "withoutTax_token": withoutTaxToken,
        "product_jtcToken_margin": productJtcTokenMargin,
        "product_jtcToken_investors": productJtcTokenInvestors,
        "small_price": smallPrice,
        "medium_price": mediumPrice,
        "large_price": largePrice,
        "small_token": smallToken,
        "medium_token": mediumToken,
        "large_token": largeToken,
        "is_variant_check": isVariantCheck,
        "addons": addons == null
            ? []
            : List<dynamic>.from(addons!.map((x) => x.toJson())),
        "is_favourite": isFavourite,
        "images":
            images == null ? [] : List<dynamic>.from(images!.map((x) => x)),
        "image_url": List<dynamic>.from(imageUrl.map((x) => x)),
        "barcode_image_url": barcodeImageUrl,
        "media": List<dynamic>.from(media.map((x) => x.toJson())),
        "small_token_price": smallTokenPrice,
        "medium_token_price": mediumTokenPrice,
        "large_token_price": largeTokenPrice,
        "is_deleted": isDeleted,
      };
}

class Addon {
  dynamic addonName;
  dynamic addonId;
  List<AddonItem> addonItems;

  Addon({
    required this.addonName,
    required this.addonId,
    required this.addonItems,
  });

  factory Addon.fromJson(Map<String, dynamic> json) => Addon(
        addonName: json["addon_name"],
        addonId: json["addon_id"],
        addonItems: List<AddonItem>.from(
            json["addon_items"].map((x) => AddonItem.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "addon_name": addonName,
        "addon_id": addonId,
        "addon_items": List<dynamic>.from(addonItems.map((x) => x.toJson())),
      };
}

class AddonItem {
  dynamic itemId;
  dynamic itemName;
  dynamic itemPrice;
  dynamic itemToken;
  String? parentId;

  AddonItem({
    required this.itemId,
    required this.itemName,
    required this.itemPrice,
    required this.itemToken,
    this.parentId,
  });

  factory AddonItem.fromJson(Map<String, dynamic> json) => AddonItem(
        itemId: json["item_id"],
        itemName: json["item_name"],
        itemPrice: json["item_price"],
        itemToken: json["item_token"],
      );

  Map<String, dynamic> toJson() => {
        "item_id": itemId,
        "item_name": itemName,
        "item_price": itemPrice,
        "item_token": itemToken,
      };
}

class EnumValues<T> {
  Map<String, T> map;
  late Map<T, String> reverseMap;

  EnumValues(this.map);

  Map<T, String> get reverse {
    reverseMap = map.map((k, v) => MapEntry(v, k));
    return reverseMap;
  }
}
