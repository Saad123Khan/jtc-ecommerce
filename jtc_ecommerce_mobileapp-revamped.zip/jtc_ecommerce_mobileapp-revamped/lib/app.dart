import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/auth/controllers/auth_controller.dart';
import 'package:jtc_ecommerce/cart/controllers/cart_controller.dart';
import 'package:jtc_ecommerce/order_summary/controllers/order_summary_controller.dart';
import 'package:jtc_ecommerce/settings/controllers/settings_controller.dart';
import 'package:jtc_ecommerce/splash/controllers/splash_controller.dart';
import 'package:jtc_ecommerce/utils/app_constants.dart';
import 'package:jtc_ecommerce/utils/app_fonts.dart';
import 'package:jtc_ecommerce/utils/app_router.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';
import 'package:jtc_ecommerce/utils/app_strings.dart';
import 'package:jtc_ecommerce/utils/constants.dart';
import 'home/controllers/home_controller.dart';

class JtcEcommerceApp extends StatelessWidget {
  JtcEcommerceApp({super.key});

  final controller = Get.put(HomeController());
  final cartController = Get.put(CartController());
  final authController = Get.put(AuthController());
  final splashController = Get.put(SplashController());
  final settingsContorller = Get.put(SettingsController());
  final orderSummary = Get.put(OrderSummaryController());

  @override
  Widget build(BuildContext mainContext) {
    return ScreenUtilInit(
      designSize: AppConstant.artbaordSize,
      minTextAdapt: true,
      splitScreenMode: true,
      child: GetBuilder<SplashController>(
        init: SplashController(),
        builder: (controller) {
          return GetMaterialApp(
            localizationsDelegates: mainContext.localizationDelegates,
            supportedLocales: mainContext.supportedLocales,
            locale: mainContext.locale,
            title: AppStrings.APP_TITLE_TEXT,
            debugShowCheckedModeBanner: false,
            navigatorKey: Constants.navigatorKey,
            scrollBehavior: CustomScrollBehaviour(),
            theme: ThemeData(
                fontFamily: AppFonts.defaultFont,
                primarySwatch: Constants.PRIMARY_SWATCH_COLOR,
                useMaterial3: false),
            // initialRoute: AppRouteName.LOCATION_SCREEN_ROUTE,
            initialRoute: AppRouteName.SPLASH_SCREEN_ROUTE,
            getPages: AppRouter.routes,
          );
        },
      ),
    );
  }
}

class CustomScrollBehaviour extends ScrollBehavior {
  const CustomScrollBehaviour();
  @override
  ScrollPhysics getScrollPhysics(BuildContext context) {
    switch (getPlatform(context)) {
      case TargetPlatform.iOS:
      case TargetPlatform.macOS:
      case TargetPlatform.android:
        return const BouncingScrollPhysics();
      case TargetPlatform.fuchsia:
      case TargetPlatform.linux:
      case TargetPlatform.windows:
        return const ClampingScrollPhysics();
    }
  }
}
