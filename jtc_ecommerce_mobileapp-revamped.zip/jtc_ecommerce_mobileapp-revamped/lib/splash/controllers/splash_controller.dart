import 'dart:async';
import 'dart:convert';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/auth/models/user_model.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/auth_singleton.dart';
import 'package:jtc_ecommerce/services/firebase_messaging_service.dart';
import 'package:jtc_ecommerce/services/local_storage.dart';
import 'package:jtc_ecommerce/services/notification_navigation.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';
import 'package:jtc_ecommerce/utils/enums.dart';
import 'package:permission_handler/permission_handler.dart';

class SplashController extends GetxController {
  final AuthSingletonUserRole authSingletonUserRole = AuthSingletonUserRole();
  Rxn<UserData> currentUser = Rxn(null);
  late Timer splashTimer;

  @override
  void onInit() async {
    await initShared();
    authSingletonUserRole.switchValue = SwitchValue.email;
    splashTimer = Timer(
      const Duration(seconds: 3),
      () {
        _checkLocationPermission();
        _setNotifications();
      },
    );
    super.onInit();
  }

  @override
  void dispose() {
    splashTimer.cancel();
    super.dispose();
  }

  Future<void> _checkLocationPermission() async {
    if (await Permission.locationWhenInUse.isDenied) {
      await Permission.locationWhenInUse.request();
    }
  }

  Future<void> initShared() async {
    await SharedPreference().sharedPreference;
  }

  Future<void> loadCurrentUserFromSharedPreference(
      {required BuildContext context}) async {
    logData(message: "is user saved in shared preference?");
    final userJson = SharedPreference().getUser();
    final token = SharedPreference().getBearerToken();
    logData(message: "Token: $token");
    logData(message: "Saved User: ${userJson}");
    if (token != null && userJson != null) {
      final jsonResponse = jsonDecode(userJson);
      final UserData? _currentUser = UserData.fromJson(jsonResponse);
      logData(message: "_currentUser: ${_currentUser?.email}");
      if (_currentUser != null) {
        currentUser.value = _currentUser;
        update();
        AppNavigation.navigateToRemovingAll(
          context,
          AppRouteName.BOTTOM_NAVIGATION_SCREEN_ROUTE,
        );
        return;
      }
    }
    // If no token or user data found, navigate to login screen
    AppNavigation.navigateToRemovingAll(
      context,
      AppRouteName.LOGIN_SCREEN_ROUTE,
    );
  }

  NotificationNavigationClass _notificationNavigationClass =
      NotificationNavigationClass();

  // void _validateUser() async {
  //   logData(message: "_validateUser");
  //   try {
  //     await SharedPreference().sharedPreference;
  //     await FirebaseMessagingService().initializeNotificationSettings();
  //     _setNotifications();
  //     print("haha");
  //   } catch (error) {
  //     print("Error: $error");
  //     _notificationNavigationClass.clearAppDataMethod(context: Get.context!);
  //   }
  // }

  void _setNotifications() async {
    print("_setNotifications");
    await FirebaseMessagingService().initializeNotificationSettings();
    FirebaseMessagingService().foregroundNotification();
    FirebaseMessagingService().backgroundTapNotification();
  }
}
