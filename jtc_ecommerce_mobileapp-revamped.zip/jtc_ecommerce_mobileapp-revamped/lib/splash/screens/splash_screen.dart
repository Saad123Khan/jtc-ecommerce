import 'package:entry/entry.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/splash/controllers/splash_controller.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_fonts.dart';

class SplashScreen extends GetView<SplashController> {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(SplashController());
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/revamped/splashLogo.png'),
            fit: BoxFit.fill,
          ),
        ),
        child: Entry.scale(
          // scale: .4,  
          duration: Duration(seconds: 1),
          delay: Duration(milliseconds: 200),        
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                height: 20.h,
              ),
              Image.asset(
                'assets/images/logo.png',
                color: AppColors.WHITE_COLOR,
                fit: BoxFit.contain,
                height: 110.h,
              ),
              50.verticalSpace,
              CustomText(
                text: "coffee_so_good",
                color: AppColors.WHITE_COLOR,
                isLeftAlign: false,
                fontsize: 26.sp,
                // fontFamily: AppFonts.robotoMedium,
              ),
              CustomText(
                text: "your_taste_buds",
                color: AppColors.WHITE_COLOR,
                isLeftAlign: false,
                fontsize: 26.sp,
                // fontFamily: AppFonts.robotoMedium,
              ),
              CustomText(
                text: "will_love_it",
                color: AppColors.WHITE_COLOR,
                isLeftAlign: false,
                fontsize: 26.sp,
                // fontFamily: AppFonts.robotoMedium,
              ),
              10.verticalSpace,
              CustomText(
                text: "best_grain",
                color: AppColors.WHITE_COLOR,
                isLeftAlign: false,
                fontsize: 18.sp,
                fontFamily: AppFonts.defaultFont,
              ),
              CustomText(
                text: "powerful_flavor",
                color: AppColors.WHITE_COLOR,
                isLeftAlign: false,
                fontsize: 18.sp,
                fontFamily: AppFonts.defaultFont,
              ),
            ],
          ),
        ),
      ),
      // Uncomment the following lines if you want to use the Get Started button
      // floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      // floatingActionButton: GestureDetector(
      //   onTap: () {},
      //   child: Container(
      //     width: 180.w,
      //     height: 42,
      //     decoration: BoxDecoration(
      //       color: AppColors.WHITE_COLOR,
      //       borderRadius: BorderRadius.circular(20),
      //     ),
      //     child: CustomText(
      //       text: LocaleKeys.get_started.tr(),
      //       color: AppColors.PRIMARY_COLOR,
      //       isLeftAlign: false,
      //       fontsize: 16.sp,
      //       fontFamily: AppFonts.robotoMedium,
      //     ),
      //   ),
      // ),
    );
  }
}
