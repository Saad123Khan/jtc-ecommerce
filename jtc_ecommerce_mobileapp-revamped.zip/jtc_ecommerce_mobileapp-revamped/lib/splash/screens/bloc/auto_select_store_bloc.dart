import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as GetxController;
import 'package:jtc_ecommerce/home/controllers/home_controller.dart';
import 'package:jtc_ecommerce/services/local_storage.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/splash/screens/model/store_list_model.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';

class NearestStoreAutoSelectBloc {
  Response? _response;
  VoidCallback? _onSuccess, _onFailure;
  dynamic formData;

  Future<void> getNearbyStore(
      {required BuildContext context,
      required VoidCallback setProgressBar,
      required double lat,
      required double lon}) async {
    setProgressBar();
    // final postion = await HomeController.i.getCurrentLocation();
    // if (postion == null) {
    //   debugPrint('Failed to get location');
    //   Navigator.pop(context);
    //   return;
    // }

    formData = {"lat": lat, "long": lon};

    // ! ============> If Api succeeds then start the loader

    // ! ============> If Api fails then stop the loader
    _onFailure = () async {
      Navigator.pop(context);

      if (_response?.data['data'] != null &&
          _response?.data['data'].isNotEmpty) {
        HomeController.i.selectedStore.value =
            StoreData.fromJson(_response?.data['data'].first);

        SharedPreference().setStore(
            token: HomeController.i.selectedStore.value?.id.toString());

        AppNavigation.navigateToRemovingAll(
            context, AppRouteName.BOTTOM_NAVIGATION_SCREEN_ROUTE);
      } else {
        HomeController.i.selectedStore.value = null;
        AppDialogs.showToast(message: tr("store_not_found"));
      }
    };

    //! ============> Call api
    await _postRequest(
      endPoint: NetworkStrings.GET_AUTO_NEAREST_STORE,
      context: GetxController.Get.context!,
    );

    //! ============> Get the login response
    _onSuccess = () {
      // HomeController.i.loadingStores.value = false;
      AppNavigation.navigatorPop(context);
    };

    //! ============> Validate the response
    _validateResponse();
  }

  //! ============> Post Request
  Future<void> _postRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().postRequest(
        endPoint: endPoint,
        context: context,
        customFailure: true,
        formData: formData,
        onFailure: _onFailure,
        isHeaderRequire: true,
        isToast: true,
        isErrorToast: false);
  }

  //! ============> Validate Response
  void _validateResponse() {
    if (_response != null) {
      Network().validateResponse(
        isToast: false,
        response: _response,
        onSuccess: _onSuccess,
        onFailure: _onFailure,
      );
    }
  }
}
