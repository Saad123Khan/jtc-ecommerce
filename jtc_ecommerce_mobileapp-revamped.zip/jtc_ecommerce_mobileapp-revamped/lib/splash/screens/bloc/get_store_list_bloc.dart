import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as GetxController;
import 'package:jtc_ecommerce/home/controllers/home_controller.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/splash/screens/model/store_list_model.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';

class GetStoreListBloc {
  Response? _response;
  VoidCallback? _onSuccess, _onFailure;

  Future<void> getAllStores(
      {required BuildContext context,
      required VoidCallback setProgressBar,
      required double lat,
      required double lng,
      Function()? onSuccess}) async {
    setProgressBar();

    // ! ============> If Api fails then stop the loader
    _onFailure = () async {
      HomeController.i.loadingStores.value = false;

      if (_response?.data['data'] != null) {
        HomeController.i.storeListModel.value =
            StoreListModel.fromJson(_response?.data);

        // if (_response?.data['data'].isNotEmpty) {
        //   final store = StoreData.fromJson(_response?.data['data'].first);
        //   HomeController.i.selectedStore.value = store;
        // }

        onSuccess?.call();
      } else {
        HomeController.i.storeListModel.value = null;
      }
    };

    //! ============> Call api
    await _postRequest(
      endPoint: NetworkStrings.GET_ALL_STORES_LIST + "?lat=$lat&lon=$lng",
      context: GetxController.Get.context!,
    );

    //! ============> Get the login response
    _onSuccess = () {
      HomeController.i.loadingStores.value = false;
    };

    //! ============> Validate the response
    _validateResponse();
  }

  //! ============> Post Request
  Future<void> _postRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().getRequest(
        endPoint: endPoint,
        context: context,
        customFailure: true,
        onFailure: _onFailure,
        isHeaderRequire: true,
        isToast: true,
        isErrorToast: false);
  }

  //! ============> Validate Response
  void _validateResponse() {
    if (_response != null) {
      Network().validateResponse(
        isToast: false,
        response: _response,
        onSuccess: _onSuccess,
        onFailure: _onFailure,
      );
    }
  }
}
