class StoreListModel {
  List<StoreData>? data;
  Pagination? meta;

  StoreListModel({
    this.data,
  });

  StoreListModel.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      data = <StoreData>[];
      json['data'].forEach((v) {
        data!.add(new StoreData.fromJson(v));
      });
    }
    meta = json['meta'] != null ? new Pagination.fromJson(json['meta']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    if (this.meta != null) {
      data['meta'] = this.meta!.toJson();
    }
    return data;
  }
}

class StoreData {
  String? type;
  int? id;
  StoreAttributes? attributes;

  StoreData({
    this.type,
    this.id,
    this.attributes,
  });

  StoreData.fromJson(Map<String, dynamic> json) {
    type = json['type'];
    id = json['id'];
    attributes = json['attributes'] != null
        ? new StoreAttributes.fromJson(json['attributes'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['type'] = this.type;
    data['id'] = this.id;
    if (this.attributes != null) {
      data['attributes'] = this.attributes!.toJson();
    }
    return data;
  }
}

class StoreAttributes {
  int? id;
  String? name;
  String? address;
  String? openTime;
  String? closeTime;
  String? checkTime;
  String? storeImage;
  String? startDate;
  String? image;
  String? endDate;
  String? dailyActiveHours;
  // Null? hourlyTarget;

  StoreAttributes({
    this.id,
    this.name,
    this.address,
    // this.target,
    this.openTime,
    this.closeTime,
    this.checkTime,
    this.storeImage,
    this.startDate,
    this.image,
    this.endDate,
    this.dailyActiveHours,
    // this.hourlyTarget,
  });

  StoreAttributes.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    address = json['address'];
    // target = json['target'];
    openTime = json['openTime'];
    closeTime = json['closeTime'];
    checkTime = json['checkTime'];
    storeImage = json['store_image'];
    startDate = json['startDate'];
    image = json['image'];
    endDate = json['endDate'];
    dailyActiveHours = json['daily_active_hours'];
    // hourlyTarget = json['hourly_target'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['address'] = this.address;
    // data['target'] = this.target;
    data['openTime'] = this.openTime;
    data['closeTime'] = this.closeTime;
    data['checkTime'] = this.checkTime;
    data['store_image'] = this.storeImage;
    data['startDate'] = this.startDate;
    data['image'] = this.image;
    data['endDate'] = this.endDate;
    data['daily_active_hours'] = this.dailyActiveHours;
    // data['hourly_target'] = this.hourlyTarget;
    return data;
  }
}

class Pagination {
  int? currentPage;
  int? from;
  int? lastPage;
  String? path;
  int? perPage;
  int? to;
  int? total;

  Pagination(
      {this.currentPage,
      this.from,
      this.lastPage,
      this.path,
      this.perPage,
      this.to,
      this.total});

  Pagination.fromJson(Map<String, dynamic> json) {
    currentPage = json['current_page'];
    from = json['from'];
    lastPage = json['last_page'];
    path = json['path'];
    perPage = json['per_page'];
    to = json['to'];
    total = json['total'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['current_page'] = this.currentPage;
    data['from'] = this.from;
    data['last_page'] = this.lastPage;
    data['path'] = this.path;
    data['per_page'] = this.perPage;
    data['to'] = this.to;
    data['total'] = this.total;
    return data;
  }
}
