import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/splash/screens/store_list_screen.dart';
import 'package:jtc_ecommerce/widgets/custom_button.dart';
import 'package:jtc_ecommerce/widgets/custom_extended_image.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/widgets/no_data_found.dart';
import 'package:jtc_ecommerce/home/controllers/home_controller.dart';
import 'package:jtc_ecommerce/services/connectivity_manager.dart';
import 'package:jtc_ecommerce/services/local_storage.dart';
import 'package:jtc_ecommerce/splash/screens/bloc/auto_select_store_bloc.dart';
import 'package:jtc_ecommerce/splash/screens/bloc/get_store_list_bloc.dart';
import 'package:jtc_ecommerce/splash/screens/model/store_list_model.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';
import 'package:jtc_ecommerce/utils/app_strings.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';
import 'package:jtc_ecommerce/utils/constants.dart';
import 'package:shimmer/shimmer.dart';

class StoreSetupDialog extends StatefulWidget {
  const StoreSetupDialog({super.key, this.isFromEdit = false});
  final bool isFromEdit;

  @override
  State<StoreSetupDialog> createState() => _StoreSetupDialogState();
}

class _StoreSetupDialogState extends State<StoreSetupDialog> {
  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Stack(
        children: [
          Container(
            padding: EdgeInsets.symmetric(vertical: 20, horizontal: 16),
            decoration: BoxDecoration(
                color: AppColors.WHITE_COLOR,
                borderRadius: BorderRadius.circular(12)),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  height: 50,
                  width: 50,
                  child: Image.asset(
                    AssetPaths.LOGO,
                  ),
                ),
                CustomText(
                  text: 'select_a_store',
                  color: AppColors.BLACK_COLOR,
                  fontWeight: FontWeight.w500,
                ),
                SizedBox(height: 20.h),
                CustomButton(
                    fontSize: 14,
                    withBorderOnly: true,
                    fontWeight: FontWeight.w600,
                    textColor: AppColors.BLACK_COLOR,
                    buttonColor: AppColors.viewCartContainer,
                    onTap: () async {
                      if (await ConnectivityManager().isInternetConnected()) {
                        AppDialogs.progressAlertDialog(context: context);
                        final postion =
                            await HomeController.i.getCurrentLocation();

                        Future.delayed(Duration(milliseconds: 500), () {
                          print(postion?.latitude);
                          print(postion?.longitude);

                          AppNavigation.navigatorPop(context);

                          if (postion != null) {
                            NearestStoreAutoSelectBloc().getNearbyStore(
                                context: Constants.navigatorKey.currentContext!,
                                lat: postion.latitude,
                                lon: postion.longitude,
                                setProgressBar: () {
                                  AppDialogs.progressAlertDialog(
                                      context: context);
                                });
                          } else {
                            AppDialogs.showToast(
                                message: tr("please_enable_location"));
                          }
                        });
                      } else {
                        AppDialogs.showToast(
                            message: tr(NetworkStrings.NO_INTERNET));
                      }
                    },
                    buttonText: tr("select_automatically")),
                SizedBox(height: 20.h),
                CustomButton(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    withBorderOnly: true,
                    textColor: AppColors.BLACK_COLOR,
                    buttonColor: AppColors.viewCartContainer,
                    onTap: () async {
                      AppDialogs.progressAlertDialog(context: context);
                      final postion =
                          await HomeController.i.getCurrentLocation();

                      print(postion?.latitude);
                      print(postion?.longitude);

                      Future.delayed(Duration(milliseconds: 500), () {
                        AppNavigation.navigatorPop(context);

                        if (postion != null) {
                          Get.toNamed(
                            AppRouteName.STORE_SELECTION_SCREEN,
                            arguments: {
                              'lat': postion.latitude,
                              'lon': postion.longitude,
                            },
                          );
                          // AppDialogs.showAppDialog(
                          //     context: context,
                          //     child: StoreSelectionScreen(
                          //       lat: postion.latitude,
                          //       lon: postion.longitude,
                          //     ));
                        } else {
                          AppDialogs.showToast(
                              message: tr("please_enable_location"));
                        }
                      });
                    },
                    buttonText: tr("select_mannually")),
                SizedBox(
                  height: 20,
                )
              ],
            ),
          ),
          // if (widget.isFromEdit)
            Positioned(
                right: 0,
                top: 5,
                child: IconButton(
                    onPressed: () {
                      AppNavigation.navigatorPop(context);
                    },
                    icon: Icon(Icons.close)))
        ],
      ),
    );
  }
}

class StoreCardShimmer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Shimmer.fromColors(
        baseColor: Colors.grey[300]!,
        highlightColor: Colors.grey[100]!,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            color: Colors.white,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Shimmer for Image
              Container(
                height: 90.0,
                decoration: BoxDecoration(
                  color: Colors.grey,
                  borderRadius: BorderRadius.circular(15),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class StoreCard extends StatelessWidget {
  const StoreCard(
      {super.key, required this.storeData, required this.selectedStoreData});
  final StoreData storeData;
  final Rxn<StoreData> selectedStoreData;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        selectedStoreData.value = storeData;
      },
      child: Obx(
        () => AnimatedContainer(
          height: MediaQuery.sizeOf(context).height * 0.1,
          duration: Duration(seconds: 1),
          padding: EdgeInsets.symmetric(vertical: 12, horizontal: 5),
          decoration: BoxDecoration(
              color: selectedStoreData == storeData
                  ? AppColors.PRIMARY_COLOR
                  : Color(0xFFF6F6F6),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color:
                    selectedStoreData == storeData ? Colors.red : Colors.grey,
              )),
          child: Row(
            children: [
              CircleAvatar(
                radius: 30.r,
                backgroundColor: Colors.red,
                child: ColorFiltered(
                  colorFilter: ColorFilter.mode(
                    Colors.white,
                    BlendMode.srcATop,
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Image.asset("assets/revamped/store.png"),
                  ),
                ),
              ),
              10.horizontalSpace,
              Expanded(
                  child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CustomText(
                    text: storeData.attributes?.name,
                    color: selectedStoreData == storeData
                        ? AppColors.WHITE_COLOR
                        : AppColors.BLACK_COLOR,
                    fontWeight: FontWeight.w500,
                    maxLines: 4,
                    fontsize: 14,
                    isLeftAlign: true,
                  ),
                  CustomText(
                    text: storeData.attributes?.address,
                    color: selectedStoreData == storeData
                        ? AppColors.WHITE_COLOR
                        : AppColors.BLACK_COLOR,
                    maxLines: 2,
                    fontsize: 11,
                    isLeftAlign: true,
                  ),
                ],
              )),
              SizedBox(
                width: 10,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
