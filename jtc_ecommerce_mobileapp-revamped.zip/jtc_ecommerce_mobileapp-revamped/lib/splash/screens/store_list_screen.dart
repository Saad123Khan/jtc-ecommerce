import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';
import 'package:jtc_ecommerce/home/controllers/home_controller.dart';
import 'package:jtc_ecommerce/services/local_storage.dart';
import 'package:jtc_ecommerce/splash/screens/bloc/get_store_list_bloc.dart';
import 'package:jtc_ecommerce/splash/screens/components/store_setup_dialog.dart';
import 'package:jtc_ecommerce/splash/screens/model/store_list_model.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';
import 'package:jtc_ecommerce/widgets/custom_button.dart';
import 'package:jtc_ecommerce/widgets/custom_scaffold.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/widgets/no_data_found.dart';

class StoreSelectionScreen extends StatefulWidget {
  const StoreSelectionScreen({super.key, required this.lat, required this.lon});
  final double lat;
  final double lon;

  @override
  State<StoreSelectionScreen> createState() => _StoreSelectionScreenState();
}

class _StoreSelectionScreenState extends State<StoreSelectionScreen> {
  Rxn<StoreData> _selectedStore = Rxn<StoreData>();

  @override
  void initState() {
    GetStoreListBloc().getAllStores(
        context: context,
        lat: widget.lat,
        lng: widget.lon,
        onSuccess: () {
          final selectedStore = SharedPreference().getStore();
          if (selectedStore != null) {
            _selectedStore.value = HomeController.i.storeListModel.value?.data
                ?.where((element) => element.id.toString() == selectedStore)
                .firstOrNull;
          }
        },
        setProgressBar: () {
          HomeController.i.loadingStores.value = true;
        });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      appBarTitle: tr("select_a_store"),
      onTap: () => AppNavigation.navigatorPop(context),
      isAuthScreen: false,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 5, horizontal: 10),
        decoration: BoxDecoration(
            color: AppColors.WHITE_COLOR,
            borderRadius: BorderRadius.circular(12)),
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            _buildList(),
            SizedBox(
              height: 10.h,
            ),
            Obx(
              () => CustomButton(
                  height: 50,
                  buttonColor: _selectedStore.value == null
                      ? AppColors.APP_GREY_COLOR
                      : AppColors.PRIMARY_COLOR,
                  onTap: () async {
                    SharedPreference()
                        .setStore(token: _selectedStore.value!.id.toString());

                    AppNavigation.navigateToRemovingAll(
                        context, AppRouteName.BOTTOM_NAVIGATION_SCREEN_ROUTE);
                    // AppDialogs.progressAlertDialog(context: context);
                    // final postion = await HomeController.i.getCurrentLocation();

                    // print(postion?.latitude);
                    // print(postion?.longitude);

                    // Future.delayed(Duration(seconds: 1), () {
                    //   AppNavigation.navigatorPop(context);
                    // });

                    // if (postion != null) {
                    //   final distance= HomeController().checkDistanceInMeters(postion.latitude, postion.longitude, 50.000000, -85.0000002);

                    //   print(distance);

                    //   //Check distance is in 50KM range
                    //   if (distance < 50000) {

                    //   } else {
                    //     AppDialogs.showToast(
                    //         message: tr("store_not_in_range"));
                    //   }
                    // SharedPreference()
                    //     .setStore(token: _selectedStore.value!.id.toString());

                    // AppNavigation.navigateToRemovingAll(
                    //   //     context, AppRouteName.BOTTOM_NAVIGATION_SCREEN_ROUTE);
                    // } else {
                    //   AppDialogs.showToast(
                    //       message: tr("please_enable_location"));
                    // }
                  },
                  buttonText: "save"),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildList() {
    return Obx(() => HomeController.i.loadingStores.value
        ? Expanded(
            child: ListView.builder(
                itemCount: 10,
                itemBuilder: (context, index) {
                  return StoreCardShimmer();
                }),
          )
        : HomeController.i.storeListModel.value?.data?.isNotEmpty == true
            ? Expanded(
                child: ListView.separated(
                    separatorBuilder: (context, index) => SizedBox(
                          height: 10.h,
                        ),
                    itemCount:
                        HomeController.i.storeListModel.value?.data?.length ??
                            0,
                    itemBuilder: (context, index) {
                      final store =
                          HomeController.i.storeListModel.value?.data?[index];
                      return StoreCard(
                        selectedStoreData: _selectedStore,
                        storeData: store!,
                      );
                    }),
              )
            : Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    NoDataPage(text: tr("data_not_found")),
                    SizedBox(height: 22.h),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 30.w),
                      child: CustomButton(
                        fontSize: 14,
                        height: 50,
                        fontWeight: FontWeight.w600,
                        withBorderOnly: true,
                        textColor: AppColors.BLACK_COLOR,
                        buttonColor: AppColors.viewCartContainer,
                        onTap: () {
                          AppNavigation.navigatorPop(context);
                        },
                        buttonText: tr("Go_back_text"),
                      ),
                    ),
                  ],
                ),
              ));
  }
}
