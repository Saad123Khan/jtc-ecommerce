import 'package:get/get.dart';
import 'package:jtc_ecommerce/wallet/blocs/user_wallet_bloc.dart';
import 'package:jtc_ecommerce/wallet/blocs/wallet_transactions_bloc.dart';
import 'package:jtc_ecommerce/wallet/models/wallet_transactions_model.dart';

class WalletController extends GetxController {
  RxString walletTokens = "".obs;
  RxString walletID = "".obs;
  RxList<WalletTransaction> walletTransaction = <WalletTransaction>[].obs;

  @override
  void onInit() {
    get_user_wallet();
    get_wallet_transactions();
    super.onInit();
  }

  RxBool isLoading = false.obs;
  Future<void> get_user_wallet() async {
    try {
      isLoading.value = true;
      await UserWalletBloc().getUserWalletBlocMethod(
        context: Get.context!,
      );
    } catch (e) {
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> get_wallet_transactions() async {
    try {
      isLoading.value = true;
      await WalletTransactionsBloc().getWalletTransactionsBlocMethod(
        context: Get.context!,
      );

      if (WalletTransactionsBloc().contentTypeResponse != null) {
        walletTransaction.addAll(
          List.from(WalletTransactionsBloc().contentTypeResponse),
        );
      }
    } catch (e) {
    } finally {
      isLoading.value = false;
    }
  }

  bool isFetching = false;
  onRefreshPage() async {
    // FocusManager.instance.primaryFocus?.unfocus();
    if (isFetching) {
      // If already fetching, ignore this call
      return;
    }
    isFetching = true;
    //Clear the listings
    walletID.value = "";
    walletTokens.value = "";
    walletTransaction.value = [];
    // Fetch new data
    await get_user_wallet();
    await get_wallet_transactions();
    // Once fetch is complete, reset the flag
    isFetching = false;
  }
}
