import 'package:jtc_ecommerce/home/models/single_product_model.dart';

class CartModel {
  bool? status;
  CartResponseData? data;
  String? message;

  CartModel({this.status, this.data, this.message});

  CartModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    data = json['data'] != null
        ? new CartResponseData.fromJson(json['data'])
        : null;
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    data['message'] = this.message;
    return data;
  }
}

class CartResponseData {
  List<CartItem>? cart;
  double delivery = 0.0;
  double subtotal = 0.0;
  double tax = 0.0;
  double total = 0.0;
  // double grandTotal = 0.0;

  double? tokensDelivery;
  int? tokens;
  int? taxToken;
  int? totalToken;

  CartResponseData(
      {this.cart,
      this.delivery = 0.0,
      this.subtotal = 0.0,
      this.tax = 0.0,
      this.total = 0.0,
      this.tokensDelivery,
      // this.grandTotal = 0.0,
      this.tokens,
      this.taxToken,
      this.totalToken});

  CartResponseData.fromJson(Map<String, dynamic> json) {
    if (json['cart'] != null) {
      cart = <CartItem>[];
      json['cart'].forEach((v) {
        cart!.add(new CartItem.fromJson(v));
      });
    }
    delivery = json['fiat_delivery'] != null
        ? double.parse(json['fiat_delivery'].toString())
        : 0.0;
    subtotal = json['fiat_subtotal'] != null
        ? double.parse(json['fiat_subtotal'].toString())
        : 0.0;

    // grandTotal = json['grand_total'] != null
    //     ? double.tryParse(json['fiat_total'].toString()) ?? 0.0
    //     : 0.0;
    tax = json['fiat_tax'] != null ? double.parse(json['fiat_tax'].toString()) : 0.0;
    total =
        json['fiat_total'] != null ? double.parse(json['fiat_total'].toString()) : 0.0;
    
    
    
    tokensDelivery = json['tokens_delivery'] != null ? double.parse(json['tokens_delivery'].toString()):0.0;
    tokens = json['tokens_subtotal'];
    taxToken = json['tokens_tax'];
    totalToken = json['tokens_total'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.cart != null) {
      data['cart'] = this.cart!.map((v) => v.toJson()).toList();
    }
    data['delivery'] = this.delivery;
    data['subtotal'] = this.subtotal;
    data['tax'] = this.tax;
    data['total'] = this.total;
    data['tokens_delivery'] = this.tokensDelivery;
    data['tokens'] = this.tokens;
    data['tax_token'] = this.taxToken;
    data['total_token'] = this.totalToken;
    return data;
  }
}

class CartItem {
  int? id;
  int? productId;
  int? userId;
  int quantity = 1;
  String? addonItemsId;
  String? createdAt;
  String? updatedAt;
  String? message;
  String? addonId;
  String? productVariation;
  String? couponCode;
  String? discountToken;
  double grandTotal = 0.0;
  List<CartAddonDetails>? addonDetails;
  SingleProductModel? productDetail;

  CartItem({
    this.id,
    this.productId,
    this.userId,
    this.quantity = 1,
    this.addonItemsId,
    this.createdAt,
    this.updatedAt,
    this.message,
    this.addonId,
    this.grandTotal = 0.0,
    this.productVariation,
    this.couponCode,
    this.discountToken,
    this.addonDetails,
    this.productDetail,
  });

  CartItem.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    productId = json['product_id'];
    userId = json['user_id'];
    quantity = json['quantity'] ?? 1;
    addonItemsId = json['addon_items_id'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    grandTotal = json['grand_total'] != null
        ? double.tryParse(json['grand_total'].toString()) ?? 0.0
        : 0.0;
    message = json['message'];
    addonId = json['addon_id'];
    productVariation = json['product_variation'];
    couponCode = json['coupon_code'];
    discountToken = json['discount_token'];
    if (json['addon_details'] != null) {
      addonDetails = <CartAddonDetails>[];
      json['addon_details'].forEach((v) {
        addonDetails!.add(new CartAddonDetails.fromJson(v));
      });
    }
    productDetail = json['product_detail'] != null
        ? new SingleProductModel.fromJson(json['product_detail'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['product_id'] = this.productId;
    data['user_id'] = this.userId;
    data['quantity'] = this.quantity;
    data['addon_items_id'] = this.addonItemsId;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['message'] = this.message;
    data['addon_id'] = this.addonId;
    data['product_variation'] = this.productVariation;
    data['coupon_code'] = this.couponCode;
    data['discount_token'] = this.discountToken;
    if (this.addonDetails != null) {
      data['addon_details'] =
          this.addonDetails!.map((v) => v.toJson()).toList();
    }
    if (this.productDetail != null) {
      data['product_detail'] = this.productDetail!.toJson();
    }
    // if (this.cartId != null) {
    //   data['cart_id'] = this.cartId!.map((v) => v.toJson()).toList();
    // }
    // if (this.product != null) {
    //   data['product'] = this.product!.toJson();
    // }
    return data;
  }
}

class CartAddonDetails {
  int? id;
  String? name;
  String? slug;
  String? description;
  String? createdAt;
  String? updatedAt;
  int? addonsId;
  List<Addons>? addons;
  Addon? addon;

  CartAddonDetails(
      {this.id,
      this.name,
      this.slug,
      this.description,
      this.createdAt,
      this.updatedAt,
      this.addonsId,
      this.addons,
      this.addon});

  CartAddonDetails.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    slug = json['slug'];
    description = json['description'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    addonsId = json['addons_id'];
    if (json['addons'] != null) {
      addons = <Addons>[];
      json['addons'].forEach((v) {
        addons!.add(new Addons.fromJson(v));
      });
    }
    addon = json['addon'] != null ? new Addon.fromJson(json['addon']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['slug'] = this.slug;
    data['description'] = this.description;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['addons_id'] = this.addonsId;
    if (this.addons != null) {
      data['addons'] = this.addons!.map((v) => v.toJson()).toList();
    }
    if (this.addon != null) {
      data['addon'] = this.addon!.toJson();
    }
    return data;
  }
}

class Addons {
  int? id;
  String? name;
  String? slug;
  String? description;
  String? createdAt;
  String? updatedAt;
  String? deletedAt;
  String? image;
  int? productCategoryId;

  Addons({
    this.id,
    this.name,
    this.slug,
    this.description,
    this.createdAt,
    this.updatedAt,
    this.deletedAt,
    this.image,
    this.productCategoryId,
  });

  Addons.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    slug = json['slug'];
    description = json['description'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    deletedAt = json['deleted_at'];
    image = json['image'];
    productCategoryId = json['product_category_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['slug'] = this.slug;
    data['description'] = this.description;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['deleted_at'] = this.deletedAt;
    data['image'] = this.image;
    data['product_category_id'] = this.productCategoryId;
    return data;
  }
}

class Addon {
  int? id;
  String? name;
  String? slug;
  String? description;
  String? createdAt;
  String? updatedAt;
  String? image;
  int? productCategoryId;

  Addon({
    this.id,
    this.name,
    this.slug,
    this.description,
    this.createdAt,
    this.updatedAt,
    this.image,
    this.productCategoryId,
  });

  Addon.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    slug = json['slug'];
    description = json['description'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    image = json['image'];
    productCategoryId = json['product_category_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['slug'] = this.slug;
    data['description'] = this.description;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['image'] = this.image;
    data['product_category_id'] = this.productCategoryId;
    return data;
  }
}
