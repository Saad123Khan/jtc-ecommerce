// To parse this JSON data, do
//
//     final userWalletModel = userWalletModelFromJson(jsonString);

import 'dart:convert';

UserWalletModel userWalletModelFromJson(String str) =>
    UserWalletModel.fromJson(json.decode(str));

String userWalletModelToJson(UserWalletModel data) =>
    json.encode(data.toJson());

class UserWalletModel {
  String? walletId;
  int? availableTokens;

  UserWalletModel({
    this.walletId,
    this.availableTokens,
  });

  factory UserWalletModel.fromJson(Map<String, dynamic> json) =>
      UserWalletModel(
        walletId: json["walletId"],
        availableTokens: json["availableTokens"],
      );

  Map<String, dynamic> toJson() => {
        "walletId": walletId,
        "availableTokens": availableTokens,
      };
}
