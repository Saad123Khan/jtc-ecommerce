// To parse this JSON data, do
//
//     final referralHistory = referralHistoryFromJson(jsonString);

import 'dart:convert';

ReferralHistory referralHistoryFromJson(String str) =>
    ReferralHistory.fromJson(json.decode(str));

String referralHistoryToJson(ReferralHistory data) =>
    json.encode(data.toJson());

class ReferralHistory {
  bool status;
  List<WalletTransaction> walletTransactions;

  ReferralHistory({
    required this.status,
    required this.walletTransactions,
  });

  factory ReferralHistory.fromJson(Map<String, dynamic> json) =>
      ReferralHistory(
        status: json["status"],
        walletTransactions: List<WalletTransaction>.from(
            json["wallet_transactions"]
                .map((x) => WalletTransaction.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "status": status,
        "wallet_transactions":
            List<dynamic>.from(walletTransactions.map((x) => x.toJson())),
      };
}

class WalletTransaction {
  String message;
  String messageEn;
  String messageSp;
  int points;
  String name;

  WalletTransaction({
    required this.message,
    required this.messageEn,
    required this.messageSp,
    required this.points,
    required this.name,
  });

  factory WalletTransaction.fromJson(Map<String, dynamic> json) =>
      WalletTransaction(
        message: json["message"],
        messageEn: json["message_en"],
        messageSp: json["message_sp"],
        points: json["points"],
        name: json["name"],
      );

  Map<String, dynamic> toJson() => {
        "message": message,
        "message_en": messageEn,
        "message_sp": messageSp,
        "points": points,
        "name": name,
      };
}
