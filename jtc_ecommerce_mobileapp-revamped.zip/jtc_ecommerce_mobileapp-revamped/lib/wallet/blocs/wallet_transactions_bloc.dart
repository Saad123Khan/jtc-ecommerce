import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as Getx;
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';
import 'package:jtc_ecommerce/wallet/controllers/wallet_controller.dart';
import 'package:jtc_ecommerce/wallet/models/wallet_transactions_model.dart';

class WalletTransactionsBloc {
  Map<String, dynamic>? _queryParameters;
  Response? _response;
  VoidCallback? _onSuccess;
  dynamic contentTypeResponse;
  // GetProductByCategoryModel? _getProductByCategoryModel;
  ReferralHistory? _referralHistory;

  ////////////////////////// Terms and Condition And Privacy Policy //////////////////////////////////
  Future<void> getWalletTransactionsBlocMethod({
    required BuildContext context,
  }) async {
    await _getRequest(
      endPoint: NetworkStrings.WALLET_TRANSACTIONS_ENDPOINT,
      context: context,
    );

    _onSuccess = () {
      contentTypeResponse = _response?.data;
    };

    _validateResponse();

    return contentTypeResponse;
  }

  // Get Request
  Future<void> _getRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().getRequest(
      context: context,
      endPoint: endPoint,
      queryParameters: _queryParameters,
      isToast: false,
      isHeaderRequire: true,
    );
  }

  void _validateResponse() {
    var controller = Getx.Get.find<WalletController>();

    try {
      _referralHistory = ReferralHistory.fromJson(_response?.data);
      logData(
          message:
              "_getGoalModel: ${_referralHistory?.walletTransactions.length}");
      //1

      List<WalletTransaction> updatedListForHome =
          List.from(controller.walletTransaction);
      //2
      updatedListForHome.addAll(_referralHistory?.walletTransactions ?? []);
      //3
      controller.walletTransaction.assignAll(updatedListForHome);
      logData(
          message: "goalList For home: ${controller.walletTransaction.length}");

      Network().validateResponse(
        response: _response,
        onSuccess: _onSuccess,
        isToast: false,
      );
    } catch (error, stackTrace) {
      print("Error in _validateResponse: $error");
      print("Stack Trace: $stackTrace");
    }
  }
}
