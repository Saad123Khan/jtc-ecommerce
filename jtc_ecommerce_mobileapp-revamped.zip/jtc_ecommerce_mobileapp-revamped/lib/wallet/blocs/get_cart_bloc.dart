import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as Getx;
import 'package:jtc_ecommerce/order_summary/controllers/order_summary_controller.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';
import 'package:jtc_ecommerce/wallet/models/cart_model.dart';

class GetSalesAppBloc {
  Map<String, dynamic>? _queryParameters;
  Response? _response;
  VoidCallback? _onSuccess;
  dynamic contentTypeResponse;
  // GetProductByCategoryModel? _getProductByCategoryModel;
  CartModel? _userWalletModel;

  ////////////////////////// Terms and Condition And Privacy Policy //////////////////////////////////
  Future<void> getSalestBlocMethod({
    required BuildContext context,
    required String orderId,
  }) async {
    await _getRequest(
      endPoint: NetworkStrings.GET_SALES_APP + orderId,
      context: context,
    );

    _onSuccess = () {
      contentTypeResponse = _response?.data;
    };

    _validateResponse();

    return contentTypeResponse;
  }

  // Get Request
  Future<void> _getRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().getRequest(
      context: context,
      endPoint: endPoint,
      queryParameters: _queryParameters,
      isToast: false,
      isHeaderRequire: true,
    );
  }

  void _validateResponse() {
    var controller = Getx.Get.find<OrderSummaryController>();

    try {
      // _userWalletModel = CartModel.fromJson(_response?.data);
      // var controller = Getx.Get.find<OrderSummaryController>();
      // controller.getSalesappVar.value = _userWalletModel;

      Getx.Get.find<OrderSummaryController>().orderStatus.value =
          _response?.data['order_status'].toString() ?? "0";

      print(
          "ORDER STATUS ${Getx.Get.find<OrderSummaryController>().orderStatus.value}");
      Getx.Get.find<OrderSummaryController>().orderType.value =
          _response?.data['order_type'] ?? "delivery";
      print("ORDER TYPE" + _response?.data['order_type']);
      Network().validateResponse(
        response: _response,
        onSuccess: _onSuccess,
        isToast: false,
      );
    } catch (error, stackTrace) {
      print("Error in _validateResponse: $error");
      print("Stack Trace: $stackTrace");
    }
  }
}
