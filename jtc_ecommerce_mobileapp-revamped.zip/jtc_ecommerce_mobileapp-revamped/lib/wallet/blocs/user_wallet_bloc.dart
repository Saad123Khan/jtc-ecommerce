import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as Getx;
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';
import 'package:jtc_ecommerce/wallet/controllers/wallet_controller.dart';
import 'package:jtc_ecommerce/wallet/models/user_wallet_model.dart';

class UserWalletBloc {
  Map<String, dynamic>? _queryParameters;
  Response? _response;
  VoidCallback? _onSuccess;
  dynamic contentTypeResponse;
  // GetProductByCategoryModel? _getProductByCategoryModel;
  UserWalletModel? _userWalletModel;

  ////////////////////////// Terms and Condition And Privacy Policy //////////////////////////////////
  Future<void> getUserWalletBlocMethod({
    required BuildContext context,
  }) async {
    await _getRequest(
      endPoint: NetworkStrings.USERWALLET_ENDPOINT,
      context: context,
    );

    _onSuccess = () {
      contentTypeResponse = _response?.data;
    };

    _validateResponse();

    return contentTypeResponse;
  }

  // Get Request
  Future<void> _getRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().getRequest(
      context: context,
      endPoint: endPoint,
      queryParameters: _queryParameters,
      isToast: false,
      isHeaderRequire: true,
    );
  }

  void _validateResponse() {
    var controller = Getx.Get.find<WalletController>();

    try {
      _userWalletModel = UserWalletModel.fromJson(_response?.data);
      controller.walletID.value = _userWalletModel?.walletId.toString() ?? "";
      controller.walletTokens.value =
          _userWalletModel?.availableTokens.toString() ?? "";
      logData(
          message:
              "WalletTokens: ${controller.walletTokens} WalletID: ${controller.walletID}");

      Network().validateResponse(
        response: _response,
        onSuccess: _onSuccess,
        isToast: false,
      );
    } catch (error, stackTrace) {
      print("Error in _validateResponse: $error");
      print("Stack Trace: $stackTrace");
    }
  }
}
