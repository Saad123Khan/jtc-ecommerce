import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/widgets/custom_app_bar.dart';
import 'package:jtc_ecommerce/widgets/custom_scaffold.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/widgets/no_data_found.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_fonts.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/wallet/controllers/wallet_controller.dart';
import 'package:easy_localization/easy_localization.dart';

class WalletListScreen extends StatelessWidget {
  var controller = Get.find<WalletController>();
  WalletListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      appBarTitle: tr('WalletScreen.recent_history'),
      onTap: () => AppNavigation.navigatorPop(context),
      child: !controller.isLoading.value && controller.walletTransaction.isEmpty
          ? SizedBox(
              height: Get.height,
              width: Get.width,
              child: SingleChildScrollView(
                physics: AlwaysScrollableScrollPhysics(
                  parent: BouncingScrollPhysics(),
                ),
                child: Container(
                  height: Get.height / 1.3,
                  alignment: Alignment.center,
                  child: NoDataPage(
                    text:
                        // 'No History Found',
                        //  tr('WalletScreen.no_history_found'),
                        tr('WalletScreen.no_history_found'),
                  ),
                ),
              ),
            )
          : Padding(
              padding: const EdgeInsets.all(0.0),
              child: ListView.builder(
                  itemCount: controller.walletTransaction.length,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 0, vertical: 5),
                      child: Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 15.w, vertical: 10.h),
                        height: MediaQuery.sizeOf(context).height * 0.08,
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: index == 0 ? Colors.red : Colors.grey,
                          ),
                          borderRadius: BorderRadius.circular(12.r),
                          color: index == 0
                              ? Color(0XFFC81925)
                              : Color(0xFFF6F6F6),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CustomText(
                                  text:
                                      controller.walletTransaction[index].name,
                                  // text: "AHEMREMREMREMRMERMER",
                                  color:
                                      index == 0 ? Colors.white : Colors.black,
                                  isLeftAlign: true,
                                  fontsize: 14.sp,
                                  textAlign: TextAlign.start,
                                ),
                                CustomText(
                                  // text:
                                  //     controller
                                  //         .walletTransaction[index]
                                  //         .message,

                                  text: context.locale.languageCode == 'es'
                                      ? controller.walletTransaction[index]
                                              .messageSp ??
                                          ''
                                      : controller.walletTransaction[index]
                                              .messageEn ??
                                          '',
                                  // " AHEMREMR EMREMRMERMER",
                                  color:
                                      index == 0 ? Colors.white : Colors.grey,
                                  fontsize: 12.sp,
                                  maxLines: 3,
                                  isLeftAlign: true,
                                  fontFamily: AppFonts.defaultFont,
                                  textAlign: TextAlign.start,
                                ),
                              ],
                            ),
                            // 10.horizontalSpace,
                            Container(
                              height: 40.h,
                              width: 40.w,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(40.r),
                                color: index == 0
                                    ? Color(0XFF670003)
                                    : Color(0XFFC81925),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Center(
                                  child: Text(
                                    "\$ ${controller.walletTransaction[index].points}",
                                    style: TextStyle(
                                      color: Colors.white,
                                      overflow: TextOverflow.fade,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }),
            ),
    );
  }
}
