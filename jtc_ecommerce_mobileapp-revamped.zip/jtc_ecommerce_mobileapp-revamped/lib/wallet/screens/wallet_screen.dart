import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/widgets/no_data_found.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_fonts.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';
import 'package:jtc_ecommerce/wallet/controllers/wallet_controller.dart';

class WalletScreen extends StatelessWidget {
  var controller = Get.put(WalletController());
  WalletScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 20.h),
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(24.r),
            topRight: Radius.circular(24.r),
          )),
      child: Obx(
        () => Container(
          child: RefreshIndicator(
            onRefresh: () async {
              controller.onRefreshPage();
            },
            color: AppColors.PRIMARY_COLOR,
            child: controller.isLoading.value
                ? Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Center(
                      child: CircularProgressIndicator(
                        color: AppColors.PRIMARY_COLOR,
                      ),
                    ),
                  )
                : SingleChildScrollView(
                    physics: AlwaysScrollableScrollPhysics(
                      parent: BouncingScrollPhysics(),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          walletCard(context),
                          30.verticalSpace,
                          Container(
                            padding: EdgeInsets.symmetric(horizontal: 10.w),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(18.r),
                              border: Border.all(color: Colors.grey),
                              color: Color(0xFFF6F6F6),
                            ),
                            // height: MediaQuery.sizeOf(context).height * 0.70,
                            child: Column(
                              children: [
                                10.verticalSpace,
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    CustomText(
                                      text:
                                          // "Recent History",
                                          tr('WalletScreen.recent_history'),
                                      color: AppColors.BLACK_COLOR,
                                      fontWeight: FontWeight.bold,
                                      isLeftAlign: false,
                                      align: Alignment.centerLeft,
                                    ),
                                    GestureDetector(
                                      onTap: () {
                                        AppNavigation.navigateTo(
                                          context,
                                          AppRouteName.WALLET_LIST_SCREEN_ROUTE,
                                        );
                                      },
                                      child: CustomText(
                                        text:
                                            // "View All",
                                            tr('WalletScreen.view_all'),
                                        fontsize: 12.sp,
                                        textDecoration:
                                            TextDecoration.underline,
                                        color: AppColors.PRIMARY_COLOR,
                                        isLeftAlign: false,
                                        align: Alignment.centerLeft,
                                      ),
                                    ),
                                  ],
                                ),
                                20.verticalSpace,
                                !controller.isLoading.value &&
                                        controller.walletTransaction.isEmpty
                                    ? SizedBox(
                                        height: Get.height / 3,
                                        width: Get.width,
                                        child: Container(
                                          height: Get.height / 3,
                                          alignment: Alignment.center,
                                          child: NoDataPage(
                                            text:
                                                //  'No History Found',
                                                tr('WalletScreen.no_history_found'),
                                          ),
                                        ),
                                      )
                                    : ListView.builder(
                                        physics: NeverScrollableScrollPhysics(),
                                        shrinkWrap: true,
                                        itemCount:
                                            controller.walletTransaction.length,
                                        itemBuilder:
                                            (BuildContext context, int index) {
                                          return Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 0, vertical: 5),
                                            child: Container(
                                              padding: EdgeInsets.symmetric(
                                                  horizontal: 15.w,
                                                  vertical: 10.h),
                                              height: MediaQuery.sizeOf(context)
                                                      .height *
                                                  0.12,
                                              decoration: BoxDecoration(
                                                border: Border.all(
                                                  color: index == 0
                                                      ? Colors.red
                                                      : Colors.grey,
                                                ),
                                                borderRadius:
                                                    BorderRadius.circular(12.r),
                                                color: index == 0
                                                    ? Color(0XFFC81925)
                                                    : Color(0xFFF6F6F6),
                                              ),
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      CustomText(
                                                        text: controller
                                                            .walletTransaction[
                                                                index]
                                                            .name,
                                                        color: index == 0
                                                            ? Colors.white
                                                            : Colors.black,
                                                        isLeftAlign: true,
                                                        fontsize: 14.sp,
                                                        textAlign:
                                                            TextAlign.start, 
                                                      ), 
                                                      Container(
                                                        width: MediaQuery.sizeOf(context).height * 0.25, 
                                                        child: CustomText( 
                                                          text:
                                                              // controller
                                                              //     .walletTransaction[index]
                                                              //     .message,
                                                        
                                                              context.locale
                                                                          .languageCode ==
                                                                      'es'
                                                                  ? controller 
                                                                          .walletTransaction[
                                                                              index]
                                                                          .messageSp ??
                                                                      ''
                                                                  : controller
                                                                          .walletTransaction[
                                                                              index]
                                                                          .messageEn ??
                                                                      '',
                                                          color: index == 0
                                                              ? Colors.white
                                                              : Colors.grey,
                                                          fontsize: 11.sp,
                                                          maxLines: 3,
                                                          isLeftAlign: true, 
                                                          fontFamily: AppFonts
                                                              .defaultFont,
                                                          // textAlign:
                                                          //     TextAlign.start,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  // 10.horizontalSpace,
                                                  Container(
                                                    height: 40.h,
                                                    width: 40.w,
                                                    decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              40.r),
                                                      color: index == 0
                                                          ? Color(0XFF670003)
                                                          : Color(0XFFC81925),
                                                    ),
                                                    child: Padding(
                                                      padding:
                                                          const EdgeInsets.all(
                                                              8.0),
                                                      child: Center(
                                                        child: Text(
                                                          "${controller.walletTransaction[index].points}",
                                                          style: TextStyle(
                                                            color: Colors.white,
                                                            overflow:
                                                                TextOverflow
                                                                    .fade,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          );
                                          // Card(
                                          //   elevation: 2,
                                          //   shape: RoundedRectangleBorder(
                                          //     borderRadius:
                                          //         BorderRadius.circular(8),
                                          //   ),
                                          //   child: ListTile(
                                          //     // contentPadding: EdgeInsets.zero,
                                          //     title: Row(
                                          //       mainAxisAlignment:
                                          //           MainAxisAlignment
                                          //               .spaceBetween,
                                          //       children: [
                                          //         CustomText(
                                          //           text: controller
                                          //               .walletTransaction[
                                          //                   index]
                                          //               .name,
                                          //           color:
                                          //               AppColors.BLACK_COLOR,
                                          //           isLeftAlign: true,
                                          //           fontsize: 14.sp,
                                          //           textAlign: TextAlign.start,
                                          //         ),
                                          //         CustomText(
                                          //           text:
                                          //               "\$${controller.walletTransaction[index].points.toString()}",
                                          //           color:
                                          //               AppColors.BLACK_COLOR,
                                          //           isLeftAlign: true,
                                          //           fontsize: 14.sp,
                                          //           textAlign: TextAlign.start,
                                          //         ),
                                          //       ],
                                          //     ),
                                          //     subtitle: Padding(
                                          //       padding:
                                          //           const EdgeInsets.all(4.0),
                                          //       child: CustomText(
                                          //         text:
                                          //             // controller
                                          //             //     .walletTransaction[index]
                                          //             //     .message,

                                          //             context.locale
                                          //                         .languageCode ==
                                          //                     'es'
                                          //                 ? controller
                                          //                         .walletTransaction[
                                          //                             index]
                                          //                         .messageSp ??
                                          //                     ''
                                          //                 : controller
                                          //                         .walletTransaction[
                                          //                             index]
                                          //                         .messageEn ??
                                          //                     '',
                                          //         color: AppColors.BLACK_COLOR,
                                          //         fontsize: 12.sp,
                                          //         maxLines: 3,
                                          //         isLeftAlign: true,
                                          //         fontFamily:
                                          //             AppFonts.defaultFont,
                                          //         textAlign: TextAlign.start,
                                          //       ),
                                          //     ),
                                          //     // trailing: CustomText(
                                          //     //     text:
                                          //     //         "\$${controller.walletTransaction[index].points.toString()}"),
                                          //     onTap: () {},
                                          //   ),
                                          // );
                                        },
                                      ),
                                SizedBox(height: 20.h),
                              ],
                            ),
                          ),
//
//
                        ],
                      ),
                    ),
                  ),
            // ),
          ),
        ),
      ),
    );
  }

  Widget walletCard(BuildContext context) {
    return Container(
      // padding: EdgeInsets.symmetric(horizontal: 5.0),
      height: MediaQuery.of(context).size.height * 0.2,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12.r),
      ),
      child: Stack(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12.r),
            child: Image.asset(
              'assets/revamped/jtc_token.png', // Your image path
              fit: BoxFit.cover,
              width: double.infinity,
            ),
          ),
          Center(
            child: Row(
              // mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Image in the Row
                10.horizontalSpace,
                Image.asset(
                  'assets/images/logo.png', // Replace with your icon image path
                  width: 105.w, // Adjust width as needed
                  height: 105.h, // Adjust height as needed
                ),
                10.horizontalSpace, // Spacing between the image and the text column
                // Column with four Text widgets
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Available Balance',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15.sp, // Adjust font size as needed
                      ),
                    ),
                    Text(
                      "\$${controller.walletTokens.toString()}",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20.sp,
                      ),
                    ),
                    Text(
                      'Mexican Pesos',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                      ),
                    ),
                    Row(
                      children: [
                        Image.asset(
                          'assets/revamped/bottom_nav/wallet.png', // Replace with your icon image path
                          width: 10.w, // Adjust width as needed
                          height: 10.h, // Adjust height as needed
                          color: Colors.white,
                        ),
                        Text(
                          "  Wallet ID:" +
                              " ${controller.walletID}".toUpperCase(),
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 10.sp,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );

    // Stack(
    //   alignment: Alignment.center,
    //   children: [
    //     Image.asset(
    //       AssetPaths.WALLET_GREY,
    //     ),
    //     Positioned(
    //       left: 30,
    //       child: Column(
    //         crossAxisAlignment: CrossAxisAlignment.start,
    //         children: [
    //           CustomText(
    //             text:
    //                 // "AVAILABLE BALANCE",
    //                 tr('WalletScreen.available_balance'),
    //             color: AppColors.WHITE_COLOR,
    //             fontsize: 12.sp,
    //           ),
    //           Text(
    //             // "\$/300".toUpperCase(),
    //             // "\$/${controller.walletTokens.isEmpty ? "0" : controller.walletTokens}"

    //             // .toUpperCase(),

    //             "\$${controller.walletTokens.toString()}",
    //             style: TextStyle(
    //               color: AppColors.WHITE_COLOR,
    //               fontSize: 50.sp,
    //             ),
    //           ),
    //           CustomText(
    //             text:
    //                 // "MAXICAN PESOS".toUpperCase(),
    //                 tr('WalletScreen.mexican_pesos'),
    //             color: AppColors.WHITE_COLOR,
    //             fontsize: 14.sp,
    //           ),
    //           20.verticalSpace,
    //           CustomText(
    //             text:
    //                 //  "Wallet ID",
    //                 tr('WalletScreen.wallet_id'),
    //             color: AppColors.WHITE_COLOR,
    //             fontsize: 14.sp,
    //           ),
    //           5.verticalSpace,
    //           CustomText(
    //             text: "${controller.walletID}".toUpperCase(),
    //             color: AppColors.WHITE_COLOR,
    //             fontsize: 14.sp,
    //           ),
    //         ],
    //       ),
    //     ),
    //     Positioned(
    //       right: 30,
    //       child: Image.asset(
    //         AssetPaths.WALLET_COIN,
    //       ),
    //     )
    //   ],
    // );
  }
}
