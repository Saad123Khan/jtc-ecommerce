// To parse this JSON data, do
//
//     final clearCartModel = clearCartModelFromJson(jsonString);

import 'dart:convert';

ClearCartModel clearCartModelFromJson(String str) => ClearCartModel.fromJson(json.decode(str));

String clearCartModelToJson(ClearCartModel data) => json.encode(data.toJson());

class ClearCartModel {
    dynamic status;
    List<dynamic> data;
    dynamic message;

    ClearCartModel({
        required this.status,
        required this.data,
        required this.message,
    });

    factory ClearCartModel.fromJson(Map<String, dynamic> json) => ClearCartModel(
        status: json["status"],
        data: List<dynamic>.from(json["data"].map((x) => x)),
        message: json["message"],
    );

    Map<String, dynamic> toJson() => {
        "status": status,
        "data": List<dynamic>.from(data.map((x) => x)),
        "message": message,
    };
}
