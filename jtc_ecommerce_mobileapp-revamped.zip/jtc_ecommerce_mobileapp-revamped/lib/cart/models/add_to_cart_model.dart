// // To parse this JSON data, do
// //
// //     final addToCartModel = addToCartModelFromJson(jsonString);

// import 'dart:convert';

// AddToCartModel addToCartModelFromJson(String str) => AddToCartModel.fromJson(json.decode(str));

// String addToCartModelToJson(AddToCartModel data) => json.encode(data.toJson());

// class AddToCartModel {
//     bool success;
//     AddToCartData data;
//     String message;

//     AddToCartModel({
//         required this.success,
//         required this.data,
//         required this.message,
//     });

//     factory AddToCartModel.fromJson(Map<String, dynamic> json) => AddToCartModel(
//         success: json["status"],
//         data: AddToCartData.fromJson(json["data"]),
//         message: json["message"],
//     );

//     Map<String, dynamic> toJson() => {
//         "success": success,
//         "data": data.toJson(),
//         "message": message,
//     };
// }

// class AddToCartData {
//     String productId;
//     String quantity;
//     String message;
//     int userId;
//     String addonId;
//     String addonItemsId;
//     DateTime updatedAt;
//     DateTime createdAt;
//     int id;

//     AddToCartData({
//         required this.productId,
//         required this.quantity,
//         required this.message,
//         required this.userId,
//         required this.addonId,
//         required this.addonItemsId,
//         required this.updatedAt,
//         required this.createdAt,
//         required this.id,
//     });

//     factory AddToCartData.fromJson(Map<String, dynamic> json) => AddToCartData(
//         productId: json["product_id"],
//         quantity: json["quantity"],
//         message: json["message"],
//         userId: json["user_id"],
//         addonId: json["addon_id"],
//         addonItemsId: json["addon_items_id"],
//         updatedAt: DateTime.parse(json["updated_at"]),
//         createdAt: DateTime.parse(json["created_at"]),
//         id: json["id"],
//     );

//     Map<String, dynamic> toJson() => {
//         "product_id": productId,
//         "quantity": quantity,
//         "message": message,
//         "user_id": userId,
//         "addon_id": addonId,
//         "addon_items_id": addonItemsId,
//         "updated_at": updatedAt.toIso8601String(),
//         "created_at": createdAt.toIso8601String(),
//         "id": id,
//     };
// }

// To parse this JSON data, do
//
//     final jtcTokenPlanModel = jtcTokenPlanModelFromJson(jsonString);

import 'dart:convert';

AddToCartModel jtcTokenPlanModelFromJson(String str) =>
    AddToCartModel.fromJson(json.decode(str));

String jtcTokenPlanModelToJson(AddToCartModel data) =>
    json.encode(data.toJson());

class AddToCartModel {
  dynamic? status;
  AddToCartData? data;
  dynamic? message;

  AddToCartModel({
    this.status,
    this.data,
    this.message,
  });

  factory AddToCartModel.fromJson(Map<String, dynamic> json) => AddToCartModel(
        status: json["status"],
        data:
            json["data"] == null ? null : AddToCartData.fromJson(json["data"]),
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "status": status,
        "data": data?.toJson(),
        "message": message,
      };
}

class AddToCartData {
  // dynamic? productId;
  // dynamic? quantity;
  // dynamic? message;
  // dynamic? userId;
  // dynamic? updatedAt;
  // dynamic? createdAt;
  // dynamic? id;
  // List<Addon>? addons;
  dynamic id;
  dynamic productId;
  dynamic userId;
  dynamic quantity;
  dynamic addonItemsId;
  DateTime createdAt;
  DateTime updatedAt;
  dynamic message;
  dynamic addonId;
  List<Addon> addons;

  AddToCartData({
    // this.productId,
    // this.quantity,
    // this.message,
    // this.userId,
    // this.updatedAt,
    // this.createdAt,
    // this.id,
    // this.addons,
    required this.id,
    required this.productId,
    required this.userId,
    required this.quantity,
    required this.addonItemsId,
    required this.createdAt,
    required this.updatedAt,
    required this.message,
    required this.addonId,
    required this.addons,
  });

  factory AddToCartData.fromJson(Map<String, dynamic> json) => AddToCartData(
        // productId: json["product_id"],
        // quantity: json["quantity"],
        // message: json["message"],
        // userId: json["user_id"],
        // updatedAt: json["updated_at"] == null
        //     ? null
        //     : DateTime.parse(json["updated_at"]),
        // createdAt: json["created_at"] == null
        //     ? null
        //     : DateTime.parse(json["created_at"]),
        // id: json["id"],
        // addons: json["addons"] == null
        //     ? []
        //     : List<Addon>.from(json["addons"]!.map((x) => Addon.fromJson(x))),

        id: json["id"],
        productId: json["product_id"],
        userId: json["user_id"],
        quantity: json["quantity"],
        addonItemsId: json["addon_items_id"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        message: json["message"],
        addonId: json["addon_id"],
        addons: json["addons"] == null
            ? []
            : List<Addon>.from(json["addons"].map((x) => Addon.fromJson(x))) ??
                [],
      );

  Map<String, dynamic> toJson() => {
        // "product_id": productId,
        // "quantity": quantity,
        // "message": message,
        // "user_id": userId,
        // "updated_at": updatedAt?.toIso8601String(),
        // "created_at": createdAt?.toIso8601String(),
        // "id": id,
        // "addons": addons == null
        //     ? []
        //     : List<dynamic>.from(addons!.map((x) => x.toJson())),
        "id": id,
        "product_id": productId,
        "user_id": userId,
        "quantity": quantity,
        "addon_items_id": addonItemsId,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "message": message,
        "addon_id": addonId,
        "addons": List<dynamic>.from(addons.map((x) => x.toJson())) ?? [],
      };
}

// class Addon {
//   dynamic? addonId;
//   List<int>? addonItemsId;

//   Addon({
//     this.addonId,
//     this.addonItemsId,
//   });

//   factory Addon.fromJson(Map<String, dynamic> json) => Addon(
//         addonId: json["addon_id"],
//         addonItemsId: json["addon_items_id"] == null
//             ? []
//             : List<int>.from(json["addon_items_id"].map((x) => x)),
//       );

//   Map<String, dynamic> toJson() => {
//         "addon_id": addonId,
//         "addon_items_id": addonItemsId == null
//             ? []
//             : List<dynamic>.from(addonItemsId!.map((x) => x)),
//       };
// }
class Addon {
  dynamic id;
  dynamic addonsId;
  dynamic addonItemsId;
  dynamic createdAt;
  dynamic updatedAt;

  Addon({
    required this.id,
    required this.addonsId,
    required this.addonItemsId,
    // required this.createdAt,
    // required this.updatedAt,
  });

  factory Addon.fromJson(Map<String, dynamic> json) => Addon(
        id: json["id"],
        addonsId: json["addons_id"],
        addonItemsId: json["addon_items_id"],
        // createdAt: DateTime.parse(json["created_at"]),
        // updatedAt: DateTime.parse(json["updated_at"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "addons_id": addonsId,
        "addon_items_id": addonItemsId,
        // "created_at": createdAt.toIso8601String(),
        // "updated_at": updatedAt.toIso8601String(),
      };
}
