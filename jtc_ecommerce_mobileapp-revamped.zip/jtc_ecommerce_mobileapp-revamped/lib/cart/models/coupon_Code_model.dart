// To parse this JSON data, do
//
//     final couponCodeModel = couponCodeModelFromJson(jsonString);

import 'dart:convert';

CouponCodeModel couponCodeModelFromJson(String str) => CouponCodeModel.fromJson(json.decode(str));

String couponCodeModelToJson(CouponCodeModel data) => json.encode(data.toJson());

class CouponCodeModel {
    bool success;
    String message;
    int token;

    CouponCodeModel({
        required this.success,
        required this.message,
        required this.token,
    });

    factory CouponCodeModel.fromJson(Map<String, dynamic> json) => CouponCodeModel(
        success: json["success"],
        message: json["message"],
        token: json["token"],
    );

    Map<String, dynamic> toJson() => {
        "success": success,
        "message": message,
        "token": token,
    };
}
