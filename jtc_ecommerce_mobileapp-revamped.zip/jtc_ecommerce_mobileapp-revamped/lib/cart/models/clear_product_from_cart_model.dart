// To parse this JSON data, do
//
//     final clearProductFromCartModel = clearProductFromCartModelFromJson(jsonString);

import 'dart:convert';

ClearProductFromCartModel clearProductFromCartModelFromJson(String str) => ClearProductFromCartModel.fromJson(json.decode(str));

String clearProductFromCartModelToJson(ClearProductFromCartModel data) => json.encode(data.toJson());

class ClearProductFromCartModel {
    dynamic status;
    ClearProductFromCart data;
    dynamic message;

    ClearProductFromCartModel({
        required this.status,
        required this.data,
        required this.message,
    });

    factory ClearProductFromCartModel.fromJson(Map<String, dynamic> json) => ClearProductFromCartModel(
        status: json["status"],
        data: ClearProductFromCart.fromJson(json["data"]),
        message: json["message"],
    );

    Map<String, dynamic> toJson() => {
        "status": status,
        "data": data.toJson(),
        "message": message,
    };
}

class ClearProductFromCart {
    List<Cart> cart;
    dynamic delivery;
    dynamic subtotal;
    dynamic tax;
    dynamic total;
    dynamic tokens;
    dynamic taxToken;
    dynamic totalToken;

    ClearProductFromCart({
        required this.cart,
        required this.delivery,
        required this.subtotal,
        required this.tax,
        required this.total,
        required this.tokens,
        required this.taxToken,
        required this.totalToken,
    });

    factory ClearProductFromCart.fromJson(Map<String, dynamic> json) => ClearProductFromCart(
        cart: List<Cart>.from(json["cart"].map((x) => Cart.fromJson(x))),
        delivery: json["delivery"],
        subtotal: json["subtotal"],
        tax: json["tax"],
        total: json["total"],
        tokens: json["tokens"],
        taxToken: json["tax_token"],
        totalToken: json["total_token"],
    );

    Map<String, dynamic> toJson() => {
        "cart": List<dynamic>.from(cart.map((x) => x.toJson())),
        "delivery": delivery,
        "subtotal": subtotal,
        "tax": tax,
        "total": total,
        "tokens": tokens,
        "tax_token": taxToken,
        "total_token": totalToken,
    };
}

class Cart {
    dynamic id;
    dynamic productId;
    dynamic userId;
    dynamic quantity;
    dynamic addonItemsId;
    DateTime createdAt;
    DateTime updatedAt;
    dynamic message;
    dynamic addonId;
    ProductDetail productDetail;
    CartId? cartId;
    Product product;

    Cart({
        required this.id,
        required this.productId,
        required this.userId,
        required this.quantity,
        required this.addonItemsId,
        required this.createdAt,
        required this.updatedAt,
        required this.message,
        required this.addonId,
        required this.productDetail,
        required this.cartId,
        required this.product,
    });

    factory Cart.fromJson(Map<String, dynamic> json) => Cart(
        id: json["id"],
        productId: json["product_id"],
        userId: json["user_id"],
        quantity: json["quantity"],
        addonItemsId: json["addon_items_id"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        message: json["message"],
        addonId: json["addon_id"],
        productDetail: ProductDetail.fromJson(json["product_detail"]),
      
        cartId:  json["cart_id"] != null ?  CartId.fromJson(json["cart_id"]): null,
        product: Product.fromJson(json["product"]),
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "product_id": productId,
        "user_id": userId,
        "quantity": quantity,
        "addon_items_id": addonItemsId,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "message": message,
        "addon_id": addonId,
        "product_detail": productDetail.toJson(),
        "cart_id": cartId?.toJson(),
        "product": product.toJson(),
    };
}

class CartId {
    dynamic id;
    dynamic cartId;
    dynamic addonItemsId;
    dynamic addonsId;
    DateTime createdAt;
    DateTime updatedAt;
    List<Addon> addons;
    List<AddonsItem> addonsItems;

    CartId({
        required this.id,
        required this.cartId,
        required this.addonItemsId,
        required this.addonsId,
        required this.createdAt,
        required this.updatedAt,
        required this.addons,
        required this.addonsItems,
    });

    factory CartId.fromJson(Map<String, dynamic> json) => CartId(
        id: json["id"],
        cartId: json["cart_id"],
        addonItemsId: json["addon_items_id"],
        addonsId: json["addons_id"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        addons: List<Addon>.from(json["addons"].map((x) => Addon.fromJson(x))),
        addonsItems: List<AddonsItem>.from(json["addons_items"].map((x) => AddonsItem.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "cart_id": cartId,
        "addon_items_id": addonItemsId,
        "addons_id": addonsId,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "addons": List<dynamic>.from(addons.map((x) => x.toJson())),
        "addons_items": List<dynamic>.from(addonsItems.map((x) => x.toJson())),
    };
}

class Addon {
    dynamic id;
    dynamic name;
    dynamic slug;
    dynamic description;
    DateTime createdAt;
    DateTime updatedAt;
    dynamic deletedAt;
    dynamic image;
    dynamic productCategoryId;
    ProductCategory productCategory;
    Pivot? pivot;

    Addon({
        required this.id,
        required this.name,
        required this.slug,
        required this.description,
        required this.createdAt,
        required this.updatedAt,
        required this.deletedAt,
        required this.image,
        required this.productCategoryId,
        required this.productCategory,
        this.pivot,
    });

    factory Addon.fromJson(Map<String, dynamic> json) => Addon(
        id: json["id"],
        name: json["name"],
        slug: json["slug"],
        description: json["description"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        deletedAt: json["deleted_at"],
        image: json["image"],
        productCategoryId: json["product_category_id"],
        productCategory: ProductCategory.fromJson(json["product_category"]),
        pivot: json["pivot"] == null ? null : Pivot.fromJson(json["pivot"]),
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "slug": slug,
        "description": description,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "deleted_at": deletedAt,
        "image": image,
        "product_category_id": productCategoryId,
        "product_category": productCategory.toJson(),
        "pivot": pivot?.toJson(),
    };
}

class Pivot {
    dynamic addonItemsId;
    dynamic addonsId;

    Pivot({
        required this.addonItemsId,
        required this.addonsId,
    });

    factory Pivot.fromJson(Map<String, dynamic> json) => Pivot(
        addonItemsId: json["addon_items_id"],
        addonsId: json["addons_id"],
    );

    Map<String, dynamic> toJson() => {
        "addon_items_id": addonItemsId,
        "addons_id": addonsId,
    };
}

class ProductCategory {
    dynamic id;
    dynamic name;
    DateTime createdAt;
    DateTime updatedAt;
    dynamic imageUrl;
    List<Media> media;

    ProductCategory({
        required this.id,
        required this.name,
        required this.createdAt,
        required this.updatedAt,
        required this.imageUrl,
        required this.media,
    });

    factory ProductCategory.fromJson(Map<String, dynamic> json) => ProductCategory(
        id: json["id"],
        name: json["name"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        imageUrl: json["image_url"],
        media: List<Media>.from(json["media"].map((x) => Media.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "image_url": imageUrl,
        "media": List<dynamic>.from(media.map((x) => x.toJson())),
    };
}

class Media {
    dynamic id;
    dynamic modelType;
    dynamic modelId;
    dynamic uuid;
    dynamic collectionName;
    dynamic name;
    dynamic fileName;
    dynamic mimeType;
    dynamic disk;
    dynamic conversionsDisk;
    dynamic size;
    List<dynamic> manipulations;
    List<dynamic> customProperties;
    List<dynamic> generatedConversions;
    List<dynamic> responsiveImages;
    dynamic orderColumn;
    DateTime createdAt;
    DateTime updatedAt;
    dynamic originalUrl;
    dynamic previewUrl;

    Media({
        required this.id,
        required this.modelType,
        required this.modelId,
        required this.uuid,
        required this.collectionName,
        required this.name,
        required this.fileName,
        required this.mimeType,
        required this.disk,
        required this.conversionsDisk,
        required this.size,
        required this.manipulations,
        required this.customProperties,
        required this.generatedConversions,
        required this.responsiveImages,
        required this.orderColumn,
        required this.createdAt,
        required this.updatedAt,
        required this.originalUrl,
        required this.previewUrl,
    });

    factory Media.fromJson(Map<String, dynamic> json) => Media(
        id: json["id"],
        modelType: json["model_type"],
        modelId: json["model_id"],
        uuid: json["uuid"],
        collectionName: json["collection_name"],
        name: json["name"],
        fileName: json["file_name"],
        mimeType: json["mime_type"],
        disk: json["disk"],
        conversionsDisk: json["conversions_disk"],
        size: json["size"],
        manipulations: List<dynamic>.from(json["manipulations"].map((x) => x)),
        customProperties: List<dynamic>.from(json["custom_properties"].map((x) => x)),
        generatedConversions: List<dynamic>.from(json["generated_conversions"].map((x) => x)),
        responsiveImages: List<dynamic>.from(json["responsive_images"].map((x) => x)),
        orderColumn: json["order_column"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        originalUrl: json["original_url"],
        previewUrl: json["preview_url"],
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "model_type": modelType,
        "model_id": modelId,
        "uuid": uuid,
        "collection_name": collectionName,
        "name": name,
        "file_name": fileName,
        "mime_type": mimeType,
        "disk": disk,
        "conversions_disk": conversionsDisk,
        "size": size,
        "manipulations": List<dynamic>.from(manipulations.map((x) => x)),
        "custom_properties": List<dynamic>.from(customProperties.map((x) => x)),
        "generated_conversions": List<dynamic>.from(generatedConversions.map((x) => x)),
        "responsive_images": List<dynamic>.from(responsiveImages.map((x) => x)),
        "order_column": orderColumn,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "original_url": originalUrl,
        "preview_url": previewUrl,
    };
}

class AddonsItem {
    dynamic id;
    dynamic name;
    dynamic slug;
    dynamic description;
    DateTime createdAt;
    DateTime updatedAt;
    dynamic deletedAt;
    dynamic addonsId;
    List<Addon> addons;
    Addon addon;

    AddonsItem({
        required this.id,
        required this.name,
        required this.slug,
        required this.description,
        required this.createdAt,
        required this.updatedAt,
        required this.deletedAt,
        required this.addonsId,
        required this.addons,
        required this.addon,
    });

    factory AddonsItem.fromJson(Map<String, dynamic> json) => AddonsItem(
        id: json["id"],
        name: json["name"],
        slug: json["slug"],
        description: json["description"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        deletedAt: json["deleted_at"],
        addonsId: json["addons_id"],
        addons: List<Addon>.from(json["addons"].map((x) => Addon.fromJson(x))),
        addon: Addon.fromJson(json["addon"]),
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "slug": slug,
        "description": description,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "deleted_at": deletedAt,
        "addons_id": addonsId,
        "addons": List<dynamic>.from(addons.map((x) => x.toJson())),
        "addon": addon.toJson(),
    };
}

class Product {
    dynamic id;
    dynamic name;
    dynamic code;
    dynamic barcodeSymbol;
    dynamic productCategoryId;
    dynamic productSubcategoryId;
    dynamic brandId;
    dynamic productCost;
    dynamic makingTime;
    dynamic productPrice;
    dynamic productUnit;
    dynamic saleUnit;
    dynamic purchaseUnit;
    dynamic stockAlert;
    dynamic quantityLimit;
    dynamic orderTax;
    dynamic taxType;
    dynamic notes;
    DateTime createdAt;
    DateTime updatedAt;
    dynamic orderCreateBy;
    dynamic description;
    dynamic productInvesters;
    dynamic productJtcToken;
    dynamic totalPrice;
    dynamic totalJtcToken;
    dynamic profitMargin;
    dynamic withoutTaxToken;
    dynamic productJtcTokenMargin;
    dynamic productJtcTokenInvestors;
    dynamic smallPrice;
    dynamic mediumPrice;
    dynamic largePrice;
    dynamic smallToken;
    dynamic mediumToken;
    dynamic largeToken;
    dynamic isVariantCheck;
    List<String> imageUrl;
    dynamic barcodeImageUrl;
    List<Variation> variations;
    List<Media> media;

    Product({
        required this.id,
        required this.name,
        required this.code,
        required this.barcodeSymbol,
        required this.productCategoryId,
        required this.productSubcategoryId,
        required this.brandId,
        required this.productCost,
        required this.makingTime,
        required this.productPrice,
        required this.productUnit,
        required this.saleUnit,
        required this.purchaseUnit,
        required this.stockAlert,
        required this.quantityLimit,
        required this.orderTax,
        required this.taxType,
        required this.notes,
        required this.createdAt,
        required this.updatedAt,
        required this.orderCreateBy,
        required this.description,
        required this.productInvesters,
        required this.productJtcToken,
        required this.totalPrice,
        required this.totalJtcToken,
        required this.profitMargin,
        required this.withoutTaxToken,
        required this.productJtcTokenMargin,
        required this.productJtcTokenInvestors,
        required this.smallPrice,
        required this.mediumPrice,
        required this.largePrice,
        required this.smallToken,
        required this.mediumToken,
        required this.largeToken,
        required this.isVariantCheck,
        required this.imageUrl,
        required this.barcodeImageUrl,
        required this.variations,
        required this.media,
    });

    factory Product.fromJson(Map<String, dynamic> json) => Product(
        id: json["id"],
        name: json["name"],
        code: json["code"],
        barcodeSymbol: json["barcode_symbol"],
        productCategoryId: json["product_category_id"],
        productSubcategoryId: json["product_subcategory_id"],
        brandId: json["brand_id"],
        productCost: json["product_cost"],
        makingTime: json["making_time"],
        productPrice: json["product_price"],
        productUnit: json["product_unit"],
        saleUnit: json["sale_unit"],
        purchaseUnit: json["purchase_unit"],
        stockAlert: json["stock_alert"],
        quantityLimit: json["quantity_limit"],
        orderTax: json["order_tax"],
        taxType: json["tax_type"],
        notes: json["notes"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        orderCreateBy: json["order_create_by"],
        description: json["description"],
        productInvesters: json["product_investers"],
        productJtcToken: json["product_jtcToken"],
        totalPrice: json["total_price"],
        totalJtcToken: json["total_jtcToken"],
        profitMargin: json["profit_margin"],
        withoutTaxToken: json["withoutTax_token"],
        productJtcTokenMargin: json["product_jtcToken_margin"],
        productJtcTokenInvestors: json["product_jtcToken_investors"],
        smallPrice: json["small_price"],
        mediumPrice: json["medium_price"],
        largePrice: json["large_price"],
        smallToken: json["small_token"],
        mediumToken: json["medium_token"],
        largeToken: json["large_token"],
        isVariantCheck: json["is_variant_check"],
        imageUrl: List<String>.from(json["image_url"].map((x) => x)),
        barcodeImageUrl: json["barcode_image_url"],
        variations: List<Variation>.from(json["variations"].map((x) => Variation.fromJson(x))),
        media: List<Media>.from(json["media"].map((x) => Media.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "code": code,
        "barcode_symbol": barcodeSymbol,
        "product_category_id": productCategoryId,
        "product_subcategory_id": productSubcategoryId,
        "brand_id": brandId,
        "product_cost": productCost,
        "making_time": makingTime,
        "product_price": productPrice,
        "product_unit": productUnit,
        "sale_unit": saleUnit,
        "purchase_unit": purchaseUnit,
        "stock_alert": stockAlert,
        "quantity_limit": quantityLimit,
        "order_tax": orderTax,
        "tax_type": taxType,
        "notes": notes,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "order_create_by": orderCreateBy,
        "description": description,
        "product_investers": productInvesters,
        "product_jtcToken": productJtcToken,
        "total_price": totalPrice,
        "total_jtcToken": totalJtcToken,
        "profit_margin": profitMargin,
        "withoutTax_token": withoutTaxToken,
        "product_jtcToken_margin": productJtcTokenMargin,
        "product_jtcToken_investors": productJtcTokenInvestors,
        "small_price": smallPrice,
        "medium_price": mediumPrice,
        "large_price": largePrice,
        "small_token": smallToken,
        "medium_token": mediumToken,
        "large_token": largeToken,
        "is_variant_check": isVariantCheck,
        "image_url": List<dynamic>.from(imageUrl.map((x) => x)),
        "barcode_image_url": barcodeImageUrl,
        "variations": List<dynamic>.from(variations.map((x) => x.toJson())),
        "media": List<dynamic>.from(media.map((x) => x.toJson())),
    };
}

class Variation {
    dynamic id;
    dynamic productId;
    dynamic addonsId;
    dynamic addonItemsId;
    dynamic price;
    DateTime createdAt;
    DateTime updatedAt;
    dynamic deletedAt;
    dynamic jtcToken;

    Variation({
        required this.id,
        required this.productId,
        required this.addonsId,
        required this.addonItemsId,
        required this.price,
        required this.createdAt,
        required this.updatedAt,
        required this.deletedAt,
        required this.jtcToken,
    });

    factory Variation.fromJson(Map<String, dynamic> json) => Variation(
        id: json["id"],
        productId: json["product_id"],
        addonsId: json["addons_id"],
        addonItemsId: json["addon_items_id"],
        price: json["price"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        deletedAt: json["deleted_at"],
        jtcToken: json["jtc_token"],
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "product_id": productId,
        "addons_id": addonsId,
        "addon_items_id": addonItemsId,
        "price": price,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "deleted_at": deletedAt,
        "jtc_token": jtcToken,
    };
}

class ProductDetail {
    dynamic id;
    dynamic name;
    dynamic code;
    dynamic productCategoryId;
    dynamic productSubcategoryId;
    dynamic brandId;
    dynamic productCost;
    dynamic productPrice;
    dynamic productUnit;
    dynamic saleUnit;
    dynamic purchaseUnit;
    dynamic stockAlert;
    dynamic quantityLimit;
    dynamic makingTime;
    dynamic orderTax;
    dynamic taxType;
    dynamic notes;
    dynamic description;
    List<String> images;
    List<String> imageUrl;
    dynamic productCategoryName;
    dynamic productSubcategoryName;
    dynamic brandName;
    dynamic barcodeImageUrl;
    dynamic barcodeSymbol;
    DateTime createdAt;
    dynamic orderCreateBy;
    ProductUnitName productUnitName;
    EUnitName purchaseUnitName;
    EUnitName saleUnitName;
    Stock stock;
    List<ProductAddon> productAddons;
    List<Warehouse> warehouse;
    dynamic barcodeUrl;
    dynamic inStock;
    dynamic review;
    bool isFavourite;
    dynamic favouriteCount;
    dynamic profitMargin;
    dynamic productInvesters;
    dynamic productJtcToken;

    ProductDetail({
        required this.id,
        required this.name,
        required this.code,
        required this.productCategoryId,
        required this.productSubcategoryId,
        required this.brandId,
        required this.productCost,
        required this.productPrice,
        required this.productUnit,
        required this.saleUnit,
        required this.purchaseUnit,
        required this.stockAlert,
        required this.quantityLimit,
        required this.makingTime,
        required this.orderTax,
        required this.taxType,
        required this.notes,
        required this.description,
        required this.images,
        required this.imageUrl,
        required this.productCategoryName,
        required this.productSubcategoryName,
        required this.brandName,
        required this.barcodeImageUrl,
        required this.barcodeSymbol,
        required this.createdAt,
        required this.orderCreateBy,
        required this.productUnitName,
        required this.purchaseUnitName,
        required this.saleUnitName,
        required this.stock,
        required this.productAddons,
        required this.warehouse,
        required this.barcodeUrl,
        required this.inStock,
        required this.review,
        required this.isFavourite,
        required this.favouriteCount,
        required this.profitMargin,
        required this.productInvesters,
        required this.productJtcToken,
    });

    factory ProductDetail.fromJson(Map<String, dynamic> json) => ProductDetail(
        id: json["id"],
        name: json["name"],
        code: json["code"],
        productCategoryId: json["product_category_id"],
        productSubcategoryId: json["product_subcategory_id"],
        brandId: json["brand_id"],
        productCost: json["product_cost"],
        productPrice: json["product_price"],
        productUnit: json["product_unit"],
        saleUnit: json["sale_unit"],
        purchaseUnit: json["purchase_unit"],
        stockAlert: json["stock_alert"],
        quantityLimit: json["quantity_limit"],
        makingTime: json["making_time"],
        orderTax: json["order_tax"],
        taxType: json["tax_type"],
        notes: json["notes"],
        description: json["description"],
        images: List<String>.from(json["images"].map((x) => x)),
        imageUrl: List<String>.from(json["image_url"].map((x) => x)),
        productCategoryName: json["product_category_name"],
        productSubcategoryName: json["product_subcategory_name"],
        brandName: json["brand_name"],
        barcodeImageUrl: json["barcode_image_url"],
        barcodeSymbol: json["barcode_symbol"],
        createdAt: DateTime.parse(json["created_at"]),
        orderCreateBy: json["order_create_by"],
        productUnitName: ProductUnitName.fromJson(json["product_unit_name"]),
        purchaseUnitName: EUnitName.fromJson(json["purchase_unit_name"]),
        saleUnitName: EUnitName.fromJson(json["sale_unit_name"]),
        stock: Stock.fromJson(json["stock"]),
        productAddons: List<ProductAddon>.from(json["product_addons"].map((x) => ProductAddon.fromJson(x))),
        warehouse: List<Warehouse>.from(json["warehouse"].map((x) => Warehouse.fromJson(x))),
        barcodeUrl: json["barcode_url"],
        inStock: json["in_stock"],
        review: json["review"],
        isFavourite: json["is_favourite"],
        favouriteCount: json["favourite_count"],
        profitMargin: json["profit_margin"],
        productInvesters: json["product_investers"],
        productJtcToken: json["product_jtcToken"],
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "code": code,
        "product_category_id": productCategoryId,
        "product_subcategory_id": productSubcategoryId,
        "brand_id": brandId,
        "product_cost": productCost,
        "product_price": productPrice,
        "product_unit": productUnit,
        "sale_unit": saleUnit,
        "purchase_unit": purchaseUnit,
        "stock_alert": stockAlert,
        "quantity_limit": quantityLimit,
        "making_time": makingTime,
        "order_tax": orderTax,
        "tax_type": taxType,
        "notes": notes,
        "description": description,
        "images": List<dynamic>.from(images.map((x) => x)),
        "image_url": List<dynamic>.from(imageUrl.map((x) => x)),
        "product_category_name": productCategoryName,
        "product_subcategory_name": productSubcategoryName,
        "brand_name": brandName,
        "barcode_image_url": barcodeImageUrl,
        "barcode_symbol": barcodeSymbol,
        "created_at": createdAt.toIso8601String(),
        "order_create_by": orderCreateBy,
        "product_unit_name": productUnitName.toJson(),
        "purchase_unit_name": purchaseUnitName.toJson(),
        "sale_unit_name": saleUnitName.toJson(),
        "stock": stock.toJson(),
        "product_addons": List<dynamic>.from(productAddons.map((x) => x.toJson())),
        "warehouse": List<dynamic>.from(warehouse.map((x) => x.toJson())),
        "barcode_url": barcodeUrl,
        "in_stock": inStock,
        "review": review,
        "is_favourite": isFavourite,
        "favourite_count": favouriteCount,
        "profit_margin": profitMargin,
        "product_investers": productInvesters,
        "product_jtcToken": productJtcToken,
    };
}

class ProductAddon {
    dynamic addonName;
    dynamic addonId;
    List<AddonItem> addonItems;

    ProductAddon({
        required this.addonName,
        required this.addonId,
        required this.addonItems,
    });

    factory ProductAddon.fromJson(Map<String, dynamic> json) => ProductAddon(
        addonName: json["addon_name"],
        addonId: json["addon_id"],
        addonItems: List<AddonItem>.from(json["addon_items"].map((x) => AddonItem.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "addon_name": addonName,
        "addon_id": addonId,
        "addon_items": List<dynamic>.from(addonItems.map((x) => x.toJson())),
    };
}

class AddonItem {
    dynamic itemId;
    dynamic itemName;
    dynamic itemPrice;
    dynamic itemToken;

    AddonItem({
        required this.itemId,
        required this.itemName,
        required this.itemPrice,
        required this.itemToken,
    });

    factory AddonItem.fromJson(Map<String, dynamic> json) => AddonItem(
        itemId: json["item_id"],
        itemName: json["item_name"],
        itemPrice: json["item_price"],
        itemToken: json["item_token"],
    );

    Map<String, dynamic> toJson() => {
        "item_id": itemId,
        "item_name": itemName,
        "item_price": itemPrice,
        "item_token": itemToken,
    };
}

class ProductUnitName {
    dynamic id;
    dynamic name;
    dynamic isDefault;
    DateTime createdAt;
    DateTime updatedAt;

    ProductUnitName({
        required this.id,
        required this.name,
        required this.isDefault,
        required this.createdAt,
        required this.updatedAt,
    });

    factory ProductUnitName.fromJson(Map<String, dynamic> json) => ProductUnitName(
        id: json["id"],
        name: json["name"],
        isDefault: json["is_default"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "is_default": isDefault,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
    };
}

class EUnitName {
    dynamic id;
    dynamic name;
    dynamic shortName;
    dynamic baseUnit;
    DateTime createdAt;
    DateTime updatedAt;

    EUnitName({
        required this.id,
        required this.name,
        required this.shortName,
        required this.baseUnit,
        required this.createdAt,
        required this.updatedAt,
    });

    factory EUnitName.fromJson(Map<String, dynamic> json) => EUnitName(
        id: json["id"],
        name: json["name"],
        shortName: json["short_name"],
        baseUnit: json["base_unit"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "short_name": shortName,
        "base_unit": baseUnit,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
    };
}

class Stock {
    dynamic id;
    dynamic warehouseId;
    dynamic productId;
    dynamic quantity;
    DateTime createdAt;
    DateTime updatedAt;
    dynamic alert;

    Stock({
        required this.id,
        required this.warehouseId,
        required this.productId,
        required this.quantity,
        required this.createdAt,
        required this.updatedAt,
        required this.alert,
    });

    factory Stock.fromJson(Map<String, dynamic> json) => Stock(
        id: json["id"],
        warehouseId: json["warehouse_id"],
        productId: json["product_id"],
        quantity: json["quantity"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        alert: json["alert"],
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "warehouse_id": warehouseId,
        "product_id": productId,
        "quantity": quantity,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "alert": alert,
    };
}

class Warehouse {
    dynamic totalQuantity;
    dynamic name;

    Warehouse({
        required this.totalQuantity,
        required this.name,
    });

    factory Warehouse.fromJson(Map<String, dynamic> json) => Warehouse(
        totalQuantity: json["total_quantity"],
        name: json["name"],
    );

    Map<String, dynamic> toJson() => {
        "total_quantity": totalQuantity,
        "name": name,
    };
}
