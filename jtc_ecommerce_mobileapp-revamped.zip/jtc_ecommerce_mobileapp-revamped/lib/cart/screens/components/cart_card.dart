import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart'; // Assuming you are using the GetX package
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:jtc_ecommerce/cart/blocs/add_to_cart_bloc.dart';
import 'package:jtc_ecommerce/cart/blocs/clear_product_from_cart_bloc.dart';
import 'package:jtc_ecommerce/cart/controllers/cart_controller.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';
import 'package:jtc_ecommerce/wallet/models/cart_model.dart'; // Assuming you are using screenutil

class CartCard extends StatelessWidget {
  final CartItem? cartList;
  final BuildContext context;
  final int index;

  CartCard({
    required this.cartList,
    required this.context,
    required this.index,
  });

  double getPriceWithVariations() {
    // bool isVarAvaible = cartList?.productVariation != null;
    // String? variations = cartList?.productVariation;
    // print(double.parse(cartList?.productDetail?.productPrice ?? '0.0'));
    // double totalPrice = 0;
    // print(cartList?.productDetail?.smallPrice);
    // if (isVarAvaible) {
    //   if (variations == Variant.small.name) {
    //     totalPrice = cartList!.quantity *
    //         double.parse(cartList?.productDetail?.smallPrice ?? '0.0');
    //   } else if (variations == Variant.medium.name) {
    //     totalPrice = cartList!.quantity *
    //         double.parse(cartList?.productDetail?.mediumPrice ?? '0.0');
    //   } else if (variations == Variant.large.name) {
    //     totalPrice = cartList!.quantity *
    //         double.parse(cartList?.productDetail?.largePrice ?? '0.0');
    //   }
    // } else {
    //   totalPrice = cartList!.quantity *
    //       double.parse(cartList?.productDetail?.productPrice ?? '0.0');
    // }

    // return totalPrice;
    return 0.0;
  }

  @override
  Widget build(BuildContext context) {
    double totalPrice = cartList!.quantity *
        double.parse(cartList?.grandTotal.toString() ?? '0.0');

    // getPriceWithVariations();

    // print("${index}  ${totalPrice}");

    return Stack(
      children: [
        GestureDetector(
          onTap: () {
            // Navigate to product detail if necessary
          },
          child: Container(
            width: Get.width,
            padding:
                const EdgeInsets.symmetric(horizontal: 12.0, vertical: 16.0),
            margin: const EdgeInsets.symmetric(vertical: 8.0),
            decoration: BoxDecoration(
                color: Color(0xFFF6F6F6),
                borderRadius: BorderRadius.circular(15),
                border: Border.all(
                  color: Colors.grey,
                )
                // boxShadow: [
                //   BoxShadow(
                //     color: Colors.grey.withOpacity(0.4),
                //     spreadRadius: 1,
                //     blurRadius: 5,
                //     offset: const Offset(0, 3),
                //   ),
                // ],
                ),
            child: Column(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Product Image
                    Container(
                      height: 100.h,
                      width: 100.w,
                      decoration: BoxDecoration(
                        color: AppColors.RED_GMAIL_COLOR,
                        borderRadius: BorderRadius.circular(15),
                        image: DecorationImage(
                          image: NetworkImage(
                            cartList!.productDetail!.imageUrl.isNotEmpty
                                ? cartList!.productDetail!.imageUrl[0]
                                : AssetPaths.USER_IMAGE,
                          ),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    // Product Details
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Product Name
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                width: 120.w,
                                child: Text(
                                  context.locale.languageCode == 'es'
                                      ? cartList!.productDetail?.nameSp ?? ''
                                      : cartList!.productDetail?.nameEn ?? '',
                                  style: TextStyle(
                                    fontSize: 14.sp,
                                    fontWeight: FontWeight.bold, 
                                    color: Colors.red,
                                  ),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis, 
                                ),
                              ),
                              GestureDetector(
                                onTap: () {
                                  ClearProductFromCartBloc()
                                      .clearProductFromCartBlocMethod(
                                    context: context,
                                    cart_id: cartList!.id.toString(),
                                    setProgressBar: () {
                                      AppDialogs.progressAlertDialog(
                                          context: context);
                                    },
                                  );
                                },
                                child: Container(
                                  height: 25.h,
                                  width: 25.w,
                                  decoration: BoxDecoration(
                                    border: Border.all(color: Colors.red),
                                    borderRadius: BorderRadius.circular(30.r),
                                  ),
                                  child: Center(
                                    child: Icon(
                                      Icons.delete,
                                      color: AppColors.RED_GMAIL_COLOR,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 5,
                          ),

                          if (cartList?.productVariation != null &&
                              cartList?.productVariation != "") ...[
                            Text(
                              tr("variations_text"),
                              style: TextStyle(
                                fontSize: 12.sp,
                                fontWeight: FontWeight.bold,
                                color: AppColors.GREY_COLOR,
                              ),
                            ),
                            2.verticalSpace,
                            Text(
                              cartList!.productVariation.toString(),
                              style: TextStyle(
                                fontSize: 12.sp,
                                fontWeight: FontWeight.bold,
                                color: AppColors.PRIMARY_COLOR,
                              ),
                            ),
                            const SizedBox(height: 10),
                          ],

                          // Addons Text
                          if (cartList?.addonDetails != null &&
                              cartList!.addonDetails!.isNotEmpty)
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  tr("addons"),
                                  style: TextStyle(
                                    fontSize: 12.sp,
                                    fontWeight: FontWeight.bold,
                                    color: AppColors.GREY_COLOR,
                                  ),
                                ),
                                const SizedBox(height: 5),
                                Wrap(
                                  spacing: 8.0,
                                  runSpacing: 4.0,
                                  children: List.generate(
                                      cartList?.addonDetails?.length ?? 0,
                                      (index) {
                                    final parentAddon = cartList
                                        ?.productDetail?.productAddons
                                        .where((element) =>
                                            element.addonId ==
                                            cartList
                                                ?.addonDetails?[index].addonsId)
                                        .firstOrNull;
                                    double addonPrice = 0.0;
                                    if (parentAddon != null) {
                                      final chaild = parentAddon.addonItems
                                          ?.where((element) =>
                                              element.itemId ==
                                              cartList?.addonDetails?[index].id)
                                          .firstOrNull;

                                      if (chaild != null) {
                                        addonPrice = double.parse(
                                            chaild.itemPrice.toString());
                                      }
                                    }
                                    return Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 8.0, vertical: 4.0),
                                      decoration: BoxDecoration(
                                        color: AppColors.PRIMARY_COLOR
                                            .withOpacity(0.1),
                                        borderRadius: BorderRadius.circular(5),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Text(
                                            cartList?.addonDetails![index]
                                                    .name ??
                                                "",
                                            style: TextStyle(
                                              fontSize: 12.sp,
                                              color: AppColors.PRIMARY_COLOR,
                                            ),
                                          ),
                                          // 5.verticalSpace,
                                          Text(
                                            " " +
                                                "\$" +
                                                addonPrice.toStringAsFixed(1),
                                            style: TextStyle(
                                              fontSize: 12.sp,
                                              color: AppColors.PRIMARY_COLOR,
                                            ),
                                          ),
                                        ],
                                      ),
                                    );
                                  }),
                                ),
                                const SizedBox(height: 16),
                              ],
                            ),

                          // Price Text
                        ],
                      ),
                    ),
                  ],
                ),
                15.verticalSpace,
                _quantity(totalPrice, totalPrice),
              ],
            ),
          ),
        ),
      ],
    );
  }

  //  IconButton(
  //         onPressed: () {
  //           ClearProductFromCartBloc().clearProductFromCartBlocMethod(
  //             context: context,
  //             cart_id: cartList!.id.toString(),
  //             setProgressBar: () {
  //               AppDialogs.progressAlertDialog(context: context);
  //             },
  //           );
  //         },
  //         icon: Icon(
  //           Icons.delete,
  //           color: AppColors.RED_GMAIL_COLOR,
  //         ),
  //       ),

  _quantity(double quanity, double totalPrice) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        // Quantity Controls
        // 0.horizontalSpace,
        Padding(
          padding: const EdgeInsets.only(left: 5.0),
          child: Text(
            tr("total_text") + ": " + "\$${totalPrice}",
            style: TextStyle(
              fontSize: 13.sp,
              fontWeight: FontWeight.normal,
              color: AppColors.PRIMARY_COLOR,
            ),
          ),
        ),
        // Inserting a Horizontal Divider (line)
        Expanded( 
          child: Container(
            margin: EdgeInsets.symmetric(horizontal: 10.0),
            height: 1.0, 
            color: Colors.grey[300],
          ),
        ),
        10.horizontalSpace,
        Container(
          padding: EdgeInsets.symmetric(horizontal: 5.w),
          decoration: BoxDecoration(
            color: Color(0xFFF6F6F6),
            borderRadius: BorderRadius.circular(10.r),
            border: Border.all(color: Colors.grey),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Decrement Button
              GestureDetector(
                onTap: () {
                  if (cartList!.quantity > 1) {
                    AddToCartBloc().addToCartBlocMethod(
                      context: context,
                      cart_id: cartList!.id.toString(),
                      product_id: cartList!.productId.toString(),
                      addons: [],
                      quantity: cartList!.quantity! - 1,
                      message: cartList!.message,
                      isFromDetailScreen: false,
                      setProgressBar: () {
                        AppDialogs.progressAlertDialog(context: context);
                      },
                    );
                    CartController.i.decrementCartItemQuantity(index);
                  }
                },
                child: Container(
                  padding: const EdgeInsets.all(8.0),
                  child: Icon(
                    Icons.remove,
                    size: 20.sp,
                    color: Colors.grey,
                  ),
                ),
              ),

              // Vertical Divider after remove icon
              IntrinsicHeight(
                child: VerticalDivider(
                  color: Colors.grey, // Divider color
                  thickness: 1, // Divider thickness
                  width: 10, // Space between the icon and the divider
                ),
              ),

              // Quantity Text
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: Text(
                  cartList!.quantity.toString(),
                  style: TextStyle(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.bold,
                    color: AppColors.BLACK_COLOR,
                  ),
                ),
              ),

              // Vertical Divider before add icon
              IntrinsicHeight(
                child: VerticalDivider(
                  color: Colors.grey, // Divider color
                  thickness: 1, // Divider thickness
                  width: 10, // Space between the quantity text and the divider
                ),
              ),

              // Increment Button
              GestureDetector(
                onTap: () {
                  AddToCartBloc().addToCartBlocMethod(
                    context: context,
                    product_id: cartList?.productId.toString(),
                    addons: [],
                    cart_id: cartList?.id.toString(),
                    quantity: cartList!.quantity! + 1,
                    message: cartList?.message,
                    isFromDetailScreen: false,
                    setProgressBar: () {
                      AppDialogs.progressAlertDialog(context: context);
                    },
                  );
                  CartController.i.incrementCartItemQuantity(index);
                },
                child: Container(
                  padding: const EdgeInsets.all(8.0),
                  child: Icon(
                    Icons.add,
                    size: 20.sp,
                    color: Colors.grey,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
