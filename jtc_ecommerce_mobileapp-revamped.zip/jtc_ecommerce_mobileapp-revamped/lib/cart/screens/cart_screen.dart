// import 'package:easy_localization/easy_localization.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:get/get.dart';
// import 'package:jtc_ecommerce/bottom_navigation/controllers/bottom_navigation_controller.dart';
// import 'package:jtc_ecommerce/cart/blocs/add_to_cart_bloc.dart';
// import 'package:jtc_ecommerce/cart/blocs/clear_cart_bloc.dart';
// import 'package:jtc_ecommerce/cart/blocs/clear_product_from_cart_bloc.dart';
// import 'package:jtc_ecommerce/cart/controllers/cart_controller.dart';
// import 'package:jtc_ecommerce/cart/models/view_cart_model.dart';
// import 'package:jtc_ecommerce/gloabl_widgets/custom_app_bar.dart';
// import 'package:jtc_ecommerce/gloabl_widgets/custom_button.dart';
// import 'package:jtc_ecommerce/gloabl_widgets/custom_extended_image.dart';
// import 'package:jtc_ecommerce/gloabl_widgets/custom_text.dart';
// import 'package:jtc_ecommerce/gloabl_widgets/no_data_found.dart';
// import 'package:jtc_ecommerce/home/models/single_product_model.dart';
// import 'package:jtc_ecommerce/services/app_logger.dart';
// import 'package:jtc_ecommerce/utils/app_colors.dart';
// import 'package:jtc_ecommerce/utils/app_dialogs.dart';
// import 'package:jtc_ecommerce/utils/app_fonts.dart';
// import 'package:jtc_ecommerce/utils/app_navigation.dart';
// import 'package:jtc_ecommerce/utils/app_routes_name.dart';
// import 'package:jtc_ecommerce/utils/assets_paths.dart';

// class CartScreen extends StatefulWidget {
//   CartScreen({super.key});

//   @override
//   State<CartScreen> createState() => _CartScreenState();
// }

// class _CartScreenState extends State<CartScreen> {
//   late CartController controller;

//   @override
//   void initState() {
//     super.initState();
//     controller = Get.find<CartController>();
//     controller.get_cart_list();
//   }

//   @override
//   Widget build(BuildContext context) {
//     // return Scaffold();
//     return Scaffold(
//       appBar:

//           // appBarNormal(
//           //   titleText: "Cart",
//           //   onTap_back: () => AppNavigation.navigatorPop(context),
//           // ),
//           appBarNormalCart(
//               titleText:
//                   // "Cart",
//                   tr('cart_text'),
//               onTap_back: () => AppNavigation.navigatorPop(context),
//               onTap_cart: () {
//                 logData(message: "clear cart onpressed");
//                 ClearCartBloc().clearCartBlocMethod(
//                   context: context,
//                   setProgressBar: () {
//                     AppDialogs.progressAlertDialog(context: context);
//                     // controller.get_cart_list();
//                   },
//                   onCartCleared: () {
//                     // Update UI after cart is cleared
//                     controller.cart_list.clear();
//                   },
//                 );
//               }),
//       body: SingleChildScrollView(
//         child: Column(
//           children: [
//             // GestureDetector(
//             //   onTap: () {
//             //     logData(message: "clear cart onpressed");
//             //     ClearCartBloc().clearCartBlocMethod(
//             //       context: context,
//             //       setProgressBar: () {
//             //         AppDialogs.progressAlertDialog(context: context);
//             //         controller.get_cart_list();
//             //       },
//             //       onCartCleared: () {
//             //         // Update UI after cart is cleared
//             //         controller.cart_list.clear();
//             //       },
//             //     );
//             //   },
//             //   child: Container(
//             //     height: 50,
//             //     child: Row(
//             //       mainAxisAlignment: MainAxisAlignment.end,
//             //       children: [
//             //         // Text("clear Cart")
//             //         // Icon(
//             //         //   Icons.delete,
//             //         //   color: Colors.red,
//             //         // )
//             //       ],
//             //     ),
//             //   ),
//             // ),
//             //Header Total
//             Obx(
//               () => controller.isLoading.value
//                   ?

//                   // SizedBox()
//                   Container(
//                       height: 55.h,
//                       width: Get.width,
//                       decoration: BoxDecoration(
//                         color: Colors.black.withOpacity(0.7),
//                       ),
//                       child: Padding(
//                         padding: const EdgeInsets.symmetric(horizontal: 20.0),
//                         child: Row(
//                           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                           children: [
//                             // CustomText(
//                             //   text: "Total".toUpperCase(),
//                             //   isLeftAlign: true,
//                             //   fontsize: 18.sp,
//                             //   fontFamily: AppFonts.robotoMedium,
//                             // ),
//                             // CustomText(
//                             //   // text: "\$36.00".toUpperCase(),
//                             //   text:
//                             //       "\$${(controller.viewCartModel.value?.total ?? 0.0).toStringAsFixed(4)}"
//                             //           .toUpperCase(),
//                             //   isLeftAlign: true,
//                             //   fontsize: 18.sp,
//                             //   fontFamily: AppFonts.robotoMedium,
//                             // ),
//                           ],
//                         ),
//                       ),
//                     )
//                   : Container(
//                       height: 55.h,
//                       width: Get.width,
//                       decoration: BoxDecoration(
//                         color: Colors.black.withOpacity(0.7),
//                       ),
//                       child: Padding(
//                         padding: const EdgeInsets.symmetric(horizontal: 20.0),
//                         child: Row(
//                           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                           children: [
//                             CustomText(
//                               text: "Total".toUpperCase(),
//                               isLeftAlign: true,
//                               fontsize: 18.sp,
//                               fontFamily: AppFonts.robotoMedium,
//                             ),
//                             Obx(
//                               () => CustomText(
//                                 // text: "\$36.00".toUpperCase(),
//                                 text:
//                                     "\$${controller.totalPriceWihtoutTax().toStringAsFixed(2)}",
//                                 // "\$${(controller.viewCartModel.value?.total ?? 0.0).toStringAsFixed(4)}"
//                                 //     .toUpperCase(),
//                                 isLeftAlign: true,
//                                 fontsize: 18.sp,
//                                 fontFamily: AppFonts.robotoMedium,
//                               ),
//                             ),
//                           ],
//                         ),
//                       ),
//                     ),
//             ),
//             20.verticalSpace,
//             // Obx(
//             //   () => _buildCartItemsList(),
//             // ),
//             _buildCartItemsList(),
//             80.verticalSpace,
//             Obx(
//               () => controller.isLoading.value || controller.cart_list.isEmpty
//                   ?

//                   //  SizedBox()
//                   Padding(
//                       padding: EdgeInsets.symmetric(horizontal: 80.0.w),
//                       child: CustomButton(
//                         height: 55.h,
//                         buttonColor: AppColors.PRIMARY_COLOR,
//                         onTap: () {
//                           // AppNavigation.navigatorPop(context);
//                           AppNavigation.navigateReplacementNamed(
//                             context,
//                             AppRouteName.BOTTOM_NAVIGATION_SCREEN_ROUTE,
//                           );
//                         },
//                         buttonText:
//                             // "ADD MORE",
//                             tr('addmore_text'),
//                         borderRadius: 10,
//                         withBorderOnly: true,
//                         textColor: AppColors.PRIMARY_COLOR,
//                         fontSize: 14.sp,
//                       ),
//                     )
//                   : Padding(
//                       padding: EdgeInsets.symmetric(horizontal: 80.0.w),
//                       child: CustomButton(
//                         height: 55.h,
//                         buttonColor: AppColors.PRIMARY_COLOR,
//                         onTap: () {
//                           var controller =
//                               Get.find<BottomNavgationController>();
//                           controller.changePage(0);
//                           AppNavigation.navigateTo(
//                             context,
//                             AppRouteName.BOTTOM_NAVIGATION_SCREEN_ROUTE,
//                           );
//                         },
//                         buttonText: tr('addmore_text'),
//                         // "ADD MORE",
//                         borderRadius: 10,
//                         withBorderOnly: true,
//                         textColor: AppColors.PRIMARY_COLOR,
//                         fontSize: 14.sp,
//                       ),
//                     ),
//             ),
//             20.verticalSpace,
//             Obx(
//               () => controller.isLoading.value || controller.cart_list.isEmpty
//                   ? Padding(
//                       padding: EdgeInsets.symmetric(horizontal: 80.0.w),
//                       child: CustomButton(
//                         height: 55.h,
//                         buttonColor: AppColors.PRIMARY_COLOR,
//                         onTap: () {
//                           // _showModalBottomSheet(context);
//                         },
//                         buttonText:

//                             // "CHECKOUT",
//                             tr('checkout_text'),
//                         borderRadius: 10,
//                         fontSize: 14.sp,
//                       ),
//                     )
//                   : Padding(
//                       padding: EdgeInsets.symmetric(horizontal: 80.0.w),
//                       child: CustomButton(
//                         height: 55.h,
//                         buttonColor: AppColors.PRIMARY_COLOR,
//                         onTap: () {
//                           // _showModalBottomSheet(context);

//                           AppNavigation.navigateTo(
//                             context,
//                             AppRouteName.ORDER_SUMMARY_SCREEN_ROUTE,
//                             arguments: {
//                               "ViewCartData": controller.viewCartModel.value,
//                               "totalPrice": controller.totalPrice,
//                             },
//                           );
//                         },
//                         buttonText:
//                             // "CHECKOUT",
//                             tr('checkout_text'),
//                         borderRadius: 10,
//                         fontSize: 14.sp,
//                       ),
//                     ),
//             ),
//             40.verticalSpace,
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _buildCartItemsList() {
//     return Obx(
//       () => !controller.isLoading.value && controller.cart_list.isEmpty
//           ? SizedBox(
//               height: Get.height,
//               width: Get.width,
//               child: SingleChildScrollView(
//                 physics: AlwaysScrollableScrollPhysics(
//                   parent: BouncingScrollPhysics(),
//                 ),
//                 child: Container(
//                   height: Get.height / 1.5,
//                   alignment: Alignment.center,
//                   child: NoDataPage(
//                     text:

//                         // "Cart is empty",
//                         tr('emptycart_text'),
//                   ),
//                 ),
//               ),
//             )
//           : Container(
//               child: ListView.builder(
//                 scrollDirection: Axis.vertical,
//                 shrinkWrap: true,
//                 physics: NeverScrollableScrollPhysics(),
//                 // physics: AlwaysScrollableScrollPhysics(
//                 //   parent: BouncingScrollPhysics(),
//                 // ),
//                 controller: controller.scrollController,
//                 itemCount: controller.cart_list.length +
//                     (controller.isLoading.value ? 1 : 0),
//                 itemBuilder: (context, index) {
//                   if (index < controller.cart_list.length) {
//                     return GetBuilder<CartController>(
//                       builder: (cartController) {
//                         return cart_card(
//                             cartList: cartController.cart_list[index],
//                             context: context,
//                             index: index);
//                       },
//                     );
//                   }

//                   //  else {
//                   //   if (controller.isLoading.value) {
//                   //     // Show shimmer loading indicator
//                   //     return Row(
//                   //       children: List.generate(4, (index) {
//                   //         return CustomShimmer(
//                   //           shimmerType: ShimmerType.food_category_skeleton,
//                   //         );
//                   //       }),
//                   //     );
//                   //   }

//                   //   else {
//                   //     // Show an empty container when not loading to maintain the correct item count
//                   //     return Container();
//                   //   }
//                   // }
//                 },
//               ),
//             ),
//     );
//   }

//   void _showModalBottomSheet(BuildContext context) {
//     showModalBottomSheet(
//       backgroundColor: Colors.transparent,
//       context: context,
//       builder: (BuildContext context) {
//         return Container(
//           // height: Get.height / 3,
//           decoration: BoxDecoration(
//             borderRadius: BorderRadius.only(
//               topLeft: Radius.circular(15),
//               topRight: Radius.circular(15),
//             ),
//             color: Colors.white,
//           ),
//           child: Padding(
//             padding: EdgeInsets.symmetric(horizontal: 24.0.w, vertical: 20.0.h),
//             child: Column(
//               mainAxisSize: MainAxisSize.min,
//               children: <Widget>[
//                 CustomText(
//                   text:
//                       //  "Price Detail",

//                       tr('pricedetail_text'),
//                   color: AppColors.BLACK_COLOR,
//                   isLeftAlign: true,
//                   fontFamily: AppFonts.robotoMedium,
//                 ),
//                 10.verticalSpace,
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                   children: [
//                     CustomText(
//                       text: tr('order_total_text'),

//                       //  "Order Total",
//                       color: AppColors.BLACK_COLOR,
//                       isLeftAlign: true,
//                       fontFamily: AppFonts.robotoligth,
//                       fontsize: 16.sp,
//                     ),
//                     CustomText(
//                       // text: "\$36.00",
//                       text:
//                           "\$${(controller.viewCartModel.value?.subtotal ?? 0.0).toStringAsFixed(3)}"
//                               .toUpperCase(),
//                       color: AppColors.BLACK_COLOR,
//                       isLeftAlign: true,
//                       fontFamily: AppFonts.robotoRegular,
//                       fontsize: 16.sp,
//                     ),
//                   ],
//                 ),
//                 10.verticalSpace,
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                   children: [
//                     CustomText(
//                       text:
//                           // "Tax",
//                           tr('tax_text'),
//                       color: AppColors.BLACK_COLOR,
//                       isLeftAlign: true,
//                       fontFamily: AppFonts.robotoligth,
//                       fontsize: 16.sp,
//                     ),
//                     // CustomText(
//                     //   text:
//                     //       "\$${(controller.viewCartModel.value?.tax ?? 0.0).toStringAsFixed(3)}"
//                     //           .toUpperCase(),
//                     //   color: AppColors.PRIMARY_COLOR,
//                     //   isLeftAlign: true,
//                     //   fontFamily: AppFonts.robotoRegular,
//                     //   fontsize: 16.sp,
//                     // ),

//                     CustomText(
//                       text:
//                           "\$${(controller.viewCartModel.value?.tax ?? 0.0).toInt().toString()}"
//                               .toUpperCase(),
//                       color: AppColors.PRIMARY_COLOR,
//                       isLeftAlign: true,
//                       fontFamily: AppFonts.robotoRegular,
//                       fontsize: 16.sp,
//                     ),
//                   ],
//                 ),
//                 // Row(
//                 //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 //   children: [
//                 //     CustomText(
//                 //       text: "Delivery Charges",
//                 //       color: AppColors.BLACK_COLOR,
//                 //       isLeftAlign: true,
//                 //       fontFamily: AppFonts.robotoligth,
//                 //       fontsize: 16.sp,
//                 //     ),
//                 //     CustomText(
//                 //       text: "\$${controller.viewCartModel.value?.delivery}"
//                 //           .toUpperCase(),
//                 //       color: AppColors.PRIMARY_COLOR,
//                 //       isLeftAlign: true,
//                 //       fontFamily: AppFonts.robotoRegular,
//                 //       fontsize: 16.sp,
//                 //     ),
//                 //   ],
//                 // ),

//                 10.verticalSpace,
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                   children: [
//                     CustomText(
//                       text: "Grand Total",
//                       color: AppColors.BLACK_COLOR,
//                       isLeftAlign: true,
//                       fontFamily: AppFonts.robotoMedium,
//                       fontsize: 16.sp,
//                     ),
//                     CustomText(
//                       // text: "\$36.00",
//                       text:
//                           "\$${(controller.viewCartModel.value?.subtotal ?? 0.0 + (controller.viewCartModel.value?.tax ?? 0.0)).toStringAsFixed(3)}"
//                               .toUpperCase(),
//                       color: AppColors.BLACK_COLOR,
//                       isLeftAlign: true,
//                       fontFamily: AppFonts.robotoMedium,
//                       fontsize: 16.sp,
//                     ),
//                   ],
//                 ),
//                 20.verticalSpace,
//                 Padding(
//                   padding: EdgeInsets.symmetric(horizontal: 40.0.w),
//                   child: CustomButton(
//                     buttonColor: AppColors.PRIMARY_COLOR,
//                     onTap: () {
//                       AppNavigation.navigateTo(
//                         context,
//                         AppRouteName.ORDER_SUMMARY_SCREEN_ROUTE,
//                         arguments: {
//                           "ViewCartData": controller.viewCartModel.value,
//                           "totalPrice": controller.totalPrice,
//                         },
//                       );
//                     },
//                     buttonText: "PROCEED TO CHECKOUT",
//                     fontSize: 13.sp,
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         );
//       },
//     );
//   }

//   Widget cart_card({
//     required CartList? cartList,
//     required BuildContext context,
//     required int index,
//   }) {
//     double totalPrice =
//         cartList!.quantity * double.parse(cartList.productDetail.productPrice);
//     return GestureDetector(
//       onTap: () {
//         // logData(message: "product_id: ${cartList?.productId}");
//         // AppNavigation.navigateTo(
//         //   context,
//         //   AppRouteName.PRODUCT_DETAIL_SCREEN_ROUTE,
//         //   arguments: {
//         //     "product_id": cartList?.productId.toString(),
//         //   },
//         // );
//       },
//       child: Container(
//         width: Get.width,
//         child: Padding(
//           padding: const EdgeInsets.only(left: 10.0, right: 30.0, top: 25.0),
//           child: Row(
//             // crossAxisAlignment: CrossAxisAlignment.center,
//             // mainAxisAlignment: MainAxisAlignment.start,
//             children: [
//               Container(
//                 height: 80.h,
//                 width: 130.w,
//                 decoration: BoxDecoration(
//                     color: Colors.redAccent,
//                     borderRadius: BorderRadius.circular(15)),
//                 child: ClipRRect(
//                   borderRadius: BorderRadius.circular(15),
//                   // child: Image.asset(
//                   //   "assets/images/sandwich.png",
//                   //   fit: BoxFit.cover,
//                   // ),
//                   child: CustomExtendedImageWidget(
//                     imagePath: cartList.productDetail.imageUrl.isNotEmpty
//                         ? cartList.productDetail.imageUrl[0]
//                         : null,
//                     imageType: "network",
//                     fit: BoxFit.cover,
//                     imagePlaceholder: AssetPaths.USER_IMAGE,
//                   ),
//                 ),
//               ),
//               10.horizontalSpace,
//               Expanded(
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Align(
//                       // alignment: Alignment.topLeft,
//                       child: CustomText(
//                         maxLines: 2,
//                         text:

//                             // cartList.productDetail.name.toUpperCase(),
//                             context.locale.languageCode == 'es'
//                                 ? cartList.productDetail.nameSp ?? ''
//                                 : cartList.productDetail.nameEn ?? '',
//                         color: AppColors.BLACK_COLOR,
//                         isLeftAlign: true,
//                         fontsize: 16.sp,
//                       ),
//                     ),
//                     10.verticalSpace,
//                     Row(
//                       mainAxisAlignment: MainAxisAlignment.start,
//                       children: [
//                         GestureDetector(
//                           onTap: () {
//                             logData(message: "decrement quantity");
//                             logData(message: cartList.quantity.toString());
//                             if (cartList.quantity > 1) {
//                               AddToCartBloc().addToCartBlocMethod(
//                                 context: context,
//                                 cart_id: cartList.id.toString(),
//                                 product_id: cartList!.productId.toString(),
//                                 addons: [],
//                                 // transformAddonData(
//                                 //     cartList!.productDetail.productAddons),
//                                 quantity: cartList.quantity - 1,
//                                 message: cartList.message,
//                                 isFromDetailScreen: false,
//                                 setProgressBar: () {
//                                   AppDialogs.progressAlertDialog(
//                                       context: context);
//                                 },
//                               );

//                               controller.decrementCartItemQuantity(index);
//                             } else {
//                               print("Quantity is ONE");
//                             }
//                           },
//                           child: Container(
//                             width: 20.w,
//                             decoration: BoxDecoration(
//                               color: Colors.grey[300],
//                             ),
//                             child: Icon(
//                               Icons.remove,
//                               size: 20.sp,
//                             ),
//                           ),
//                         ),
//                         15.horizontalSpace,
//                         CustomText(
//                           // text: "01".toUpperCase(),
//                           text: cartList.quantity.toString(),
//                           color: AppColors.BLACK_COLOR,
//                           fontsize: 16.sp,
//                         ),
//                         15.horizontalSpace,
//                         GestureDetector(
//                           onTap: () {
//                             logData(message: "increment quantity");
//                             logData(message: cartList.quantity.toString());

//                             AddToCartBloc().addToCartBlocMethod(
//                               context: context,
//                               product_id: cartList.productId.toString(),
//                               addons: [],
//                               cart_id: cartList!.id.toString(),
//                               //  transformAddonData(
//                               //     cartList.productDetail.productAddons),
//                               quantity: cartList.quantity + 1,
//                               // quantity: cartList?.quantity.toString(),
//                               message: cartList.message,
//                               isFromDetailScreen: false,
//                               setProgressBar: () {
//                                 AppDialogs.progressAlertDialog(
//                                     context: context);
//                               },
//                             );
//                             // controller.incrementCartItemQuantity(index);
//                           },
//                           child: Container(
//                             width: 20.w,
//                             decoration: BoxDecoration(
//                               color: Colors.grey[300],
//                             ),
//                             child: Icon(
//                               Icons.add,
//                               size: 20.sp,
//                             ),
//                           ),
//                         ),
//                       ],
//                     ),
//                   ],
//                 ),
//               ),
//               // Spacer(),
//               Column(
//                 crossAxisAlignment: CrossAxisAlignment.end,
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 children: [
//                   // // Icon(Icons.more),
//                   // Image.asset(
//                   //   "assets/icons/seekh_kbab_icon.png",
//                   //   height: 15.h,
//                   //   color: Colors.grey[500],
//                   // ),

//                   PopupMenuButton(
//                     itemBuilder: (BuildContext context) => [
//                       PopupMenuItem(
//                         onTap: () {
//                           logData(message: "clear product from cart onpressed");
//                           ClearProductFromCartBloc()
//                               .clearProductFromCartBlocMethod(
//                             context: context,
//                             cart_id: cartList.id.toString(),
//                             setProgressBar: () {
//                               AppDialogs.progressAlertDialog(context: context);
//                               // controller.get_cart_list();
//                             },
//                           );
//                           // controller.get_cart_list();
//                         },
//                         child: Text(
//                           // "Delete"
//                           tr('delete_product_text'),
//                         ),
//                       ),
//                       // PopupMenuItem(
//                       //   child:

//                       //   GestureDetector(
//                       //     onTap: () {
//                       //       // Call delete API here

//                       //       logData(
//                       //           message: "clear product from cart onpressed");
//                       //       ClearProductFromCartBloc()
//                       //           .clearProductFromCartBlocMethod(
//                       //         context: context,
//                       //         cart_id: cartList!.id.toString(),
//                       //         setProgressBar: () {
//                       //           AppDialogs.progressAlertDialog(
//                       //               context: context);
//                       //           // controller.get_cart_list();
//                       //         },
//                       //       );
//                       //       Navigator.pop(context);
//                       //     },
//                       //     child: Text("Delete"),
//                       //   ),
//                       // ),
//                       // PopupMenuItem(
//                       //   child: GestureDetector(
//                       //     onTap: () {
//                       //       Navigator.pop(context);
//                       //     },
//                       //     child: Text(
//                       //       // "Cancel"
//                       //       tr('cancel_product_text'),
//                       //     ),
//                       //   ),
//                       // ),
//                     ],
//                     child: Image.asset(
//                       "assets/icons/seekh_kbab_icon.png",
//                       height: 15.h,
//                       width: 20,
//                       color: Colors.grey[500],
//                     ),
//                   ),

//                   20.verticalSpace,
//                   CustomText(
//                     // text: "\$09.00",
//                     // text: "\$${cartList?.productDetail.productPrice}",
//                     text: "\$${totalPrice.toStringAsFixed(3)}",
//                     color: AppColors.BLACK_COLOR,
//                     fontsize: 14.sp,
//                   )
//                 ],
//               )
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   List<Map<String, dynamic>> transformAddonData(
//       List<ProductAddons> productAddons) {
//     return productAddons
//         .map((addon) => ({
//               'addon_id': addon.addonId,
//               'addon_items_id':
//                   addon.addonItems!.map((item) => item.itemId).toList(),
//             }))
//         .toList();
//   }
// }

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/bottom_navigation/controllers/bottom_navigation_controller.dart';
import 'package:jtc_ecommerce/cart/blocs/add_to_cart_bloc.dart';
import 'package:jtc_ecommerce/cart/blocs/clear_cart_bloc.dart';
import 'package:jtc_ecommerce/cart/blocs/clear_product_from_cart_bloc.dart';
import 'package:jtc_ecommerce/cart/controllers/cart_controller.dart';
import 'package:jtc_ecommerce/cart/screens/components/cart_card.dart';
import 'package:jtc_ecommerce/widgets/custom_app_bar.dart';
import 'package:jtc_ecommerce/widgets/custom_button.dart';
import 'package:jtc_ecommerce/widgets/custom_extended_image.dart';
import 'package:jtc_ecommerce/widgets/custom_scaffold.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/widgets/no_data_found.dart';
import 'package:jtc_ecommerce/order_summary/controllers/order_summary_controller.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_fonts.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';
import 'package:jtc_ecommerce/wallet/models/cart_model.dart';
import 'package:shimmer/shimmer.dart';

class CartScreen extends StatefulWidget {
  CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  late CartController controller;

  @override
  void initState() {
    super.initState();
    controller = Get.find<CartController>();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.get_cart_list();
    });
  }

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      appBarTitle: tr('cart_text'),
      onTap: () => AppNavigation.navigatorPop(context),
      isFavoriteIcon: true,
      child2: GestureDetector(
        onTap : () {
          logData(message: "clear cart onpressed");
          ClearCartBloc().clearCartBlocMethod(
            context: context,
            setProgressBar: () {
              AppDialogs.progressAlertDialog(context: context);
            },
            onCartCleared: () {
              controller.cart_list.clear();
            },
          );
        },
        child: Icon(Icons.delete,color: Colors.white,),
      ),
      // appBar: appBarNormalCart(
      //   titleText: 
      //   onTap_back: 
      //   onTap_cart: () {
      //     logData(message: "clear cart onpressed");
      //     ClearCartBloc().clearCartBlocMethod(
      //       context: context,
      //       setProgressBar: () {
      //         AppDialogs.progressAlertDialog(context: context);
      //       },
      //       onCartCleared: () {
      //         controller.cart_list.clear();
      //       },
      //     );
      //   },
      // ),
      // backgroundColor: Colors.white,
      child: Obx(
        () => controller.isLoading.value
            ? Center(child: _buildShimmerLoading())
            : controller.cart_list.isEmpty
                ? NoDataPage(text: tr('emptycart_text'))
                : SingleChildScrollView(
                    child: Column(
                      children: [
                        _buildTotalHeader(),
                        20.verticalSpace,
                        _buildCartItemsList(),
                        80.verticalSpace,
                        _buildAddMoreButton(),
                        20.verticalSpace,
                        _buildCheckoutButton(),
                        40.verticalSpace,
                      ],
                    ),
                  ),
      ),
    );
  }

  Widget _buildTotalHeader() {
    return Container(
      height: 55.h,
      width: Get.width,
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.7),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            CustomText(
              text: "Total".toUpperCase(),
              isLeftAlign: true,
              fontsize: 18.sp,
              // fontFamily: AppFonts.robotoMedium,
            ),
            Obx(
              () => CustomText(
                text:
                    "\$${controller.totalPriceWihtoutTax().toStringAsFixed(2)}",
                isLeftAlign: true,
                fontsize: 18.sp,
                // fontFamily: AppFonts.robotoMedium,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCartItemsList() {
    return Obx(
      () => controller.cart_list.isEmpty
          ? NoDataPage(text: tr('emptycart_text'))
          : ListView.builder(
              scrollDirection: Axis.vertical,
              shrinkWrap: true,
              padding: EdgeInsets.symmetric(horizontal: 12),
              physics: NeverScrollableScrollPhysics(),
              itemCount: controller.cart_list.length,
              itemBuilder: (context, index) {
                return GetBuilder<CartController>(
                  builder: (cartController) {
                    return CartCard(
                      index: index,
                      cartList: controller.cart_list[index],
                      context: context,
                    );
                  },
                );
              },
            ),
    );
  }

  Widget _buildAddMoreButton() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 20.0.w),
      child: CustomButton(
        height: 60.h,
        buttonColor: Color(0XFF10071D),
        onTap: () {
          var controller = Get.find<BottomNavgationController>();
          controller.changePage(0);
          AppNavigation.navigateTo(
            context,
            AppRouteName.BOTTOM_NAVIGATION_SCREEN_ROUTE,
          );
        },
        buttonText: tr('addmore_text'),
        borderRadius: 10,
        withBorderOnly: false,
        textColor: Colors.white,
        fontSize: 14.sp,
      ),
    );
  }

  Widget _buildCheckoutButton() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 20.0.w),
      child: CustomButton(
        height: 60.h,
        buttonColor: Color(0XFFE0221E),
        onTap: () {
          Get.find<OrderSummaryController>().viewCartModel.value = null;
          AppNavigation.navigateTo(
            context,
            AppRouteName.ORDER_SUMMARY_SCREEN_ROUTE,
            arguments: {
              "ViewCartData": controller.viewCartModel.value,
              "totalPrice": controller.totalPrice,
            },
          );
        },
        buttonText: tr('checkout_text'),
        borderRadius: 10,
        fontSize: 14.sp,
      ),
    );
  }

  Widget cart_card({
    required CartItem? cartList,
    required BuildContext context,
    required int index,
  }) {
    double totalPrice =
        cartList!.quantity * (cartList.productDetail?.productPrice ?? 0.0);
    return GestureDetector(
      onTap: () {
        // Navigate to product detail if necessary
      },
      child: Container(
        width: Get.width,
        padding: const EdgeInsets.only(left: 10.0, right: 30.0, top: 25.0),
        child: Row(
          children: [
            Container(
              height: 80.h,
              width: 130.w,
              decoration: BoxDecoration(
                color: Colors.grey.withOpacity(.3),
                borderRadius: BorderRadius.circular(15),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: CustomExtendedImageWidget(
                  imagePath: cartList.productDetail!.imageUrl.isNotEmpty
                      ? cartList.productDetail!.imageUrl[0]
                      : null,
                  imageType: "network",
                  fit: BoxFit.cover,
                  imagePlaceholder: AssetPaths.USER_IMAGE,
                ),
              ),
            ),
            10.horizontalSpace,
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CustomText(
                    maxLines: 2,
                    text: context.locale.languageCode == 'es'
                        ? cartList.productDetail?.nameSp ?? ''
                        : cartList.productDetail?.nameEn ?? '',
                    color: AppColors.BLACK_COLOR,
                    isLeftAlign: true,
                    fontsize: 16.sp,
                  ),
                  10.verticalSpace,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      GestureDetector(
                        onTap: () {
                          if (cartList.quantity > 1) {
                            AddToCartBloc().addToCartBlocMethod(
                              context: context,
                              cart_id: cartList.id.toString(),
                              product_id: cartList.productId.toString(),
                              addons: [],
                              quantity: cartList.quantity - 1,
                              message: cartList.message,
                              isFromDetailScreen: false,
                              setProgressBar: () {
                                AppDialogs.progressAlertDialog(
                                    context: context);
                              },
                            );
                            controller.decrementCartItemQuantity(index);
                          }
                        },
                        child: Container(
                          width: 20.w,
                          decoration: BoxDecoration(
                            color: Colors.grey[300],
                          ),
                          child: Icon(
                            Icons.remove,
                            size: 20.sp,
                          ),
                        ),
                      ),
                      15.horizontalSpace,
                      CustomText(
                        text: cartList.quantity.toString(),
                        color: AppColors.BLACK_COLOR,
                        fontsize: 16.sp,
                      ),
                      15.horizontalSpace,
                      GestureDetector(
                        onTap: () {
                          AddToCartBloc().addToCartBlocMethod(
                            context: context,
                            product_id: cartList.productId.toString(),
                            addons: [],
                            cart_id: cartList.id.toString(),
                            quantity: cartList.quantity + 1,
                            message: cartList.message,
                            isFromDetailScreen: false,
                            setProgressBar: () {
                              AppDialogs.progressAlertDialog(context: context);
                            },
                          );
                          controller.incrementCartItemQuantity(index);
                        },
                        child: Container(
                          width: 20.w,
                          decoration: BoxDecoration(
                            color: Colors.grey[300],
                          ),
                          child: Icon(
                            Icons.add,
                            size: 20.sp,
                          ),
                        ),
                      ),
                    ],
                  ),
                  5.verticalSpace,
                  CustomText(
                    text: 'Addons',
                    color: AppColors.BLACK_COLOR,
                    isLeftAlign: true,
                    fontsize: 12.sp,
                  ),
                  Wrap(
                    runAlignment: WrapAlignment.spaceAround,
                    children: [
                      ...List.generate(
                        cartList.addonDetails?.length ?? 0,
                        (index) => Container(
                          decoration: BoxDecoration(
                              color: AppColors.PRIMARY_COLOR,
                              borderRadius: BorderRadius.circular(5)),
                          child: Row(
                            children: [
                              CustomText(
                                text: cartList.addonDetails?[index].name,
                                color: AppColors.BLACK_COLOR,
                                fontsize: 11.sp,
                              ),
                            ],
                          ),
                        ),
                      )
                    ],
                  )
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                IconButton(
                  onPressed: () {
                    ClearProductFromCartBloc().clearProductFromCartBlocMethod(
                      context: context,
                      cart_id: cartList.id.toString(),
                      setProgressBar: () {
                        AppDialogs.progressAlertDialog(context: context);
                      },
                      // onProductRemovedFromCart: () {
                      //   controller.cart_list.removeAt(index);
                      // },
                    );
                  },
                  icon: Icon(
                    Icons.delete,
                    color: AppColors.RED_GMAIL_COLOR,
                  ),
                ),
                20.verticalSpace,
                CustomText(
                  text: "\$${totalPrice.toStringAsFixed(2)}",
                  color: AppColors.BLACK_COLOR,
                  isLeftAlign: true,
                  fontsize: 16.sp,
                  fontWeight: FontWeight.w500,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildShimmerLoading() {
    return ListView.builder(
      itemCount: 6,
      itemBuilder: (context, index) {
        return Shimmer.fromColors(
          baseColor: Colors.grey[300]!,
          highlightColor: Colors.grey[100]!,
          child: Container(
            margin: EdgeInsets.symmetric(vertical: 10.h, horizontal: 20.w),
            padding: EdgeInsets.all(10.w),
            height: 120.h,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Row(
              children: [
                // Imagen del producto
                Container(
                  width: 100.w,
                  height: 100.h,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                SizedBox(width: 20.w),
                // Información del producto
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Nombre del producto
                      Container(
                        width: double.infinity,
                        height: 20.h,
                        color: Colors.white,
                      ),
                      SizedBox(height: 10.h),
                      // Cantidad del producto
                      Container(
                        width: 80.w,
                        height: 20.h,
                        color: Colors.white,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
