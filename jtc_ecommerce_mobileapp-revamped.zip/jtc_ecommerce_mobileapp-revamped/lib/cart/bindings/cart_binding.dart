import 'package:get/get.dart';
import 'package:jtc_ecommerce/cart/controllers/cart_controller.dart';

class CartBinding extends Bindings{
  @override
  void dependencies() {
    Get.lazyPut(() => CartController());
  }
}