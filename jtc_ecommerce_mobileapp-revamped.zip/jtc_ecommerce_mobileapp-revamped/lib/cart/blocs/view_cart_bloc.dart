// import 'package:dio/dio.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get_core/src/get_main.dart';
// import 'package:jtc_ecommerce/cart/controllers/cart_controller.dart';
// import 'package:jtc_ecommerce/cart/models/view_cart_model.dart';
// import 'package:jtc_ecommerce/services/app_logger.dart';
// import 'package:jtc_ecommerce/services/network.dart';
// import 'package:jtc_ecommerce/utils/app_network_strings.dart';

// class ViewCartBloc {
//   Map<String, dynamic>? _queryParameters;
//   Response? _response;
//   VoidCallback? _onSuccess;
//   dynamic contentTypeResponse;
//   ViewCartModel? _viewCartModel;

//   ////////////////////////// Terms and Condition And Privacy Policy //////////////////////////////////
//   Future<void> getViewCartBlocMethod({
//     required BuildContext context,
//   }) async {
//     await _getRequest(
//       endPoint: NetworkStrings.VIEW_CART_ENDPOINT,
//       context: context,
//     );

//     _onSuccess = () {
//       contentTypeResponse = _response?.data;
//     };

//     _validateResponse();

//     return contentTypeResponse;
//   }

//   // Get Request
//   Future<void> _getRequest(
//       {required String endPoint, required BuildContext context}) async {
//     _response = await Network().getRequest(
//       context: context,
//       endPoint: endPoint,
//       queryParameters: _queryParameters,
//       isToast: false,
//       customFailure: true,
//       isHeaderRequire: true,
//     );
//   }

//   void _validateResponse() {
//     var controller = Get.find<CartController>();
//     try {
//       _viewCartModel = ViewCartModel.fromJson(_response?.data);
//       controller.viewCartModel.value = _viewCartModel?.data;
//       logData(message: "_getGoalModel: ${_viewCartModel?.data.cart.length}");

//       // Replace the contents of the cart_list with the new data
//       controller.cart_list.clear();
//       controller.cart_list.addAll(_viewCartModel?.data.cart ?? []);

//       logData(message: "cart_list: ${controller.cart_list.length}");

//       Network().validateResponse(
//         response: _response,
//         onSuccess: _onSuccess,
//         isToast: false,
//       );
//     } catch (error, stackTrace) {
//       print("Error in _validateResponse: $error");
//       print("Stack Trace: $stackTrace");
//     }
//   }
// }

import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as GetxController;
import 'package:jtc_ecommerce/auth/controllers/auth_controller.dart';
import 'package:jtc_ecommerce/cart/controllers/cart_controller.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/services/translate_service.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';
import 'package:jtc_ecommerce/wallet/models/cart_model.dart';

import '../models/view_cart_model.dart';

class ViewCartBloc {
  Response? _response;
  VoidCallback? _onSuccess, _onFailure;

  void getViewCartBlocMethod({
    required BuildContext context,
    String? userEmail,
    Function()? onSuccess,
    Function()? failureCallBack,
    required VoidCallback setProgressBar,
    final Map<String, dynamic>? queryParams,
    final bool loader = false,
    String? password,
  }) async {
    setProgressBar();

    _onFailure = () async {
      failureCallBack?.call();
      if (loader) {
        AppNavigation.navigatorPop(context);
      }

      print("STATUSSS CODEE ${_response?.statusCode}");
      // final message = _response?.data['message'] ?? "";

      // print(message);

      // switch (message) {
      //   default:
      //     if (context.locale.languageCode != "en") {
      //       final _translatedMessage = await GoogleTranslatorService()
      //           .translate(text: message, context: context);
      //       AppDialogs.showToast(message: _translatedMessage);
      //     } else {
      //       AppDialogs.showToast(message: message);
      //     }
      // }
    };

    //! ============> Call api
    await _postRequest(
        endPoint: NetworkStrings.VIEW_CART_ENDPOINT,
        context: GetxController.Get.context!,
        queryParams: queryParams);

    //! ============> Get the login response
    _onSuccess = () {
      if (loader) {
        AppNavigation.navigatorPop(context);
      }
      // AppNavigation.navigatorPop(context);
      // GetxController.Get.find<CartController>().isLoading.value = false;

      _loginResponseMethod(context: context, onSuccess: onSuccess);
    };

    //! ============> Validate the response
    _validateResponse();
  }

  //! ============> Post Request
  Future<void> _postRequest({
    required String endPoint,
    required BuildContext context,
    final Map<String, dynamic>? queryParams,
  }) async {
    _response = await Network().getRequest(
        endPoint: endPoint,
        context: context,
        customFailure: true,
        queryParameters: queryParams,
        onFailure: _onFailure,
        isHeaderRequire: true,
        isToast: true,
        isErrorToast: false);
  }

  //! ============> Validate Response
  void _validateResponse() {
    if (_response != null) {
      Network().validateResponse(
        isToast: false,
        response: _response,
        onSuccess: _onSuccess,
        onFailure: _onFailure,
      );
    }
  }

  //! ============> Creating a controller instance to save the user id
  //temp for next verification otp api
  var authContorller = GetxController.Get.find<AuthController>();

  //! ============> Login Response
  void _loginResponseMethod({
    required BuildContext context,
    Function()? onSuccess,
  }) async {
    // try {

    var controller = GetxController.Get.find<CartController>();

    final _cart = CartModel.fromJson(_response?.data);
    controller.viewCartModel.value = _cart.data;
    logData(message: "_getGoalModel: ${_cart.data?.cart?.length}");

    // Replace the contents of the cart_list with the new data
    controller.cart_list.clear();
    controller.cart_list.addAll(_cart.data?.cart ?? []);

    onSuccess?.call();
    // } catch (error) {
    //   AppDialogs.showToast(message: tr(NetworkStrings.SOMETHING_WENT_WRONG));
    // }
  }
}
