import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as GetxController;
import 'package:get/get_core/src/get_main.dart';
import 'package:jtc_ecommerce/cart/controllers/cart_controller.dart';
import 'package:jtc_ecommerce/cart/models/add_to_cart_model.dart';
import 'package:jtc_ecommerce/cart/models/clear_cart_model.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/services/translate_service.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';

class ClearCartBloc {
  Response? _response;
  VoidCallback? _onSuccess, _onFailure;

  ClearCartModel? _clearCartModel;

  void clearCartBlocMethod({
    required BuildContext context,
    required VoidCallback setProgressBar,
    required VoidCallback onCartCleared,
  }) async {
    setProgressBar();
// Clear the cart locally
    CartController().cart_list.clear();
    CartController().update();
    Future.delayed(Duration(seconds: 1), () {
      // After clearing the cart, update the cart_list in CartController
      Get.find<CartController>().updateCartList([]);

      // Notify that the cart is cleared
      onCartCleared();
    });
    _onFailure = () async {
      AppNavigation.navigatorPop(context);

      print("STATUSSS CODEE ${_response?.statusCode}");
      final message = _response?.data['message'] ?? "";

      print(message);

      switch (message) {
        default:
          if (context.locale.languageCode != "en") {
            final _translatedMessage = await GoogleTranslatorService()
                .translate(text: message, context: context);
            AppDialogs.showToast(message: _translatedMessage);
          } else {
            AppDialogs.showToast(message: message);
          }
      }
    };

    //! ============> Call api
    await _postRequest(
      endPoint: NetworkStrings.CLEAR_CART_ENDPOINT,
      context: GetxController.Get.context!,
    );

    //! ============> Get the login response
    _onSuccess = () async {
      AppNavigation.navigatorPop(context);
      onCartCleared();
      _loginResponseMethod(
        context: context,
      );
      // await CartController().get_cart_list();
    };

    _validateResponse();
  }

  Future<void> _postRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().postRequest(
      endPoint: endPoint,
      onFailure: _onFailure,
      isHeaderRequire: true,
      context: context,
      customFailure: true
    );
  }

  //! ============> Validate Response
  void _validateResponse() {
    if (_response != null) {
      Network().validateResponse(
        isToast: false,
        response: _response,
        onSuccess: _onSuccess,
        onFailure: _onFailure,
      );
      logData(message: "Re: ${_response}");
    }
  }

  void _loginResponseMethod({
    required BuildContext context,
  }) async {
    logData(message: "Response: ${_response?.data}");

    _clearCartModel = ClearCartModel.fromJson(_response?.data);
    // AppDialogs.showToast(message: _clearCartModel?.message);

    if (_clearCartModel?.message == 'Cart Cleared Successfully!') {
      AppDialogs.showToast(message: tr('cart_cleared'));
    } else {
      AppDialogs.showToast(message: _clearCartModel?.message);
    }

    // Clear the cart locally
    CartController().cart_list.clear();

    // Update the UI after clearing the cart
    CartController().update();
    print("UI Updated");
  }
}
