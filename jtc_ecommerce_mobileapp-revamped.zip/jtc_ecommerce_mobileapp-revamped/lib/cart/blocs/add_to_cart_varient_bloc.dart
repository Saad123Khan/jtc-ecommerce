import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as GetxController;
import 'package:jtc_ecommerce/cart/models/add_to_cart_model.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/services/translate_service.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';

class AddToCartVarientBloc {
  // FormData? _formData;
  Map<String, dynamic>? _formDataMap;
  Response? _response;
  VoidCallback? _onSuccess, _onFailure;
  // UserResponseModel? _loginResponse;
  // UserData? _userData;
  AddToCartModel? _addToCartModel;

  void addToCartVarientBlocMethod({
    required BuildContext context,
    required VoidCallback setProgressBar,
    String? product_id,
    String? cart_id,
    List<Map<String, dynamic>>? addons,
    int? quantity,
    String? message,
    String? product_variation,
    bool isFromDetailScreen = true,
  }) async {
    setProgressBar();

    //! ============> Form Data
    _formDataMap = {
      "product_id": product_id,
      "cart_id": cart_id,
      "addons": addons,
      "quantity": quantity,
      "message": message,
      "product_variation": product_variation,
    };

    //! ============> Print Form Data
    print({
      "cart_id": cart_id,
      "product_id": product_id,
      "addons": addons,
      "quantity": quantity,
      "message": message,
      "product_variation": product_variation,
    });

    //! ============> If Api fails then stop the loader
   _onFailure = () async {
      AppNavigation.navigatorPop(context);

      print("STATUSSS CODEE ${_response?.statusCode}");
      final message = _response?.data['message'] ?? "";

      print(message);

      switch (message) {
        default:
          if (context.locale.languageCode != "en") {
            final _translatedMessage = await GoogleTranslatorService()
                .translate(text: message, context: context);
            AppDialogs.showToast(message: _translatedMessage);
          } else {
            AppDialogs.showToast(message: message);
          }
      }
    };
    //! ============> Call api
    await _postRequest(
      endPoint: NetworkStrings.ADD_TO_CART_ENDPOINT,
      context: GetxController.Get.context!,
    );

    //! ============> Get the login response
    _onSuccess = () {
      AppNavigation.navigatorPop(context);
      _loginResponseMethod(
          context: context, isFromDetailScreen: isFromDetailScreen);
    };

    //! ============> Validate the response
    _validateResponse();
  }

  //! ============> Post Request
  Future<void> _postRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().postRequestRawData(
      endPoint: endPoint,
      body: _formDataMap,
      onFailure: _onFailure,
      isHeaderRequire: true,
      customFailure: true,
      context: context,
    );
  }

  //! ============> Validate Response
  void _validateResponse() {
    if (_response != null) {
      Network().validateResponse(
        isToast: false,
        response: _response,
        onSuccess: _onSuccess,
        onFailure: _onFailure,
      );
      logData(message: "Re: ${_response}");
    }
  }

  //! ============> Creating a controller instance to save the user id temp for next verification otp api
  // var authContorller = GetxController.Get.find<AuthController>();

  //! ============> Login Response
  void _loginResponseMethod({
    required BuildContext context,
    required bool isFromDetailScreen,
  }) async {
    // try {
    logData(message: "Response: ${_response?.data}");
    _addToCartModel = AddToCartModel.fromJson(_response?.data);
    // AppDialogs.showToast(message: _addToCartModel?.message);



    if (_addToCartModel?.message == 'New item added to cart successfully!') {
      AppDialogs.showToast(message: tr('add_to_cart_success'));
    } else if (_addToCartModel?.message ==
        'Cart quantity has been updated successfully!') {
      AppDialogs.showToast(message: tr('add_to_cart_quantity_success'));
    } else if (_addToCartModel?.message == 'This product is out of stock.') {
      AppDialogs.showToast(message: tr('out_of_Stock'));
    } else {
      AppDialogs.showToast(message: _addToCartModel?.message);
    }




    if (isFromDetailScreen) {
      AppNavigation.navigateToRemovingAll(
          context, AppRouteName.BOTTOM_NAVIGATION_SCREEN_ROUTE);
    } else {
      return null;
    }
    // } catch (error) {
    //   AppDialogs.showToast(message: tr(NetworkStrings.SOMETHING_WENT_WRONG));
    // }
  }
}
