import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/cart/blocs/view_cart_bloc.dart';
import 'package:jtc_ecommerce/cart/models/view_cart_model.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/utils/constants.dart';
import 'package:jtc_ecommerce/wallet/models/cart_model.dart';

class CartController extends GetxController {
  static CartController get i => Get.find<CartController>();

  @override
  void onInit() {
    super.onInit();
  }

  var grandtotalPrice;
  void grandTotal() {
    grandtotalPrice = viewCartModel.value?.total ?? 0.0;
    logData(message: "Total: $grandtotalPrice");
  }

  double totalPriceTax() {
    return (viewCartModel.value?.total ??
            0.0 * (viewCartModel.value?.tax ?? 1.0))
        .toDouble();
  }

  double totalPriceWihtoutTax() {
    return viewCartModel.value?.subtotal ?? 0.0;
    update();
  }

  RxList<CartItem> cart_list = <CartItem>[].obs;

  void clearCart() {
    cart_list.clear();
  }

  Rxn<CartResponseData> viewCartModel = Rxn(null);
  //----

  RxBool isLoading = false.obs;
  ScrollController scrollController = ScrollController();

  // Rxn<ViewCartModel> viewCartModel = Rxn(null);
  var totalPrice;
  void total() {
    for (int i = 0; i < cart_list.length; i++) {
      totalPrice = cart_list[i].productDetail!.productPrice;
    }
    logData(message: "Total: ${totalPrice}");
  }

  Future<void> get_cart_list() async {
    // isLoading.value = true;
    ViewCartBloc().getViewCartBlocMethod(
      context: Constants.navigatorKey.currentContext!,
      failureCallBack: () {
        isLoading.value = false;
      },
      setProgressBar: () {
        isLoading.value = true;
      },
      onSuccess: () {
        isLoading.value = false;
        total();
      },
    );

    // if (ViewCartBloc().contentTypeResponse != null) {
    //   // cart_list.addAll(
    //   //   List.from(ViewCartBloc().contentTypeResponse),
    //   // );
    // }
  }

// Increment quantity of a cart item
  void incrementCartItemQuantity(int index) async {
    if (index >= 0 && index < cart_list.length) {
      // cart_list[index].quantity++;
      update(); // Trigger UI update

      // Call API to update cart after incrementing quantity
      // await get_cart_list();
    }
  }

  // Decrement quantity of a cart item
  void decrementCartItemQuantity(int index) async {
    if (index >= 0 && index < cart_list.length) {
      if (cart_list[index].quantity! > 1) {
        // cart_list[index].quantity--;
        update(); // Trigger UI update

        // Call API to update cart after decrementing quantity
        // await get_cart_list();
      }
    }
  }

  void updateCartList(List<CartItem> newList) {
    cart_list.assignAll(newList);
  }

  bool isFetching = false;
  onRefreshPage() async {
    FocusManager.instance.primaryFocus?.unfocus();
    if (isFetching) {
      // If already fetching, ignore this call
      return;
    }
    isFetching = true;
    //Clear the listings
    cart_list.value = [];
    // Fetch new data
    // await get_cart_list(); // Replace with your API call
    // Once fetch is complete, reset the flag
    isFetching = false;
  }
}
