class AppRouteName {
  ///-------------------- Common Navigation Routes -------------------- ///
  static const String SPLASH_SCREEN_ROUTE = "/";
  static const String LOGIN_SCREEN_ROUTE = "/login_screen";
  static const String REGISTER_SCREEN_ROUTE = "/register_screen";
  static const String VERIFY_OTP_SCREEN_ROUTE = "/verify_otp_screen";
  static const String VERIFY_OTP_SCREEN_ROUTE_RESET_PASSWORD =
      "/verify_otp_screen_reset_password";
  static const String LOCATION_SCREEN_ROUTE = "/location_screen";
  static const String LOCATION_SCREEN_Neareast_ROUTE =
      "/location__nearest_screen";
  static const String CURRENT_LOCATION_SCREEN_ROUTE =
      "/current_location_screen";
  static const String BOTTOM_NAVIGATION_SCREEN_ROUTE =
      "/bottom_navigaiton_screen";
  static const String HOME_SCREEN_ROUTE = "/home_screen";
  static const String FAVOURITE_SCREEN_ROUTE = "/favourite_screen";
  static const String SETTINGS_SCREEN_ROUTE = "/settings_screen";
  static const String WALLET_SCREEN_ROUTE = "/wallet_screen";
  static const String USER_PROFILE_SCREEN_ROUTE = "/user_profile_screen";
  static const String CHANGE_PASSWORD_SCREEN_ROUTE = "/change_password_screen";
  static const String CHANGE_PASSWORD_SCREEN_ROUTE_RESET =
      "/change_password_screen_reset";
  static const String WALLET_LIST_SCREEN_ROUTE = "/wallet_list_screen";
  static const String PRODUCT_DETAIL_SCREEN_ROUTE = "/product_detail_screen";
  static const String FOOD_CATEGORIES_LIST_SCREEN_ROUTE =
      "/food_categories_list_screen";
  static const String CART_SCREEN_ROUTE = "/cart_screen";
  static const String RESET_PASSWORD_SCREEN_ROUTE = "/reset_password_screen";
  static const String ORDER_SUMMARY_SCREEN_ROUTE = "/order_summary_screen";
  static const String USER_REFFERAL_CODE_SCREEN_ROUTE =
      "/user_refferal_code_screen";

  static const String BUY_JTC_TOKEN_SCREEN_ROUTE = "/buy_jtc_token_screen";
  static const String COUPON_SCREEN_ROUTE = "/coupon_screen";
  static const String PREPARATION_TIME_ROUTE = "/preparation_time_screen";
  static const String PREPARATION_TIME__CASH_ROUTE =
      "/preparation_time_cash_screen";
  static const String PREPARATION_TIME_ORDER_ROUTE =
      "/preparation_time_order_screen";
  static const String NOTIFICATION_SCREEN_ROUTE = "/notification_screen";
  static const String MY_ORDERS = "/my_order_screen";
  static const String SettingScreen = "/setting_screen";
  static const String PAYMENT_SCREEN = "/payment_screen";
  static const String CARD_PAYMENT_SCREEN = "/card_payment_screen";

  //Store Selection Screen
    static const String STORE_SELECTION_SCREEN = "/store_selection_screen";

}
