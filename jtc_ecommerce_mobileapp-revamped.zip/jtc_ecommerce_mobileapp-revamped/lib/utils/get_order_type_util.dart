import 'package:easy_localization/easy_localization.dart';

import '../enum/order_type.dart';

extension OrderTypeString on OrderType {
  String get orderString {
    switch (this) {
      case OrderType.Delivery:
        return tr('delivery_text');
      case OrderType.Dine_In:
        return tr('dinein_text');
      case OrderType.Curbside:
        return tr('curbside_text');
      case OrderType.Take_Away:
        return tr('takeaway_text');
      case OrderType.Drive_Thru:
        return tr('drivethru_text');
      default:
        return '';
    }
  }
}

extension OrderTypeStringForCheckout on OrderType {
  String get orderStringCheckout {
    switch (this) {
      case OrderType.Delivery:
        //  return tr('delivery_text');
        return "delivery";
      case OrderType.Dine_In:
        // return tr('dinein_text');
        return "dine-in";
      case OrderType.Curbside:
        // return tr('curbside_text');
        return "curve_side";
      case OrderType.Take_Away:
        // return tr('takeaway_text');  
        return "take-away";
      case OrderType.Drive_Thru:
        // return tr('drivethru_text');
        return "drive-thru";
      default:
        return '';
    }
    return '';
  }
}

extension OrderTypeEnum on String {
  OrderType get getOrderEnum {
    switch (this) {
      case 'Delivery':
      case 'Entrega': // Spanish for Delivery
        return OrderType.Delivery;
      case 'Dine-In':
      case 'Comer en el local': // Spanish for Dine-In
        return OrderType.Dine_In;
      case 'Curbside':
      case 'Acera': // Spanish for Curbside
        return OrderType.Curbside;
      case 'Take Away':
      case 'Para Llevar': // Spanish for Take Away
        return OrderType.Take_Away;
      case 'Drive Thru':
      case 'Auto servicio': // Spanish for Drive Thru
        return OrderType.Drive_Thru;
      default:
        return OrderType.Delivery;
    }
  }
}
