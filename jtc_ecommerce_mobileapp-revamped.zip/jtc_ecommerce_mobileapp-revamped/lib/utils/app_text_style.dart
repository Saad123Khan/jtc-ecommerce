import 'package:flutter/material.dart';
import 'package:jtc_ecommerce/utils/app_fonts.dart';

class AppTextStyles {
  static TextStyle textStyleBold(
      {TextOverflow? overflow,
      double fontSize = 12,
      Color color = Colors.black,
      double? letterSpacing,
      TextDecoration? textDecoration,
      double? height}) {
    return TextStyle(
        color: color,
        fontWeight: FontWeight.bold,
        fontSize: fontSize,
        overflow: overflow ?? TextOverflow.ellipsis,
        letterSpacing: letterSpacing ?? 0.0,
        decoration: textDecoration,
        height: height);
  }

  static TextStyle textStyleLight(
      {TextOverflow? overflow,
      double fontSize = 12,
      Color color = Colors.black,
      double? letterSpacing,
      TextDecoration? textDecoration,
      double? height}) {
    return TextStyle(
        color: color,
        fontWeight: FontWeight.w300,
        fontSize: fontSize,
        overflow: overflow ?? TextOverflow.ellipsis,
        letterSpacing: letterSpacing ?? 0.0,
        decoration: textDecoration,
        height: height);
  }

  static TextStyle textStyleMedium(
      {TextOverflow? overflow,
      double fontSize = 12,
      Color color = Colors.black,
      double? letterSpacing,
      TextDecoration? textDecoration,
      double? height}) {
    return TextStyle(
        color: color,
        fontWeight: FontWeight.w500,
        fontSize: fontSize,
        overflow: overflow ?? TextOverflow.ellipsis,
        letterSpacing: letterSpacing ?? 0.0,
        decoration: textDecoration,
        height: height);
  }

  static TextStyle textStyleRegular(
      {TextOverflow? overflow,
      double fontSize = 12,
      Color color = Colors.black,
      double? letterSpacing,
      TextDecoration? textDecoration,
      double? height}) {
    return TextStyle(
        color: color,
        fontSize: fontSize,
        fontFamily: AppFonts.defaultFont,
        overflow: overflow ?? TextOverflow.ellipsis,
        letterSpacing: letterSpacing ?? 0.0,
        decoration: textDecoration,
        height: height);
  }
}
