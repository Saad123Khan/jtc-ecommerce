enum SwitchValue {
  phone,
  email,
  none,
}

enum ShimmerType {
  //New Shimmer Types
  food_category_skeleton,
  food_category_wise_skeleton,
  food_detail,
  favourite_list,
  //Old
  visionBoardListViewSkeleton,
  eventDetailPageSkeleton,
  quotesListSkeleton,
  goalPageSkeleton,
  venueProfilePageSkeleton,
  reviewRatingPageSkeleton,
  chatListSkeleton
}

enum PaymentType {
  Visa,
  Cash,
  Jtctoken,
  Digitalcurrency,
}
