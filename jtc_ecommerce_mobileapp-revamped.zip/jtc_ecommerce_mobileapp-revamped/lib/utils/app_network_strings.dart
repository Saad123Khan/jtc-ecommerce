class NetworkStrings {
  ////////////////////// API BASE URL //////////////////////////////////
  static const String API_BASE_URL =
      "https://pos-admin.javatimescaffe.com/api/";

  /// STRIPE
  static const String PUBLISH_KEY =
      "pk_test_51MvYFsHR4p2bAk2CwOzjbovbZZQI05WyT3OlF7Ov1jEB8s3qApeF7VK1DoZJDpXXg24IcfuEMou7gxeKtjLYpqrd00XW9orPni";

  /////// API HEADER TEXT ////////////////////////
  static const String ACCEPT = 'application/json';
  // static const String BEARER_TOKEN = "Bearer Token";

  ////////////////////// API ENDPOINTS  ////////////////////////

  //Social Login Endpoints
  //Auth APIS

  static const String POST_FAV_ENDPOINT = "updateFavourite";
  static const String LOGIN_ENDPOINT = "ecomuser/login";
  static const String QR_SCAN_ENDPOINT = "ecomuser/scan";
  static const String GETUSERPROFILE = "ecomuser/getUserProfile/";
  static const String SEND_PASSWORD_ENDPOINT =
      "ecomuser/sendPasswordResetLinkEmailEcom";
  static const String REGISTER_ENDPOINT = "ecomuser/register";
  static const String VERIFY_OTP_ENDPOINT = "ecomuser/otp-verify";
  static const String RESEND_OTP_ENDPOINT = "ecomuser/resend-otp";
  static const String RESEND_OTP_NOTVALID_ENDPOINT =
      "ecomuser/resend-otp-not-valid";
  static const String UPDATE_PROFILE_ENDPOINT =
      "ecommerceProfile/updateProfileEcom";
  static const String LOGOUT_OTP_ENDPOINT = "logout";
  static const String DELETE_ACCOUNT_ENDPOINT = "deleteAccount";
  static const String CHANGE_PASSWORD_ENDPOINT = "ecomuser/change-password";
  static const String CHANGE_PASSWORD_RESET_ENDPOINT =
      "ecomuser/resetPasswordEcom";
  //Core API
  static const String GET_FOOD_CATEGORIES_ENDPOINT = "indexApp";
  static const String GET_FOOD_CATEGORIES_PRODUCT_ENDPOINT =
      "getProductCategory";
  static const String GET_FOOD_CATEGORIES_LIST_ENDPOINT =
      "category/getProductCategory/";
  static const String STORE_DISCOUNT_BANNER = "storeDiscount";
  static const String SOCIAL_LOGIN_ENDPOINT = "social-login-app";
  //  "tokenSingUp";  
  static const String GET_SINGLE_PRODUCT_DETAIL_ENDPOINT = "showApp/";
  //Cart
  static const String ADD_TO_CART_ENDPOINT = "ecomuser/cart";
  static const String SEND_TOKEN_TOSERVER = "ecomuser/store-token";
  static const String SEND_LANG_TOSERVER = "change-language";
  static const String COUPON_CODE_URL = "ecomuser/apply-coupon";
  static const String CLEAR_CART_ENDPOINT = "ecomuser/clear-cart";
  static const String CLEAR_PRODUCT_FROM_CART_ENDPOINT = "ecomuser/remove-cart";
  static const String VIEW_CART_ENDPOINT = "ecomuser/view-cart";
  //Checkout
  static const String CHECKOUT_ENDPOINT = "ecomuser/cart/checkout";
  static const String ORDER_CONFIRM_PREPARATIONTime = "ecomuser/orderConfirm";
  static const String PAYMENT_INTENT_ENDPOINT =
      "ecomuser/create-payment-intent";
  //Wallet
  static const String USERWALLET_ENDPOINT = "userWallet";
  static const String GET_SALES_APP = "getSalesApp/";
  static const String WALLET_TRANSACTIONS_ENDPOINT = "referralApi";
  //Get JTC Token List
  static const String JTC_TOKEN_ENDPOINT = "tokenPlan";
  static const String COUPON_ENDPOINT = "couponUser";
  static const String NOTIFICATION_ENDPOINT = "notification";
  //Get my orders
  static const String MY_ORDERS = "orderHistory";
  static const String LOGOUT_ENDPOINT = "logout";
  //favourite
  static const String GET_FAVOURITE_ENDPOINT = "getFavourite";
  //Buy Jtc Token
  static const String BUY_JTC_TOKEN_ENDPOINT = "buy-jtc-token-payment-mobile";
  // static const String ORDER_CONFIRM_MOBILE_ENDPOINT =
  //     "ecomuser/order-confirm-mobile";

  static const String ORDER_CONFIRM_MOBILE_ENDPOINT = "ecomuser/create-payment";
  static const String GET_ALL_STORES_LIST = "get-nearest-store";
  static const String GET_AUTO_NEAREST_STORE = "getNearestStores";

  /////////////// SOCKET EMIT EVENTS ////////////////
  static const String GET_MESSAGES_EVENT = "get_messages";
  static const String SEND_MESSAGE_EVENT = "send_message";
  static const String SEND_EMOJI_EVENT = "send_emoji";
  static const String DELETE_EMOJI_EVENT = "delete_emoji";
  static const String DELETE_MESSAGE_EVENT = "delete_message";
  static const String ON_LOCATION_CHANGED_EVENT = "location-change";

  /////////////// SOCKET RESPONSE KEYS ////////////////
  static const String GET_MESSAGES_KEY = "get_messages";
  static const String GET_MESSAGE_KEY = "get_message";
  static const String GET_PARTNER_KEY = "get_location";
  // static const String

  static const String CHAT_ERROR = "Chat not found.";

  ////// API STATUS CODE/////////////
  static const int SUCCESS_CODE = 200;
  static const int UNAUTHORIZED_CODE = 401;
  static const int CARD_ERROR_CODE = 402;
  static const int BAD_REQUEST_CODE = 400;
  static const int FORBIDDEN_CODE = 403;
  static const int Unprocessable_CODE = 422;

  /////////// API MESSAGES /////////////////
  static const int API_SUCCESS_STATUS = 1;
  static const String EMAIL_UNVERIFIED = "0";
  static const String EMAIL_VERIFIED = "1";
  static const String PROFILE_INCOMPLETED = "0";
  static const String PROFILE_COMPLETED = "1";

  static const String ADMIN_APROVED = "1";
  static const String ADMIN_NOTAPROVED = "0";
  static const int USER_SUBSCRIBED = 1;
  static const int USER_NOTSUBSCRIBED = 0;

  /////////// USER PAYMENT STATUS VALUE /////////////////
  static const int PAID_USER = 1;
  static const int UN_PAID_USER = 0;
  static const int PAID_DATA = 1;
  static const int UN_PAID_DATA = 0;
  static const int GUEST_USER = 1;
  static const String ADMIN_ACTIVITY = 'admins';
  static const String USER_ACTIVITY = 'users';

  /////////// API TOAST MESSAGES //////////////////
  static const String NO_INTERNET_CONNECTION = "No Internet Connection!";
  static const String STATUS_NOT_FOUND = "No Status Found";
  static const String INVALID_CARD_ERROR = "Invalid Card Details.";
  static const String CARD_TYPE_ERROR = "Wrong card type.";
  static const String INVALID_BANK_ACCOUNT_DETAILS_ERROR =
      "Invalid Bank Account Details.";
  static const String MERCHANT_ACCOUNT_ERROR =
      "Error:Merchant Account can not be created.";

//---------------- API SHOW ERROR MESSAGE -------------------//

  static const String NOTIFICATION_EMPTY_ERROR = "Notification not found";
  static const String CONTENT_EMPTY_ERROR = "Content not found";
  static const String CHAT_EMPTY_ERROR = "Chat not found";
  static const String STATUS_EMPTY_ERROR = "Stories not found";
  static const String MY_STATUS_EMPTY_ERROR = "My Stories not found";
  static const String MEDIA_EMPTY_ERROR = "Media not found";
  static const String CONNECTION_REQUEST_EMPTY_ERROR =
      "Connection Request not found";
  static const String PARTNER_EMPTY_ERROR = "Partners not found";
  static const String PENDING_PARTNER_EMPTY_ERROR =
      "Pending partners not found";
  static const String REQUEST_EMPTY_ERROR = "Requests not found";

  ///API ERRORS
  static const String SOMETHING_WENT_WRONG = "something_went_wrong";
  static const String INVALID_EMAIL_OR_PASSWORD = "invalid_email_pass";
  static const String USER_NOT_FOUND = "user_not_found";
  static const String NO_INTERNET = "no_internet";
}
