import 'dart:io';
import 'package:easy_localization/easy_localization.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_fonts.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_strings.dart';
import 'package:jtc_ecommerce/utils/constants.dart';
import 'package:permission_handler/permission_handler.dart';

class ImageGalleryClass {
  ImagePicker picker = ImagePicker();
  XFile? getFilePath;
  CroppedFile? croppedImageFile;
  // File? imageFile;

  Map<String, dynamic>? imageGalleryBottomSheet(
      {required BuildContext context,
      required ValueChanged<File?> onMediaChanged,
      bool? multiImage,
      bool? showFile = false}) {
    showModalBottomSheet(
        shape: RoundedRectangleBorder(
          // <-- SEE HERE
          borderRadius: BorderRadius.vertical(
            top: Radius.circular(10),
          ),
        ),
        context: context,
        builder: (_) {
          return Container(
            decoration: BoxDecoration(
                // color: AppColors.whiteColor,
                borderRadius: BorderRadius.only(
                    topRight: Radius.circular(10),
                    topLeft: Radius.circular(10))),
            child: SafeArea(
              child: Wrap(
                children: <Widget>[
                  //getCameraImage
                  GestureDetector(
                    onTap: () {
                      // AppNavigation.navigatorPop(context);
                      getCameraImage(
                        onMediaChanged: onMediaChanged,
                        context: Constants.navigatorKey.currentContext!,
                        fromCreateFeed: false,
                      );
                    },
                    child: Container(
                      color: Colors.transparent,
                      padding: const EdgeInsets.only(top: 16.0, bottom: 16.0),
                      child: Row(
                        children: [
                          SizedBox(
                            width: 15.0,
                          ),
                          Icon(
                            Icons.camera_enhance,
                            color: AppColors.PRIMARY_COLOR,
                          ),
                          SizedBox(
                            width: 15.0,
                          ),
                          CustomText(
                            text:

                                //  AppStrings.CAMERA,
                                tr('camera_text'),
                            color: AppColors.PRIMARY_COLOR,
                            fontsize: 18.0,
                            fontFamily: AppFonts.defaultFont,
                          )
                        ],
                      ),
                    ),
                  ),
                  // const Divider(
                  //   color: AppColors.whiteColor,
                  //   height: 1.0,
                  // ),
                  //getGalleryImage
                  GestureDetector(
                    onTap: () {
                      // multiImage == true
                      //     ? getMultipleImages(
                      //         onMediaChanged: onMediaChanged, context: context)
                      //     :
                      getGalleryImage(
                          onMediaChanged: onMediaChanged, context: context);
                      //AppNavigation.navigatorPop(context);
                    },
                    child: Container(
                      color: Colors.transparent,
                      padding: const EdgeInsets.only(top: 16.0, bottom: 16.0),
                      child: Row(
                        children: [
                          SizedBox(
                            width: 15.0,
                          ),
                          Icon(
                            Icons.image,
                            color: AppColors.PRIMARY_COLOR,
                          ),
                          SizedBox(
                            width: 15.0,
                          ),
                          CustomText(
                            text:
                                // AppStrings.GALLERY,
                                tr('galler_text'),
                            color: AppColors.PRIMARY_COLOR,
                            fontsize: 18.0,
                            fontFamily: AppFonts.defaultFont,
                          )
                        ],
                      ),
                    ),
                  ),

                  ///// FILE UPLOAD //////////
                  if (showFile == true) ...[
                    //getPdfFile
                    GestureDetector(
                      onTap: () {
                        print("pdf");
                        print("Image file path: ${getFilePath?.path}");

                        // getPdfFile(
                        //     onMediaChanged: onMediaChanged, context: context);
                      },
                      child: Container(
                        color: Colors.transparent,
                        padding: const EdgeInsets.only(top: 16.0, bottom: 16.0),
                        child: Row(
                          children: [
                            SizedBox(
                              width: 15.0,
                            ),
                            Icon(
                              Icons.file_copy_sharp,
                              color: AppColors.PRIMARY_COLOR,
                            ),
                            SizedBox(
                              width: 15.0,
                            ),
                            CustomText(
                              text: AppStrings.FILE,
                              color: AppColors.PRIMARY_COLOR,
                              fontsize: 18.0,
                              fontFamily: AppFonts.defaultFont,
                            )
                          ],
                        ),
                      ),
                    ),
                  ]
                ],
              ),
            ),
          );
        });
    return null;
  }

  void getPdfFile(
      {required ValueChanged<String?> onMediaChanged,
      BuildContext? context}) async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ["pdf", "doc"],
      );
      if (result != null) {
        PlatformFile file = result.files.first;
        print(file.name);
        print("Bytes ${file.bytes}");
        print("Size ${file.size}");
        print(file.extension);
        print(file.path);
        onMediaChanged(file.path);
        //AppNavigation.navigatorPop(context!);
      }
    } on PlatformException catch (e) {
      AppDialogs.showToast(message: e.message ?? 'Something went wrong.');
    }
  }

  void getCameraImage({
    required ValueChanged<File?> onMediaChanged,
    BuildContext? context,
    bool? fromCreateFeed = false,
  }) async {
    try {
      // final permission = await Permission.camera.request();
      final getFilePath = await picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 70,
      );

      if (getFilePath != null) {
        // cropImage(
        //   imageFilePath: getFilePath.path,
        //   onMediaChanged: onMediaChanged,
        //   context: context,
        //   fromCreateFeed: fromCreateFeed,
        // );

        onMediaChanged.call(File(getFilePath.path));

        // AppNavigation.navigatorPop(context!);

        

        // Future.delayed(Duration(milliseconds: 100), (){
        //   // AppNavigation.navigatorPop(context!);
        // });
      } else {
        // Handle the case when the image capture was canceled or failed.
        fromCreateFeed! ? null : AppNavigation.navigatorPop(context!);
      }
    } on PlatformException catch (e) {
      print(e.message.toString());
      // Handle any platform-specific exceptions.
    }
  }

  void getGalleryImage(
      {required ValueChanged<File?> onMediaChanged,
      BuildContext? context,
      bool? fromCreateFeed = false}) async {
    try {
      getFilePath =
          await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
      if (getFilePath != null) {
        cropImage(
            imageFilePath: getFilePath!.path,
            onMediaChanged: onMediaChanged,
            context: context,
            fromCreateFeed: fromCreateFeed);
      } else {
        fromCreateFeed! ? null : AppNavigation.navigatorPop(context!);
        // AppNavigation.navigatorPop(context!);
      }
    } on PlatformException catch (e) {
      // AppDialogs.showToast(
      //     message: e.message ?? AppStrings.SOMETHING_WENT_WRONG_ERROR);
    }
  }

  void getMultipleImages(
      {required ValueChanged<List<String?>?> onMediaChanged,
      required BuildContext context}) async {
    try {
      // getFilePath =
      List<XFile> multiImages = await picker.pickMultiImage(imageQuality: 80);
      List<String> multiImagesPath = [];
      //print("Multi Images:${multiImages.length}");
      if (multiImages.length > 0) {
        for (int i = 0; i < multiImages.length; i++) {
          multiImagesPath.add(multiImages[i].path);
        }
      }
      //print("Multi Images PAth:${multiImagesPath.length}");
      onMediaChanged(multiImagesPath);
      AppNavigation.navigatorPop(context);
    } on PlatformException {
      // AppDialogs.showToast(
      //     message: e.message ?? AppStrings.SOMETHING_WENT_WRONG_ERROR);
    }
  }

  void cropImage({
    String? imageFilePath,
    BuildContext? context,
    required ValueChanged<File?> onMediaChanged,
    bool? fromCreateFeed,
  }) async {
    final croppedImageFile = await ImageCropper().cropImage(
      sourcePath: imageFilePath!,
      aspectRatioPresets: [
        CropAspectRatioPreset.square,
        CropAspectRatioPreset.ratio3x2,
        CropAspectRatioPreset.original,
        CropAspectRatioPreset.ratio4x3,
        CropAspectRatioPreset.ratio16x9,
      ],
      uiSettings: <PlatformUiSettings>[
        // Create a list of PlatformUiSettings
        AndroidUiSettings(
          toolbarTitle: context!.locale.languageCode == "en"
              ? 'Edit Photo'
              : "Editar foto",
          initAspectRatio: CropAspectRatioPreset.original,
          lockAspectRatio: false,
        ),
      ],
    );

    if (croppedImageFile != null) {
      onMediaChanged(File(croppedImageFile.path));
    } else {
      onMediaChanged(null);
    }

    if (context != null) {
      AppNavigation.navigatorPop(context);
    }
  }
}
