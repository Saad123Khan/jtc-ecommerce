import 'package:flutter/material.dart';

class AppColors {
  static const Color TRANSPARENT_COLOR = Colors.transparent;
  static const Color PRIMARY_COLOR = Color(0xffE0201C);
  static const Color SECONDARY_COLOR = Color(0xffFFFFFF);
  static const Color BLACK_COLOR = Colors.black;
  static const Color WHITE_COLOR = Colors.white;
  static const Color GREEN_PHONE_COLOR = Color(0xff00CB38);
  static const Color RED_GMAIL_COLOR = Color(0xffCF2C1F);
  static const Color QUOTES_BOX_COLOR = Color(0xFFEBEBEB);
  static const Color INNER_PINK_CONTAINER_COLOR = Color(0xffFD2256);
  static const Color GREY_COLOR = Color(0xff707070);
  static const Color GREY_COLOR_SHADE_100 = Color(0xFFF0F0F0);
  static const Color APP_GREY_COLOR = Color(0xffECECEC);
  static const Color viewCartContainer = const Color(0xFFE3E3E3);
}
