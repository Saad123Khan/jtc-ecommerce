import 'package:get/get.dart';
import 'package:jtc_ecommerce/auth/bindings/auth_binding.dart';
import 'package:jtc_ecommerce/auth/screens/current_location_screen.dart';
import 'package:jtc_ecommerce/auth/screens/location_nearest_screen.dart';
import 'package:jtc_ecommerce/auth/screens/location_screen.dart';
import 'package:jtc_ecommerce/auth/screens/login_screen.dart';
import 'package:jtc_ecommerce/auth/screens/register_screen.dart';
import 'package:jtc_ecommerce/auth/screens/reset_password_screen.dart';
import 'package:jtc_ecommerce/auth/screens/verify_otp_screen.dart';
import 'package:jtc_ecommerce/auth/screens/verify_otp_screen_resetpassword.dart';
import 'package:jtc_ecommerce/bottom_navigation/bindings/bottom_binding.dart';
import 'package:jtc_ecommerce/bottom_navigation/screens/bottom_navgation_screen.dart';
import 'package:jtc_ecommerce/cart/bindings/cart_binding.dart';
import 'package:jtc_ecommerce/cart/screens/cart_screen.dart';
import 'package:jtc_ecommerce/favourite/bindings/favourite_binding.dart';
import 'package:jtc_ecommerce/favourite/screens/favourite_screen.dart';
import 'package:jtc_ecommerce/home/bindings/home_binding.dart';
import 'package:jtc_ecommerce/home/screens/food_categories_list_screen.dart';
import 'package:jtc_ecommerce/home/screens/home_screen.dart';
import 'package:jtc_ecommerce/home/screens/product_detail_screen.dart';
import 'package:jtc_ecommerce/order_summary/bindings/order_summary_bindings.dart';
import 'package:jtc_ecommerce/order_summary/screens/cardpayment_screen.dart';
import 'package:jtc_ecommerce/order_summary/screens/order_summary_screen.dart';
import 'package:jtc_ecommerce/order_summary/screens/payment_screen.dart';
import 'package:jtc_ecommerce/order_summary/screens/prepartion_screen_arguments.dart';
import 'package:jtc_ecommerce/order_summary/screens/prepartion_time_screen.dart';
import 'package:jtc_ecommerce/settings/bindings/settings_binding.dart';
import 'package:jtc_ecommerce/settings/screens/buy_jtc_token_screen.dart';
import 'package:jtc_ecommerce/settings/screens/change_password_screen.dart';
import 'package:jtc_ecommerce/settings/screens/change_password_screen_reset.dart';
import 'package:jtc_ecommerce/settings/screens/coupon_screen.dart';
import 'package:jtc_ecommerce/settings/screens/my_orders_screen.dart';
import 'package:jtc_ecommerce/settings/screens/notification_screen.dart';
import 'package:jtc_ecommerce/settings/screens/setting_screen.dart';
import 'package:jtc_ecommerce/settings/screens/settings_screen.dart';
import 'package:jtc_ecommerce/settings/screens/user_profile_screen.dart';
import 'package:jtc_ecommerce/settings/screens/user_referral_code_screen.dart';
import 'package:jtc_ecommerce/splash/bindings/splash_binding.dart';
import 'package:jtc_ecommerce/splash/screens/splash_screen.dart';
import 'package:jtc_ecommerce/splash/screens/store_list_screen.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';
import 'package:jtc_ecommerce/wallet/bindings/wallet_binding.dart';
import 'package:jtc_ecommerce/wallet/screens/wallet_list_screen.dart';
import 'package:jtc_ecommerce/wallet/screens/wallet_screen.dart';

class AppRouter {
  static final routes = [
    GetPage(
      name: AppRouteName.SPLASH_SCREEN_ROUTE,
      page: () => const SplashScreen(),
      binding: SplashBinding(),
    ),
    GetPage(
      name: AppRouteName.LOGIN_SCREEN_ROUTE,
      page: () => LoginScreen(),
      binding: AuthBinding(),
    ),
    GetPage(
      name: AppRouteName.REGISTER_SCREEN_ROUTE,
      page: () => RegisterScreen(),
      binding: AuthBinding(),
    ),
    GetPage(
      name: AppRouteName.VERIFY_OTP_SCREEN_ROUTE,
      page: () => VerifyOtpScreen(),
      binding: AuthBinding(),
    ),
    GetPage(
      name: AppRouteName.VERIFY_OTP_SCREEN_ROUTE_RESET_PASSWORD,
      page: () => VerifyOtpScreenResetPassword(),
      binding: AuthBinding(),
    ),
    GetPage(
      name: AppRouteName.LOCATION_SCREEN_ROUTE,
      page: () => LocationScreen(),
      binding: AuthBinding(),
    ),
    GetPage(
      name: AppRouteName.LOCATION_SCREEN_Neareast_ROUTE,
      page: () => LocationNearestScreen(),
      binding: AuthBinding(),
    ),
    GetPage(
      name: AppRouteName.CURRENT_LOCATION_SCREEN_ROUTE,
      page: () => CurrentLocationScreen(),
      binding: AuthBinding(),
    ),
    GetPage(
      name: AppRouteName.BOTTOM_NAVIGATION_SCREEN_ROUTE,
      page: () => BottomNavigationScreen(),
      binding: BottomNavigationBinding(),
    ),
    GetPage(
      name: AppRouteName.HOME_SCREEN_ROUTE,
      page: () => HomeScreen(),
      binding: HomeBinding(),
    ),
    GetPage(
      name: AppRouteName.FAVOURITE_SCREEN_ROUTE,
      page: () => FavouriteScreen(),
      binding: FavouriteBinding(),
    ),
    GetPage(
      name: AppRouteName.SETTINGS_SCREEN_ROUTE,
      page: () => SettingScreen(),
      binding: SettingBinding(),
    ),
    GetPage(
      name: AppRouteName.WALLET_SCREEN_ROUTE,
      page: () => WalletScreen(),
      binding: WalletBinding(),
    ),
    GetPage(
      name: AppRouteName.USER_PROFILE_SCREEN_ROUTE,
      page: () => UserProfileScreen(),
      binding: WalletBinding(),
    ),
    GetPage(
      name: AppRouteName.CHANGE_PASSWORD_SCREEN_ROUTE,
      page: () => ChangePasswordScreen(),
      binding: WalletBinding(),
    ),
    GetPage(
      name: AppRouteName.CHANGE_PASSWORD_SCREEN_ROUTE_RESET,
      page: () => ChangePasswordScreenReset(),
      binding: WalletBinding(),
    ),
    GetPage(
      name: AppRouteName.WALLET_LIST_SCREEN_ROUTE,
      page: () => WalletListScreen(),
      binding: WalletBinding(),
    ),
    GetPage(
      name: AppRouteName.PRODUCT_DETAIL_SCREEN_ROUTE,
      page: () => ProductDetailScreen(),
      binding: HomeBinding(),
    ),
    GetPage(
      name: AppRouteName.FOOD_CATEGORIES_LIST_SCREEN_ROUTE,
      page: () => FoodCategoriesListScreen(),
      // binding: HomeBinding(),
    ),
    GetPage(
      name: AppRouteName.CART_SCREEN_ROUTE,
      page: () => CartScreen(),
      binding: CartBinding(),
    ),
    GetPage(
      name: AppRouteName.RESET_PASSWORD_SCREEN_ROUTE,
      page: () => ResetPasswordScreen(),
      binding: AuthBinding(),
    ),
    GetPage(
      name: AppRouteName.ORDER_SUMMARY_SCREEN_ROUTE,
      page: () => OrderSummaryScreen(),
      binding: OrderSummaryBinding(),
    ),
    GetPage(
      name: AppRouteName.USER_REFFERAL_CODE_SCREEN_ROUTE,
      page: () => UserRefferalScreen(),
      // binding: OrderSummaryBinding(),
    ),
    GetPage(
      name: AppRouteName.BUY_JTC_TOKEN_SCREEN_ROUTE,
      page: () => BuyJtcTokenScreen(),
      // binding: OrderSummaryBinding(),
    ),
    GetPage(
      name: AppRouteName.COUPON_SCREEN_ROUTE,
      page: () => CouponScreen(),
      // binding: OrderSummaryBinding(),
    ),

    // GetPage(
    //     name: AppRouteName.PREPARATION_TIME_ROUTE,
    //     page: () {
    //       PreparaationScreenArguments args =
    //           Get.arguments as PreparaationScreenArguments;
    //       return PrepartionTimeScreen(
    //         orderId: args.orderId,
    //       );
    //     }
    //     // binding: OrderSummaryBinding(),
    //     ),
    // GetPage(
    //   name: AppRouteName.PREPARATION_TIME__CASH_ROUTE,
    //   page: () => PrepartionTimeCashScreen(),
    //   // binding: OrderSummaryBinding(),
    // ),
    // GetPage(
    //   name: AppRouteName.PREPARATION_TIME_ORDER_ROUTE,
    //   page: () => PrepartionTimeOrderScreen(
    //     data: '',
    //   ),
    //   // binding: OrderSummaryBinding(),
    // ),
    GetPage(
      name: AppRouteName.NOTIFICATION_SCREEN_ROUTE,
      page: () => NotificationListView(),
      // binding: OrderSummaryBinding(),
    ),
    GetPage(
      name: AppRouteName.MY_ORDERS,
      page: () => MyOrderScreen(),
      // binding: OrderSummaryBinding(),
    ),
    GetPage(
      name: AppRouteName.SettingScreen,
      page: () => MySettingScreens(),
      // binding: OrderSummaryBinding(),
    ),
    GetPage(
      name: AppRouteName.PAYMENT_SCREEN,
      page: () => PaymentScreen(),
      // binding: OrderSummaryBinding(),
    ),
    GetPage(
      name: AppRouteName.CARD_PAYMENT_SCREEN,
      page: () => CardPaymentScreen(),
      // binding: OrderSummaryBinding(),
    ),

    ///
    /// Store Selection Screen
    ///
    GetPage(
      name: AppRouteName.STORE_SELECTION_SCREEN,
      page: () => StoreSelectionScreen(
        lat: Get.arguments['lat'],
        lon: Get.arguments['lon'],
      ),
    ),
  ];
}
