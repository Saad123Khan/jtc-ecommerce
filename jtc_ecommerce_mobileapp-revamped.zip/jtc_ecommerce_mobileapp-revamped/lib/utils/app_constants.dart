import 'dart:ui';

import 'package:intl/intl.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';

class AppConstant {
  //Font Family
  static const artbaordSize = Size(375, 812);

  static String selectedOption = '';

  bool? is_current_appointment = false;
  static int? zoom_index;

  // WEBVIEW URL
  static const String WEB_VIEW_URL = "https://www.lipsum.com/";

  //Date Formats
  static const String MM_DD_YYYY_FORMAT = 'MM/dd/yyyy';

  static MaskTextInputFormatter MASK_TEXT_FORMATTER_PHONE_NO =
      MaskTextInputFormatter(
    mask: '+1(###) ###-####',
    filter: {"#": RegExp(r'[0-9]')},
    type: MaskAutoCompletionType.lazy,
  );

  static MaskTextInputFormatter MASK_TEXT_FORMATTER_CARD_NO =
      MaskTextInputFormatter(
    mask: '#### #### #### ####',
    filter: {"#": RegExp(r'[0-9]')},
    type: MaskAutoCompletionType.lazy,
  );

  static MaskTextInputFormatter MASK_TEXT_FORMATTER_EXPIRY =
      MaskTextInputFormatter(
    mask: '##/##',
    filter: {"#": RegExp(r'[0-9]')},
    type: MaskAutoCompletionType.lazy,
  );

  static MaskTextInputFormatter MASK_TEXT_FORMATTER_HOURS =
      MaskTextInputFormatter(
    mask: ' ##',
    filter: {"#": RegExp(r'[0-9]')},
    type: MaskAutoCompletionType.lazy,
  );

  static MaskTextInputFormatter MASK_TEXT_FORMATTER_AMOUNT =
      MaskTextInputFormatter(
    mask: '\$#####',
    filter: {"#": RegExp(r'[0-9]')},
    type: MaskAutoCompletionType.lazy,
  );

  
  static List times = [
    "09:00AM",
    "09:30AM",
    "10:00AM",
    "10:30AM",
    "11:00AM",
    "11:30AM",
    "12:00PM",
    "12:30PM",
    "01:00PM",
    "01:30PM",
    "02:00PM",
  ];

  static final f = DateFormat('dd-MM-yyyy HH:mm');

  static formatDate(String date) {
    return f.format(DateTime.parse(
      date,
    ));
  }

}
