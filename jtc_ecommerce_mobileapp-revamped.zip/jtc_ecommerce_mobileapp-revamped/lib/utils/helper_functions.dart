// import 'package:easy_localization/easy_localization.dart';
import 'package:intl/intl.dart';

import 'package:intl/intl.dart';

class HelperFunctions {
  
  // Function to change date format into -> "Jan 26, 2022"
  static String changeDateFormat(String dateString) {
    DateTime dateTime = DateTime.parse(dateString);
    return DateFormat('MMM d, yyyy').format(dateTime);
  }

  // Function to convert date string into time format -> "09:32:10 PM"
  static String convertToTimeFormat(String dateString) {
    DateTime dateTime = DateTime.parse(dateString);
    return DateFormat('hh:mm:ss a').format(dateTime);
  }
}
