class AssetPaths {
  static const String IMAGES = "assets/images";
  static const String REVAMPED = "assets/revamped/bottom_nav";
  static const String ICONS = "assets/icons";
  static const String PLACEHOLDERS = "assets/placeholders";

  //Main Background Image
  //FOR SPLASH SCREEN
  static const String BG_SPLASH_SCREEN = "$IMAGES/splash_bg.png";
  static const String LOGO = "$IMAGES/logo.png";
  //Card
  static const String CALENDAR_ICON = "$ICONS/calendar_icon.png";
  static const String MAIL_ICON = "$ICONS/mail.png";

  //Social Login
  static const String ENVALOPE_ICON = "$ICONS/envalope_icon.png";
  static const String PHONE_ICON = "$ICONS/phone_icon.png";
  static const String GOOGLE_ICON = "$ICONS/google_icon.png";
  static const String APPLE_ICON = "$ICONS/apple_icon.png";

  //Complete Profile
  static const String USER_IMAGE = "$IMAGES/user_img.png";
  static const String CAMERA_ICON = "$ICONS/camera_hover_icon.png";
  static const String CHECK_CIRCLE_ICON = "$ICONS/check_circle.png";
  static const String CROSS_CIRCLE_ICON = "$ICONS/delete_circle.png";
  static const String CANCEL_ICON = "$ICONS/cancel_icon.png";

  //Bottom Navigation bar
  static const String home_icon_bottom_focused =
      "$ICONS/home_icon_bottom_focused.png";
  static const String home_icon_bottom_unfocused =
      "$ICONS/home_icon_bottom_unfocused.png";
  static const String vision_icon_bottom_focused =
      "$ICONS/vision_icon_bottom_focused.png";
  static const String vision_icon_bottom_unfocused =
      "$ICONS/vision_icon_bottom_unfocused.png";
  static const String quotes_icon_bottom_focused =
      "$ICONS/quotes_icon_bottom_focused.png";
  static const String quotes_icon_bottom_unfocused =
      "$ICONS/quotes_icon_bottom_unfocused.png";
  static const String profile_icon_bottom_focused =
      "$ICONS/profile_icon_bottom_focused.png";
  static const String profile_icon_bottom_unfocused =
      "$ICONS/profile_icon_bottom_unfocused.png";

  //Profile Screen
  static const String EDIT_ICON = "$ICONS/edit_icon.png";

  //Quotes Screen
  static const String CARD_PICTURE = "$IMAGES/picture_01.jpeg";

  //Appbar
  static const String LEADING__MENU_ICON = "$ICONS/leading_icon.png";
  static const String BELL_ICON = "$ICONS/bell_icon.png";

  //homeScreen
  static const String SEARCH_ICON = "$ICONS/search_icon.png";

  //goaldetail
  static const String PDF_ICON = "$ICONS/pdf_icon.png";
  static const String TRAILING_MENU_ICON = "$ICONS/menu_icon.png";
  static const String CROSS_ICON = "$ICONS/cross.png";

  //createGoal
  static const String CLOUD_ICON = "$ICONS/cloud_icon.png";
  static const String CALENDER_ICON = "$ICONS/calendar_icon.png";

  //visionBoard
  static const String VISION_BOARD_PICTURE = "$IMAGES/vision_board_image.jpeg";

  //drawer
  static const String HOME_ICON = "$ICONS/drawer_home_icon.png";
  static const String REMINDERS_ICON = "$ICONS/drawer_reminder_icon.png";
  static const String SETTINGS_ICON = "$ICONS/drawer_setting_icon.png";
  static const String PRIVACY_ICON = "$ICONS/drawer_policy_icon.png";
  static const String TERMS_ICON = "$ICONS/drawer_terms_icon.png";
  static const String ABOUT_ICON = "$ICONS/drawer_about_icon.png";
  static const String LOGOUT_ICON = "$ICONS/drawer_logout_icon.png";
  static const String CANCEL_ICON_DRAWER = "$ICONS/cancel_drawer_icon.png";

  static const String EMPTY_IMAGE_VENUE_PLACEHOLDER =
      "$PLACEHOLDERS/gray_image.png";
  // static const String EMPTY_LIST_PLACEHOLDER = "$PLACEHOLDERS/calendar.png";
  static const String EMPTY_LIST_PLACEHOLDER =
      "$PLACEHOLDERS/no_data_found.png";
  static const String FILTER_ICON = "$ICONS/filter_icon.png";
  static const String SEARCH = "$ICONS/search.png";

  //! New Icons Starts From Here
  static const String FNAME_ICON = "$ICONS/fname_icon.png";
  static const String NEAREASTADDRESS_ICON = "$ICONS/location_icon.png";
  static const String PASSWORD_ICON = "$ICONS/password_icon.png";
  static const String EMAIL_ICON = "$ICONS/email_icon.png";
  static const String PHONE_ICON_LOGIN = "$IMAGES/callblack.png";
  static const String PHONE = "$IMAGES/phoneicon.png";

  //Bottom Navigation Icons
  static const String HOME_ICON_BOTTOM_NAVIGAITON =
      "$IMAGES/home_icon_bottom.png";
  static const String FAV_ICON_BOTTOM_NAVIGAITON =
      "$IMAGES/fav_icon_bottom.png";
  static const String SETTINGS_ICON_BOTTOM_NAVIGAITON =
      "$IMAGES/settings_icon_bottom.png";
  static const String WALLET_ICON_BOTTOM_NAVIGAITON =
      "$IMAGES/wallet_icon_bottom.png";
  // static const String BELL_ICON_BOTTOM_NAVIGAITON = "$IMAGES/home/bellicon.png";
  // static const String NOTIFICATION_ICON_BOTTOM_NAVIGAITON =
  //     "$IMAGES/home/bell_icon.png";

  static const String BELL_ICON_BOTTOM_NAVIGAITON = "$IMAGES/noti.png";
  static const String NOTIFICATION_ICON_BOTTOM_NAVIGAITON = "$IMAGES/noti.png";
  // static const String CART_ICON_BOTTOM_NAVIGAITON = "$IMAGES/home/lockicon.png";
  static const String CART_ICON_BOTTOM_NAVIGAITON = "$IMAGES/cart.png";
  static const String STORE_ICONM = "$ICONS/store.png";
  // static const String LOCK_ICON_BOTTOM_NAVIGAITON = "$IMAGES/home/carticon.png";
  static const String LOCK_ICON_BOTTOM_NAVIGAITON = "$IMAGES/cart_icon.png";
  static const String WALLET_GREY = "$IMAGES/wallet_card.png";

  static const String WALLET_COIN = "$IMAGES/wallet_screen_coin.png";
  static const String HEART_ICON = "$IMAGES/home/heart.png";
  static const String STAR_ICON = "$IMAGES/star_icon.png";

  static const String BACK_ICON_DETAIL = "$IMAGES/back_icon.png";
  static const String HEART_ICON_DETAIL = "$IMAGES/heart_icon.png";
  static const String CART_ICON_DETAIL = "$IMAGES/cart_icon.png";
  static const String FILLED_HEART_ICON = "$IMAGES/filled_heart_icon.png";
  static const String VISA_ICON = "$ICONS/visa.png";
  static const String CASH_ICON = "$ICONS/cash.png";
  static const String TOKEN_ICON = "$ICONS/token.png";
  static const String COIN_ICON = "$ICONS/coin.png";
  static const String QR_ICON = "$ICONS/qr.png";

  // cash_image.png
  // jtc_coin_alert.png

  //Revamped bottom nav bar icons
  //Bottom Navigation Icons
  static const String HOME_BOTTOM_NAVIGAITON = "$REVAMPED/home.png";
  static const String FAV_BOTTOM_NAVIGAITON = "$REVAMPED/favorite.png";
  static const String WALLET_BOTTOM_NAVIGAITON = "$REVAMPED/wallet.png";
  static const String PERSON_BOTTOM_NAVIGAITON = "$REVAMPED/person.png";
}
