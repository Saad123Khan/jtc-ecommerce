class AppFonts {
  static const String defaultFont = "Outfit";
}
