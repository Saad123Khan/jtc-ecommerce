import 'dart:io';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_google_places_hoc081098/flutter_google_places_hoc081098.dart';
import 'package:google_maps_webservice/places.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_strings.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:place_picker/entities/localization_item.dart';
import 'package:place_picker/place_picker.dart';

class Constants {

  static List<Locale> supportedLocales = [Locale('en'), Locale('es')];
  static String translationPath = "assets/translations";
  //! ============> Address Picker
  static Future<Prediction?> addressPicker(BuildContext context) {
    return PlacesAutocomplete.show(
        offset: 0,
        logo: const Text(""),
        types: [],
        strictbounds: false,
        context: context,
        apiKey: googleApiKey,
        mode: Mode.overlay,
        language: context.locale == 'es' ? "es" : "en"

        //  "en",

        );
  }

  static ImageProvider<Object> getImageProvider({
    required String imagePath,
    bool updatingProfile = true,
  }) {
    return updatingProfile
        ? NetworkImage(imagePath) as ImageProvider
        : FileImage(File(imagePath));
  }

  //!-----Captital First Letter
  String capitalize(String input) {
    return input.isNotEmpty
        ? "${input[0].toUpperCase()}${input.substring(1)}"
        : input;
  }

  static Widget fadeNetworkImage({
    required String imagePath,
  }) {
    return FadeInImage(
      placeholder: AssetImage(AssetPaths.USER_IMAGE),
      image: getImageProvider(imagePath: imagePath),
      fit: BoxFit.cover,
      imageErrorBuilder: (context, error, stackTrace) {
        print("Error loading image: $error");
        // You can customize the error message or return a different widget here
        return Container(
          color: Colors.grey, // Placeholder color in case of an error
          child: Center(
            child: Image.file(
              File(imagePath),
              fit: BoxFit.cover,
            ),
          ),
        );
      },
    );
  }

  static DateTime extractDate2(String dateTimeString) {
    // Parse the String into a DateTime object
    // Parse the String into a DateTime object
    DateTime dateTime = DateFormat('MM/dd/yyyy').parse(dateTimeString);

    return dateTime;
  }

  //! ============> Date converter from  11/14/1991 to this 14-11-1991
  static String convertDOBFormatered(String inputDOB) {
    try {
      DateTime dobDate = DateFormat("MM/dd/yyyy").parse(inputDOB);
      return DateFormat("dd-MM-yyyy").format(dobDate);
    } catch (e) {
      // Handle any parsing or formatting errors here
      print("Error: $e");
      return "Invalid DOB";
    }
  }

  //! ============> Checking 18 or 18+ Date for DateTime Validation
  static bool isAdult(String birthDateString) {
    String datePattern = "dd-MM-yyyy";

    DateTime birthDate = DateFormat(datePattern).parse(birthDateString);
    DateTime today = DateTime.now();

    int yearDiff = today.year - birthDate.year;
    int monthDiff = today.month - birthDate.month;
    int dayDiff = today.day - birthDate.day;

    return yearDiff >= 18 ||
        yearDiff == 18 && monthDiff > 0 ||
        yearDiff == 18 && monthDiff == 0 && dayDiff >= 0;
  }

  //! ============> Date converter from  11/14/1991 to this 2000-12-31
  static String convertDOBForCompleteProfile(String inputDOB) {
    try {
      DateTime dobDate = DateFormat("MM/dd/yyyy").parse(inputDOB);
      return DateFormat("yyyy-MM-dd").format(dobDate);
    } catch (e) {
      // Handle any parsing or formatting errors here
      print("Error: $e");
      return "Invalid DOB";
    }
  }

  static GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

  static const String EMAIL_VALIDATION_REGEX =
      r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';

  static const String PASSWORD_VALIDATE_REGEX =
      r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$';

  static const String PHONE_NO_VALIDATION_REGEX = r'^[+][0-9]*$';

  static const String SPECIAL_CHARACTERS_REGEX = r'[^\d]';

  static const EMAIL_MAX_LENGTH = 35;
  static const PASSWORD_MAX_LENGTH = 30;
  static const NAME_MAX_LENGTH = 30;
  static const ZIP_CODE_MAX_LENGTH = 7;
  static const DESCRIPTION_MAX_LENGTH = 275;
  static const NO_OF_FOLLOWERS_LENGTH = 9;
  static const NO_OF_GUESTS_LENGTH = 6;

  //Mask Text Formatter For Phone No
  // static MaskTextInputFormatter MASK_TEXT_FORMATTER_PHONE_NO =
  //     MaskTextInputFormatter(
  //         mask: '(###) ###-####',
  //         filter: {"#": RegExp(r'[0-9]')},
  //         type: MaskAutoCompletionType.lazy);

  static MaskTextInputFormatter MASK_TEXT_FORMATTER_PHONE_NO =
      MaskTextInputFormatter(
    mask: '(###) ###-####',
    filter: {"#": RegExp(r'[0-9]')},
    type: MaskAutoCompletionType.lazy,
  );

  static MaskTextInputFormatter MASK_TEXT_FORMATTER_CARD_NUMBER =
      MaskTextInputFormatter(
    mask: '####-####-####-####',
    filter: {"#": RegExp(r'[0-9]')},
    type: MaskAutoCompletionType.lazy,
  );

  static MaskTextInputFormatter MASK_TEXT_FORMATTER_PHONE_CODE =
      MaskTextInputFormatter(
          mask: '###',
          filter: {"#": RegExp(r'[0-9]')},
          type: MaskAutoCompletionType.lazy);

  static MaskTextInputFormatter MASK_TEXT_FORMATTER_PHONE_HALF_NUMBER =
      MaskTextInputFormatter(
          mask: '###-####',
          filter: {"#": RegExp(r'[0-9]')},
          type: MaskAutoCompletionType.lazy);

  //Email Regex Expression
  static RegExp EMAIL_REGEX_EXPRESSION = RegExp(EMAIL_VALIDATION_REGEX);

  //Password Regex Expression
  static RegExp PASSWORD_REGEX_EXPRESSION = RegExp(PASSWORD_VALIDATE_REGEX);

  //Phone No Regex Expression
  static RegExp PHONE_NO_REGEX_EXPRESSION = RegExp(PHONE_NO_VALIDATION_REGEX);

  //Special Characters Regex Expression
  static RegExp SPECIAL_CHARACTERS_REGEX_EXPRESSION =
      RegExp(SPECIAL_CHARACTERS_REGEX);

  //MaskTextInputFormatter for Card Number Field
  // static MaskTextInputFormatter cardNumberMaskFormatter =
  // MaskTextInputFormatter(
  //     mask: '#### #### #### ####', filter: {"#": RegExp(r'[0-9]')});

  //Google Auto Places Api Key
  static const String googleApiKey = "AIzaSyBmaS0B0qwokES4a_CiFNVkVJGkimXkNsk";

  static Future<Map<String, dynamic>> findStreetAreaMethod(
      {required BuildContext context, String? prediction}) async {
    Map<String, dynamic>? addressDetail = {
      "address": null,
      "city": null,
      "state": null
    };

    try {
      List? addressInArray = prediction?.split(",");
      print("Address in array:${addressInArray}");
      String address = "";
      if (addressInArray != null) {
        if (addressInArray.length == 1) {
          addressDetail["address"] = addressInArray[0];
        } else {
          for (int i = 0; i < addressInArray.length - 2; i++) {
            address = address + addressInArray[i];
          }
          print("Check the address:${addressDetail}");
          addressDetail["address"] = address;
          addressDetail["state"] =
              (addressInArray[addressInArray.length - 1] ?? "");
          addressDetail["city"] =
              (addressInArray[addressInArray.length - 2] ?? "");
        }
      }
    } catch (e) {
      print("error:${e}");
    }
    return addressDetail;
  }

  // static Future<Prediction?> addressPicker(BuildContext context) {
  //   return PlacesAutocomplete.show(
  //     offset: 0,
  //     logo: const Text(""),
  //     types: [],
  //     strictbounds: false,
  //     context: context,
  //     apiKey: googleApiKey,
  //     mode: Mode.overlay,
  //     language: "en",
  //     //! New
  //     // components: [
  //     //   Component(Component.country, "PK"),
  //     //   Component(Component.administrativeArea, "SD"),
  //     //   Component(Component.locality, "Karachi")
  //     // ],
  //   );
  // }

  //------------------ App Font Family -------------------//
  static const String APP_FONT_FAMILY = "Poppins-Regular";

  static MaterialColor PRIMARY_SWATCH_COLOR =
      MaterialColor(0xff000000, <int, Color>{
    50: Color(0xff000000),
    100: Color(0xff000000),
    200: Color(0xff000000),
    300: Color(0xff000000),
    400: Color(0xff000000),
    500: Color(0xff000000),
    600: Color(0xff000000),
    700: Color(0xff000000),
    800: Color(0xff000000),
    900: Color(0xff000000),
  });

  // static Future<void> timePickerWidget({
  //   required BuildContext context,
  //   final ValueChanged<String?>? getSelectedDate,
  // }) async {
  //   // return
  //   final TimeOfDay? timePicked = await showTimePicker(
  //     context: context,
  //     initialTime: TimeOfDay(hour: 0, minute: 0),
  //     builder: (BuildContext context, Widget? child) {
  //       return Theme(
  //         data: ThemeData.dark().copyWith(
  //           colorScheme: ColorScheme.light(
  //             //header color light(white)
  //             primary: AppColors.PINK_TEXT_COLOR, //! header background color
  //             onPrimary: AppColors.WHITE_COLOR, //!(Today or select date color)
  //             surface: AppColors.WHITE_COLOR,
  //             onSurface: AppColors.BLACK_COLOR, //! body text color
  //           ),
  //           textTheme: const TextTheme(
  //             titleMedium: TextStyle(
  //               color: AppColors.BLACK_COLOR,
  //             ),
  //           ),
  //           dialogBackgroundColor: AppColors.PINK_TEXT_COLOR,
  //         ),
  //         child: child!,
  //       );
  //     },
  //   );
  //   if (timePicked != null) {
  //     // String _selectedDate = Constants.formatTime(
  //       // parseFormat: AppStrings.DATE_MONTH_YEAR_FORMAT_YYYY_MM_DD,
  //       // inputDateTime: timePicked,
  //     // );
  //     getSelectedDate!(timePicked.toString());
  //   }
  // }
  static Future<void> showSelectTimePicker({
    BuildContext? context,
    final ValueChanged<String?>? getSelectedTime,
    // String? getSelectedTime,
    // bool? disabledPastTime = true,
  }) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context!,
      initialTime: TimeOfDay.now(),
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(
              primary: AppColors.PRIMARY_COLOR, // header background color
            ),
            textButtonTheme: TextButtonThemeData(
              style: TextButton.styleFrom(
                primary: AppColors.PRIMARY_COLOR, // button text color
              ),
            ),
          ),
          child: Hero(tag: "selectTime", child: child!),
        );
      },
    );
    if (picked != null) {
      String _selectedTime = picked.format(context);
      print("_selectedTime: $_selectedTime");
      // getSelectedTime = _selectedTime;
      getSelectedTime != null ? getSelectedTime(_selectedTime) : "";
      print("Picker: $getSelectedTime");
    }
    // if (getSelectedTime != null) {
    //   String _selectedTime = picked!.format(context);
    //   getSelectedTime(_selectedTime);
    //   print("getSelectedTime: ${_selectedTime}");
    // }
  }

  // static Future<void> showSelectDatePicker({
  //   BuildContext? context,
  //   final ValueChanged<String?>? getSelectedDate,
  //   bool? disabledPastDate = true,
  // }) async {
  //   final DateTime? picked = await showDatePicker(
  //       context: context!,
  //       initialDate: DateTime.now(),
  //       firstDate: disabledPastDate != null
  //           ? disabledPastDate
  //               ? DateTime.now()
  //               : DateTime(1000)
  //           : DateTime(1000),
  //       lastDate: disabledPastDate != null
  //           ? disabledPastDate
  //               ? DateTime(2101)
  //               : DateTime.now()
  //           : DateTime(2101),
  //       helpText: "Select Date",
  //       builder: (BuildContext context, Widget? child) {
  //         return Theme(
  //           data: Theme.of(context).copyWith(
  //             colorScheme: ColorScheme.light(
  //               primary: AppColors.PRIMARY_COLOR, // header background color
  //               //onPrimary: Colors.black, // header text color
  //               //onSurface: Colors.green, // body text color
  //             ),
  //             textButtonTheme: TextButtonThemeData(
  //               style: TextButton.styleFrom(
  //                 primary: AppColors.PRIMARY_COLOR, // button text color
  //               ),
  //             ),
  //           ),
  //           child: Hero(tag: "selectDate", child: child!),
  //         );
  //       });
  //   if (picked != null) {
  //     String _selectedDate = Constants.formatDateTime(
  //         parseFormat: AppStrings.DATE_MONTH_YEAR_FORMAT_YYYY_MM_DD,
  //         inputDateTime: picked);
  //     getSelectedDate!(_selectedDate);
  //   }
  // }

  //! ============> Only Date selection dialog
  Future<void> showSelectDatePicker({
    BuildContext? context,
    final ValueChanged<String?>? getSelectedDate,
    bool? disabledPastDate = true,
    DateTime? initailDatetime,
  }) async {
    final DateTime? picked = await showDatePicker(
      context: context!,
      locale: context.locale,
      // initialDate: DateTime.now(),
      initialDate: initailDatetime ?? DateTime.now(),
      firstDate: disabledPastDate! ? DateTime.now() : DateTime(1000),
      lastDate: disabledPastDate ? DateTime(2101) : DateTime.now(),
      // helpText: "Select Date",
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(
              primary: AppColors.PRIMARY_COLOR,
            ),
            textButtonTheme: TextButtonThemeData(
              style: TextButton.styleFrom(
                primary: AppColors.PRIMARY_COLOR,
              ),
            ),
          ),
          child: Hero(tag: "selectDate", child: child!),
        );
      },
    );
    if (picked != null) {
      // authSingletonUserRole.utcDateSavedTemp =
      //     Constants.extractDate(picked.toString());
      String _selectedDate = Constants.formatDateTime(
        parseFormat: AppStrings.DATE_MONTH_YEAR_FORMAT_YYYY_MM_DD,
        inputDateTime: picked,
      );
      getSelectedDate!(_selectedDate);
    }
  }

  static String formatDateTime(
      {required String parseFormat, required DateTime inputDateTime}) {
    return DateFormat(parseFormat).format(inputDateTime);
  }

  String formatTime({required DateTime inputDateTime}) {
    return DateFormat.jm()
        .format(inputDateTime); // "jm" format represents "h:mm a"
  }

  static String convertDateFormat(String originalDate) {
    // Define the input date format
    DateFormat originalFormat = DateFormat('MM/dd/yyyy');

    // Parse the original date string into a DateTime object
    DateTime dateTime = originalFormat.parse(originalDate);

    // Define the desired output format
    DateFormat outputFormat = DateFormat('dd-MM-yyyy');

    // Format the DateTime object to the desired output format
    String formattedDate = outputFormat.format(dateTime);

    return formattedDate;
  }

  static String oppositeConvertDateFormat(String originalDate) {
    if (originalDate.isNotEmpty) {
      // Define the input date format
      DateFormat originalFormat = DateFormat('dd-MM-yyyy');

      // Parse the original date string into a DateTime object
      DateTime dateTime = originalFormat.parse(originalDate);

      // Define the desired output format
      DateFormat outputFormat = DateFormat('MM/dd/yyyy');

      // Format the DateTime object to the desired output format
      String formattedDate = outputFormat.format(dateTime);
      return formattedDate;
    } else {
      return originalDate;
    }
  }

  static String convertTo24HourFormat(String time) {
    final inputFormat = DateFormat('h:mm a', 'en_US'); // Specify the locale
    final outputFormat = DateFormat('HH:mm');

    final dateTime = inputFormat.parse(time);
    final formattedTime = outputFormat.format(dateTime);

    return formattedTime;
  }

  static String convertTo12HourFormat(String time) {
    final inputFormat = DateFormat('HH:mm');
    final outputFormat = DateFormat('h:mm a', 'en_US');

    final dateTime = inputFormat.parse(time);
    final formattedTime = outputFormat.format(dateTime);

    return formattedTime;
  }

  static String formatDateTimeAgo(String dateString) {
    // Parse the input date string
    DateTime dateTime = DateTime.parse(dateString);

    // Calculate the difference between the current date and the input date
    Duration difference = DateTime.now().difference(dateTime);

    // Convert the difference to days
    int days = difference.inDays;

    // Format the output string based on the number of days
    if (days == 0) {
      return 'Today';
    } else if (days == 1) {
      return 'Yesterday';
    } else {
      return '$days days ago';
    }
  }

  static Future<LocationResult?> showPlacePicker(context) async {
    LocationResult? result = await Navigator.of(context).push(MaterialPageRoute(
      builder: (context) => PlacePicker(
        googleApiKey,
        langCode: context.locale.languageCode,
        localizationItem: LocalizationItem(
            languageCode: context.locale.languageCode,
            nearBy: context.locale.languageCode == "es"
                ? "Lugares cercanos"
                : "Nearby Places",
            tapToSelectLocation: context.locale.languageCode == "es"
                ? "Toque aquí para seleccionar la ubicación"
                : "Tap Here to Select Location",
            findingPlace: context.locale.languageCode == "es"
                ? "Buscando lugar..."
                : "Finding Place...",
            unnamedLocation: context.locale.languageCode == "es"
                ? "Ubicación sin nombre"
                : "Unnamed location",
            noResultsFound: context.locale.languageCode == "es"
                ? "No se han encontrado resultados"
                : "No Results Found"),
      ),
    ));
    return result;
  }
}
