// import 'package:another_flushbar/flushbar.dart';
import 'dart:ui';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/widgets/custom_button.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';


class AppDialogs {
  static void showToast({
    String? message,
    Toast? toastLength,
    int? timeInSecForIosWeb,
  }) {
    Fluttertoast.showToast(
      msg: message ?? "",
      toastLength: toastLength ?? Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      timeInSecForIosWeb: timeInSecForIosWeb ?? 1,
    );
  }

  //! ============> Spinkit for API call
  static void progressAlertDialog({required BuildContext context}) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return PopScope(
          canPop: false,
          child: Stack(
            fit: StackFit.loose,
            children: [
              Positioned.fill(
                  child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 4, sigmaY: 4),
                child: const SizedBox(),
              )),
              const Center(
                child: CircularProgressIndicator(
                  backgroundColor: AppColors.WHITE_COLOR,
                  color: AppColors.PRIMARY_COLOR,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  static void showAppDialog({
    required BuildContext context,
    required Widget child,
    bool dismissable = false,
  }) {
    showDialog(
      context: context,
      barrierDismissible: dismissable,
      builder: (context) {
        return PopScope(
          canPop: false,
          child: Stack(
            fit: StackFit.loose,
            children: [
              Positioned.fill(
                  child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 4, sigmaY: 4),
                child: const SizedBox(),
              )),
              Center(child: child)
            ],
          ),
        );
      },
    );
  }

  static void showBottomSheetttttt(
      {required BuildContext context,
      void Function()? onTap,
      bool showButton = true,
      String image = "assets/images/verified_logo.png",
      String firstHeading =
          //  "Verified!",
          'continue_dialog',
      String secondHeading =
          // "Hurrah! You have successfully",

          'hurah_Gialog',
      String thirdHeading =
          // "verified the account",
          'account_verified_Dialog'}) {
    showModalBottomSheet(
      backgroundColor: Colors.transparent,
      context: context,
      builder: (context) => Container(
        height: 400.h,
        width: double.infinity,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(20),
            topRight: Radius.circular(20),
          ),
        ),
        child: Column(
          children: [
            20.verticalSpace,
            Image.asset(image),
            // Image.asset('assets/images/coinbasket.png'),
            20.verticalSpace,
            Container(
              width: Get.width,
              padding: EdgeInsets.all(4.0),
              decoration: BoxDecoration(
                color: AppColors.RED_GMAIL_COLOR,
              ),
              child: Text(
                // 'Verified!',
                firstHeading,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w600,
                  color: AppColors.WHITE_COLOR,
                ),
              ).tr(),
            ),
            10.verticalSpace,
            Text(
              // 'Hurrah! You have successfully',
              secondHeading,
              style: TextStyle(
                color: Color(0xFF3D3D3D),
                fontSize: 16,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w400,
              ),
            ).tr(),
            10.verticalSpace,
            Text(
              // 'verified the account',
              thirdHeading,
              style: TextStyle(
                color: Color(0xFF3D3D3D),
                fontSize: 16,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w400,
              ),
            ).tr(),
            20.verticalSpace,
            showButton
                ? GestureDetector(
                    onTap: onTap,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 15),
                      child: Container(
                        width: 344,
                        height: 50,
                        decoration: BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Center(
                          child: Text(
                            // 'Continue',
                            tr('continue_dialog'),
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                  )
                : SizedBox.shrink(),
          ],
        ),
      ),
    );
  }

// //Dialog Box With Single Button
//   Future<void> showDialogForSingleButton({
//     required BuildContext context,
//     required String assetPath,
//     required String buttonText,
//     required dynamic Function()? onTap,
//     String? titleText,
//   }) async {
//     return showDialog<void>(
//       // barrierColor: Colors.white.withOpacity(0.5),
//       context: context,
//       barrierDismissible: false,
//       builder: (BuildContext context) {
//         return BackdropFilter(
//           filter: CustomBlurFilter.getBlurFilter(),
//           child: Dialog(
//             backgroundColor: AppColors.WHITE_COLOR,
//             insetPadding:
//                 const EdgeInsets.symmetric(horizontal: 20, vertical: 10.0),
//             shape: RoundedRectangleBorder(
//                 borderRadius: BorderRadius.circular(20.r)),
//             elevation: 5,
//             child: SingleChildScrollView(
//               child: Column(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   _dialogTitle(
//                       context, titleText ?? AppStrings.SUCESSFULL_TEXT),
//                   20.verticalSpace,
//                   _tickContainer(assetPath: assetPath, height: 130.h),
//                   _continueButton(
//                     context: context,
//                     buttonName: buttonText,
//                     onTap: onTap,
//                   ),
//                   10.verticalSpace,
//                 ],
//               ),
//             ),
//           ),
//         );
//       },
//     );
//   }

// //Dialog Box With Single Button With Content Text
  Future<void> showDialogForSingleButtonWithContentText({
    required BuildContext context,
    required String assetPath,
    required String buttonText,
    required String contentText,
    required dynamic Function()? onTap,
    String? titleText,
  }) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      barrierColor: AppColors.BLACK_COLOR.withOpacity(0.8),
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: AppColors.WHITE_COLOR,
          insetPadding:
              const EdgeInsets.symmetric(horizontal: 20, vertical: 10.0),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.r)),
          elevation: 5,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _dialogTitle(context, titleText ?? 'successfully'),
                20.verticalSpace,
                _tickContainer(assetPath: assetPath),
                20.verticalSpace,
                _description(contentText: contentText),
                5.verticalSpace,
                _continueButton(
                  context: context,
                  buttonName: buttonText,
                  onTap: onTap,
                ),
                20.verticalSpace,
              ],
            ),
          ),
        );
      },
    );
  }

  //Will pop dialog
  Future<void> willpopDialog({
    required BuildContext context,
  }) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      barrierColor: AppColors.BLACK_COLOR.withOpacity(0.8),
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: AppColors.WHITE_COLOR,
          insetPadding:
              const EdgeInsets.symmetric(horizontal: 20, vertical: 10.0),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.r)),
          elevation: 5,
          child: Container(
            height: 120.h,
            decoration: BoxDecoration(
                color: AppColors.TRANSPARENT_COLOR,
                borderRadius: BorderRadius.circular(5.sp)),
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 5.sp),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  CustomText(
                    text: 'are_you_sure',
                    isLeftAlign: false,
                    fontsize: 14.sp,
                  ),
                  10.verticalSpace,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Expanded(
                        child: CustomButton(
                          height: 40.h,
                          buttonColor: AppColors.PRIMARY_COLOR,
                          onTap: () => SystemNavigator.pop(),
                          buttonText: 'yes',
                        ),
                      ),
                      7.horizontalSpace,
                      Expanded(
                        child: CustomButton(
                          height: 40.h,
                          buttonColor: AppColors.PRIMARY_COLOR,
                          onTap: () {
                            AppNavigation.navigatorPop(context);
                          },
                          buttonText: 'no',
                        ),
                      ),
                    ],
                  ),
                  10.verticalSpace,
                ],
              ),
            ),
          ),
        );
      },
    );
  }

// //Dialog Box With Two Buttons in a Row
  Future<void> showDialogForRowRowTwoButtons({
    required BuildContext context,
    required String assetPath,
    required String contentText,
    required String firstButtonText,
    Color? firstButtonColor,
    required String secondButtonText,
    required dynamic Function()? onTapFirstButton,
    required dynamic Function()? onTapSecondButton,
    String? titleText,
  }) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: AppColors.WHITE_COLOR,
          insetPadding:
              const EdgeInsets.symmetric(horizontal: 20, vertical: 10.0),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.r)),
          elevation: 5,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _dialogTitle(context, titleText ?? 'successfully'),
                20.verticalSpace,
                _tickContainer(assetPath: assetPath),
                15.verticalSpace,
                _description(contentText: contentText),
                Row(
                  children: [
                    17.5.horizontalSpace,
                    Expanded(
                      child: _continueButton(
                        context: context,
                        buttonColor: firstButtonColor,
                        buttonName: firstButtonText,
                        onTap: onTapFirstButton,
                      ),
                    ),
                    Expanded(
                      child: _continueButton(
                        context: context,
                        buttonName: secondButtonText,
                        onTap: onTapSecondButton,
                      ),
                    ),
                    17.5.horizontalSpace
                  ],
                ),
                10.verticalSpace,
              ],
            ),
          ),
        );
      },
    );
  }

// //Dialog Box With Two Buttons in a Column Second button has no border and Description textfield
//   Future<void> showDialogForColumnTwoButtonsSecondButtonHasBorderWithTextfield({
//     required BuildContext context,
//     required String assetPath,
//     required String firstButtonText,
//     required String secondButtonText,
//     required dynamic Function()? onTapFirstButton,
//     required dynamic Function()? onTapSecondButton,
//     TextEditingController? descriptionTextController,
//     String? validatorString,
//     String? titleText,
//     BoxBorder? border,
//   }) async {
//     return showDialog<void>(
//       context: context,
//       barrierDismissible: false,
//       builder: (BuildContext context) {
//         return BackdropFilter(
//           filter: CustomBlurFilter.getBlurFilter(),
//           child: Dialog(
//             backgroundColor: AppColors.WHITE_COLOR,
//             insetPadding:
//                 const EdgeInsets.symmetric(horizontal: 20, vertical: 10.0),
//             shape: RoundedRectangleBorder(
//                 borderRadius: BorderRadius.circular(20.r)),
//             elevation: 5,
//             child: SingleChildScrollView(
//               child: Column(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   _dialogTitle(
//                       context, titleText ?? AppStrings.SUCESSFULL_TEXT),
//                   20.verticalSpace,
//                   _tickContainer(assetPath: assetPath),
//                   15.verticalSpace,
//                   _descriptionField(
//                     descriptionTextController: descriptionTextController,
//                     validatorString: validatorString,
//                     textInputFormattors: [
//                       LengthLimitingTextInputFormatter(
//                         Constants.DESCRIPTION_MAX_LENGTH,
//                       ),
//                     ],
//                   ),
//                   Column(
//                     children: [
//                       _continueButton(
//                         context: context,
//                         buttonName: firstButtonText,
//                         onTap: onTapFirstButton,
//                       ),
//                       GestureDetector(
//                         onTap: onTapSecondButton,
//                         child: Container(
//                           height: 60.h,
//                           margin: const EdgeInsets.symmetric(horizontal: 24.0),
//                           decoration: BoxDecoration(
//                             border: border ??
//                                 Border.all(
//                                   color: AppColors.PINK_TEXT_COLOR,
//                                 ),
//                             borderRadius: BorderRadius.circular(10.r),
//                           ),
//                           child: CustomText(
//                             text: secondButtonText,
//                             isLeftAlign: false,
//                             fontsize: 18.sp,
//                             fontFamily: AppFonts.poppinsSemiBold,
//                             color: AppColors.PINK_TEXT_COLOR,
//                           ),
//                         ),
//                       ),
//                     ],
//                   ),
//                   20.verticalSpace,
//                 ],
//               ),
//             ),
//           ),
//         );
//       },
//     );
//   }

//Dialog Box With Two Button in a Column Second button has border
  Future<void> showDialogForColumnTwoButtonSecondButtonHasBorder({
    required BuildContext context,
    required String assetPath,
    required String contentText,
    required String firstButtonText,
    required String secondButtonText,
    required dynamic Function()? onTapFirstButton,
    required dynamic Function()? onTapSecondButton,
    String? titleText,
  }) async {
    return showDialog<void>(
      // barrierColor: Colors.redAccent.withOpacity(0.2),
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: AppColors.WHITE_COLOR,
          insetPadding:
              const EdgeInsets.symmetric(horizontal: 20, vertical: 20.0),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.r)),
          elevation: 5,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _dialogTitle(context, titleText ?? "Success"),
                20.verticalSpace,
                _tickContainer(assetPath: assetPath),
                20.verticalSpace,
                _description(contentText: contentText),
                Column(
                  children: [
                    //Saad
                    _continueButtonDelete(
                      context: context,
                      buttonName: firstButtonText,
                      onTap: onTapFirstButton,
                    ),
                    10.verticalSpace,
                    GestureDetector(
                      onTap: onTapSecondButton,
                      child: Container(
                        height: 60.h,
                        margin: const EdgeInsets.symmetric(horizontal: 24.0),
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: AppColors.PRIMARY_COLOR,
                          ),
                          borderRadius: BorderRadius.circular(10.r),
                        ),
                        child: CustomText(
                          text: secondButtonText,
                          isLeftAlign: false,
                          fontsize: 18.sp,
                          color: AppColors.PRIMARY_COLOR,
                        ),
                      ),
                    ),
                  ],
                ),
                20.verticalSpace,
              ],
            ),
          ),
        );
      },
    );
  }

  // Future<void> filterDialogForQuoteSearch({
  //   required BuildContext context,
  //   required List<GetCategoriesList> categoriesList,
  //   required void Function(int?)? onChangedRadioButton,
  //   required int? groupValue,
  //   String? titleText,
  // }) async {
  //   return showDialog<void>(
  //     barrierColor: Colors.black.withOpacity(0.2),
  //     context: context,
  //     barrierDismissible: false,
  //     builder: (BuildContext context) {
  //       return Dialog(
  //         backgroundColor: AppColors.WHITE_COLOR,
  //         insetPadding:
  //             const EdgeInsets.symmetric(horizontal: 20, vertical: 20.0),
  //         shape:
  //             RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.r)),
  //         elevation: 5,
  //         child: SingleChildScrollView(
  //           child: Column(
  //             mainAxisSize: MainAxisSize.min,
  //             children: [
  //               _dialogTitle(context, titleText ?? "Success"),
  //               SingleChildScrollView(
  //                 physics: AlwaysScrollableScrollPhysics(
  //                   parent: BouncingScrollPhysics(),
  //                 ),
  //                 child: Column(
  //                   children: [
  //                     for (int i = 0; i < categoriesList.length; i++)
  //                       RadioListTile<int>(
  //                         title: Text(categoriesList[i].name.toString()),
  //                         value: i,
  //                         groupValue: groupValue,
  //                         onChanged: onChangedRadioButton,
  //                       ),
  //                   ],
  //                 ),
  //               ),
  //               20.verticalSpace,
  //             ],
  //           ),
  //         ),
  //       );
  //     },
  //   );
  // }

// //Dialog Box With Multiple Radio Buttons and textfield also 1 button
//   Future showDisputeDialog(
//       {required BuildContext context, required String title}) {
//     return showDialog(
//       barrierDismissible: false,
//       context: context,
//       // barrierColor: AppColors.APP_GREY_COLOR.withOpacity(0.8),
//       builder: (context) {
//         return DisputeDialog(title: title);
//       },
//     );
//   }

// //Dialog Box With 5 rating stars and one button
//   Future showDisputeDialogWithStarRating(context) {
//     return showDialog(
//       barrierDismissible: false,
//       context: context,
//       // barrierColor: AppColors.APP_GREY_COLOR.withOpacity(0.8),
//       builder: (context) {
//         return StarRatingDialog();
//       },
//     );
//   }

//   //Dialog Box With 5 rating stars and one button
//   Future showDisputeDialogForInivitingInlfuencer(context) {
//     return showDialog(
//       barrierDismissible: false,
//       context: context,
//       // barrierColor: AppColors.APP_GREY_COLOR.withOpacity(0.8),
//       builder: (context) {
//         return InviteInfluencerDialog();
//       },
//     );
//   }

//Widgets For Dialog
  Widget _dialogTitle(context, String titleText) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.PRIMARY_COLOR,
        // gradient: LinearGradient(
        //     begin: Alignment.topCenter,
        //     end: Alignment.bottomCenter,
        //     colors: [AppColors.COAL_COLOR, AppColors.RED_COLOR]),
        borderRadius: BorderRadius.only(
          topRight: Radius.circular(10.r),
          topLeft: Radius.circular(10.r),
          bottomLeft: Radius.circular(10.r),
          bottomRight: Radius.circular(10.r),
        ),
      ),
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 12.h),
        child: Row(
          children: [
            SizedBox(width: 20.w),
            const Spacer(),
            CustomText(
              text: titleText,
              color: AppColors.WHITE_COLOR,
              fontsize: 18.sp,
            ),
            const Spacer(),
            GestureDetector(
              onTap: () {
                AppNavigation.navigatorPop(context);
              },
              child: SizedBox(
                width: 30.w,
                child: Image.asset(
                  AssetPaths.CANCEL_ICON,
                  scale: 5.sp,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _continueButton(
      {required BuildContext context,
      required String buttonName,
      required dynamic Function()? onTap,
      Color? buttonColor}) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 2.5.w, vertical: 10.h),
      child: CustomButton(
        buttonColor: buttonColor ?? AppColors.PRIMARY_COLOR,
        onTap: onTap,
        buttonText: buttonName,
        fontSize: 18.sp,
      ),
      // child: Container(
      //   height: 60.h,
      //   margin: const EdgeInsets.symmetric(horizontal: 24.0),
      //   decoration: BoxDecoration(
      //     border: Border.all(
      //       color: AppColors.PRIMARY_COLOR,
      //     ),
      //     color: AppColors.PRIMARY_COLOR,
      //     borderRadius: BorderRadius.circular(10.r),
      //   ),
      //   child: CustomText(
      //     text: buttonName,
      //     isLeftAlign: false,
      //     fontsize: 18.sp,
      //     fontFamily: AppFonts.robotoBold,
      //     color: AppColors.WHITE_COLOR,
      //   ),
      // ),
    );
  }

  Widget _continueButtonDelete(
      {required BuildContext context,
      required String buttonName,
      required dynamic Function()? onTap,
      Color? buttonColor}) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 2.5.w, vertical: 10.h),
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          height: 60.h,
          margin: const EdgeInsets.symmetric(horizontal: 24.0),
          decoration: BoxDecoration(
            border: Border.all(
              color: AppColors.PRIMARY_COLOR,
            ),
            color: AppColors.PRIMARY_COLOR,
            borderRadius: BorderRadius.circular(10.r),
          ),
          child: CustomText(
            text: buttonName,
            isLeftAlign: false,
            fontsize: 18.sp,
            color: AppColors.WHITE_COLOR,
          ),
        ),
      ),
    );
  }

  Widget _tickContainer({required String assetPath, double? height}) {
    return Center(
      child: Image.asset(
        assetPath,
        height: height ?? 80.h,
      ),
    );
  }

  Widget _description({required String contentText}) {
    return SizedBox(
      width: 280.w,
      child: CustomText(
        maxLines: 3,
        isLeftAlign: false,
        text: contentText,
        color: AppColors.BLACK_COLOR,
        fontsize: 16.sp,
      ),
    );
  }

  // Widget _descriptionField(
  //     {String? validatorString,
  //     TextEditingController? descriptionTextController,
  //     List<TextInputFormatter>? textInputFormattors}) {
  //   return Padding(
  //     padding: const EdgeInsets.symmetric(horizontal: 20.0),
  //     child: CustomTextField(
  //       // helpertext: AppStrings.DESCRIPTION,
  //       hintText: AppStrings.DELETE_DIALOG_DESCRIPTION_HINT_TEXT,
  //       hintTextColor: AppColors.BLACK_COLOR,
  //       fontSize: 16.sp,
  //       filled: true,
  //       filledColor: AppColors.DESCRIPTION_COLOR_DELETE_ACCOUNT,
  //       borderColor: AppColors.DESCRIPTION_COLOR_DELETE_ACCOUNT,
  //       focusedColor: AppColors.DESCRIPTION_COLOR_DELETE_ACCOUNT,
  //       enabledBorderColor: AppColors.DESCRIPTION_COLOR_DELETE_ACCOUNT,
  //       // textInputFormattors: [
  //       //   LengthLimitingTextInputFormatter(Constants.DESCRIPTION_MAX_LENGTH)
  //       // ],
  //       textInputFormattors: textInputFormattors,
  //       // textEditingController: controller.descriptionTextController,
  //       // validator: (value) => value?.validateDescription,
  //       textEditingController: descriptionTextController,
  //       validator: (value) => validatorString,
  //       keyboardType: TextInputType.text,
  //       isMultiLine: true,
  //       maxLines: 3,
  //       onChanged: (value) {},
  //     ),
  //   );
  // }
}
