import 'package:easy_localization/easy_localization.dart';
import 'package:get/get.dart';

class FieldValidator2 {
  static bool isHideoldpassword = true;
  static bool isHidepassword = true;
  static bool isHideconfirmpassword = true;
  static const String PASSWORD_VALIDATION_REGEX =
      r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@}#\]{$&:)[*~^_,(+-.<%;/>]).{8,}$';

//------------- hide/Un hide--------------//
  static void oldpassword_hideIcon() {
    if (isHideoldpassword) {
      isHideoldpassword = false;
    } else {
      isHideoldpassword = true;
    }
  }

  static void password_hideIcon() {
    if (isHidepassword) {
      isHidepassword = false;
    } else {
      isHidepassword = true;
    }
  }

  static void confirm_password_hideIcon() {
    if (isHideconfirmpassword) {
      isHideconfirmpassword = false;
    } else {
      isHideconfirmpassword = true;
    }
  }

//------------------ Empty Validator ---------------//
  static String? validatePhone({required String value}) {
    if (value.isEmpty) {
      return "Phone number field can't be empty.";
    } else if (value.length < 16) {
      return "The phone number must be at least 11 characters.";
    }
    return null;
  }

//------------------ Dialog Validator ---------------//
  static String? validateDialog(
      {required String value, required String label}) {
    if (value.isEmpty) {
      return "$label can't be empty.";
    }
    return null;
  }

//------------------ Empty Validator ---------------//
  static String? validateEmpty({required String value, required String label}) {
    if (value.isEmpty) {
      return "$label ${tr('field_cant_be_empty')}";
    }
    return null;
  }

//------------------ Empty Validator ---------------//
  static String? validateNull({required String value, required String label}) {
    if (value == "") {
      return "$label ${tr('field_cant_be_empty')}";
    }
    return null;
  }

//------------------ Email Validator ---------------//
  static String? validateEmail(String value) {
    if (value.isEmpty) {
      return "Email field can't be empty.";
    } else if (!GetUtils.isEmail(value)) {
      return "Please enter valid email.";
    }
    return null;
  }

  //------------------Confirm Email Validator ---------------//
  static String? validateConfirmEmail(String value, String email) {
    if (value.isEmpty) {
      return "Confirm Email address field can't be empty.";
    } else if (!(value == email)) {
      return "Email and Confirm Email must be same.";
    }
    return null;
  }

//----------------Login Password Validator -----------------//
  static String? validateLoginPassword(String value, String? label) {
    if (value.trim().isEmpty) {
      return "$label ${tr('field_cant_be_empty')}";
    } else if (!RegExp(PASSWORD_VALIDATION_REGEX).hasMatch(value)) {
      return "Invalid Password.";
    }
    return null;
  }

//---------------- Password Validator -----------------//
  static String? validatePassword(String value, String? label) {
    if (value.trim().isEmpty) {
      return "$label  ${tr('field_cant_be_empty')}";
    } else if (!RegExp(PASSWORD_VALIDATION_REGEX).hasMatch(value)) {
      return "Password must be of 8 characters long and contain atleast 1 uppercase, 1 lowercase, 1 digit and 1 special character.";
    }
    return null;
  }

//--------------------Confirm Password Validator--------//
  static String? validateConfirmPassword(
      String password, String confirmPassword, String label) {
    if (confirmPassword.isEmpty) {
      return "Confirm Password ${tr('field_cant_be_empty')}";
    } else if (!(password == confirmPassword)) {
      return '$label and Confirm Password must be same.';
    } else if (password.isEmpty) {
      return "Confirm Password ${tr('field_cant_be_empty')}";
    } else {
      return null;
    }
  }

  //-----------------------OTP Validator---------------//
  static String? validatePin(String value) {
    if (value.isEmpty) {
      return "The OTP${tr('field_cant_be_empty')}";
    } else if (value.length == 6) {
      return null;
    }
    return "Invalid OTP verification code.";
  }

//---------------- CVC Validator -----------------//
  static String? validateCVC({required String value, String? label}) {
    if (value.trim().isEmpty) {
      return "$label ${tr('field_cant_be_empty')}";
    } else if (value.length <= 2) {
      return "$label must be atleast 3 digits.";
    }
    return null;
  }

  //---------------- Password Validator -----------------//
  static String? validateCardNo({required String value, String? label}) {
    if (value.trim().isEmpty) {
      return "$label ${tr('field_cant_be_empty')}";
    } else if (value.length <= 15) {
      return "$label must be atleast 16 digits.";
    }
    return null;
  }
  //-----------------------Null Validator---------------//
  // static String? valiadteEmpty(String value) {
  //   if (value.isEmpty || value == null) {
  //     return "Must Provide";
  //   }
  //   return null;
  // }
  //------------- Name Validator--------------//
}
