import 'package:jtc_ecommerce/utils/assets_paths.dart';

class AppStrings {
  //App Name
  static const String APP_TITLE_TEXT = "JTC Ecommerce";

  //Device Type
  static const String ANDROID = "android";
  static const String IOS = "ios";

  //Login Types
  static const String GOOGLE_SOCIAL_TYPE = "Google";
  static const String PHONE_SOCIAL_TYPE = "Phone";
  static const String APPLE_SOCIAL_TYPE = "Apple";

  //Payment is non Refundable
  static const PAYMENT_IS_NON_REFUNDABLE_TEXT = 'Payment is non-refundable';

  //Add New Card
  static const CARD_HOLDER_TEXT = 'Card Holder';
  static const CARD_NUMBER_TEXT = 'Card Number';
  static const EXPIRY_DATE_TEXT = 'Expiry Date';
  static const CVC_TEXT = 'CVC';
  static const ADD_TEXT = 'Add';

  //Lorem Lipsum URL
  static const String TEMP_WEBVIEW_URL = "https://www.lipsum.com/";

  //Social Login
  static const String SOCIAL_LOGIN_HEADING = "Social Login";

  //Date Format
  static const String DATE_MONTH_YEAR_FORMAT_YYYY_MM_DD = "MM/dd/yyyy";

  //Login Screen
  static const String phone_hint = '1234567890';
  static const String INVALID_PHONE_NUMBER_MESSAGE = "invalid phone number";
  static const String INVALID_PHONE_NUMBER = "invalid-phone-number";

  // -------------- Galley Camera Text ---------
  static const String CAMERA_TEXT = "CAMERA";
  static const String GALLERY_TEXT = "GALLERY";
  static const String FILE_TEXT = "FILE";
  static const String IMAGE_TYPE_FILE = "file";
  static const String IMAGE_TYPE_NETWORK = "network";
  static const String IMAGE_TYPE_ASSET = "asset";

  //Terms and Conditions
  static const String bySigningIn = 'By Sign-in, You agree to our\n';
  static const String termsAndCondition = "Terms & Conditions";
  static const privacyPolicy = "Privacy Policy";
  static const String POLICY_AND_TERMS =
      "Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of de Finibus Bonorum et Malorum (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, Lorem ipsum dolor sit amet.., comes from a line in section 1.10.32.";

  // //Complete Profile
  //  static const String profileCompleteToastMsg = "Profile updated successfully";

  //Gallery Camera Text
  static const String IMAGE_FILE_TYPE = "file";
  static const String IMAGE_ASSETS_TYPE = "Asset";
  static const String IMAGE_NETWORK_TYPE = "network";
  static const String SOMETHING_WENT_WRONG_ERROR = "Something went wrong";
  static const String CAMERA = "Camera";
  static const String GALLERY = "Gallery";
  static const String FILE = "File";

  static const String USER_NAME_DRAWER = "John Smith";
  static const String USER_EMAIL = "info@example.com";

  static const List<String> drawerImageList = [
    AssetPaths.HOME_ICON,
    AssetPaths.REMINDERS_ICON,
    AssetPaths.SETTINGS_ICON,
    AssetPaths.PRIVACY_ICON,
    AssetPaths.TERMS_ICON,
    AssetPaths.ABOUT_ICON,
  ];

  ////////// PUSH NOTIFICATION CHANNEL /////////////
  static const String NOTIFICATION_ID = "jtc_ecommerce_channel_1";
  static const String NOTIFICATION_TITLE =
      "JTC Menu Notification";
  static const String NOTIFICATION_DESCRIPTION =
      "This channel is used for important notifications.";

  /////////// PUSH NOTIFICATION TYPE ///////////
  static const String FOREGROUND_NOTIFICATION = "foreground";
  static const String BACKGROUND_NOTIFICATION = "background";
  static const String KILLED_NOTIFICATION = "killed";

/////////// LOCAL NOTIFICATION CHANNEL ///////////
  static const String LOCAL_NOTIFICATION_ID =
      "jtc_ecommerce_local_channel1";
  static const String LOCAL_NOTIFICATION_TITLE =
      "JTC Menu local Notification.";
  static const String LOCAL_NOTIFICATION_DESCRIPTION =
      "This channel is used for local notifications.";

  //Network Related Strings
  static const String BEARER_TOKEN_KEY = 'token';
  static const String STORE_KEY = 'store_key';
  static const String CURRENT_USER_DATA_KEY = 'saveUser';
  static const String VIEW_ONBOARDING_DATA_KEY = 'onboard';
  static const String NOTIFICATION_MESSAGE_ID_KEY = 'notification';
  static const String LANGUAGE_KEY = 'languagekeys';

  //Bottom Nav Names
  static const String HOME_NAV_BAR_ITEM = "Home";
  static const String FAVOURITE_NAV_BAR_ITEM = "Favourite";
  static const String SETTING_NAV_BAR_ITEM = "Settings";
  static const String WALLET_NAV_BAR_ITEM = "Wallet";
}
