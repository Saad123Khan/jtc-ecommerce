import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:jtc_ecommerce/app.dart';
import 'package:jtc_ecommerce/services/local_storage.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:jtc_ecommerce/utils/constants.dart';
import 'generated/codegen_loader.g.dart';
import 'utils/app_network_strings.dart';
import 'package:easy_localization/easy_localization.dart';

//! ============> Main Method
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await EasyLocalization.ensureInitialized();
  Stripe.publishableKey = NetworkStrings.PUBLISH_KEY;
  HttpOverrides.global = MyHttpOverrides();

  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // Initialize shared preferences
  await SharedPreference().sharedPreference;
  String? savedLanguageCode = SharedPreference().getLanguage();
  Locale startLocale = Locale(
      savedLanguageCode ?? 'es'); // Default to Spanish if no saved language

  runApp(
    EasyLocalization(
      supportedLocales: Constants.supportedLocales,
      assetLoader: CodegenLoader(),
      path: Constants.translationPath,
      startLocale: startLocale,
      fallbackLocale: Constants.supportedLocales.first,
      child: JtcEcommerceApp(),
    ),
  );
}

class MyHttpOverrides extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext? context) {
    return super.createHttpClient(context)
      ..badCertificateCallback =
          (X509Certificate cert, String host, int port) => true;
  }
}
