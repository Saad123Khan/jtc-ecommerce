import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'package:jtc_ecommerce/widgets/custom_button.dart';
import 'package:jtc_ecommerce/widgets/custom_willpopscope_dialog.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';
import 'package:shimmer/shimmer.dart';

import '../controllers/order_summary_controller.dart';

class PrepartionTimeOrderScreen extends StatefulWidget {
  final dynamic data;
  final bool navigatorPOP;

  const PrepartionTimeOrderScreen({
    super.key,
    required this.data,
    this.navigatorPOP = false,
  });

  @override
  State<PrepartionTimeOrderScreen> createState() =>
      _PrepartionTimeOrderScreenState();
}

class _PrepartionTimeOrderScreenState extends State<PrepartionTimeOrderScreen> {
  final controller = Get.find<OrderSummaryController>();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      controller.getSalesAppFunc(widget.data);
    });
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      key: GlobalKey(),
      onWillPop: () async {
        return await Get.defaultDialog(
          barrierDismissible: false,
          title: tr('exit'),
          content: ExitButtonContent(
            onTapYesButton: () {
              SystemNavigator.pop();
            },
          ),
        );
      },
      child: Scaffold(
        body: Stack(
          children: [
            _buildBackground(),
            _buildOrderStatus(),
            _buildBottomSection(context),
          ],
        ),
      ),
    );
  }

  Widget _buildBackground() {
    return Container(
      color: Color(0xff2E2E2E),
      width: double.infinity,
      child: Column(
        children: [
          // SizedBox(height: 120.h),
        ],
      ),
    );
  }

  Widget _buildOrderStatus() {
    return Obx(
      () {
        if (controller.isLoading.value) {
          return _buildLoadingText();
        } else {
          return _buildOrderInfo();
        }
      },
    );
  }

  Widget _buildLoadingText() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        SizedBox(height: 120.h),
        Shimmer.fromColors(
          baseColor: Colors.white.withOpacity(0.5),
          highlightColor: Colors.white,
          child: Container(
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: AppColors.WHITE_COLOR.withOpacity(.3)),
            width: 50.sw,
            height: 40,
          ),
        ),
        SizedBox(
          height: 10,
        ),
        Shimmer.fromColors(
          baseColor: Colors.white.withOpacity(0.5),
          highlightColor: Colors.white,
          child: Container(
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: AppColors.WHITE_COLOR.withOpacity(.3)),
            width: 50.sw,
            height: 40,
          ),
        ),
        SizedBox(
          height: 10,
        ),
        Shimmer.fromColors(
          baseColor: Colors.white.withOpacity(0.5),
          highlightColor: Colors.white,
          child: Container(
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: AppColors.WHITE_COLOR.withOpacity(.3)),
            width: 50.sw,
            height: 40,
          ),
        ),
        SizedBox(
          height: 10,
        ),
        Shimmer.fromColors(
          baseColor: Colors.white.withOpacity(0.5),
          highlightColor: Colors.white,
          child: Container(
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: AppColors.WHITE_COLOR.withOpacity(.3)),
            width: 120,
            height: 40,
          ),
        ),
      ],
    );
  }

  Widget _buildOrderInfo() {
    return SizedBox(
      height: 1.sh,
      child: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 12.w),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 150.h),
              Text(
                _getTextBasedOnStatus(
                  controller.orderStatus.value.toString(),
                  controller.orderType.value.toString(),
                ),
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 35.sp,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w500,
                ),
              ),
              SizedBox(height: 5.h),
              Text(
                tr('thanku_for_order'),
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 17.sp,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w400,
                ),
              ),
              SizedBox(height: .5.sh),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBottomSection(BuildContext context) {
    return Positioned(
      bottom: 0,
      left: 0,
      right: 0,
      child: Container(
        width: double.infinity,
        height: 350.h,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(15.r),
            topRight: Radius.circular(15.r),
          ),
          boxShadow: [
            BoxShadow(
              color: Color(0x3F000000),
              blurRadius: 40,
              offset: Offset(0, -15),
            ),
          ],
        ),
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 15.w),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              GestureDetector(
                onTap: () {
                  // Handle image tap if needed
                },
                child: Image.asset("assets/images/order_time_image.png"),
              ),
              Text(
                tr("bepatience_text"),
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF3D3D3D),
                  fontSize: 18.sp,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w400,
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 50.w),
                child: CustomButton(
                  buttonColor: AppColors.PRIMARY_COLOR,
                  onTap: () {
                    if (widget.navigatorPOP) {
                      AppNavigation.navigatorPop(context);
                    } else {
                      AppNavigation.navigateTo(
                        context,
                        AppRouteName.BOTTOM_NAVIGATION_SCREEN_ROUTE,
                      );
                    }
                  },
                  buttonText: widget.navigatorPOP
                      ? tr('Go_back_text')
                      : tr('Go_home_text'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _getTextBasedOnStatus(String orderStatus, String orderType) {
    print("STATUS: $orderStatus");
    switch (orderStatus) {
      case "0":
        return tr('preparationscreenstatus.pending_text');
      case "1":
        return tr('preparationscreenstatus.accepted_text');
      case "2":
        return tr('preparationscreenstatus.preparing_text');
      case "3":
        return tr('preparationscreenstatus.delivered_text');
      case "4":
        return orderType == "delivery"
            ? tr('preparationscreenstatus.complete_rider')
            : tr('preparationscreenstatus.completed_text');
      case "5":
        return tr('preparationscreenstatus.returned_text');
      case "6":
        return tr('preparationscreenstatus.refunded_text');
      case "7":
        return tr('preparationscreenstatus.cancelled_text');
      case "8":
        return tr('preparationscreenstatus.hold_text');
      case "9":
        return tr('preparationscreenstatus.start_delivery_text');
      case "10":
        return tr('preparationscreenstatus.rider_arrived_text');
      case "11":
        return tr('preparationscreenstatus.rider_pickup_text');
      case "12":
        return tr('preparationscreenstatus.quality_check');
      default:
        return tr('preparationscreenstatus.processing_text');
    }
  }
}
