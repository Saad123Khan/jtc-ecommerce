import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_datetime_picker_plus/flutter_datetime_picker_plus.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/enum/order_type.dart';
import 'package:jtc_ecommerce/widgets/custom_scaffold.dart';
import 'package:jtc_ecommerce/widgets/custom_text_field.dart';
import 'package:jtc_ecommerce/widgets/custom_app_bar.dart';
import 'package:jtc_ecommerce/widgets/custom_button.dart';
import 'package:jtc_ecommerce/widgets/custom_month_picker.dart';
import 'package:jtc_ecommerce/order_summary/blocs/checkout_bloc.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/custom_keybaord_action.dart';
import 'package:jtc_ecommerce/services/stripe_service.dart';
import 'package:jtc_ecommerce/splash/controllers/splash_controller.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_constants.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';
import 'package:jtc_ecommerce/utils/validations.dart';
import 'package:easy_localization/easy_localization.dart';
import '../controllers/order_summary_controller.dart';

import 'package:jtc_ecommerce/utils/get_order_type_util.dart';

class CardPaymentScreen extends StatefulWidget {
  CardPaymentScreen({
    Key? key,
  }) : super(key: key);

  @override
  State<CardPaymentScreen> createState() => _CardPaymentScreenState();
}

class _CardPaymentScreenState extends State<CardPaymentScreen> {
  final controller = Get.find<OrderSummaryController>();

  @override
  void initState() {
    controller.expiry_controller.clear();
    controller.account_holder_controller.clear();
    controller.account_number_controller.clear();
    controller.cvc_controller.clear();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  GlobalKey<FormState> formKey = GlobalKey<FormState>();
  FocusNode cardNoFocusNode = FocusNode();
  FocusNode cvcFocusNode = FocusNode();

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      appBarTitle: tr('Enter_Card_Information'),
      onTap: () => AppNavigation.navigatorPop(
        context,
      ),
      child: GestureDetector(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 10.0, vertical: 20.0),
          decoration: BoxDecoration(
            shape: BoxShape.rectangle,
            color: Colors.white,
            borderRadius: BorderRadius.circular(16.0),
          ),
          child: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  // SizedBox(
                  //   height: .05.sh,
                  // ),
                  // InkWell(
                  //   splashColor: AppColors.TRANSPARENT_COLOR,
                  //   focusColor: AppColors.TRANSPARENT_COLOR,
                  //   onTap: () {
                  //     AppNavigation.navigatorPop(context);
                  //   },
                  //   child: Image.asset('assets/images/back_icon.png',
                  //   height: 25,
                  //   width: 25,
                  //   )),
                  //   SizedBox(
                  //   height: .05.sh,
                  // ),
                  // Center(
                  //   child: Text(
                  //     tr('Enter_Card_Information'),
                  //     style:
                  //         TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
                  //   ),
                  // ),
                  // SizedBox(height: 16.0),
                  SizedBox(
                    height: 300.0,
                    child: SingleChildScrollView(
                      child: Column(
                        children: <Widget>[
                          nameOnCardWidget(),
                          SizedBox(height: 8.0),
                          cardDetailsWidget(),
                          SizedBox(height: 8.0),
                          expiryAndCvvWidget(context),
                        ],
                      ),
                    ),
                  ),
                  // SizedBox(height: 16.0),
                  saveButtonWidget(context, "12" ?? ""),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget nameOnCardWidget() {
    return CustomTextField(
      hintText: tr('jtctokenscreen.cardholder_text'),
      textInputFormattors: [LengthLimitingTextInputFormatter(35)],
      textEditingController: controller.account_holder_controller,
      validator: (value) {
        return FieldValidator2.validateEmpty(
          value: value!,
          label: tr('jtctokenscreen.cardholder_text'),
        );
      },
    );
  }

  Widget cardDetailsWidget() {
    return CustomKeyboardActionWidget(
      focusNode: cardNoFocusNode,
      child: CustomTextField(
        focusNode: cardNoFocusNode,
        hintText: tr('jtctokenscreen.cardnumber_text'),
        textInputFormattors: [AppConstant.MASK_TEXT_FORMATTER_CARD_NO],
        keyboardType: TextInputType.phone,
        textEditingController: controller.account_number_controller,
        validator: (value) {
          return FieldValidator2.validateCardNo(
            value: AppConstant.MASK_TEXT_FORMATTER_CARD_NO.unmaskText(value!),
            label: tr('jtctokenscreen.cardnumber_text'),
          );
        },
      ),
    );
  }

  Widget expiryAndCvvWidget(context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          flex: 1,
          child: Column(
            children: [
              CustomTextField(
                suffixIcon: AssetPaths.CALENDAR_ICON,
                readyOnly: true,
                onTap: () async {
                  DatePicker.showPicker(
                    context,
                    pickerModel: CustomMonthPicker(
                      minTime: DateTime.now(),
                      maxTime: DateTime(2050, 1, 1),
                      currentTime: DateTime.now(),
                    ),
                    onConfirm: (time) {
                      if (time != null) {
                        String formattedDate = DateFormat('MM/yy').format(time);
                        logData(message: "formattedDate: $formattedDate");
                        controller.expiry_controller.text = formattedDate;
                      } else {
                        print("Date is not selected");
                      }
                    },
                  );
                },
                textInputFormattors: [AppConstant.MASK_TEXT_FORMATTER_EXPIRY],
                keyboardType: TextInputType.phone,
                textEditingController: controller.expiry_controller,
                validator: (value) {
                  return FieldValidator2.validateEmpty(
                    value: value!,
                    label: tr('jtctokenscreen.expirydate_text'),
                  );
                },
                hintText: tr('jtctokenscreen.expirydate_text'),
              ),
            ],
          ),
        ),
        SizedBox(width: 15),
        Expanded(
          flex: 1,
          child: Column(
            children: [
              CustomKeyboardActionWidget(
                focusNode: cvcFocusNode,
                child: CustomTextField(
                  focusNode: cvcFocusNode,
                  hintText: tr('jtctokenscreen.cvc_text'),
                  textInputFormattors: [
                    LengthLimitingTextInputFormatter(3),
                    FilteringTextInputFormatter.digitsOnly,
                  ],
                  keyboardType: TextInputType.phone,
                  textEditingController: controller.cvc_controller,
                  validator: (value) {
                    return FieldValidator2.validateCVC(
                      value: value!,
                      label: tr('jtctokenscreen.cvc_text'),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget saveButtonWidget(context, String tokenId) {
    var controller = Get.find<OrderSummaryController>();
    return CustomButton(
      buttonText: tr('jtctokenscreen.add_text'),
      onTap: () async {
        final isValid = formKey.currentState!.validate();
        if (!isValid) {
          return;
        }
        formKey.currentState!.save();
        log("Card Number ${controller.account_number_controller.text}");
        log("Exp Month ${controller.expiry_controller.text.split('/').first}");
        log("Exp Year ${controller.expiry_controller.text.split('/').last}");
        log("CVC ${controller.cvc_controller.text}");
        int expMonth =
            int.parse(controller.expiry_controller.text.split('/').first);
        int expYear =
            int.parse(controller.expiry_controller.text.split('/').last);

        AppDialogs.progressAlertDialog(context: context);

        final cardToken = await StripeService.stripeToken(
          cardNumber: controller.account_number_controller.text.trim(),
          expMonth: expMonth,
          expYear: expYear,
          cvc: controller.cvc_controller.text,
        );

        AppNavigation.navigatorPop(context);

        if (cardToken != null) {
          logData(message: "CARD TOKEN FROM STRIPE ${cardToken}");
          final user = Get.find<SplashController>().currentUser.value;

          CheckoutCardBloc().checkoutBlocMethod(
            context: context,
            instructions: Get.find<OrderSummaryController>()
                .instructtionsController
                .text
                .trim(),
            latitude: user?.lat.toString(),
            deliveryCharges:
                Get.find<OrderSummaryController>().selectedOrderType.value ==
                        OrderType.Delivery
                    ? Get.find<OrderSummaryController>()
                        .viewCartModel
                        .value
                        ?.delivery
                        .toString()
                    : null,
            longitude: user?.long.toString(),
            order_type: Get.find<OrderSummaryController>()
                .selectedOrderType
                .value
                ?.orderStringCheckout,
            address: user?.address,
            nearestAddress: Get.find<OrderSummaryController>()
                .nearestAddressContoller
                .text
                .trim(),
            nearestFlat:
                Get.find<OrderSummaryController>().nearestFlatNo.text.trim(),
            promo_code_id: Get.find<OrderSummaryController>().promocode.text,
            table_number: Get.find<OrderSummaryController>().dineIncode.text,
            paymentId: cardToken,
            setProgressBar: () {
              AppDialogs.progressAlertDialog(context: context);
            },
          );
        }

        // ProductPaymentBloc().saveAddress(
        //   context: context,
        //   cardNumber: controller.account_number_controller.text,
        //   expMonth: expMonth,
        //   expYear: expYear,
        //   cvc: controller.cvc_controller.text.trim(),
        //   token: tokenId,
        //   amount: controller
        //       .calculateTotalOrderPrice(controller.selectedOrderType.value!)
        //       .toString(),
        //   setProgressBar: () {
        //     AppDialogs.progressAlertDialog(context: context);

        //     controller.account_holder_controller.text = '';
        //     controller.account_number_controller.text = '';
        //     controller.expiry_controller.text = '';
        //     controller.cvc_controller.text = '';
        //   },
        // );
        FocusScope.of(context).unfocus();
      },
      buttonColor: AppColors.PRIMARY_COLOR,
    );
  }
}
