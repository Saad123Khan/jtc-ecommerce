// import 'package:easy_localization/easy_localization.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:get/get.dart';
// import 'package:jtc_ecommerce/bottom_navigation/controllers/bottom_navigation_controller.dart';
// import 'package:jtc_ecommerce/cart/controllers/cart_controller.dart';
// import 'package:jtc_ecommerce/enum/order_type.dart';
// import 'package:jtc_ecommerce/gloabl_widgets/custom_button.dart';
// import 'package:jtc_ecommerce/gloabl_widgets/custom_willpopscope_dialog.dart';
// import 'package:jtc_ecommerce/utils/app_colors.dart';
// import 'package:jtc_ecommerce/utils/app_navigation.dart';
// import 'package:jtc_ecommerce/utils/app_routes_name.dart';
// import 'package:jtc_ecommerce/utils/get_order_type_util.dart';

// import '../controllers/order_summary_controller.dart';

// class PrepartionTimeScreen extends StatefulWidget {
//   final String orderId;

  
//   PrepartionTimeScreen({super.key, required this.orderId});

//   @override
//   State<PrepartionTimeScreen> createState() => _PrepartionTimeScreenState();
// }

// class _PrepartionTimeScreenState extends State<PrepartionTimeScreen> {
//   final controller = Get.put(OrderSummaryController());
//   @override
//   void initState() {
//     super.initState();
//   WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
//       controller.getSalesAppFunc(widget.orderId);
//   });
//   }

//   // @override
//   // void dispose() {
//   //   // Stop the timer when the screen is disposed
//   //   controller.stopTimer();
//   //   super.dispose();
//   // }

//   @override
//   Widget build(BuildContext context) {
//     // print("${controller.getSalesappVar.value?.orderType}");
//     // print("${controller.getSalesappVar.value?.orderStatus}");
//     return WillPopScope(
//       key: GlobalKey(),
//       onWillPop: () async {
//         return await Get.defaultDialog(
//           barrierDismissible: false,
//           title: tr('exit'),
//           content: ExitButtonContent(
//             onTapYesButton: () {
//               SystemNavigator.pop();
//             },
//           ),
//         );
//       },
//       child: Scaffold(
//           body: Stack(
//         children: [
//           Container(
//             color: Color(0xff2E2E2E),
//             width: double.infinity,
//             child: Column(
//               children: [
//                 SizedBox(
//                   height: 180,
//                 ),
//                 // Obx(
//                 //   () => controller.showButton.value
//                 //       ? Text(
//                 //           controller.formattedTime.value,
//                 //           textAlign: TextAlign.center,
//                 //           style: TextStyle(
//                 //             color: Colors.white,
//                 //             fontSize: 40,
//                 //             fontFamily: 'Poppins',
//                 //             fontWeight: FontWeight.w500,
//                 //           ),
//                 //         )
//                 //       : Text(
//                 //           "",
//                 //           style: TextStyle(
//                 //             color: Colors.white,
//                 //             fontSize: 40,
//                 //             fontFamily: 'Poppins',
//                 //             fontWeight: FontWeight.w500,
//                 //           ),
//                 //         ),
//                 // ),
//                 // Text(
//                 //   'Required Time',
//                 //   textAlign: TextAlign.center,
//                 //   style: TextStyle(
//                 //     color: Colors.white,
//                 //     fontSize: 18,
//                 //     fontFamily: 'Poppins',
//                 //     fontWeight: FontWeight.w400,
//                 //   ),
//                 // ),
//                 // Obx(
//                 //   () {
//                 //     if (controller.getSalesappVar != null) {
//                 //       return Column(
//                 //         children: [
//                 //           Text(
//                 //             // controller.formattedTime.value,
//                 //             // controller.getSalesappVar.value!.orderStatus,
//                 //             _getTextBasedOnStatus(
//                 //                 controller.getSalesappVar.value!.orderStatus),
//                 //             textAlign: TextAlign.center,
//                 //             style: TextStyle(
//                 //               color: Colors.white,
//                 //               fontSize: 40,
//                 //               fontFamily: 'Poppins',
//                 //               fontWeight: FontWeight.w500,
//                 //             ),
//                 //           ),
//                 //           SizedBox(
//                 //             height: 5,
//                 //           ),
//                 //           Text(
//                 //             'Thank you For Your Order',
//                 //             textAlign: TextAlign.center,
//                 //             style: TextStyle(
//                 //               color: Colors.white,
//                 //               fontSize: 18,
//                 //               fontFamily: 'Poppins',
//                 //               fontWeight: FontWeight.w400,
//                 //             ),
//                 //           ),
//                 //         ],
//                 //       );
//                 //     } else {
//                 //       return SizedBox.shrink();
//                 //     }
//                 //   },
//                 // )

//                 Obx(
//                   () {
//                     if (controller.getSalesappVar.value != null) {
//                       return Column(
//                         children: [
//                           Text(
//                             // _getTextBasedOnStatus(controller
//                             //         .getSalesappVar.value?.orderStatus
//                             //         .toString() ??
//                             //     "0"),

//                             // _getTextBasedOnStatus(controller
//                             //         .getSalesappVar.value?.orderStatus ??
//                             //     tr('preparationscreenstatus.processing_text')),
//                             "",
//                             textAlign: TextAlign.center,
//                             style: TextStyle(
//                               color: Colors.white,
//                               fontSize: 40,
//                               fontFamily: 'Poppins',
//                               fontWeight: FontWeight.w500,
//                             ),
//                           ),
//                           SizedBox(
//                             height: 5,
//                           ),
//                           Text(
//                             // // 'Thank you For Your Order',
//                             // controller.getSalesappVar.value?.orderType
//                             //             .toLowerCase() !=
//                             //         OrderType.Delivery.orderString.toLowerCase()
//                             //     ? "Your order has been placed successfully"
//                             //     : "Thank you for your order",
//                             tr('thanku_for_order'),
//                             textAlign: TextAlign.center,
//                             style: TextStyle(
//                               color: Colors.white,
//                               fontSize: 18,
//                               fontFamily: 'Poppins',
//                               fontWeight: FontWeight.w400,
//                             ),
//                           ),
//                         ],
//                       );
//                     } else {
//                       // Handle the case when controller.getSalesappVar is null
//                       return Column(
//                         children: [
//                           Text(
//                             // 'Loading...', // or any other message indicating loading state

//                             // tr('loading_text'),

//                             tr('preparationscreenstatus.pending_text'),
//                             textAlign: TextAlign.center,
//                             style: TextStyle(
//                               color: Colors.white,
//                               fontSize: 40,
//                               fontFamily: 'Poppins',
//                               fontWeight: FontWeight.w500,
//                             ),
//                           ),
//                           SizedBox(
//                             height: 5,
//                           ),
//                           Text(
//                             // // 'Thank you For Your Order',
//                             // controller.getSalesappVar.value?.orderType
//                             //             .toLowerCase() !=
//                             //         OrderType.Delivery.orderString.toLowerCase()
//                             //     ? "Your order has been placed successfully"
//                             //     : "Thank you for your order",
//                             tr('thanku_for_order'),
//                             textAlign: TextAlign.center,
//                             style: TextStyle(
//                               color: Colors.white,
//                               fontSize: 18,
//                               fontFamily: 'Poppins',
//                               fontWeight: FontWeight.w400,
//                             ),
//                           ),
//                         ],
//                       );
//                     }
//                   },
//                 )
//                 // Obx(
//                 //   () =>

//                 //   controller.showButton.value
//                 //       ?
//                 //       Column(
//                 //           children: [
//                 //             Text(
//                 //               controller.formattedTime.value,
//                 //               textAlign: TextAlign.center,
//                 //               style: TextStyle(
//                 //                 color: Colors.white,
//                 //                 fontSize: 40,
//                 //                 fontFamily: 'Poppins',
//                 //                 fontWeight: FontWeight.w500,
//                 //               ),
//                 //             ),
//                 //             Text(
//                 //               'Required Time',
//                 //               textAlign: TextAlign.center,
//                 //               style: TextStyle(
//                 //                 color: Colors.white,
//                 //                 fontSize: 18,
//                 //                 fontFamily: 'Poppins',
//                 //                 fontWeight: FontWeight.w400,
//                 //               ),
//                 //             ),
//                 //           ],
//                 //         )
//                 //       : SizedBox.shrink(),
//                 // )
//               ],
//             ),
//           ),
//           // Positioned(
//           //     top: 14,
//           //     left: 15,
//           //     // right: 10,
//           //     child: GestureDetector(
//           //         onTap: () {
//           //           // Get.back();
//           //         },
//           //         child: Image.asset("assets/images/back_white.png"))
//           //         ),
//           Positioned(
//             bottom: 0,
//             left: 0,
//             right: 0,
//             child: Container(
//               width: double.infinity,
//               height: 350,
//               decoration: BoxDecoration(
//                 color: Colors.white,
//                 borderRadius: BorderRadius.only(
//                   topLeft: Radius.circular(15),
//                   topRight: Radius.circular(15),
//                 ),
//                 boxShadow: [
//                   BoxShadow(
//                     color: Color(0x3F000000),
//                     blurRadius: 40,
//                     offset: Offset(0, -15),
//                     spreadRadius: 0,
//                   ),
//                 ],
//               ),
//               child: Padding(
//                 padding: const EdgeInsets.symmetric(horizontal: 15),
//                 child: Column(
//                   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                   crossAxisAlignment: CrossAxisAlignment.center,
//                   children: [
//                     GestureDetector(
//                         onTap: () {
//                           // Get.to(ThankYouScreen());
//                         },
//                         child:
//                             Image.asset("assets/images/order_time_image.png")),
//                     Text(
//                       // 'Be Patience',
//                       tr('bepatience_text'),

//                       textAlign: TextAlign.center,
//                       style: TextStyle(
//                         color: Color(0xFF3D3D3D),
//                         fontSize: 18,
//                         fontFamily: 'Poppins',
//                         fontWeight: FontWeight.w400,
//                       ),
//                     ),
//                     Padding(
//                       padding: const EdgeInsets.symmetric(horizontal: 50.0),
//                       child: CustomButton(
//                         buttonColor: AppColors.PRIMARY_COLOR,
//                         onTap: () {
//                           // AppNavigation.navigateToRemovingAll(
//                           //   context,
//                           //   AppRouteName.BOTTOM_NAVIGATION_SCREEN_ROUTE,
//                           // );
//                           // var controller =
//                           //     Get.find<BottomNavgationController>();

//                           final CartController cartController =
//                               Get.put(CartController());
//                           cartController.clearCart();

//                           var controller = Get.put(BottomNavgationController());
//                           controller.changePage(0);
//                           AppNavigation.navigateToRemovingAll(
//                             context,
//                             AppRouteName.BOTTOM_NAVIGATION_SCREEN_ROUTE,
//                           );
//                         },
//                         // buttonText: "Go Home ",
//                         buttonText: tr('Go_home_text'),
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           ),
//         ],
//       )),
//     );
//   }

//   String _getTextBasedOnStatus(String orderStatus) {
//     switch (orderStatus) {
//       case "0":
//         return tr('preparationscreenstatus.pending_text');
//       case "1":
//         return tr('preparationscreenstatus.accepted_text');
//       case "2":
//         return tr('preparationscreenstatus.preparing_text');
//       case "3":
//         return tr('preparationscreenstatus.delivered_text');
//       case "4":
//         return tr('preparationscreenstatus.completed_text');
//       case "5":
//         return tr('preparationscreenstatus.returned_text');
//       case "6":
//         return tr('preparationscreenstatus.refunded_text');
//       case "7":
//         return tr('preparationscreenstatus.cancelled_text');
//       case "8":
//         return tr('preparationscreenstatus.hold_text');
//       case "9":
//         return tr('preparationscreenstatus.start_delivery_text');
//       case "10":
//         return tr('preparationscreenstatus.rider_arrived_text');
//       case "11":
//         return tr('preparationscreenstatus.rider_pickup_text');
//       default:
//         return tr('preparationscreenstatus.processing_text');
//     }
//   }
// }
