import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/auth/blocs/coupon_Code_bloc.dart';
import 'package:jtc_ecommerce/auth/controllers/auth_controller.dart';
import 'package:jtc_ecommerce/cart/blocs/view_cart_bloc.dart';
import 'package:jtc_ecommerce/cart/controllers/cart_controller.dart';
import 'package:jtc_ecommerce/enum/order_type.dart';
import 'package:jtc_ecommerce/widgets/custom_scaffold.dart';
import 'package:jtc_ecommerce/widgets/custom_text_field.dart';
import 'package:jtc_ecommerce/widgets/custom_app_bar.dart';
import 'package:jtc_ecommerce/widgets/custom_button.dart';
import 'package:jtc_ecommerce/widgets/custom_dropdown.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/order_summary/controllers/order_summary_controller.dart';
import 'package:jtc_ecommerce/services/custom_keybaord_action.dart';
import 'package:jtc_ecommerce/splash/controllers/splash_controller.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_fonts.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';
import 'package:jtc_ecommerce/utils/constants.dart';
import 'package:jtc_ecommerce/utils/get_order_type_util.dart';
import 'package:jtc_ecommerce/utils/validations.dart';
import 'package:place_picker/place_picker.dart';

class OrderSummaryScreen extends StatefulWidget {
  OrderSummaryScreen({super.key});

  @override
  State<OrderSummaryScreen> createState() => _OrderSummaryScreenState();
}

class _OrderSummaryScreenState extends State<OrderSummaryScreen> {
  var controller = Get.find<OrderSummaryController>();
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  ScrollController scrollController = ScrollController();

  initUserDeliveryAddress() {
    // user_address.value.text = splashController.currentUser.value?.address ?? "";
    controller.user_address.value.text =
        Get.find<SplashController>().currentUser.value?.address ?? "";

    controller.promocode.clear();
    controller.token.value = "";
    controller.dineIncode.clear();
    controller.nearestAddressContoller.clear();
    controller.nearestFlatNo.clear();
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.selectedOrderType.value = null;
      final _queryParameters = {
        // 'lat': Get.find<SplashController>().currentUser.value?.lat,
        // 'long': Get.find<SplashController>().currentUser.value?.long,
        // 'order_type': controller.selectedOrderType.value?.orderStringCheckout,
      };
      initUserDeliveryAddress();
      ViewCartBloc().getViewCartBlocMethod(
          // queryParams: _queryParameters,
          context: context,
          loader: true,
          onSuccess: () {
            controller.viewCartModel.value =
                Get.find<CartController>().viewCartModel.value;

            if (controller.viewCartModel.value == null) {
              controller.selectedOrderType.value = null;
            }
          },
          setProgressBar: () {
            AppDialogs.progressAlertDialog(context: context);
          });
    });
  }

  @override
  Widget build(BuildContext context) {
    final user = Get.find<SplashController>().currentUser.value;
    return CustomScaffold(
      appBarTitle: tr('OrderSummaryScreen'),
      onTap: () => AppNavigation.navigatorPop(context),
      isAuthScreen: false,
      child: SingleChildScrollView(
        controller: scrollController,
        physics: AlwaysScrollableScrollPhysics(),
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 10.0.w, vertical: 10.h),
          child: Obx(
            () => Form(
              key: _formKey,
              child: Column(
                children: [
                  if (controller.selectedOrderType == OrderType.Delivery) ...[
                    CustomText(
                      text:
                          // "Delivery Address",
                          tr('Delivery_address'),
                      color: AppColors.BLACK_COLOR,
                      fontsize: 16.sp,
                      isLeftAlign: true,
                    ),
                    10.verticalSpace,
                    user_address(context),
                    if (user?.nearest_address != null) ...[
                      10.verticalSpace,
                      CustomText(
                        text:
                            //  "Flat No/Residency",
                            tr('Flat_No_Residency'),
                        color: AppColors.BLACK_COLOR,
                        fontsize: 16.sp,
                        isLeftAlign: true,
                      ),
                      10.verticalSpace,
                      nearestAddress(),
                    ],
                    if (user?.nearest_address != null) ...[
                      10.verticalSpace,
                      CustomText(
                        text:
                            // "Nearest Landmark ",
                            tr('Nearest_landmark'),
                        color: AppColors.BLACK_COLOR,
                        fontsize: 16.sp,
                        isLeftAlign: true,
                      ),
                      10.verticalSpace,
                      nearestFlatResidency(),

                      // 10.verticalSpace,
                    ],
                  ],

                  20.verticalSpace,
                  CustomText(
                    text:
                        // "Order Type",
                        tr('Order_Type'),
                    color: AppColors.BLACK_COLOR,
                    fontsize: 16.sp,
                    isLeftAlign: true,
                  ),
                  10.verticalSpace,
                  _selectOrderType(),
                  20.verticalSpace,

                  controller.selectedOrderType.value == OrderType.Dine_In
                      ? Column(
                          children: [
                            // 20.verticalSpace,
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  tr('Dine_in_Table_No'),
                                  style: TextStyle(
                                    color: Color(0xFF3D3D3D),
                                    fontSize: 16,
                                    fontFamily: 'Poppins',
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ],
                            ),
                            10.verticalSpace,
                            dineInTextfield(),
                            10.verticalSpace,
                          ],
                        )
                      : SizedBox.shrink(),

                  // 10.verticalSpace,
                  ...[
                    // 10.verticalSpace,
                    CustomText(
                      text:
                          // "Delivery Address",
                          tr('note'),
                      color: AppColors.BLACK_COLOR,
                      fontsize: 16.sp,
                      isLeftAlign: true,
                    ),
                    10.verticalSpace,
                    notes(),
                    20.verticalSpace,
                  ],

                  CustomText(
                    text:
                        //  "Add Coupon Code",
                        tr('Add_Coupon_Code'),
                    color: AppColors.BLACK_COLOR,
                    fontsize: 16.sp,
                    isLeftAlign: true,
                  ),
                  10.verticalSpace,
                  // _selectPromoCode(),
                  promocodeTextfield(),

                  30.verticalSpace,
                  Padding(
                    padding: const EdgeInsets.only(left: 10.0),
                    child: CustomText(
                      text:
                          // "Order Summary",
                          tr('OrderSummaryScreen'),
                      color: AppColors.BLACK_COLOR,
                      fontsize: 16.sp,
                      isLeftAlign: true,
                    ),
                  ),
                  10.verticalSpace,
                  order_summary(controller.selectedOrderType.value),

                  controller.token == ''
                      ? SizedBox()
                      : Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                          child: Column(
                            children: [
                              10.verticalSpace,
                              CustomText(
                                text: tr('coupon_applied', namedArgs: {
                                  'tokens': controller.token.value
                                }),
                                color: Color.fromARGB(255, 7, 117, 38),
                                fontsize: 14.sp,
                                isLeftAlign: true,
                                maxLines: 10,
                                fontWeight: FontWeight.bold,
                              ),
                            ],
                          ),
                        ),

                  30.verticalSpace,
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 5.0.w),
                    child: CustomButton(
                      buttonColor: controller.viewCartModel.value == null
                          ? AppColors.GREY_COLOR
                          : AppColors.PRIMARY_COLOR,
                      onTap: controller.viewCartModel.value == null
                          ? () {}
                          : () async {
                              if (_formKey.currentState!.validate()) {
                                if (controller.selectedOrderType.value ==
                                    null) {
                                  AppDialogs.showToast(
                                    message:
                                        // "Order Type is Required"
                                        tr('order_type_req_text'),
                                  );
                                } else if (controller.selectedOrderType.value ==
                                    OrderType.Delivery) {
                                  controller.user_address.value.text == ""
                                      ? AppDialogs.showToast(
                                          message: tr('address_cannot_be_null'),
                                        )
                                      : AppNavigation.navigateTo(
                                          context, AppRouteName.PAYMENT_SCREEN);
                                } else {
                                  AppNavigation.navigateTo(
                                      context, AppRouteName.PAYMENT_SCREEN);
                                }
                              } else {
                                scrollController.animateTo(
                                    scrollController.initialScrollOffset,
                                    duration: Duration(milliseconds: 300),
                                    curve: Curves.easeIn);
                              }
                            },
                      buttonText:
                          //  "CHECKOUT",
                          tr('checkout_text'),
                    ),
                  ),
                  20.verticalSpace,
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget order_summary(OrderType? orderType) {
    // dynamic total = controller.viewCartModel.value!.total;
    // double delivery = double.parse(controller.viewCartModel.value!.delivery);
    // double differenceFiat = total - delivery;

    // int totalTokens = controller.viewCartModel.value?.totalToken ?? 0;
    // int deliveryTokens = controller.viewCartModel.value?.tokensDelivery ?? 0;
    // int differenceToken = totalTokens - deliveryTokens;
    double totalFiat = controller.calculateTotalOrderPrice(orderType);
    double totalToken = controller.calculateTotalOrderPriceToken(orderType);
    // controller.calculateTotals(controller.viewCartModel.value);

    // double

    return Column(
      children: [
        Container(
          width: double.infinity,
          // height: 250,
          decoration: BoxDecoration(
              color: Color(0xFFF6F6F6),
              borderRadius: BorderRadius.circular(18.r),
              border: Border.all(color: Color(0XFFE4E4E4))),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Obx(
              () => Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  10.verticalSpace,
                  // Text(
                  //   'Total: \$${total.toStringAsFixed(2)}', // Formatting total with two decimal places
                  //   style: TextStyle(fontSize: 16),
                  // ),
                  // Text(
                  //   'Delivery: \$${delivery.toStringAsFixed(2)}', // Formatting delivery with two decimal places
                  //   style: TextStyle(fontSize: 16),
                  // ),
                  // Text(
                  //   'Difference: \$${difference.toStringAsFixed(2)}', // Formatting difference with two decimal places
                  //   style: TextStyle(fontSize: 16),
                  // ),

                  CustomText(
                    text: tr('fiaat_text'),
                    // "Fiat",
                    color: AppColors.RED_GMAIL_COLOR,
                    isLeftAlign: true,
                    // fontFamily: AppFonts.robotoBold,
                  ),
                  10.verticalSpace,
                  // for (int i = 0;
                  //     i < controller.viewCartModel.value!.cart.length;
                  //     i++)
                  //   Row(
                  //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //     children: [
                  //       Text(
                  //         controller
                  //                 .viewCartModel.value?.cart[i].productDetail.name ??
                  //             "",
                  //         style: TextStyle(
                  //           color: Color(0xFF3D3D3D),
                  //           fontSize: 16,
                  //           fontFamily: 'Poppins',
                  //           fontWeight: FontWeight.w400,
                  //         ),
                  //       ),
                  //       Text(
                  //         controller.viewCartModel.value?.cart[i].productDetail
                  //                 .productPrice ??
                  //             "",
                  //         textAlign: TextAlign.right,
                  //         style: TextStyle(
                  //           color: Color(0xFF3D3D3D),
                  //           fontSize: 14,
                  //           fontFamily: 'Poppins',
                  //           fontWeight: FontWeight.w500,
                  //         ),
                  //       ),
                  //     ],
                  //   ),
                  Row(
                    //'
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        // "Order Total",
                        tr('order_total_text'),
                        style: TextStyle(
                          color: Color(0xFF3D3D3D),
                          fontSize: 16,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      // Spacer(),
                      10.horizontalSpace,
                      Text(
                        '\$${controller.viewCartModel.value?.subtotal.toStringAsFixed(2) ?? "0.0"}',
                        textAlign: TextAlign.right,
                        style: TextStyle(
                          color: Color(0xFF666666),
                          fontSize: 14,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                  20.verticalSpace,
                  Row(
                    children: List.generate(
                        50,
                        (index) => Expanded(
                              child: Container(
                                color: index % 2 == 0
                                    ? Colors.transparent
                                    : Colors.grey,
                                height: 1,
                                width: 4,
                              ),
                            )),
                  ),
                  20.verticalSpace,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        // "Tax",
                        tr('tax_text'),
                        style: TextStyle(
                          color: Color(0xFF3D3D3D),
                          fontSize: 16,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      Spacer(),

                      //=
                      10.horizontalSpace,
                      Text(
                        // controller.viewCartModel.value?.tax.toString() ?? "",
                        '\$${controller.viewCartModel.value?.tax.toStringAsFixed(2) ?? "0.0"}',
                        textAlign: TextAlign.right,
                        style: TextStyle(
                          color: Color(0xFF666666),
                          fontSize: 14,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  // controller.selectedOrderType.value == 'Dine-In' ||
                  //         controller.selectedOrderType.value == 'Take Away' ||
                  //         controller.selectedOrderType.value == 'Drive Thru' ||
                  //         controller.selectedOrderType.value == 'Curbside'
                  //     ? SizedBox.shrink()
                  //     : Obx(
                  //         () => Row(
                  //           mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //           children: [
                  //             Text(
                  //               "Delivery Charges",
                  //               style: TextStyle(
                  //                 color: Color(0xFF3D3D3D),
                  //                 fontSize: 16,
                  //                 fontFamily: 'Poppins',
                  //                 fontWeight: FontWeight.w400,
                  //               ),
                  //             ),
                  //             Spacer(),
                  //             10.horizontalSpace,
                  //             Text(
                  //               controller.viewCartModel.value?.delivery ?? "",
                  //               textAlign: TextAlign.right,
                  //               style: TextStyle(
                  //                 color: Color(0xFF3D3D3D),
                  //                 fontSize: 14,
                  //                 fontFamily: 'Poppins',
                  //                 fontWeight: FontWeight.w500,
                  //               ),
                  //             ),
                  //           ],
                  //         ),
                  //       ),
                  controller.selectedOrderType.value == OrderType.Delivery
                      ? Obx(
                          () => Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                // "Delivery Charges",
                                tr('delivery_charges_text'),
                                style: TextStyle(
                                  color: Color(0xFF3D3D3D),
                                  fontSize: 16,
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                              Spacer(),
                              10.horizontalSpace,
                              Text(
                                '\$${controller.viewCartModel.value?.delivery.toString()}' ??
                                    "",
                                textAlign: TextAlign.right,
                                style: TextStyle(
                                  color: Color(0xFF666666),
                                  fontSize: 14,
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        )
                      : SizedBox.shrink(),
                  20.verticalSpace,
                  Row(
                    children: List.generate(
                        50,
                        (index) => Expanded(
                              child: Container(
                                color: index % 2 == 0
                                    ? Colors.transparent
                                    : Colors.grey,
                                height: 1,
                                width: 4,
                              ),
                            )),
                  ),
                  20.verticalSpace,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        // 'Grand Total',
                        tr('grand_total_text'),
                        style: TextStyle(
                          color: Color(0xFF3D3D3D),
                          fontSize: 16,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Text(
                        controller.viewCartModel.value != null
                            ?

                            //  controller.selectedOrderType.value == 'Dine-In' ||
                            //         controller.selectedOrderType.value ==
                            //             'Take Away' ||
                            //         controller.selectedOrderType.value ==
                            //             'Drive Thru' ||
                            //         controller.selectedOrderType.value == 'Curbside'
                            //     ?
                            //    differenceFiat.toStringAsFixed(2)
                            //     :

                            //     controller.viewCartModel.value!.total.toStringAsFixed(2)

                            // controller.selectedOrderType.value == OrderType.Delivery
                            //     ? controller.viewCartModel.value!.total
                            //         .toStringAsFixed(2)
                            //     : controller.differenceFiat.toStringAsFixed(2)
                            // : "",

                            '\$' + totalFiat.toStringAsFixed(2)
                            : '0.0',
                        textAlign: TextAlign.right,
                        style: TextStyle(
                          color: Color(0xFF666666),
                          fontSize: 14,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  20.verticalSpace,
                ],
              ),
            ),
          ),
        ),
        10.verticalSpace,
        Container(
          width: double.infinity,
          // height: 250,
          decoration: BoxDecoration(
              color: Color(0xFFF6F6F6),
              borderRadius: BorderRadius.circular(18.r),
              border: Border.all(color: Color(0XFFE4E4E4))),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 14.w),
            child: Column(
              children: [
                10.verticalSpace,
                CustomText(
                  text:
                      // "JTC Token",
                      tr('jtc_tokens_text'),
                  color: AppColors.BLACK_COLOR,
                  isLeftAlign: true,
                  // fontFamily: AppFonts.robotoBold,
                ),

                10.verticalSpace,
                //Order total
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      // "Order Total",

                      tr('order_total_text'),
                      style: TextStyle(
                        color: Color(0xFF3D3D3D),
                        fontSize: 16,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                    Spacer(),
                    // Image.asset(
                    //   AssetPaths.LOGO,
                    //   height: 10,
                    // ),
                    10.horizontalSpace,
                    Text(
                      controller.viewCartModel.value?.tokens.toString() ?? "",
                      textAlign: TextAlign.right,
                      style: TextStyle(
                        color: Color(0xFF666666),
                        fontSize: 14,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
                20.verticalSpace,
                Row(
                  children: List.generate(
                      50,
                      (index) => Expanded(
                            child: Container(
                              color: index % 2 == 0
                                  ? Colors.transparent
                                  : Colors.grey,
                              height: 1,
                              width: 4,
                            ),
                          )),
                ),
                20.verticalSpace,
                //Tax
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      // "Tax",
                      tr('tax_text'),
                      style: TextStyle(
                        color: Color(0xFF3D3D3D),
                        fontSize: 16,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                    Spacer(),
                    // Image.asset(
                    //   AssetPaths.LOGO,
                    //   height: 10,
                    // ),
                    10.horizontalSpace,
                    Text(
                      controller.viewCartModel.value?.taxToken.toString() ??
                          '0',
                      textAlign: TextAlign.right,
                      style: TextStyle(
                        color: Color(0xFF666666),
                        fontSize: 14,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                20.verticalSpace,
                Row(
                  children: List.generate(
                      50,
                      (index) => Expanded(
                            child: Container(
                              color: index % 2 == 0
                                  ? Colors.transparent
                                  : Colors.grey,
                              height: 1,
                              width: 4,
                            ),
                          )),
                ),
                20.verticalSpace,
                // controller.selectedOrderType.value == 'Dine-In' ||
                //         controller.selectedOrderType.value == 'Take Away' ||
                //         controller.selectedOrderType.value == 'Drive Thru' ||
                //         controller.selectedOrderType.value == 'Curbside'
                //     ? SizedBox.shrink()
                //     : Row(
                //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
                //         children: [
                //           Text(
                //             "Deliver Charges ",
                //             style: TextStyle(
                //               color: Color(0xFF3D3D3D),
                //               fontSize: 16,
                //               fontFamily: 'Poppins',
                //               fontWeight: FontWeight.w400,
                //             ),
                //           ),
                //           Spacer(),
                //           Image.asset(
                //             AssetPaths.LOGO,
                //             height: 10,
                //           ),
                //           10.horizontalSpace,
                //           Text(
                //             controller.viewCartModel.value?.tokensDelivery
                //                     .toString() ??
                //                 '0',
                //             textAlign: TextAlign.right,
                //             style: TextStyle(
                //               color: Color(0xFF3D3D3D),
                //               fontSize: 14,
                //               fontFamily: 'Poppins',
                //               fontWeight: FontWeight.w500,
                //             ),
                //           ),
                //         ],
                //       ),

                controller.selectedOrderType.value == OrderType.Delivery
                    ? Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            // "Delivery Charges ",
                            tr('delivery_charges_text'),
                            style: TextStyle(
                              color: Color(0xFF3D3D3D),
                              fontSize: 16,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                          Spacer(),
                          Image.asset(
                            AssetPaths.LOGO,
                            height: 10,
                          ),
                          10.horizontalSpace,
                          Text(
                            controller.viewCartModel.value?.tokensDelivery
                                    .toString() ??
                                '0',
                            textAlign: TextAlign.right,
                            style: TextStyle(
                              color: Color(0xFF3D3D3D),
                              fontSize: 14,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      )
                    : SizedBox.shrink(),

                //Grand Total

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      // 'Grand Total',
                      tr('grand_total_text'),
                      style: TextStyle(
                        color: Color(0xFF3D3D3D),
                        fontSize: 16,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Spacer(),
                    // Image.asset(
                    //   AssetPaths.LOGO,
                    //   height: 10,
                    // ),
                    20.horizontalSpace,
                    // Text(
                    //   controller.viewCartModel.value != null
                    //       ? (

                    //               // controller.selectedOrderType.value == 'Dine-In' ||

                    //               //           controller.selectedOrderType.value ==
                    //               //               'Take Away'
                    //               controller.selectedOrderType.value ==
                    //                           'Dine-In' ||
                    //                       controller.selectedOrderType.value ==
                    //                           'Take Away' ||
                    //                       controller.selectedOrderType.value ==
                    //                           'Drive Thru' ||
                    //                       controller.selectedOrderType.value ==
                    //                           'Curbside'
                    //                   ? differenceToken.toStringAsFixed(2)
                    //                   : controller
                    //                       .viewCartModel.value!.totalToken)
                    //           .toString()
                    //       : "",
                    //   textAlign: TextAlign.right,
                    //   style: TextStyle(
                    //     color: Color(0xFF3D3D3D),
                    //     fontSize: 16,
                    //     fontFamily: 'Poppins',
                    //     fontWeight: FontWeight.w600,
                    //   ),
                    // ),

                    Text(
                      "\$" + totalToken.toString(),
                      textAlign: TextAlign.right,
                      style: TextStyle(
                        color: Color(0xFF666666),
                        fontSize: 14,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                10.verticalSpace,
              ],
            ),
          ),
        ),
      ],
    );
  }

  // Widget _selectPromoCode() {
  Widget _selectOrderType() {
    return BusinessTypeDropdown(
      hintText:
          // "Select Any One",
          tr('select_anyone_text'),
      selectedValue: controller.selectedOrderType.value?.orderString,
      selectionTypes: OrderType.values.map((e) => e.orderString).toList(),
      onChanged: (String? value) {
        controller.selectedOrderType.value = value?.getOrderEnum;
        print(controller.selectedOrderType.value?.name);

        final _queryParameters = {
          'lat': Get.find<SplashController>().currentUser.value?.lat,
          'long': Get.find<SplashController>().currentUser.value?.long,
          'order_type': controller.selectedOrderType.value?.orderStringCheckout,
        };
        controller.dineIncode.clear();

        ViewCartBloc().getViewCartBlocMethod(
            queryParams: _queryParameters,
            context: context,
            loader: true,
            onSuccess: () {
              controller.viewCartModel.value =
                  Get.find<CartController>().viewCartModel.value;
            },
            setProgressBar: () {
              AppDialogs.progressAlertDialog(context: context);
            });
      },
      validator: (value) =>
          // (value == null || value.isEmpty) ? "Select Order Type" : null,
          (value == null || value.isEmpty) ? tr('select_anyone_text') : null,
    );
  }

  LatLng? latLng;

  Widget user_address(BuildContext context) {
    return TextField(
      // controller: controller.user_address,
      // readOnly: !_isEditing,
      controller: controller.user_address.value,
      readOnly: true,
      onTap: () async {
        // final Prediction? prediction =
        //     await Constants.addressPicker(Get.context!);
        // logData(message: "prediction: ${prediction}");
        // if (prediction != null) {
        //   logData(message: "prediction: ${prediction}");
        //   controller.user_address.value.text =
        //       prediction.description.toString();
        //   logData(message: "message: ${controller.user_address.value.text}");
        //   // controller.getLatLongFromAddress(controller.address.value.text);
        // }

        final result = await Constants.showPlacePicker(context);

        if (result != null) {
          controller.user_address.value.text = result.formattedAddress ?? "";
          latLng = result.latLng;

          AuthController.i.getLocationAndUpdateProfile(
              isFromOrderSummary: true,
              address: controller.user_address.value.text,
              context: context,
              onSuccess: () {
                final _queryParams = {
                  'lat': latLng?.latitude.toString() ?? '',
                  'long': latLng?.longitude.toString() ?? '',
                  'order_type':
                      controller.selectedOrderType.value?.orderStringCheckout,
                };

                ViewCartBloc().getViewCartBlocMethod(
                    queryParams: _queryParams,
                    loader: true,
                    context: context,
                    onSuccess: () {
                      controller.viewCartModel.value =
                          Get.find<CartController>().viewCartModel.value;
                    },
                    setProgressBar: () {
                      AppDialogs.progressAlertDialog(context: context);
                    });
              },
              latLng: latLng);
        }
      },
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.grey[200],
        enabledBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Color(0xF3F3F3), width: 0),
          borderRadius: BorderRadius.circular(6.0),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Color(0xF3F3F3), width: 1.5),
          borderRadius: BorderRadius.circular(6.0),
        ),
        isDense: true,
        contentPadding: const EdgeInsets.all(18.0),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(6.0),
        ),
        hintStyle: TextStyle(color: Colors.red),
        prefixIcon: const Padding(
          padding: EdgeInsets.all(8.0),
          child: Icon(
            Icons.location_pin,
            size: 20,
            color: Colors.black,
          ),
        ),
        suffixIcon: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.only(right: 8.0),
              child: GestureDetector(
                onTap: () {},
                child: Text(
                  // 'Edit',
                  tr('locatonscreen.edit'),
                  style: TextStyle(
                    color: Color(0xFFE0201C),
                    fontSize: 14,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w500,
                    decoration: TextDecoration.underline,
                    height: 0,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget promocodeTextfield() {
    return TextField(
      controller: controller.promocode,
      readOnly: false,
      decoration: InputDecoration(
        filled: true,
        fillColor: Color(0xFFF6F6F6),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: Color(0xFFE4E4E4),
            width: 1.0,
            style: BorderStyle.solid,
          ),
          borderRadius: BorderRadius.circular(5.r),
        ),
        hintText: tr('Add_Coupon_Code'),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: Color(0xFFE4E4E4),
            width: 1.0,
            style: BorderStyle.solid,
          ),
          borderRadius: BorderRadius.circular(5.r),
        ),
        isDense: true,
        contentPadding: const EdgeInsets.all(18.0),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(5.r),
        ),
        hintStyle: TextStyle(color: Colors.grey[500]),
        suffixIcon: GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
            String promoCode = controller.promocode.text.trim();
            if (promoCode.isEmpty) {
              AppDialogs.showToast(message: tr('promo_code_is_empty'));
            } else {
              CouponCodeBloc().couponCodeBlocMethod(
                couponCodeText: promoCode,
                context: Constants.navigatorKey.currentContext!,
                setProgressBar: () {
                  AppDialogs.progressAlertDialog(context: context);
                },
              );
            }
          },
          child: Padding(
            padding: EdgeInsets.only(top: 3.h, bottom: 3.h, right: 7.w),
            child: Container(
              width: 100.w,
              decoration: BoxDecoration(
                color: AppColors.PRIMARY_COLOR,
                borderRadius: BorderRadius.circular(5.r),
              ),
              child: Center(
                child: Text(
                  tr('apply_text'),
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.normal),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  FocusNode dineInFocus = FocusNode();

  Widget dineInTextfield() {
    return CustomKeyboardActionWidget(
      focusNode: dineInFocus,
      child: TextFormField(
        focusNode: dineInFocus,
        // controller: controller.user_address,
        // readOnly: !_isEditing,
        // controller: controller.selectedPromoCode.value,
        controller: controller.dineIncode,
        validator: (p0) => FieldValidator2.validateEmpty(
            value: p0!, label: tr('Dine_in_Table_No')),
        keyboardType: TextInputType.number,
        readOnly: false,
        inputFormatters: [
          LengthLimitingTextInputFormatter(2),
          FilteringTextInputFormatter.allow(RegExp("[0-9]")),
        ],

        decoration: InputDecoration(
          filled: true,
          fillColor: Colors.grey[200],
          enabledBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Color(0xF3F3F3), width: 0),
            borderRadius: BorderRadius.circular(6.0),
          ),
          hintText:
              //  "Enter Table Number",
              tr('Dine_in_Table_No'),
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Color(0xF3F3F3), width: 1.5),
            borderRadius: BorderRadius.circular(6.0),
          ),
          isDense: true,
          contentPadding: const EdgeInsets.all(18.0),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(6.0),
          ),
          hintStyle: TextStyle(color: Color.fromARGB(255, 94, 93, 93)),
        ),
      ),
    );
  }

  Widget nearestAddress() {
    return CustomTextField(
      hintText:
          //  'Flat No/Residency',
          tr('Flat_No_Residency'),
      textEditingController: controller.nearestAddressContoller,
      filled: true,
      validator: (p0) => FieldValidator2.validateEmpty(
          value: p0!, label: tr('Flat_No_Residency')),
    );
  }

  Widget nearestFlatResidency() {
    return CustomTextField(
      hintText:
          // 'Nearest Landmark',
          tr('Nearest_landmark'),
      textEditingController: controller.nearestFlatNo,
      filled: true,
      validator: (p0) => FieldValidator2.validateEmpty(
          value: p0!, label: tr('Nearest_landmark')),
    );
  }

  Widget notes() {
    return CustomTextField(
      hintText:
          // 'Nearest Landmark',
          tr('enter_note_for_driver'),
      textEditingController: controller.instructtionsController,
      filled: true,
      isMultiLine: true,
      maxLines: 2,
    );
  }
}
