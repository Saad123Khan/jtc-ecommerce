import 'dart:developer';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_datetime_picker_plus/flutter_datetime_picker_plus.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:jtc_ecommerce/widgets/custom_scaffold.dart';
import 'package:jtc_ecommerce/widgets/custom_text_field.dart';
import 'package:jtc_ecommerce/widgets/custom_app_bar.dart';
import 'package:jtc_ecommerce/widgets/custom_button.dart';
import 'package:jtc_ecommerce/widgets/custom_month_picker.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/order_summary/blocs/payment_bloc.dart';
import 'package:jtc_ecommerce/order_summary/controllers/order_summary_controller.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_constants.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';
import 'package:jtc_ecommerce/utils/app_strings.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';
import 'package:jtc_ecommerce/utils/enums.dart';
import 'package:jtc_ecommerce/utils/validations.dart';

class PaymentScreen extends StatefulWidget {
  PaymentScreen({super.key});

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  var controller = Get.put(OrderSummaryController());

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      appBarTitle: tr('payemnet_text'),
      // titleText: "PAYMENT",
      onTap: () => AppNavigation.navigatorPop(
        context,
      ),
      child: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 10.0.w, vertical: 20.h),
          child: Obx(
            () => Column(
              children: [
                Container(
                  height: MediaQuery.sizeOf(context).height * 0.2,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Color(0xFFF6F6F6),
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(12.r),
                  ),
                  child: Column(
                    children: [
                      20.verticalSpace,
                      Text("Visa Debit Card and Master Card"),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [ 
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Radio(
                                value: PaymentType.Visa,
                                groupValue:
                                    controller.selectedPaymentType.value,
                                activeColor: AppColors.RED_GMAIL_COLOR,
                                onChanged: (PaymentType? value) {
                                  controller.setSelectedPaymentType(value!);
                                }, 
                              ),
                              SizedBox(
                                  height: 5
                                      .h), // Adds a small gap for better alignment
                              Container(
                                height: 40.h,
                                width: 60.w, 
                                child: Image.asset(
                                  AssetPaths.VISA_ICON,
                                  scale: 4.sp,
                                ),
                              ),
                            ],
                          ),
                          20.horizontalSpace,
                          Column(
                            // mainAxisAlignment: MainAxisAlignment.end,
                            // mainAxisSize: MainAxisSize.min,
                            children: [
                              Radio(
                                value: PaymentType.Jtctoken,
                                groupValue:
                                    controller.selectedPaymentType.value,
                                activeColor: AppColors.RED_GMAIL_COLOR,
                                onChanged: (PaymentType? value) {
                                  controller.setSelectedPaymentType(value!);
                                },
                              ),
                              SizedBox(
                                  height: 5
                                      .h), // Ensures the same spacing for alignment
                              Container(
                                height: 40.h,
                                width: 60.w,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8.r),
                                  color: Color(0XFFE6262B),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Image.asset(
                                    AssetPaths.TOKEN_ICON,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                // _selectPaymentTypeWidget(
                //   paymentText:
                //       //  "Debit/Credit Card",
                //       tr('card_text'),
                //   imagePath: AssetPaths.VISA_ICON,
                //   groupValue: controller.selectedPaymentType.value,
                //   onChanged: (PaymentType? value) {
                //     controller.setSelectedPaymentType(value!);
                //   },
                //   value: PaymentType.Visa,
                // ),
                // 10.verticalSpace,
                // _selectPaymentTypeWidget(
                //   paymentText: "Cash",
                //   imagePath: AssetPaths.CASH_ICON,
                //   groupValue: controller.selectedPaymentType.value,
                //   onChanged: (PaymentType? value) {
                //     controller.setSelectedPaymentType(value!);
                //   },
                //   value: PaymentType.Cash,
                // ),
                // 10.verticalSpace,
                // _selectPaymentTypeWidget(
                //   paymentText:
                //       //  "JTC Coin",
                //       tr('token_text'),
                //   imagePath: AssetPaths.TOKEN_ICON,
                //   groupValue: controller.selectedPaymentType.value,
                //   onChanged: (PaymentType? value) {
                //     controller.setSelectedPaymentType(value!);
                //   },
                //   value: PaymentType.Jtctoken,
                // ),
                // 10.verticalSpace,
                // _selectPaymentTypeWidget(
                //   paymentText: "Digital Currency",
                //   imagePath: AssetPaths.COIN_ICON,
                //   groupValue: controller.selectedPaymentType.value,
                //   onChanged: (PaymentType? value) {
                //     controller.setSelectedPaymentType(value!);
                //   },
                //   value: PaymentType.Digitalcurrency,
                // ),
                100.verticalSpace,
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10.0),
                  child: CustomButton(
                    buttonColor: AppColors.PRIMARY_COLOR,
                    onTap: () async {
                      if (controller.selectedPaymentType.value ==
                          PaymentType.Visa) {
                        // controller.latLong =
                        //     await controller.getLatLongFromAddress(
                        //         controller.user_address.value.text, context);
                        // if (controller.latLong != null) {
                        //   print(
                        //       'Latitude: ${controller.latLong?['latitude']}, Longitude: ${controller.latLong?['longitude']}');
                        // } else {
                        //   print(
                        //       'Failed to get latitude and longitude for ${controller.user_address.value.text}');
                        // }

                        AppNavigation.navigateTo(
                            context, AppRouteName.CARD_PAYMENT_SCREEN);
                      }

                      // else if (controller.selectedPaymentType.value ==
                      //     PaymentType.Cash) {
                      //   // AppDialogs.showToast(message: "cash");

                      //   controller.latLong =
                      //       await controller.getLatLongFromAddressCash(
                      //           controller.user_address.value.text,
                      //           "COD",
                      //           context);
                      //   if (controller.latLong != null) {
                      //     print(
                      //         'Latitude: ${controller.latLong?['latitude']}, Longitude: ${controller.latLong?['longitude']}');
                      //   } else {
                      //     print(
                      //         'Failed to get latitude and longitude for ${controller.user_address.value.text}');
                      //   }
                      // }

                      else if (controller.selectedPaymentType.value ==
                          PaymentType.Jtctoken) {
                        // AppDialogs.showToast(message: "coin");
                        controller.latLong =
                            await controller.getLatLongFromAddressCash(
                                controller.user_address.value.text,
                                "COINS",
                                context);
                        if (controller.latLong != null) {
                          print(
                              'Latitude: ${controller.latLong?['latitude']}, Longitude: ${controller.latLong?['longitude']}');
                        } else {
                          print(
                              'Failed to get latitude and longitude for ${controller.user_address.value.text}');
                        }
                      } else {
                        AppDialogs.showToast(
                          message:
                              //  "Please select"
                              tr('please_select_text'),
                        );
                      }
                    },
                    buttonText:
                        //  "PROCEED",
                        tr('proceed_text'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Container _selectPaymentTypeWidget({
    required String imagePath,
    required String paymentText,
    required PaymentType? groupValue,
    required void Function(PaymentType?)? onChanged,
    required PaymentType value,
  }) {
    return Container(
      height: 80,
      padding: EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15.r),
        color: AppColors.GREY_COLOR.withOpacity(0.1),
      ),
      child: Row(
        children: [
          Radio(
            value: value,
            groupValue: groupValue,
            activeColor: AppColors.RED_GMAIL_COLOR,
            onChanged: onChanged,
          ),
          Image.asset(
            imagePath,
            scale: 4.sp,
          ),
          Spacer(),
          SizedBox(
            width: 100,
            child: CustomText(
              text: paymentText,
              fontsize: 14.sp,
              color: AppColors.GREY_COLOR,
            ),
          )
        ],
      ),
    );
  }

  GlobalKey<FormState> formKey = GlobalKey<FormState>();
  Widget contentBox(BuildContext context, String? tokenId) {
    var controller = Get.find<OrderSummaryController>();
    return Material(
      child: Container(
        padding: EdgeInsets.all(16.0),
        decoration: BoxDecoration(
          shape: BoxShape.rectangle,
          color: Colors.white,
          borderRadius: BorderRadius.circular(16.0),
        ),
        child: Form(
          key: formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Text(
                // 'Enter Card Information',
                tr('Enter_Card_Information'),
                style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 16.0),
              SizedBox(
                height: 300.0,
                child: SingleChildScrollView(
                  child: Column(
                    children: <Widget>[
                      name_on_card_widget(),
                      SizedBox(height: 8.0),
                      card_details_Widget(),
                      SizedBox(height: 8.0),
                      expiry_and_cvv_Widget(context)
                    ],
                  ),
                ),
              ),
              SizedBox(height: 16.0),
              saveButtonWidget(context, tokenId ?? ""),
            ],
          ),
        ),
      ),
    );
  }

  Widget name_on_card_widget() {
    return CustomTextField(
        hintText: tr('jtctokenscreen.cardholder_text'),
        //  AppStrings.CARD_HOLDER_TEXT,
        textInputFormattors: [LengthLimitingTextInputFormatter(35)],
        textEditingController: controller.account_holder_controller,
        validator: (value) {
          return FieldValidator2.validateEmpty(
              value: value!, label: AppStrings.CARD_HOLDER_TEXT);
        });
  }

  Widget card_details_Widget() {
    return CustomTextField(
        hintText:
            // AppStrings.CARD_NUMBER_TEXT,
            tr('jtctokenscreen.cardnumber_text'),
        textInputFormattors: [AppConstant.MASK_TEXT_FORMATTER_CARD_NO],
        keyboardType: TextInputType.phone,
        textEditingController: controller.account_number_controller,
        validator: (value) {
          return FieldValidator2.validateCardNo(
              value: AppConstant.MASK_TEXT_FORMATTER_CARD_NO.unmaskText(value!),
              label: AppStrings.CARD_NUMBER_TEXT);
        });
  }

  Widget expiry_and_cvv_Widget(context) {
    return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Expanded(
        flex: 1,
        child: Column(children: [
          CustomTextField(
            suffixIcon: AssetPaths.CALENDAR_ICON,
            readyOnly: true,
            onTap: () async {
              DatePicker.showPicker(
                context,
                pickerModel: CustomMonthPicker(
                  minTime: DateTime.now(),
                  maxTime: DateTime(2050, 1, 1),
                  currentTime: DateTime.now(),
                ),
                onConfirm: (time) {
                  setState(() {});
                  if (time != null) {
                    String formattedDate = DateFormat('MM/yy').format(time);
                    logData(message: "formattedDate: ${formattedDate}");
                    controller.expiry_controller.text = formattedDate;
                  } else {
                    print("Date is not selected");
                  }
                  // },
                },
              );
            },
            textInputFormattors: [AppConstant.MASK_TEXT_FORMATTER_EXPIRY],
            keyboardType: TextInputType.phone,
            textEditingController: controller.expiry_controller,
            validator: (value) {
              return FieldValidator2.validateEmpty(
                  value: value!, label: AppStrings.EXPIRY_DATE_TEXT);
            },
            // hintText: AppStrings.EXPIRY_DATE_TEXT,
            hintText: tr('jtctokenscreen.expirydate_text'),
          ),
        ]),
      ),
      SizedBox(width: 15.w),
      Expanded(
        flex: 1,
        child: Column(children: [
          CustomTextField(
              // hintText: AppStrings.CVC_TEXT,
              hintText: tr('jtctokenscreen.cvc_text'),
              textInputFormattors: [LengthLimitingTextInputFormatter(4)],
              keyboardType: TextInputType.phone,
              textEditingController: controller.cvc_controller,
              validator: (value) {
                return FieldValidator2.validateCVC(
                    value: value!, label: AppStrings.CVC_TEXT);
              }),
        ]),
      ),
    ]);
  }

  Widget saveButtonWidget(context, String tokenId) {
    var controller = Get.find<OrderSummaryController>();
    return CustomButton(
      buttonText: tr('jtctokenscreen.add_text'),
      // buttonText: AppStrings.ADD_TEXT,

      onTap: () async {
        final isValid = formKey.currentState!.validate();
        if (!isValid) {
          return;
        }
        formKey.currentState!.save();
        //New
        log("Card Number ${controller.account_number_controller.text}");
        log("Exp Month ${controller.expiry_controller.text.split('/').first}");
        log("Exp Year ${controller.expiry_controller.text.split('/').last}");
        log("CVC ${controller.cvc_controller.text}");
        int expMonth =
            int.parse(controller.expiry_controller.text.split('/').first);
        int expYear =
            int.parse(controller.expiry_controller.text.split('/').last);
        //!Call here
        ProductPaymentBloc().saveAddress(
          context: context,
          cardNumber: controller.account_number_controller.text,
          expMonth: expMonth,
          expYear: expYear,
          cvc: controller.cvc_controller.text.trim(),
          token: tokenId,
          setProgressBar: () {
            AppDialogs.progressAlertDialog(context: context);

            // AppNavigation.navigateTo(
            //         context, AppRouteName.PREPARATION_TIME_ROUTE,
            //         arguments: [

            //         ]
            //         );
          },
        );
        FocusScope.of(context).unfocus();
      },
      buttonColor: AppColors.PRIMARY_COLOR,
    );
  }
}
