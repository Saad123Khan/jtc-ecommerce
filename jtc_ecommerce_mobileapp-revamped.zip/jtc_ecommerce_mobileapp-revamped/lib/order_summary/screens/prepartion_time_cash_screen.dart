// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:get/get.dart';
// import 'package:get/get_core/src/get_main.dart';
// import 'package:get/get_instance/get_instance.dart';
// import 'package:jtc_ecommerce/gloabl_widgets/custom_app_bar.dart';
// import 'package:jtc_ecommerce/gloabl_widgets/custom_button.dart';
// import 'package:jtc_ecommerce/gloabl_widgets/custom_willpopscope_dialog.dart';
// import 'package:jtc_ecommerce/order_summary/controllers/preparation_time_cash_controller.dart';
// import 'package:jtc_ecommerce/utils/app_colors.dart';
// import 'package:jtc_ecommerce/utils/app_navigation.dart';
// import 'package:jtc_ecommerce/utils/app_routes_name.dart';

// import '../controllers/order_summary_controller.dart';

// class PrepartionTimeCashScreen extends StatefulWidget {
//   PrepartionTimeCashScreen({
//     super.key,
//   });

//   @override
//   State<PrepartionTimeCashScreen> createState() =>
//       _PrepartionTimeCashScreenState();
// }

// class _PrepartionTimeCashScreenState extends State<PrepartionTimeCashScreen> {
//   // final controller = Get.put(PreparationTimeControllerCash());
//   // @override
//   // void initState() {
//   //   super.initState();
//   //   // Start the timer when the screen is initialized
//   //   // controller.startTimer();
//   // }

//   final controller = Get.put(OrderSummaryController());
//   @override
//   void initState() {
//     super.initState();
//     // Start the timer when the screen is initialized
//     controller.getSalesAppFunc("25");
//     // controller.startTimer();
//   }

//   @override
//   void dispose() {
//     // Stop the timer when the screen is disposed
//     controller.stopTimer();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return WillPopScope(
//       key: GlobalKey(),
//       onWillPop: () async {
//         return await Get.defaultDialog(
//           barrierDismissible: false,
//           title: "Exit",
//           content: ExitButtonContent(
//             onTapYesButton: () {
//               SystemNavigator.pop();
//             },
//           ),
//         );
//       },
//       child: Scaffold(
//           body: Stack(
//         children: [
//           Container(
//             color: Color(0xff2E2E2E),
//             width: double.infinity,
//             child: Column(
//               children: [
//                 // Row(
//                 //   children: [
//                 //     Obx(() => Text(
//                 //           controller.preparationTime.isNotEmpty
//                 //               ? controller.preparationTime[0].startTime ?? "hh"
//                 //               : "",
//                 //           style: TextStyle(
//                 //             color: Colors.white,
//                 //             fontSize: 20,
//                 //             fontFamily: 'Bebas',
//                 //             fontWeight: FontWeight.w400,
//                 //           ),
//                 //         )),
//                 //     SizedBox(width: 10),
//                 //     Obx(() => Text(
//                 //           controller.preparationTime.isNotEmpty
//                 //               ? controller.preparationTime[0].endTime ?? "hhh"
//                 //               : "",
//                 //           style: TextStyle(
//                 //             color: Colors.white,
//                 //             fontSize: 20,
//                 //             fontFamily: 'Bebas',
//                 //             fontWeight: FontWeight.w400,
//                 //           ),
//                 //         )),
//                 //   ],
//                 // ),
//                 SizedBox(
//                   height: 180,
//                 ),
//                 // Obx(
//                 //   () => controller.showButton.value
//                 //       ? Text(
//                 //           controller.formattedTime.value,
//                 //           textAlign: TextAlign.center,
//                 //           style: TextStyle(
//                 //             color: Colors.white,
//                 //             fontSize: 40,
//                 //             fontFamily: 'Poppins',
//                 //             fontWeight: FontWeight.w500,
//                 //           ),
//                 //         )
//                 //       : Text(
//                 //           "",
//                 //           style: TextStyle(
//                 //             color: Colors.white,
//                 //             fontSize: 40,
//                 //             fontFamily: 'Poppins',
//                 //             fontWeight: FontWeight.w500,
//                 //           ),
//                 //         ),
//                 // ),
//                 // Text(
//                 //   'Required Time',
//                 //   textAlign: TextAlign.center,
//                 //   style: TextStyle(
//                 //     color: Colors.white,
//                 //     fontSize: 18,
//                 //     fontFamily: 'Poppins',
//                 //     fontWeight: FontWeight.w400,
//                 //   ),
//                 // ),
//                 // Obx(
//                 //   () => controller.showButton.value
//                 //       ? Column(
//                 //           children: [
//                 //             Text(
//                 //               controller.formattedTime.value,
//                 //               textAlign: TextAlign.center,
//                 //               style: TextStyle(
//                 //                 color: Colors.white,
//                 //                 fontSize: 40,
//                 //                 fontFamily: 'Poppins',
//                 //                 fontWeight: FontWeight.w500,
//                 //               ),
//                 //             ),
//                 //             Text(
//                 //               'Required Time',
//                 //               textAlign: TextAlign.center,
//                 //               style: TextStyle(
//                 //                 color: Colors.white,
//                 //                 fontSize: 18,
//                 //                 fontFamily: 'Poppins',
//                 //                 fontWeight: FontWeight.w400,
//                 //               ),
//                 //             ),
//                 //           ],
//                 //         )
//                 //       : SizedBox.shrink(),
//                 // )

//                 Obx(
//                   () {
//                     if (controller.getSalesappVar.value != null) {
//                       return Column(
//                         children: [
//                           Text(
//                             _getTextBasedOnStatus(
//                                 controller.getSalesappVar.value?.orderStatus ??
//                                     "pending"),
//                             textAlign: TextAlign.center,
//                             style: TextStyle(
//                               color: Colors.white,
//                               fontSize: 40,
//                               fontFamily: 'Poppins',
//                               fontWeight: FontWeight.w500,
//                             ),
//                           ),
//                           SizedBox(
//                             height: 5,
//                           ),
//                           Text(
//                             'Thank you For Your Order',
//                             textAlign: TextAlign.center,
//                             style: TextStyle(
//                               color: Colors.white,
//                               fontSize: 18,
//                               fontFamily: 'Poppins',
//                               fontWeight: FontWeight.w400,
//                             ),
//                           ),
//                         ],
//                       );
//                     } else {
//                       // Handle the case when controller.getSalesappVar is null
//                       return Column(
//                         children: [
//                           Text(
//                             'Loading...', // or any other message indicating loading state
//                             textAlign: TextAlign.center,
//                             style: TextStyle(
//                               color: Colors.white,
//                               fontSize: 40,
//                               fontFamily: 'Poppins',
//                               fontWeight: FontWeight.w500,
//                             ),
//                           ),
//                         ],
//                       );
//                     }
//                   },
//                 )
//               ],
//             ),
//           ),
//           // Positioned(
//           //     top: 14,
//           //     left: 15,
//           //     // right: 10,
//           //     child: GestureDetector(
//           //         onTap: () {
//           //           // Get.back();
//           //         },
//           //         child: Image.asset("assets/images/back_white.png"))
//           //         ),
//           Positioned(
//             bottom: 0,
//             left: 0,
//             right: 0,
//             child: Container(
//               width: double.infinity,
//               height: 350,
//               decoration: BoxDecoration(
//                 color: Colors.white,
//                 borderRadius: BorderRadius.only(
//                   topLeft: Radius.circular(15),
//                   topRight: Radius.circular(15),
//                 ),
//                 boxShadow: [
//                   BoxShadow(
//                     color: Color(0x3F000000),
//                     blurRadius: 40,
//                     offset: Offset(0, -15),
//                     spreadRadius: 0,
//                   ),
//                 ],
//               ),
//               child: Padding(
//                 padding: const EdgeInsets.symmetric(horizontal: 15),
//                 child: Column(
//                   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                   crossAxisAlignment: CrossAxisAlignment.center,
//                   children: [
//                     GestureDetector(
//                         onTap: () {
//                           // Get.to(ThankYouScreen());
//                         },
//                         child:
//                             Image.asset("assets/images/order_time_image.png")),
//                     Text(
//                       'Be Patience',
//                       textAlign: TextAlign.center,
//                       style: TextStyle(
//                         color: Color(0xFF3D3D3D),
//                         fontSize: 18,
//                         fontFamily: 'Poppins',
//                         fontWeight: FontWeight.w400,
//                       ),
//                     ),
//                     Padding(
//                       padding: const EdgeInsets.symmetric(horizontal: 50.0),
//                       child: CustomButton(
//                         buttonColor: AppColors.PRIMARY_COLOR,
//                         onTap: () {
//                           AppNavigation.navigateTo(
//                             context,
//                             AppRouteName.BOTTOM_NAVIGATION_SCREEN_ROUTE,
//                           );
//                         },
//                         buttonText: "Go Back ",
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           ),
//         ],
//       )),
//     );
//   }

//   String _getTextBasedOnStatus(String orderStatus) {
//     switch (orderStatus) {
//       case "0":
//         return "Pending";
//       case "1":
//         return "Accepted By JTC";
//       case "2":
//         return "Preparing";
//       case "3":
//         return "Delivered";
//       case "4":
//         return "Completed";
//       case "5":
//         return "Returned";
//       case "6":
//         return "Refunded";
//       case "7":
//         return "Cancelled";
//       case "8":
//         return "Hold";
//       case "9":
//         return "Start Delivery";
//       case "10":
//         return "Rider Arrived";
//       case "11":
//         return "Rider Pick-Up Order";
//       default:
//         return "Processing";
//     }
//   }
// }
