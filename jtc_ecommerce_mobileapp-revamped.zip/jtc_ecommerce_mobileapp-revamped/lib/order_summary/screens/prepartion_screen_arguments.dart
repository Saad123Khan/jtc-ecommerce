class PreparaationScreenArguments {
  final String orderId;

  PreparaationScreenArguments({required this.orderId});
}
