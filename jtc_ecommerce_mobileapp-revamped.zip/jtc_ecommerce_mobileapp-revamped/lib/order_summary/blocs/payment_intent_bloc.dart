import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as GetxController;
import 'package:get/get_core/src/get_main.dart';
import 'package:jtc_ecommerce/order_summary/controllers/order_summary_controller.dart';
import 'package:jtc_ecommerce/order_summary/controllers/preparation_time_cash_controller.dart';
import 'package:jtc_ecommerce/order_summary/models/checkout_cash_model.dart';
import 'package:jtc_ecommerce/order_summary/models/checkout_model.dart';
import 'package:jtc_ecommerce/order_summary/models/payment_intent_model.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';

class PaymentIntentBloc {
  Map<String, dynamic>? _formDataMap;
  Response? _response;
  VoidCallback? _onSuccess, _onFailure;
  // AddToCartModel? _addToCartModel;
  PaymentIntentModel? _checkoutModel;

  void PaymentIntentBlocMethod({
    required BuildContext context,
    required VoidCallback setProgressBar,
    String? amount,
  }) async {
    setProgressBar();

    //! ============> Form Data
    _formDataMap = {
      "amount": amount,
    };

    //! ============> Print Form Data
    print({
      "amount": amount,
    });

    //! ============> If Api fails then stop the loader
    _onFailure = () {
      AppNavigation.navigatorPop(context);
    };

    //! ============> Call api
    await _postRequest(
      endPoint: NetworkStrings.PAYMENT_INTENT_ENDPOINT,
      context: GetxController.Get.context!,
    );

    //! ============> Get the login response
    _onSuccess = () {
      AppNavigation.navigatorPop(context);
      _loginResponseMethod(context: context);
    };

    //! ============> Validate the response
    _validateResponse(context: context);
  }

  //! ============> Post Request
  Future<void> _postRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().postRequestRawData(
      endPoint: endPoint,
      body: _formDataMap,
      onFailure: _onFailure,
      isHeaderRequire: true,
      context: context,
    );
  }

  //! ============> Validate Response
  void _validateResponse({required BuildContext context}) {
    if (_response != null) {
      Network().validateResponse(
        isToast: false,
        response: _response,
        onSuccess: _onSuccess,
        onFailure: _onFailure,
      );
      // logData(message: "Re: ${_response}");
      // _checkoutModel = CheckoutModel.fromJson(_response?.data);
      // AppDialogs.showToast(message: _checkoutModel?.message);
      // AppNavigation.navigateToRemovingAll(
      //     context, AppRouteName.BOTTOM_NAVIGATION_SCREEN_ROUTE);
    }
  }

  //! ============> Creating a controller instance to save the user id temp for next verification otp api
  // var authContorller = GetxController.Get.find<AuthController>();

  //! ============> Login Response
  void _loginResponseMethod({required BuildContext context}) async {
    final controller = Get.put(OrderSummaryController());
    try {
      logData(message: "Response: ${_response?.data}");
      _checkoutModel = PaymentIntentModel.fromJson(_response?.data);
      AppDialogs.showToast(message: _checkoutModel?.data.message ?? "");

      controller.paymentIntentVar.add(_checkoutModel!.data);

      AppNavigation.navigateTo(context, AppRouteName.PAYMENT_SCREEN);
    } catch (error) {
      AppDialogs.showToast(message: tr(NetworkStrings.SOMETHING_WENT_WRONG));
    }
  }
}
