// import 'package:dio/dio.dart';
// import 'package:easy_localization/easy_localization.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart' as GetxController;
// import 'package:jtc_ecommerce/order_summary/models/checkout_model.dart';
// import 'package:jtc_ecommerce/services/app_logger.dart';
// import 'package:jtc_ecommerce/services/network.dart';
// import 'package:jtc_ecommerce/services/translate_service.dart';
// import 'package:jtc_ecommerce/utils/app_dialogs.dart';
// import 'package:jtc_ecommerce/utils/app_navigation.dart';
// import 'package:jtc_ecommerce/utils/app_network_strings.dart';
// import 'package:jtc_ecommerce/utils/app_routes_name.dart';

// class CheckoutCashBloc {
//   Map<String, dynamic>? _formDataMap;
//   Response? _response;
//   VoidCallback? _onSuccess, _onFailure;
//   // AddToCartModel? _addToCartModel;
//   CheckoutModel? _checkoutModel;

//   void checkoutCashBlocMethod({
//     required BuildContext context,
//     required VoidCallback setProgressBar,
//     String? address,
//     String? longitude,
//     String? nearestAddress,
//     String? nearestFlat,
//     String? latitude,
//     String? order_type,
//     String? promo_code_id,
//     String? payment_type,
//     String? table_number,
//   }) async {
//     setProgressBar();

//     //! ============> Form Data
//     _formDataMap = {
//       // if (order_type == "delivery")
//       "address": address,
//       if (table_number != null) 'table_number': table_number,
//       if (promo_code_id != null && promo_code_id.isNotEmpty)
//         'promo_code': promo_code_id,
//       // "promo_code_id": promo_code_id,
//       "longitude": longitude,
//       "latitude": latitude,

//       "order_type": order_type,

//       if (order_type == "delivery") "nearest_address": nearestAddress,
//       if (order_type == "delivery") "nearest_flatno": nearestFlat,

//       "payment_type": payment_type // COINS, COD, CARD
//     };

//     //! ============> Print Form Data
//     print({
//       "address": address,
//       "promo_code_id": promo_code_id,
//       "longitude": longitude,
//       "latitude": latitude,
//       "order_type": order_type,
//       "payment_type": payment_type // COINS, COD, CARD
//     });

//     //! ============> If Api fails then stop the loader
//     // ! ============> If Api fails then stop the loader
//     _onFailure = () async {
//       AppNavigation.navigatorPop(context);

//       print("STATUSSS CODEE ${_response?.statusCode}");
//       final message = _response?.data['message'] ?? "";

//       print(message);

//       switch (message) {
//         case "Invalid Email or Password":
//           AppDialogs.showToast(
//               message: tr(NetworkStrings.INVALID_EMAIL_OR_PASSWORD));
//           break;

//         default:
//           if (context.locale.languageCode != "en") {
//             final _translatedMessage = await GoogleTranslatorService()
//                 .translate(text: message, context: context);
//             AppDialogs.showToast(message: _translatedMessage);
//             print(_translatedMessage);
//           } else {
//             AppDialogs.showToast(message: message);
//           }
//       }
//     };
//     //! ============> Call api
//     await _postRequest(
//       endPoint: NetworkStrings.CHECKOUT_ENDPOINT,
//       context: GetxController.Get.context!,
//     );

//     //! ============> Get the login response
//     _onSuccess = () {
//       AppNavigation.navigatorPop(context);
//       _loginResponseMethod(context: context);
//     };

//     //! ============> Validate the response
//     _validateResponse(context: context);
//   }

//   //! ============> Post Request
//   Future<void> _postRequest(
//       {required String endPoint, required BuildContext context}) async {
//     _response = await Network().postRequestRawData(
//       endPoint: endPoint,
//       body: _formDataMap,
//       isErrorToast: false,
//       onFailure: _onFailure,
//       isHeaderRequire: true,
//       customFailure: true,
//       isToast: false,
//       context: context,
//     );
//   }

//   //! ============> Validate Response
//   void _validateResponse({required BuildContext context}) {
//     if (_response != null) {
//       Network().validateResponse(
//         isToast: false,
//         response: _response,
//         onSuccess: _onSuccess,
//         onFailure: _onFailure,
//       );
//       // logData(message: "Re: ${_response}");
//       // _checkoutModel = CheckoutModel.fromJson(_response?.data);
//       // AppDialogs.showToast(message: _checkoutModel?.message);
//       // AppNavigation.navigateToRemovingAll(
//       //     context, AppRouteName.BOTTOM_NAVIGATION_SCREEN_ROUTE);
//     }
//   }

//   //! ============> Creating a controller instance to save the user id temp for next verification otp api
//   // var authContorller = GetxController.Get.find<AuthController>();

//   //! ============> Login Response
//   void _loginResponseMethod({
//     required BuildContext context,
//   }) async {
//     // final controller = Get.put(PreparationTimeControllerCash());
//     // try {
//     logData(message: "Response: ${_response?.data}");
//     // _checkoutModel = CheckoutCashModel.fromJson(_response?.data);
//     // // AppNavigation.navigateTo(context, AppRouteName.PAYMENT_SCREEN);

//     // print(_checkoutModel?.message);
//     // // AppDialogs.showToast(message: _checkoutModel?.message ?? "");

//     // if (_checkoutModel?.message == "Order Created Successfully!") {
//     //   AppDialogs.showToast(message: tr('order_created_successfully'));
//     // } else {
//     //   AppDialogs.showToast(message: _checkoutModel?.message);
//     // }

//     // GetxController.Get.offAll(PrepartionTimeScreen(
//     //   orderId: _checkoutModel!.data.order.id.toString(),
//     // ));

//     //  _checkoutModel = CheckoutModel.fromJson(_response?.data);
//     // AppNavigation.navigateTo(context, AppRouteName.CARD_PAYMENT_SCREEN);
//     // CardPaymentScreen
//     // AppDialogs.showToast(message: _checkoutModel?.message ?? "");

//     //   print("order_created_successfully");
//     // print(_checkoutModel?.message);

//     if (_response?.data['message'] == "Order Created Successfully!") {
//       AppDialogs.showToast(message: tr('order_created_successfully'));
//     } else {
//       AppDialogs.showToast(message: _checkoutModel?.message);
//     }

//     AppNavigation.navigateToRemovingAll(
//         context, AppRouteName.BOTTOM_NAVIGATION_SCREEN_ROUTE);

//     // controller.preparationTime.add(_checkoutModel!.data.order);

//     // logData(message: "goalList For home: ${controller.preparationTime.length}");

//     // AppNavigation.navigateTo(
//     //   context,
//     //   AppRouteName.PREPARATION_TIME__CASH_ROUTE,

//     // );
//     // } catch (error) {
//     //   AppDialogs.showToast(message: tr(NetworkStrings.SOMETHING_WENT_WRONG));
//     // }
//   }
// }
