import 'dart:developer';
import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:jtc_ecommerce/order_summary/controllers/order_summary_controller.dart';
import 'package:jtc_ecommerce/order_summary/models/order_confirm_mode.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/services/stripe_service.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';
import 'package:get/get.dart' as Getx;

class ProductPaymentBloc {
  Map<String, dynamic>? _formMapData;
  Response? _response;
  VoidCallback? _onSuccess, _onFailure;
  OrderConfirmModel? _orderConfirmModel;

  void saveAddress({
    required BuildContext context,
    required VoidCallback setProgressBar,
    String? cardNumber,
    int? expMonth,
    int? expYear,
    String? cvc,
    String? token,
    String? amount,
    String? cardToken
  }) async {
    setProgressBar();

    //Stripe
   
    if (cardToken != null) {
      _onFailure = () {
        Navigator.pop(context);
      };

      _formMapData = {"token": cardToken, "amount": amount};

      log(_formMapData.toString());

      await _postRequest(
        endPoint: NetworkStrings.ORDER_CONFIRM_MOBILE_ENDPOINT,
        context: context,
      );

      _onSuccess = () {
        Navigator.pop(context);
        _validateAddresses(context);
      };

      _validateResponse();
    } else {
      Navigator.pop(context);
    }
  }

  /// Post Request
  Future<void> _postRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().postRequestRawData(
      endPoint: endPoint,
      body: _formMapData,
      context: context,
      onFailure: _onFailure,
      isHeaderRequire: true,
      isToast: false,
    );
  }

  /// Validate Response
  void _validateResponse() {
    if (_response != null) {
      Network().validateResponse(
        response: _response,
        onSuccess: _onSuccess,
        onFailure: _onFailure,
        isToast: false,
      );
      // logData(message: "Rez: ${_response?.data}");
    }
  }

  void _validateAddresses(BuildContext context) {
    var controller = Getx.Get.find<OrderSummaryController>();
    try {
      _orderConfirmModel = OrderConfirmModel.fromJson(_response?.data);
      logData(message: " order connfirm mobilee : ${_orderConfirmModel?.data}");
      // AppDialogs.showToast(message: _orderConfirmModel?.message ?? "");

      // print("payment_created");
      // print(_orderConfirmModel?.message);

      if (_orderConfirmModel?.message == "Payment Created Successfully") {
        AppDialogs.showToast(message: tr('payment_created'));
      } else {
        AppDialogs.showToast(message: _orderConfirmModel?.message);
      }

      // // Add the received data to the couponList
      controller.createPayment.value = _orderConfirmModel;
// logData(message: "goalList For home: ${controller.preparationTime.length}");

//order checkout api call
      controller.getLatLongFromAddress(
          controller.user_address.value.text, context);

//order confirm api call
      // var orderConfirmBloc = orderConfirmPreparationTimeBloc();
      // orderConfirmBloc.orderConfirmPreparationTimeBlocMethod(
      //     context: context,
      //     setProgressBar: () {
      //       AppDialogs.progressAlertDialog(context: context);
      //     },
      //     paymentId: "ch_3PEUmQHR4p2bAk2C11iOrI8X",
      //     orderId: 1);

      // AppNavigation.navigateTo(
      //   context,
      //   AppRouteName.PREPARATION_TIME_ROUTE,
      // );
    } catch (e) {
      AppDialogs.showToast(message: tr(NetworkStrings.SOMETHING_WENT_WRONG));
    }
  }
}
