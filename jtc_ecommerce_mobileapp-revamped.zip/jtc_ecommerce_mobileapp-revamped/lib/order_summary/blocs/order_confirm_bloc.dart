import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as GetxController;
import 'package:get/get_core/src/get_main.dart';
import 'package:jtc_ecommerce/order_summary/controllers/order_summary_controller.dart';
import 'package:jtc_ecommerce/order_summary/controllers/preparation_time_cash_controller.dart';
import 'package:jtc_ecommerce/order_summary/models/checkout_cash_model.dart';
import 'package:jtc_ecommerce/order_summary/models/checkout_model.dart';
import 'package:jtc_ecommerce/order_summary/models/confirmordermodel_preparation.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';

import '../screens/prepartion_screen_arguments.dart';
import '../screens/prepartion_time_screen.dart';

class orderConfirmPreparationTimeBloc {
  Map<String, dynamic>? _formDataMap;
  Response? _response;
  VoidCallback? _onSuccess, _onFailure;
  // AddToCartModel? _addToCartModel;
  OrderConfirmPreparationTimeModel? _checkoutModel;

  Future<void> orderConfirmPreparationTimeBlocMethod({
    required BuildContext context,
    required VoidCallback setProgressBar,
    Function()? onSuccess,
    String? paymentId,
    int? orderId,
  }) async {
    setProgressBar();

    //! ============> Form Data
    _formDataMap = {
      "payment_id": paymentId,
      "order_id": orderId,
    };

    //! ============> Print Form Data
    print({
      "payment_id": paymentId,
      "order_id": orderId,
    });

    //! ============> If Api fails then stop the loader
    _onFailure = () {
      AppNavigation.navigatorPop(context);
    };

    //! ============> Call api
    await _postRequest(
      endPoint: NetworkStrings.ORDER_CONFIRM_PREPARATIONTime,
      context: GetxController.Get.context!,
    );

    //! ============> Get the login response
    _onSuccess = () {
      AppNavigation.navigatorPop(context);
      _loginResponseMethod(context: context, onSuccess: onSuccess);
    };

    //! ============> Validate the response
    _validateResponse(
      context: context,
    );
  }

  //! ============> Post Request
  Future<void> _postRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().postRequestRawData(
      endPoint: endPoint,
      body: _formDataMap,
      onFailure: _onFailure,
      isHeaderRequire: true,
      context: context,
    );
  }

  //! ============> Validate Response
  void _validateResponse({required BuildContext context}) {
    if (_response != null) {
      Network().validateResponse(
        isToast: false,
        response: _response,
        onSuccess: _onSuccess,
        onFailure: _onFailure,
      );
      // logData(message: "Re: ${_response}");
      // _checkoutModel = CheckoutModel.fromJson(_response?.data);
      // AppDialogs.showToast(message: _checkoutModel?.message);
      // AppNavigation.navigateToRemovingAll(
      //     context, AppRouteName.BOTTOM_NAVIGATION_SCREEN_ROUTE);
    }
  }

  //! ============> Creating a controller instance to save the user id temp for next verification otp api
  // var authContorller = GetxController.Get.find<AuthController>();

  //! ============> Login Response
  void _loginResponseMethod({
    required BuildContext context,
    Function()? onSuccess,
  }) async {
    final controller = Get.put(OrderSummaryController());
    try {
      logData(message: "Response: ${_response?.data}");
      _checkoutModel =
          OrderConfirmPreparationTimeModel.fromJson(_response?.data);
      // AppNavigation.navigateTo(context, AppRouteName.PAYMENT_SCREEN);
      // AppDialogs.showToast(message: _checkoutModel?.message ?? "");
      // print("order_confirmed_successfully");
      // print(_checkoutModel?.message);

      if (_checkoutModel?.message == "Order confirmed successfully!") {
        AppDialogs.showToast(message: tr('order_confirmed_successfully'));
      } else {
        AppDialogs.showToast(message: _checkoutModel?.message);
      }

      // controller.preparationTime.add(_checkoutModel!.data);
      onSuccess?.call();

      // logData(
      //     message: "goalList For home: ${controller.preparationTime.length}");

      // AppNavigation.navigateTo(
      //   context,
      //   AppRouteName.PREPARATION_TIME__CASH_ROUTE,
      // );
    } catch (error) {
      AppDialogs.showToast(message: tr(NetworkStrings.SOMETHING_WENT_WRONG));
    }
  }
}
