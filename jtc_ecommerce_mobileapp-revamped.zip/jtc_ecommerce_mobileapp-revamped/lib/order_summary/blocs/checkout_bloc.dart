import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as GetxController;
import 'package:jtc_ecommerce/cart/controllers/cart_controller.dart';
import 'package:jtc_ecommerce/order_summary/controllers/order_summary_controller.dart';
import 'package:jtc_ecommerce/order_summary/models/checkout_model.dart';
import 'package:jtc_ecommerce/order_summary/screens/prepartion_time_order_screen.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/services/translate_service.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';

class CheckoutCardBloc {
  Map<String, dynamic>? _formDataMap;
  Response? _response;
  VoidCallback? _onSuccess, _onFailure;
  // AddToCartModel? _addToCartModel;
  CheckoutModel? _checkoutModel;

  void checkoutBlocMethod({
    required BuildContext context,
    required VoidCallback setProgressBar,
    String? address,
    String? longitude,
    String? latitude,
    String? order_type,
    String? promo_code_id,
    String? table_number,
    String? nearestAddress,
    String? nearestFlat,
    String? paymentId,
    String? payment_type,
    String? instructions,
    String? deliveryCharges,
  }) async {
    setProgressBar();

    //! ============> Form Data
    _formDataMap = {
      if (order_type == "delivery") "address": address,
      if (promo_code_id != null && promo_code_id != "")
        "promo_code": promo_code_id,
      if (table_number != null) 'table_number': table_number,
      "longitude": longitude,
      "latitude": latitude,
      "order_type": order_type?.toLowerCase(),
      if (order_type == "delivery") "nearest_address": nearestAddress,
      if (order_type == "delivery") "nearest_flatno": nearestFlat,
      "payment_type": payment_type ?? "CARD", // COINS, COD, CARD,
      if (paymentId != null) "token": paymentId,
      if (instructions != null && instructions != "")
        "customer_instruction": instructions,
      if (deliveryCharges != null) "delivery_charges": deliveryCharges
      // "delivery_charge": "20",
      // "delivery_time": "10",
      // "order_amount": "343",
      // "coupon_amount": "20",
      // "amount": "343"
    };

    //! ============> Print Form Data
    print({
      "address": address,
      "promo_code_id": promo_code_id,
      "table_number": table_number,
      "longitude": longitude,
      "latitude": latitude,
      "order_type": order_type?.toLowerCase(),
      "nearest_address": nearestAddress,
      "nearest_flatno": nearestFlat,
      "token": paymentId,
      "payment_type": "CARD" // COINS, COD, CARD
    });

    //! ============> If Api fails then stop the loader
    _onFailure = () async {
      AppNavigation.navigatorPop(context);

      print("STATUSSS CODEE ${_response?.statusCode}");
      final message = _response?.data['message'] ?? "";

      switch (message) {
        // case "Invalid Email or Password":
        //   AppDialogs.showToast(
        //       message: tr(NetworkStrings.INVALID_EMAIL_OR_PASSWORD));
        //   break;

        default:
          if (context.locale.languageCode != "en") {
            final _translatedMessage = await GoogleTranslatorService()
                .translate(text: message, context: context);
            AppDialogs.showToast(message: _translatedMessage);
          } else {
            AppDialogs.showToast(message: message);
          }
      }
    };

    //! ============> Call api
    await _postRequest(
      endPoint: NetworkStrings.CHECKOUT_ENDPOINT,
      context: GetxController.Get.context!,
    );

    //! ============> Get the login response
    _onSuccess = () {
      AppNavigation.navigatorPop(context);
      _loginResponseMethod(
        context: context,
        paymentId: paymentId,
      );
    };

    //! ============> Validate the response
    _validateResponse(context: context);
  }

  //! ============> Post Request
  Future<void> _postRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().postRequestRawData(
        endPoint: endPoint,
        body: _formDataMap,
        onFailure: _onFailure,
        isHeaderRequire: true,
        context: context,
        isErrorToast: false,
        customFailure: true
        // isToast: false,
        );
  }

  //! ============> Validate Response
  void _validateResponse({required BuildContext context}) {
    if (_response != null) {
      Network().validateResponse(
        isToast: false,
        response: _response,
        onSuccess: _onSuccess,
        onFailure: _onFailure,
      );
      // logData(message: "Re: ${_response}");
      // _checkoutModel = CheckoutModel.fromJson(_response?.data);
      // AppDialogs.showToast(message: _checkoutModel?.message);
      // AppNavigation.navigateToRemovingAll(
      //     context, AppRouteName.BOTTOM_NAVIGATION_SCREEN_ROUTE);
    }
  }

  //! ============> Creating a controller instance to save the user id temp for next verification otp api
  // var authContorller = GetxController.Get.find<AuthController>();

  //! ============> Login Response
  void _loginResponseMethod(
      {required BuildContext context, String? paymentId}) async {
    try {
      logData(message: "Response: ${_response?.data}");
      // _checkoutModel = CheckoutModel.fromJson(_response?.data);
      // AppNavigation.navigateTo(context, AppRouteName.CARD_PAYMENT_SCREEN);
      // CardPaymentScreen
      // AppDialogs.showToast(message: _checkoutModel?.message ?? "");

      //   print("order_created_successfully");
      // print(_checkoutModel?.message);

      print("OORDER SUCCESS");

      if (_response?.data['message'] == "Order Created Successfully!") {
        AppDialogs.showToast(message: tr('order_created_successfully'));

        GetxController.Get.find<OrderSummaryController>()
            .selectedOrderType
            .value = null;
        GetxController.Get.find<OrderSummaryController>().promocode.clear();
        GetxController.Get.find<OrderSummaryController>().dineIncode.clear();
        GetxController.Get.find<OrderSummaryController>()
            .account_number_controller
            .clear();
        GetxController.Get.find<OrderSummaryController>()
            .account_holder_controller
            .clear();
        GetxController.Get.find<OrderSummaryController>()
            .cvc_controller
            .clear();

        GetxController.Get.find<OrderSummaryController>()
            .instructtionsController
            .clear();

        GetxController.Get.find<OrderSummaryController>().viewCartModel.value =
            null;

        GetxController.Get.find<CartController>().cart_list.clear();

        GetxController.Get.find<OrderSummaryController>()
            .expiry_controller
            .clear();
        GetxController.Get.find<OrderSummaryController>().token.value = "";
      } else {
        if (context.locale.languageCode != "en") {
          final _translatedMessage = await GoogleTranslatorService()
              .translate(text: _checkoutModel?.message ?? "", context: context);
          AppDialogs.showToast(message: _translatedMessage);
        } else {
          AppDialogs.showToast(message: _checkoutModel?.message ?? "");
        }
      }

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => PrepartionTimeOrderScreen(
              data: _response?.data['data']['order'].toString()),
        ),
      );

//  GetxController.Get.offAll(PrepartionTimeScreen(
//               orderId: _checkoutModel!.data.order.id.toString(),
//             ));

      // var orderConfirmBloc = orderConfirmPreparationTimeBloc();
      // orderConfirmBloc.orderConfirmPreparationTimeBlocMethod(
      //     context: context,
      //     setProgressBar: () {
      //       AppDialogs.progressAlertDialog(context: context);
      //     },
      //     onSuccess: () {
      //       GetxController.Get.offAll(PrepartionTimeScreen(
      //         orderId: _checkoutModel!.data.order.id.toString(),
      //       ));
      //     },
      //     paymentId: paymentId,
      //     orderId: _checkoutModel!.data.order.id);
    } catch (error) {
      AppDialogs.showToast(message: tr(NetworkStrings.SOMETHING_WENT_WRONG));
    }
  }
}
