import 'dart:async';

import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:jtc_ecommerce/enum/order_type.dart';
import 'package:jtc_ecommerce/order_summary/blocs/checkout_bloc.dart';
import 'package:jtc_ecommerce/order_summary/models/confirmordermodel_preparation.dart';
import 'package:jtc_ecommerce/order_summary/models/order_confirm_mode.dart';
import 'package:jtc_ecommerce/order_summary/models/payment_intent_model.dart';
import 'package:jtc_ecommerce/splash/controllers/splash_controller.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/enums.dart';
import 'package:jtc_ecommerce/utils/get_order_type_util.dart';
import 'package:jtc_ecommerce/wallet/blocs/get_cart_bloc.dart';
import 'package:jtc_ecommerce/wallet/models/cart_model.dart';

class OrderSummaryController extends GetxController {
  var token = ''.obs;
  var orderStatus = ''.obs;
  var orderType = ''.obs;

  void updateToken(String newToken) {
    token.value = newToken;
  }

  Rxn<OrderType> selectedOrderType = Rxn(null);
  // List<String> orderTypes = [
  //   'Take Away',
  //   'Dine-In',
  //   "Drive Thru",
  //   "Curbside",
  //   "Delivery"
  // ];
  // RxList<OrderConfirmModel> createPayment = <OrderConfirmModel>[].obs;
  Rx<OrderConfirmModel?> createPayment = Rx<OrderConfirmModel?>(null);

  RxList<OrderConfirmDatam> preparationTime = <OrderConfirmDatam>[].obs;
  RxList<PaymentIntentData> paymentIntentVar = <PaymentIntentData>[].obs;

  // var selectedPromoCode = "".obs;
  // List<String> promoCodes = [
  //   '10% cash back',
  //   '20% cashback',
  //   "30% cashback",
  //   "50% cashback",
  // ];
  // var total = 0.0.obs;
  // var delivery = 0.0.obs;
  // var differenceFiat = 0.0.obs;

  // void calculateTotals(ViewCartData? viewCartModel) {
  //   if (viewCartModel != null) {
  //     total.value = viewCartModel.total;
  //     delivery.value = double.parse(viewCartModel.delivery);
  //     differenceFiat.value = total.value - delivery.value;
  //   }
  // }
  var total = 0.0.obs;
  var delivery = 0.0.obs;
  var differenceFiat = 0.0.obs;

  // void calculateTotals(ViewCartData? viewCartModel) {
  //   if (viewCartModel != null) {
  //     total.value = viewCartModel.total is int
  //         ? viewCartModel.total.toDouble()
  //         : viewCartModel.total;

  //     delivery.value = viewCartModel.delivery is int
  //         ? viewCartModel.delivery.toDouble()
  //         : double.parse(viewCartModel.delivery);

  //     differenceFiat.value = total.value - delivery.value;
  //   }
  // }

  double calculateTotalOrderPrice(OrderType? orderType) {
    if (orderType != OrderType.Delivery) {
      return double.parse(viewCartModel.value?.total.toString() ?? "0.0");
    } else {
      return (viewCartModel.value?.total ?? 0.0) +
          (viewCartModel.value?.delivery ?? 0.0);
    }
  }

  double calculateTotalOrderPriceToken(OrderType? orderType) {
    if (orderType != OrderType.Delivery) {
      return (viewCartModel.value?.totalToken ?? 0.0).toDouble();
    } else {
      return (viewCartModel.value?.totalToken ?? 0.0).toDouble() +
          (viewCartModel.value?.tokensDelivery ?? 0.0);
    }
  }

  RxBool isLoading = false.obs;
  Rxn<CartModel> getSalesappVar = Rxn(null);
  Future<void> getSalesAppFunc(String orderId) async {
    try {
      print("Getting SALES");
      isLoading.value = true;
      await GetSalesAppBloc()
          .getSalestBlocMethod(context: Get.context!, orderId: orderId);
    } catch (e) {
    } finally {
      isLoading.value = false;
    }
  }

  Rxn<CartResponseData> viewCartModel = Rxn(null);
  String totalPrice = "";
  // final Rx<TextEditingController> address = TextEditingController().obs;
  var splashController = Get.find<SplashController>();
  final Rx<TextEditingController> user_address = TextEditingController().obs;
  final TextEditingController promocode = TextEditingController();
  final TextEditingController dineIncode = TextEditingController();

  TextEditingController nearestAddressContoller = TextEditingController();
  TextEditingController nearestFlatNo = TextEditingController();
  TextEditingController instructtionsController = TextEditingController();

  @override
  void onInit() {
    super.onInit();
  }

  Map<String, double>? latLong = {};

  Future<Map<String, double>?> getLatLongFromAddress(
      String address, BuildContext context) async {
    try {
      List<Location> locations = await locationFromAddress(address);
      if (locations.isNotEmpty) {
        Location location = locations.first;
        CheckoutCardBloc().checkoutBlocMethod(
          context: context,
          latitude: location.latitude.toString(),
          instructions: instructtionsController.text.trim(),
          longitude: location.longitude.toString(),
          order_type: selectedOrderType.value?.orderStringCheckout,
          address: address,
          deliveryCharges: selectedOrderType.value == OrderType.Delivery
              ? (viewCartModel.value?.delivery.toString())
              : null,
          nearestAddress: nearestAddressContoller.text.trim(),
          nearestFlat: nearestFlatNo.text.trim(),
          promo_code_id: promocode.text,
          table_number: dineIncode.text,
          paymentId: createPayment.value!.data,
          setProgressBar: () {
            AppDialogs.progressAlertDialog(context: context);
          },
        );

        return {
          'latitude': location.latitude,
          'longitude': location.longitude,
        };
      } else {
        throw Exception('No location found for the address: $address');
      }
    } catch (e) {
      print('Error getting location from address: $e');
      return null;
    }
  }

  Future<Map<String, double>?> getLatLongFromAddressCash(
      String address, String payment_type, BuildContext context) async {
    try {
      // List<Location> locations = await locationFromAddress(address);

      CheckoutCardBloc().checkoutBlocMethod(
        context: context,
        latitude: Get.find<SplashController>().currentUser.value?.lat,
        longitude: Get.find<SplashController>().currentUser.value?.long,
        order_type: selectedOrderType.value?.orderStringCheckout,
        instructions: instructtionsController.text.trim(),
        address: address,
        deliveryCharges: selectedOrderType.value == OrderType.Delivery
            ? (payment_type == "COINS"
                ? viewCartModel.value?.tokensDelivery.toString()
                : viewCartModel.value?.delivery.toString())
            : null,
        payment_type: payment_type,
        table_number: dineIncode.text,
        promo_code_id: promocode.text,
        nearestFlat: nearestFlatNo.text.trim(),
        nearestAddress: nearestAddressContoller.text.trim(),
        setProgressBar: () {
          AppDialogs.progressAlertDialog(context: context);
        },
      );
    } catch (e) {
      print('Error getting location from address: $e');
      return null;
    }
  }

  RxBool showButton = false.obs;
  RxString formattedTime = ''.obs;
  //Payment screen stuff

  Rx<PaymentType> selectedPaymentType = PaymentType.Visa.obs;

  void setSelectedPaymentType(PaymentType type) {
    selectedPaymentType.value = type;
  }

  void printCurrentTimeBackwards(DateTime currentTime, DateTime startTime) {
    while (currentTime.isAfter(startTime)) {
      print(
          'current time   ${DateFormat('yyyy-MM-dd HH:mm:ss.S').format(currentTime)}');
      currentTime = currentTime.subtract(Duration(seconds: 1));
    }
  }
  //Buy Jtc Token Stuff

  // GlobalKey<FormState> addCardFormKey = GlobalKey<FormState>();
  TextEditingController account_holder_controller = TextEditingController();
  TextEditingController account_number_controller = TextEditingController();
  TextEditingController expiry_controller = TextEditingController();
  TextEditingController cvc_controller = TextEditingController();
}
