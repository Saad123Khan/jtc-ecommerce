import 'dart:async';

import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:jtc_ecommerce/cart/models/view_cart_model.dart';
import 'package:jtc_ecommerce/order_summary/blocs/checkout_bloc.dart';
import 'package:jtc_ecommerce/order_summary/blocs/checkout_cash_bloc.dart';
import 'package:jtc_ecommerce/order_summary/models/checkout_cash_model.dart';
import 'package:jtc_ecommerce/order_summary/models/order_confirm_mode.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/splash/controllers/splash_controller.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/enums.dart';

class PreparationTimeControllerCash extends GetxController {
  
  RxList<Order> preparationTime = <Order>[].obs;


  @override
  void onInit() {
   
    super.onInit();
  }

  

  late Timer _timer;

  void startTimer() {
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (preparationTime.isNotEmpty) {
        updateTime(preparationTime[0].startTime, preparationTime[0].endTime);
      }
      // updateTime();
    });
  }

  void stopTimer() {
    _timer.cancel();
  }

  RxBool showButton = false.obs;
  RxString formattedTime = ''.obs;
  //Payment screen stuff



//testing dummy time

  void updateTime(String openingTime, String closingTime) {
    // Parse openingTime and closingTime strings to extract hours and minutes
    List<String> openingParts = openingTime.split(' ');
    List<String> closingParts = closingTime.split(' ');

    int openingHour = int.parse(openingParts[0].split(':')[0]);
    int openingMinute = int.parse(openingParts[0].split(':')[1]);
    bool openingPM = openingParts[1] == 'PM';

    int closingHour = int.parse(closingParts[0].split(':')[0]);
    int closingMinute = int.parse(closingParts[0].split(':')[1]);
    bool closingPM = closingParts[1] == 'PM';

    // Adjust opening and closing hours if PM
    if (openingPM && openingHour != 12) {
      openingHour += 12;
    }
    if (closingPM && closingHour != 12) {
      closingHour += 12;
    }

    DateTime currentTime = DateTime.now();
    DateTime startTime = DateTime(
      currentTime.year,
      currentTime.month,
      currentTime.day,
      openingHour,
      openingMinute,
    );

    // If the closing time is before the opening time (e.g., closing time is in PM and opening time is in AM), adjust the date
    if (closingHour < openingHour ||
        (closingHour == openingHour && closingMinute < openingMinute)) {
      currentTime = currentTime.add(Duration(days: 1));
    }

    DateTime endTime = DateTime(
      currentTime.year,
      currentTime.month,
      currentTime.day,
      closingHour,
      closingMinute,
    );
    if (currentTime.isAfter(startTime) && currentTime.isBefore(endTime)) {
      showButton.value = true;
      Duration remainingDuration = endTime.difference(currentTime);

      int hours = remainingDuration.inHours.remainder(60);
      int minutes = remainingDuration.inMinutes.remainder(60);
      int seconds = remainingDuration.inSeconds.remainder(60);
      formattedTime.value =
          '${hours.toString().padLeft(2, '0')} : ${minutes.toString().padLeft(2, '0')} : ${seconds.toString().padLeft(2, '0')}';

      // printCurrentTimeBackwards(currentTime, startTime);
    } else {
      showButton.value = false;
      formattedTime.value = 'Out of Time';
    }
  }


  void printCurrentTimeBackwards(DateTime currentTime, DateTime startTime) {
    while (currentTime.isAfter(startTime)) {
      print(
          'current time   ${DateFormat('yyyy-MM-dd HH:mm:ss.S').format(currentTime)}');
      currentTime = currentTime.subtract(Duration(seconds: 1));
    }
  }
 
}
