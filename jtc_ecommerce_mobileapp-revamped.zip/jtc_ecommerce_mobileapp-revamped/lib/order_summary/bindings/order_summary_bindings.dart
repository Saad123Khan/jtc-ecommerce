import 'package:get/get.dart';
import 'package:jtc_ecommerce/order_summary/controllers/order_summary_controller.dart';

class OrderSummaryBinding extends Bindings{
  @override
  void dependencies() {
    Get.lazyPut(() => OrderSummaryController());
  }
}