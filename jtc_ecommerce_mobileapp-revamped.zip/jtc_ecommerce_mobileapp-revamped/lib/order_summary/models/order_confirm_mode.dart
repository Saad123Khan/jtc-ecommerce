// To parse this JSON data, do
//
//     final orderConfirmModel = orderConfirmModelFromJson(jsonString);

import 'dart:convert';

OrderConfirmModel orderConfirmModelFromJson(String str) =>
    OrderConfirmModel.fromJson(json.decode(str));

String orderConfirmModelToJson(OrderConfirmModel data) =>
    json.encode(data.toJson());

class OrderConfirmModel {
  bool status;
  dynamic data;
  dynamic message;

  OrderConfirmModel({
    required this.status,
    required this.data,
    required this.message,
  });

  factory OrderConfirmModel.fromJson(Map<String, dynamic> json) =>
      OrderConfirmModel(
        status: json["status"],
        data: json["data"],
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "status": status,
        "data": data,
        "message": message,
      };
}
