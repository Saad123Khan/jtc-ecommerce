// To parse this JSON data, do
//
//     final orderConfirmPreparationTimeModel = orderConfirmPreparationTimeModelFromJson(jsonString);

import 'dart:convert';

OrderConfirmPreparationTimeModel orderConfirmPreparationTimeModelFromJson(String str) => OrderConfirmPreparationTimeModel.fromJson(json.decode(str));

String orderConfirmPreparationTimeModelToJson(OrderConfirmPreparationTimeModel data) => json.encode(data.toJson());

class OrderConfirmPreparationTimeModel {
    bool status;
    OrderConfirmDatam data;
    String message;

    OrderConfirmPreparationTimeModel({
        required this.status,
        required this.data,
        required this.message,
    });

    factory OrderConfirmPreparationTimeModel.fromJson(Map<String, dynamic> json) => OrderConfirmPreparationTimeModel(
        status: json["status"],
        data: OrderConfirmDatam.fromJson(json["data"]),
        message: json["message"],
    );

    Map<String, dynamic> toJson() => {
        "status": status,
        "data": data.toJson(),
        "message": message,
    };
}

class OrderConfirmDatam {
    String startTime;
    String endTime;
    String maxMakingTime;

    OrderConfirmDatam({
        required this.startTime,
        required this.endTime,
        required this.maxMakingTime,
    });

    factory OrderConfirmDatam.fromJson(Map<String, dynamic> json) => OrderConfirmDatam(
        startTime: json["start_time"],
        endTime: json["end_time"],
        maxMakingTime: json["max_making_time"],
    );

    Map<String, dynamic> toJson() => {
        "start_time": startTime,
        "end_time": endTime,
        "max_making_time": maxMakingTime,
    };
}
