// To parse this JSON data, do
//
//     final checkoutCashModel = checkoutCashModelFromJson(jsonString);

import 'dart:convert';

CheckoutCashModel checkoutCashModelFromJson(String str) =>
    CheckoutCashModel.fromJson(json.decode(str));

String checkoutCashModelToJson(CheckoutCashModel data) =>
    json.encode(data.toJson());

class CheckoutCashModel {
  bool status;
  dynamic message;
  dynamic maxMakingTime;
  Data data;

  CheckoutCashModel({
    required this.status,
    required this.message,
    // required this.maxMakingTime,
    required this.data,
  });

  factory CheckoutCashModel.fromJson(Map<String, dynamic> json) =>
      CheckoutCashModel(
        status: json["status"],
        message: json["message"],
        // maxMakingTime: json["max_making_time"],
        data: Data.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "status": status,
        "message": message,
        // "max_making_time": maxMakingTime,
        "data": data.toJson(),
      };
}

class Data {
  Order order;

  Data({
    required this.order,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        order: Order.fromJson(json["order"]),
      );

  Map<String, dynamic> toJson() => {
        "order": order.toJson(),
      };
}

class Order {
  String address;
  String longitude;
  String latitude;
  String orderType;
  int paymentType;
  int taxAmount;
  int customerId;
  int ecommerceUserId;
  int warehouseId;
  int discount;
  int taxRate;
  String orderThrough;
  String deliveryMode;
  double grandTotal;
  int shipping;
  int receivedAmount;
  int paidAmount;
  int paymentStatus;
  dynamic note;
  dynamic customerInstruction;
  int status;
  DateTime date;
  DateTime updatedAt;
  DateTime createdAt;
  int id;
  String endTime;
  String startTime;
  String referenceCode;
  String barcodeImageUrl;

  Order({
    required this.address,
    required this.longitude,
    required this.latitude,
    required this.orderType,
    required this.paymentType,
    required this.taxAmount,
    required this.customerId,
    required this.ecommerceUserId,
    required this.warehouseId,
    required this.discount,
    required this.taxRate,
    required this.orderThrough,
    required this.deliveryMode,
    required this.grandTotal,
    required this.shipping,
    required this.receivedAmount,
    required this.paidAmount,
    required this.paymentStatus,
    required this.note,
    required this.customerInstruction,
    required this.status,
    required this.date,
    required this.updatedAt,
    required this.createdAt,
    required this.id,
    required this.endTime,
    required this.startTime,
    required this.referenceCode,
    required this.barcodeImageUrl,
  });

  factory Order.fromJson(Map<String, dynamic> json) => Order(
        address: json["address"],
        longitude: json["longitude"],
        latitude: json["latitude"],
        orderType: json["order_type"],
        paymentType: json["payment_type"],
        taxAmount: json["tax_amount"],
        customerId: json["customer_id"],
        ecommerceUserId: json["ecommerce_user_id"],
        warehouseId: json["warehouse_id"],
        discount: json["discount"],
        taxRate: json["tax_rate"],
        orderThrough: json["order_through"],
        deliveryMode: json["delivery_mode"],
        grandTotal: json["grand_total"]?.toDouble(),
        shipping: json["shipping"],
        receivedAmount: json["received_amount"],
        paidAmount: json["paid_amount"],
        paymentStatus: json["payment_status"],
        note: json["note"],
        customerInstruction: json["customer_instruction"],
        status: json["status"],
        date: DateTime.parse(json["date"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        createdAt: DateTime.parse(json["created_at"]),
        id: json["id"],
        endTime: json["end_time"],
        startTime: json["start_time"],
        referenceCode: json["reference_code"],
        barcodeImageUrl: json["barcode_image_url"],
      );

  Map<String, dynamic> toJson() => {
        "address": address,
        "longitude": longitude,
        "latitude": latitude,
        "order_type": orderType,
        "payment_type": paymentType,
        "tax_amount": taxAmount,
        "customer_id": customerId,
        "ecommerce_user_id": ecommerceUserId,
        "warehouse_id": warehouseId,
        "discount": discount,
        "tax_rate": taxRate,
        "order_through": orderThrough,
        "delivery_mode": deliveryMode,
        "grand_total": grandTotal,
        "shipping": shipping,
        "received_amount": receivedAmount,
        "paid_amount": paidAmount,
        "payment_status": paymentStatus,
        "note": note,
        "customer_instruction": customerInstruction,
        "status": status,
        "date": date.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "created_at": createdAt.toIso8601String(),
        "id": id,
        "end_time": endTime,
        "start_time": startTime,
        "reference_code": referenceCode,
        "barcode_image_url": barcodeImageUrl,
      };
}
