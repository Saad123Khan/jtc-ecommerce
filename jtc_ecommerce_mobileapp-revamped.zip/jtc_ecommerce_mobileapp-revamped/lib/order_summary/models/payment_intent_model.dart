// To parse this JSON data, do
//
//     final paymentIntentModel = paymentIntentModelFromJson(jsonString);

import 'dart:convert';

PaymentIntentModel paymentIntentModelFromJson(String str) => PaymentIntentModel.fromJson(json.decode(str));

String paymentIntentModelToJson(PaymentIntentModel data) => json.encode(data.toJson());

class PaymentIntentModel {
    bool success;
    PaymentIntentData data;

    PaymentIntentModel({
        required this.success,
        required this.data,
    });

    factory PaymentIntentModel.fromJson(Map<String, dynamic> json) => PaymentIntentModel(
        success: json["success"],
        data: PaymentIntentData.fromJson(json["data"]),
    );

    Map<String, dynamic> toJson() => {
        "success": success,
        "data": data.toJson(),
    };
}

class PaymentIntentData {
    bool status;
    String message;
    String clientSecret;

    PaymentIntentData({
        required this.status,
        required this.message,
        required this.clientSecret,
    });

    factory PaymentIntentData.fromJson(Map<String, dynamic> json) => PaymentIntentData(
        status: json["status"],
        message: json["message"],
        clientSecret: json["clientSecret"],
    );

    Map<String, dynamic> toJson() => {
        "status": status,
        "message": message,
        "clientSecret": clientSecret,
    };
}
