// To parse this JSON data, do
//
//     final checkoutModel = checkoutModelFromJson(jsonString);

import 'dart:convert';

CheckoutModel checkoutModelFromJson(String str) =>
    CheckoutModel.fromJson(json.decode(str));

String checkoutModelToJson(CheckoutModel data) => json.encode(data.toJson());

class CheckoutModel {
  bool status;
  dynamic message;
  dynamic maxMakingTime;
  Data data;

  CheckoutModel({
    required this.status,
    required this.message,
    required this.maxMakingTime,
    required this.data,
  });

  factory CheckoutModel.fromJson(Map<String, dynamic> json) => CheckoutModel(
        status: json["status"],
        message: json["message"],
        maxMakingTime: json["max_making_time"],
        data: Data.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "status": status,
        "message": message,
        "max_making_time": maxMakingTime,
        "data": data.toJson(),
      };
}

class Data {
  String? clientSecret;
  Order? order;

  Data({
     this.clientSecret,
    required this.order,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        clientSecret: json["clientSecret"] ?? "",
        order:  json["order"] != null ? Order.fromJson(json["order"]): null,
      );

  Map<String, dynamic> toJson() => {
        "clientSecret": clientSecret,
        "order": order?.toJson(),
      };
}

class Order {
  dynamic id;
  DateTime date;
  dynamic isReturn;
  dynamic isAccept;
  dynamic acceptTimer;
  dynamic customerId;
  dynamic warehouseId;
  dynamic taxRate;
  dynamic orderType;
  dynamic orderThrough;
  dynamic taxAmount;
  dynamic discount;
  dynamic shipping;
  dynamic grandTotal;
  dynamic receivedAmount;
  dynamic paidAmount;
  dynamic paymentType;
  dynamic note;
  dynamic referenceCode;
  DateTime createdAt;
  DateTime updatedAt;
  dynamic status;
  dynamic paymentStatus;
  dynamic address;
  dynamic latitude;
  dynamic longitude;
  dynamic customerInstruction;
  dynamic ecommerceUserId;
  dynamic riderId;
  dynamic deliveryMode;
  dynamic orderStatus;
  dynamic paymentId;
  dynamic endTime;
  dynamic startTime;
  dynamic riderStartLat;
  dynamic riderStartLong;
  dynamic riderEndLat;
  dynamic riderEndLong;
  dynamic riderEarn;
  dynamic riderKmComplete;
  dynamic ecommerceuser;

  Order({
    required this.id,
    required this.date,
    required this.isReturn,
    required this.isAccept,
    required this.acceptTimer,
    required this.customerId,
    required this.warehouseId,
    required this.taxRate,
    required this.orderType,
    required this.orderThrough,
    required this.taxAmount,
    required this.discount,
    required this.shipping,
    required this.grandTotal,
    required this.receivedAmount,
    required this.paidAmount,
    required this.paymentType,
    required this.note,
    required this.referenceCode,
    required this.createdAt,
    required this.updatedAt,
    required this.status,
    required this.paymentStatus,
    required this.address,
    required this.latitude,
    required this.longitude,
    required this.customerInstruction,
    required this.ecommerceUserId,
    required this.riderId,
    required this.deliveryMode,
    required this.orderStatus,
    required this.paymentId,
    required this.endTime,
    required this.startTime,
    required this.riderStartLat,
    required this.riderStartLong,
    required this.riderEndLat,
    required this.riderEndLong,
    required this.riderEarn,
    required this.riderKmComplete,
    required this.ecommerceuser,
  });

  factory Order.fromJson(Map<String, dynamic> json) => Order(
        id: json["id"],
        date: DateTime.parse(json["date"]),
        isReturn: json["is_return"],
        isAccept: json["is_accept"],
        acceptTimer: json["accept_timer"],
        customerId: json["customer_id"],
        warehouseId: json["warehouse_id"],
        taxRate: json["tax_rate"],
        orderType: json["order_type"],
        orderThrough: json["order_through"],
        taxAmount: json["tax_amount"],
        discount: json["discount"],
        shipping: json["shipping"],
        grandTotal: json["grand_total"],
        receivedAmount: json["received_amount"],
        paidAmount: json["paid_amount"],
        paymentType: json["payment_type"],
        note: json["note"],
        referenceCode: json["reference_code"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        status: json["status"],
        paymentStatus: json["payment_status"],
        address: json["address"],
        latitude: json["latitude"],
        longitude: json["longitude"],
        customerInstruction: json["customer_instruction"],
        ecommerceUserId: json["ecommerce_user_id"],
        riderId: json["rider_id"],
        deliveryMode: json["delivery_mode"],
        orderStatus: json["order_status"],
        paymentId: json["payment_id"],
        endTime: json["end_time"],
        startTime: json["start_time"],
        riderStartLat: json["rider_start_lat"],
        riderStartLong: json["rider_start_long"],
        riderEndLat: json["rider_end_lat"],
        riderEndLong: json["rider_end_long"],
        riderEarn: json["rider_earn"],
        riderKmComplete: json["rider_km_complete"],
        ecommerceuser: json["ecommerceuser"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "date": date.toIso8601String(),
        "is_return": isReturn,
        "is_accept": isAccept,
        "accept_timer": acceptTimer,
        "customer_id": customerId,
        "warehouse_id": warehouseId,
        "tax_rate": taxRate,
        "order_type": orderType,
        "order_through": orderThrough,
        "tax_amount": taxAmount,
        "discount": discount,
        "shipping": shipping,
        "grand_total": grandTotal,
        "received_amount": receivedAmount,
        "paid_amount": paidAmount,
        "payment_type": paymentType,
        "note": note,
        "reference_code": referenceCode,
        "created_at": createdAt.toIso8601String(),  
        "updated_at": updatedAt.toIso8601String(),
        "status": status,
        "payment_status": paymentStatus,
        "address": address,
        "latitude": latitude,
        "longitude": longitude,
        "customer_instruction": customerInstruction,
        "ecommerce_user_id": ecommerceUserId,
        "rider_id": riderId,
        "delivery_mode": deliveryMode,
        "order_status": orderStatus,
        "payment_id": paymentId,
        "end_time": endTime,
        "start_time": startTime,
        "rider_start_lat": riderStartLat,
        "rider_start_long": riderStartLong,
        "rider_end_lat": riderEndLat,
        "rider_end_long": riderEndLong,
        "rider_earn": riderEarn,
        "rider_km_complete": riderKmComplete,
        "ecommerceuser": ecommerceuser.toJson(),
      };
}

class Ecommerceuser {
  dynamic id;
  dynamic firstName;
  dynamic lastName;
  dynamic email;
  DateTime emailVerifiedAt;
  dynamic phoneNo;
  DateTime createdAt;
  DateTime updatedAt;
  dynamic referalCode;
  dynamic rewardPoints;
  dynamic language;
  dynamic firebaseWebToken;
  dynamic firebaseMobileToken;
  dynamic walletId;
  dynamic address;
  dynamic lat;
  dynamic long;
  dynamic deviceType;
  dynamic countryCode;
  dynamic provider;
  dynamic accessToken;
  dynamic nearestAddress;
  dynamic imageUrl;
  List<Media> media;

  Ecommerceuser({
    required this.id,
    required this.firstName,
    required this.lastName,
    required this.email,
    required this.emailVerifiedAt,
    required this.phoneNo,
    required this.createdAt,
    required this.updatedAt,
    required this.referalCode,
    required this.rewardPoints,
    required this.language,
    required this.firebaseWebToken,
    required this.firebaseMobileToken,
    required this.walletId,
    required this.address,
    required this.lat,
    required this.long,
    required this.deviceType,
    required this.countryCode,
    required this.provider,
    required this.accessToken,
    required this.nearestAddress,
    required this.imageUrl,
    required this.media,
  });

  factory Ecommerceuser.fromJson(Map<String, dynamic> json) => Ecommerceuser(
        id: json["id"],
        firstName: json["first_name"],
        lastName: json["last_name"],
        email: json["email"],
        emailVerifiedAt: DateTime.parse(json["email_verified_at"]),
        phoneNo: json["phone_no"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        referalCode: json["referal_code"],
        rewardPoints: json["reward_points"],
        language: json["language"],
        firebaseWebToken: json["firebase_web_token"],
        firebaseMobileToken: json["firebase_mobile_token"],
        walletId: json["walletId"],
        address: json["address"],
        lat: json["lat"],
        long: json["long"],
        deviceType: json["device_type"],
        countryCode: json["country_code"],
        provider: json["provider"],
        accessToken: json["access_token"],
        nearestAddress: json["nearest_address"],
        imageUrl: json["image_url"],
        media: List<Media>.from(json["media"].map((x) => Media.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "first_name": firstName,
        "last_name": lastName,
        "email": email,
        "email_verified_at": emailVerifiedAt.toIso8601String(),
        "phone_no": phoneNo,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "referal_code": referalCode,
        "reward_points": rewardPoints,
        "language": language,
        "firebase_web_token": firebaseWebToken,
        "firebase_mobile_token": firebaseMobileToken,
        "walletId": walletId,
        "address": address,
        "lat": lat,
        "long": long,
        "device_type": deviceType,
        "country_code": countryCode,
        "provider": provider,
        "access_token": accessToken,
        "nearest_address": nearestAddress,
        "image_url": imageUrl,
        "media": List<dynamic>.from(media.map((x) => x.toJson())),
      };
}

class Media {
  dynamic id;
  String modelType;
  dynamic modelId;
  dynamic uuid;
  dynamic collectionName;
  dynamic name;
  dynamic fileName;
  dynamic mimeType;
  dynamic disk;
  dynamic conversionsDisk;
  int size;
  List<dynamic> manipulations;
  List<dynamic> customProperties;
  List<dynamic> generatedConversions;
  List<dynamic> responsiveImages;
  int orderColumn;
  DateTime createdAt;
  DateTime updatedAt;
  dynamic originalUrl;
  dynamic previewUrl;

  Media({
    required this.id,
    required this.modelType,
    required this.modelId,
    required this.uuid,
    required this.collectionName,
    required this.name,
    required this.fileName,
    required this.mimeType,
    required this.disk,
    required this.conversionsDisk,
    required this.size,
    required this.manipulations,
    required this.customProperties,
    required this.generatedConversions,
    required this.responsiveImages,
    required this.orderColumn,
    required this.createdAt,
    required this.updatedAt,
    required this.originalUrl,
    required this.previewUrl,
  });

  factory Media.fromJson(Map<String, dynamic> json) => Media(
        id: json["id"],
        modelType: json["model_type"],
        modelId: json["model_id"],
        uuid: json["uuid"],
        collectionName: json["collection_name"],
        name: json["name"],
        fileName: json["file_name"],
        mimeType: json["mime_type"],
        disk: json["disk"],
        conversionsDisk: json["conversions_disk"],
        size: json["size"],
        manipulations: List<dynamic>.from(json["manipulations"].map((x) => x)),
        customProperties:
            List<dynamic>.from(json["custom_properties"].map((x) => x)),
        generatedConversions:
            List<dynamic>.from(json["generated_conversions"].map((x) => x)),
        responsiveImages:
            List<dynamic>.from(json["responsive_images"].map((x) => x)),
        orderColumn: json["order_column"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        originalUrl: json["original_url"],
        previewUrl: json["preview_url"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "model_type": modelType,
        "model_id": modelId,
        "uuid": uuid,
        "collection_name": collectionName,
        "name": name,
        "file_name": fileName,
        "mime_type": mimeType,
        "disk": disk,
        "conversions_disk": conversionsDisk,
        "size": size,
        "manipulations": List<dynamic>.from(manipulations.map((x) => x)),
        "custom_properties": List<dynamic>.from(customProperties.map((x) => x)),
        "generated_conversions":
            List<dynamic>.from(generatedConversions.map((x) => x)),
        "responsive_images": List<dynamic>.from(responsiveImages.map((x) => x)),
        "order_column": orderColumn,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "original_url": originalUrl,
        "preview_url": previewUrl,
      };
}
