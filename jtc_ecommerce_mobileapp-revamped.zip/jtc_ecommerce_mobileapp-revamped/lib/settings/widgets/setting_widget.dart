import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_fonts.dart';

class SettingWidget extends StatelessWidget {
  final String stringImg;
  final String heading;
  final String description;
  final VoidCallback onTap;

  const SettingWidget({
    super.key,
    required this.stringImg,
    required this.description,
    required this.heading,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        // margin: EdgeInsets.symmetric(vertical: 15),
        color: Colors.white,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 55, vertical: 12),
              child: Row(
                children: [
                  Column(
                    children: [
                      SvgPicture.asset(stringImg,
                      height: 20,
                      width: 20,
                      ),
                    ],
                  ),
                  SizedBox(
                    width: 15,
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CustomText(
                          text: heading,
                          color: AppColors.BLACK_COLOR,
                          isLeftAlign: false,
                          align: Alignment.centerLeft,
                          fontsize: 16.sp,
                          // fontFamily: AppFonts.robotoMedium,
                        ),
                        CustomText(
                          text: description,
                          maxLines: 2,
                          textAlign: TextAlign.start,
                          color: Color(0xFFAAAAAA),
                          fontsize: 14.sp,
                          isLeftAlign: true,
                          align: Alignment.topLeft,
                          fontFamily: AppFonts.defaultFont,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Divider(
              color: Color(0xFFE1E1E1),
            )
          ],
        ),
      ),
    );
  }
}
