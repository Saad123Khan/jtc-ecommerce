import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/widgets/custom_app_bar.dart';
import 'package:jtc_ecommerce/widgets/custom_scaffold.dart';
import 'package:jtc_ecommerce/widgets/no_data_found.dart';
import 'package:jtc_ecommerce/settings/controllers/settings_controller.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';

import 'components/order_history_card.dart';

class MyOrderScreen extends StatefulWidget {
  MyOrderScreen({super.key});

  @override
  State<MyOrderScreen> createState() => _MyOrderScreenState();
}

class _MyOrderScreenState extends State<MyOrderScreen> {
  var controller = Get.find<SettingsController>();

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.get_my_orders();
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      appBarTitle: tr('MyOrderScreen.key'),
      onTap: () => AppNavigation.navigatorPop(context),
      isAuthScreen: false,
      child: Obx(
        () => controller.isLoading.value
            ? Padding(
                padding: EdgeInsets.all(16.0),
                child: Center(
                  child: CircularProgressIndicator(
                    color: AppColors.PRIMARY_COLOR,
                  ),
                ),
              )
            : !controller.isLoading.value && controller.myorderList.isEmpty
                ? NoDataPage(
                    height: 50.h,
                    text: tr('MyOrderScreen.noOrdersFound'),
                    // text: "No Orders Found",
                    fontSize: 12.sp,
                  )
                : ListView.separated(
                    separatorBuilder: (context, index) => SizedBox(
                      height: 10.h,
                    ),
                    shrinkWrap: true,
                    // physics: NeverScrollableScrollPhysics(),
                    itemCount: controller.myorderList.length,
                    itemBuilder: (context, index) {
                      final order = controller.myorderList[index];
                      return OrderHistoryCard(
                        orderHistory: order,
                      );
                    },
                  ),
      ),
    );
  }

  Color _getColorBasedOnStatus(String orderStatus) {
    switch (orderStatus) {
      case "0":
        return Color(0xFFFFDCDD);
      case "1":
        return Color(0xFFFFDCDD);
      case "2":
        return Color(0xFFFFDCDD);
      case "3":
        return Color(0xFFFFDCDD);
      case "4":
        return Color.fromARGB(255, 211, 204, 204);
      case "5":
        return Color(0xFFFFDCDD);
      case "6":
        return Color(0xFFFFDCDD);
      case "7":
        return Color(0xFFFFDCDD);
      case "8":
        return Color(0xFFFFDCDD);
      case "9":
        return Color(0xFFFFDCDD);
      case "10":
        return Color(0xFFFFDCDD);
      case "11":
        return Color(0xFFFFDCDD);
      default:
        return Color(0xFFFFDCDD);
    }
  }

  Color _gettextColorBasedOnStatus(String orderStatus) {
    switch (orderStatus) {
      case "0":
        return Color(0xFFE0201C);
      case "1":
        return Color(0xFFE0201C);
      case "2":
        return Color(0xFFE0201C);
      case "3":
        return Color(0xFFE0201C);
      case "4":
        return Color.fromARGB(255, 90, 89, 89);
      case "5":
        return Color(0xFFE0201C);
      case "6":
        return Color(0xFFE0201C);
      case "7":
        return Color(0xFFE0201C);
      case "8":
        return Color(0xFFE0201C);
      case "9":
        return Color(0xFFE0201C);
      case "10":
        return Color(0xFFE0201C);
      case "11":
        return Color(0xFFE0201C);
      default:
        return Color(0xFFE0201C);
    }
  }

  String _getTextBasedOnStatus(String orderStatus, String orderType) {
    print(orderType);
    switch (orderStatus) {
      case "0":
        return tr('orderstatusscreen.pending');
      case "1":
        return tr('orderstatusscreen.accepted_by_jtc');
      case "2":
        return tr('orderstatusscreen.preparing');
      case "3":
        return tr('orderstatusscreen.delivered');
      case "4":
        return tr('orderstatusscreen.completed');
      case "5":
        return tr('orderstatusscreen.returned');
      case "6":
        return tr('orderstatusscreen.refunded');
      case "7":
        return tr('orderstatusscreen.cancelled');
      case "8":
        return tr('orderstatusscreen.hold');
      case "9":
        return tr('orderstatusscreen.start_delivery');
      case "10":
        return tr('orderstatusscreen.rider_arrived');
      case "11":
        return tr('orderstatusscreen.rider_pick_up_order');
      default:
        return tr('orderstatusscreen.processing');
    }
  }
}
