import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/utils/helper_functions.dart';
import 'package:jtc_ecommerce/widgets/custom_app_bar.dart';
import 'package:jtc_ecommerce/widgets/custom_scaffold.dart';
import 'package:jtc_ecommerce/widgets/no_data_found.dart';
import 'package:jtc_ecommerce/settings/controllers/settings_controller.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';

class CouponScreen extends StatelessWidget {
  var controller = Get.find<SettingsController>();
  CouponScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      isAuthScreen: false,
      appBarTitle: tr("couponscreen.key").toUpperCase(),
      onTap: () => AppNavigation.navigatorPop(context),
      child: Container(
        height: MediaQuery.sizeOf(context).height * .8 + 28,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(28.0),
            topRight: Radius.circular(28.0),
          ),
        ),
        child: Obx(
          () => controller.isLoading.value
              ? Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Center(
                    child: CircularProgressIndicator(
                      color: AppColors.PRIMARY_COLOR,
                    ),
                  ),
                )
              : !controller.isLoading.value && controller.couponList.isEmpty
                  ? NoDataPage(
                      height: 50.h,
                      text: tr('couponscreen.no_coupon_found'),
                      fontSize: 12.sp,
                    )
                  : SingleChildScrollView(
                      child: Column(
                        children: [
                          ListView.builder(
                            physics: NeverScrollableScrollPhysics(),
                            shrinkWrap: true,
                            itemCount: controller.couponList.length,
                            itemBuilder: (BuildContext context, int index) {
                              print(
                                  "Printing the data : ${controller.couponList[index].isExpired}");
                              String productNames = "";
                              if (controller.couponList[index].isAllProduct ==
                                  '0') {
                                productNames = controller
                                    .couponList[index].products
                                    .map((product) => product.name)
                                    .join(", ");
                              } else {
                                productNames = tr('couponscreen.all_products');
                              }
                              return controller.couponList[index].isExpired
                                  ? CouponItems(
                                      token: controller.couponList[index].token
                                          .toString(),
                                      product: productNames,
                                      promo: controller.couponList[index].code
                                          .toString(),
                                      time: controller.couponList[index].endDate
                                          .toString(),
                                    )
                                  : CouponItems(
                                      token: controller.couponList[index].token
                                          .toString(),
                                      product: productNames,
                                      promo: controller.couponList[index].code
                                          .toString(),
                                      time: controller.couponList[index].endDate
                                          .toString(),
                                    );
                              // return controller.couponList[index].isExpired
                              //     ? Padding(
                              //         padding: const EdgeInsets.symmetric(
                              //             horizontal: 15, vertical: 15),
                              //         child: CouponContainer(
                              //           token: controller
                              //               .couponList[index].token
                              //               .toString(),
                              //           promocode: controller
                              //               .couponList[index].code
                              //               .toString(),
                              //           time: controller
                              //               .couponList[index].endDate
                              //               .toString(),
                              //           products: productNames,
                              //         ),
                              //       )
                              //     : Padding(
                              //         padding: const EdgeInsets.symmetric(
                              //             horizontal: 15, vertical: 15),
                              //         child: CouponContainerExpired(
                              //           token: controller
                              //               .couponList[index].token
                              //               .toString(),
                              //           promocode: controller
                              //               .couponList[index].code
                              //               .toString(),
                              //           time: controller
                              //               .couponList[index].endDate
                              //               .toString(),
                              //           products: productNames,
                              //         ),
                              //       );
                            },
                          ),
                        ],
                      ),
                    ),
        ),
      ),
    );
  }
}

class CouponContainer extends StatefulWidget {
  // final int? id;
  final String? token;
  final String? promocode;
  final String? products;
  final String? time;

  const CouponContainer({
    super.key,
    // required this.id,
    required this.token,
    required this.promocode,
    required this.products,
    required this.time,
  });

  @override
  State<CouponContainer> createState() => _CouponContainerState();
}

class _CouponContainerState extends State<CouponContainer> {
  int calculateDaysDifference(String dateString) {
    DateTime date = DateTime.parse(dateString);
    DateTime now = DateTime.now();
    Duration difference = date.difference(now); // Swap the positions
    return difference.inDays;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 95,
      decoration: ShapeDecoration(
        color: Color(0xFFF7F7F7),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 89.60.w,
            height: 150.h,
            decoration: ShapeDecoration(
              color: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.r),
              ),
              shadows: [
                BoxShadow(
                  color: Color(0x3F000000),
                  blurRadius: 10,
                  offset: Offset(7, 7),
                  spreadRadius: 0,
                )
              ],
            ),
            child: Center(
                child:
                    //  Image.asset("assets/images/myorderjtc.png")
                    SvgPicture.asset("assets/images/jtctokencashback.svg")),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    // '10% Cashback',
                    // "${widget.token} Token",
                    " ${widget.token} " + tr('token_text_only'),
                    style: TextStyle(
                      color: Color(0xFF3D3D3D),
                      fontSize: 20,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    // 'You can avail in all products',
                    // "used this promo code: ${widget.promocode}",
                    tr('couponscreen.used_promo_code') + " ${widget.promocode}",
                    style: TextStyle(
                      color: Color(0xFF3D3D3D),
                      fontSize: 12,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  Text(
                    // 'You can avail in all products',
                    "${widget.products}",
                    style: TextStyle(
                      color: Color(0xFF3D3D3D),
                      fontSize: 12,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  Text(
                    // '2 Days Left',
                    // "${calculateDaysDifference(widget.time!)} days left",
                    // " ${calculateDaysDifference(widget.time!)}" +
                    //     tr('couponscreen.days_left'),

                    widget.time!,
                    style: TextStyle(
                      color: Color(0xFF3D3D3D),
                      fontSize: 12,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}

class CouponContainerExpired extends StatelessWidget {
  // final int? id;
  final String? token;
  final String? promocode;
  final String? products;
  final String? time;
  const CouponContainerExpired({
    Key? key,
    required this.token,
    required this.promocode,
    required this.products,
    required this.time,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 95,
      decoration: ShapeDecoration(
        color: Color(0xFFF7F7F7),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 89.60,
            height: 80,
            decoration: ShapeDecoration(
              color: Colors.white ,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.r),
              ),
              shadows: [
                BoxShadow(
                  color: Color(0x3F000000),
                  blurRadius: 10,
                  offset: Offset(7, 7),
                  spreadRadius: 0,
                )
              ],
            ),
            child: Center(
                child:

                    //  Image.asset("assets/images/myorderjtc.png")
                    SvgPicture.asset("assets/images/jtctokenexpired.svg")),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    // '10% Cashback',
                    // "${token} Token",

                    " ${token} " + tr('token_text_only'),
                    style: TextStyle(
                      color: Color(0xFFA2A2A2),
                      fontSize: 20,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    // 'You can avail in all products',
                    // "used this promo code: ${promocode}",
                    tr('couponscreen.used_promo_code') + " ${promocode}",

                    style: TextStyle(
                      color: Color(0xFFA2A2A2),
                      fontSize: 12,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  Text(
                    // 'You can avail in all products',
                    "${products}",
                    style: TextStyle(
                      color: Color(0xFFA2A2A2),
                      fontSize: 12,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  Text(
                    // '2 Days Left',
                    // "${calculateDaysDifference(time!)} days left",
                    // " ${calculateDaysDifference(time!)}" +
                    //     tr('couponscreen.days_left'),
                    time!,
                    style: TextStyle(
                      color: Color(0xFFA2A2A2),
                      fontSize: 12,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  int calculateDaysDifference(String dateString) {
    DateTime date = DateTime.parse(dateString);
    DateTime now = DateTime.now();
    Duration difference = date.difference(now); // Swap the positions
    return difference.inDays;
  }
}

class CouponItems extends StatelessWidget {
  String token, promo, product, time;
  CouponItems(
      {super.key,
      required this.token,
      required this.promo,
      required this.product,
      required this.time});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(6.0),
      child: Container(
        height: 120.h,
        width: double.infinity,
        decoration: BoxDecoration(
            color: Colors.grey[100],
            borderRadius: BorderRadius.circular(12.0),
            border: Border.all(color: Colors.grey)),
        child: Row(
          children: [
            25.horizontalSpace,
            CircleAvatar(
              radius: 30.r,
              backgroundColor: Colors.red,
              child: ColorFiltered(
                colorFilter: ColorFilter.mode(
                  Colors.white,
                  BlendMode.srcATop,
                ),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Image.asset("assets/images/logo.png"),
                ),
              ),
            ),
            20.horizontalSpace,
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  // '10% Cashback',
                  // "${token} Token",
                  " ${token} " + tr('token_text_only'),
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 20,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text.rich(
                  TextSpan(
                    children: [
                      TextSpan(
                        text: tr('couponscreen.used_promo_code') + " ",
                        style: TextStyle(
                          color: Color(0xFFA2A2A2),
                          fontSize: 12,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      TextSpan(
                        text: promo,
                        style: TextStyle(
                          color: Colors.red,
                          fontSize: 12,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                ),
                Text(
                  // 'You can avail in all products',
                  "${product}",
                  style: TextStyle(
                    color: Color(0xFFA2A2A2),
                    fontSize: 12,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w400,
                  ),
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      height: 15.h,
                      width: 15.w,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10.r),
                        color: Colors.red,
                      ),
                      child: Image.asset("assets/icons/date.png"),
                    ),
                    5.horizontalSpace,
                    Text(
                      // '2 Days Left',
                      // "${calculateDaysDifference(time!)} days left",
                      // " ${calculateDaysDifference(time!)}" +
                      //     tr('couponscreen.days_left'),
                      HelperFunctions.changeDateFormat(time ?? "29, Jan 2022"),
                      style: TextStyle(
                        color: Color(0xFFA2A2A2),
                        fontSize: 12,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class CouponItemsExpired extends StatelessWidget {
  String token, promo, product, time;
  CouponItemsExpired(
      {super.key,
      required this.token,
      required this.promo,
      required this.product,
      required this.time});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(6.0),
      child: Container(
        height: 120.h,
        width: double.infinity,
        decoration: BoxDecoration(
            color: Colors.grey[100],
            borderRadius: BorderRadius.circular(12.0),
            border: Border.all(color: Colors.grey)),
        child: Row(
          children: [
            25.horizontalSpace,
            CircleAvatar(
              radius: 30.r,
              backgroundColor: Colors.grey,
              child: ColorFiltered(
                colorFilter: ColorFilter.mode(
                  Colors.white,
                  BlendMode.srcATop,
                ),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Image.asset("assets/images/logo.png"),
                ),
              ),
            ),
            20.horizontalSpace,
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  // '10% Cashback',
                  // "${token} Token",
                  " ${token} " + tr('token_text_only'),
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 20,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text.rich(
                  TextSpan(
                    children: [
                      TextSpan(
                        text: tr('couponscreen.used_promo_code') + " ",
                        style: TextStyle(
                          color: Color(0xFFA2A2A2),
                          fontSize: 12,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      TextSpan(
                        text: promo,
                        style: TextStyle(
                          color: Colors.red,
                          fontSize: 12,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                ),
                Text(
                  // 'You can avail in all products',
                  "${product}",
                  style: TextStyle(
                    color: Color(0xFFA2A2A2),
                    fontSize: 12,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w400,
                  ),
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      height: 15.h,
                      width: 15.w,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10.r),
                        color: Colors.red,
                      ),
                      child: Image.asset("assets/icons/date.png"),
                    ),
                    5.horizontalSpace,
                    Text(
                      // '2 Days Left',
                      // "${calculateDaysDifference(time!)} days left",
                      // " ${calculateDaysDifference(time!)}" +
                      //     tr('couponscreen.days_left'),
                      HelperFunctions.changeDateFormat(time ?? "29, Jan 2022"),
                      style: TextStyle(
                        color: Color(0xFFA2A2A2),
                        fontSize: 12,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}
