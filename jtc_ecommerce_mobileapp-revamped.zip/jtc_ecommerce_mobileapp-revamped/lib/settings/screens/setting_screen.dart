import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/auth/blocs/send_lang_to_server.dart';
import 'package:jtc_ecommerce/utils/app_fonts.dart';
import 'package:jtc_ecommerce/widgets/custom_app_bar.dart';
import 'package:jtc_ecommerce/services/local_storage.dart';
import 'package:jtc_ecommerce/settings/controllers/settings_controller.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/widgets/custom_scaffold.dart';

class MySettingScreens extends StatefulWidget {
  MySettingScreens({Key? key}) : super(key: key);

  @override
  _MySettingScreensState createState() => _MySettingScreensState();
}

class _MySettingScreensState extends State<MySettingScreens> {
  final SettingsController controller = Get.find<SettingsController>();
  final SendLangToServerBloc sendLangToServerBloc = SendLangToServerBloc();
  void _updateLocale(Locale locale) {
    context.setLocale(locale);
    Get.updateLocale(locale);
    // SharedPreference().setLanguage(languageCode: locale.languageCode);
    // sendLangToServerBloc.sendLangToServerBlocMethod(
    //     languageKey: locale.languageCode);

    SharedPreference().setLanguage(languageCode: locale.languageCode);

    String languageKey;
    if (locale.languageCode == 'es') {
      languageKey = 'sp';
    } else {
      languageKey = locale.languageCode;
    }

    sendLangToServerBloc.sendLangToServerBlocMethod(
        languageKey: languageKey, context: context);
  }

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      isAuthScreen: false,
      appBarTitle: tr('change_language'),
      onTap: () => AppNavigation.navigatorPop(context),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              decoration: BoxDecoration(
                color: Colors.grey[100],
                border: Border.all(color: Colors.grey),
                borderRadius: BorderRadius.circular(12.r),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  RadioListTile<Locale>(
                    title: Text(tr('settingscreen.spanish_text')),
                    value: Locale('es'),
                    groupValue: context.locale,
                    onChanged: (Locale? value) {
                      if (value != null) {
                        _updateLocale(value);
                      }
                    },
                  ),
                  RadioListTile<Locale>(
                    title: Text(tr('settingscreen.english_text')),
                    value: Locale('en'),
                    groupValue: context.locale,
                    onChanged: (Locale? value) {
                      if (value != null) {
                        _updateLocale(value);
                      }
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
