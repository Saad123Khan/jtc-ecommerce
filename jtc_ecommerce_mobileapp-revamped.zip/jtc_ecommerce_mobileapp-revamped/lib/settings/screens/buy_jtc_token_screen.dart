import 'dart:developer';
import 'dart:ui';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_datetime_picker_plus/flutter_datetime_picker_plus.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:jtc_ecommerce/widgets/custom_app_bar.dart';
import 'package:jtc_ecommerce/widgets/custom_button.dart';
import 'package:jtc_ecommerce/widgets/custom_month_picker.dart';
import 'package:jtc_ecommerce/widgets/custom_scaffold.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/widgets/no_data_found.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/settings/blocs/buy_jtc_token_bloc.dart';
import 'package:jtc_ecommerce/settings/controllers/settings_controller.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_constants.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_strings.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';
import 'package:jtc_ecommerce/utils/validations.dart';

import '../../widgets/custom_text_field.dart';

class BuyJtcTokenScreen extends StatelessWidget {
  var controller = Get.find<SettingsController>();
  BuyJtcTokenScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      appBarTitle: tr('jtctokenscreen.title'),
      onTap: () => AppNavigation.navigatorPop(context),
      child: Obx(
        () => controller.isLoading.value
            ? Padding(
                padding: EdgeInsets.all(16.0),
                child: Center(
                  child: CircularProgressIndicator(
                    color: AppColors.PRIMARY_COLOR,
                  ),
                ),
              )
            : !controller.isLoading.value && controller.tokenPlanList.isEmpty
                ? NoDataPage(
                    height: 50.h,
                    text: tr('jtctokenscreen.noTokensFound'),
                    fontSize: 12.sp,
                  )
                : SafeArea(
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          ListView.builder(
                            physics: NeverScrollableScrollPhysics(),
                            shrinkWrap: true,
                            // gridDelegate:
                            //     const SliverGridDelegateWithFixedCrossAxisCount(
                            //         crossAxisCount: 2, childAspectRatio: .57),
                            itemCount: controller.tokenPlanList.length,
                            itemBuilder: (BuildContext context, int index) {
                              return Padding(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 30.0),
                                child: JtcCoinContainer(
                                  tokens: controller.tokenPlanList[index].tokens
                                          .toString() ??
                                      "0",
                                  amount:
                                      controller.tokenPlanList[index].amount ??
                                          "0",
                                  tokenId: controller.tokenPlanList[index].id
                                      .toString(),
                                  name: context.locale.languageCode == 'es'
                                      ? controller
                                              .tokenPlanList[index].nameSp ??
                                          ''
                                      : controller
                                              .tokenPlanList[index].nameEn ??
                                          '',
                                  details: context.locale.languageCode == 'es'
                                      ? controller.tokenPlanList[index]
                                              .discriprtionSp ??
                                          ''
                                      : controller.tokenPlanList[index]
                                              .discriprtionEn ??
                                          '',
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
      ),
    );
  }
}

class JtcCoinContainer extends StatefulWidget {
  final String tokens;
  final String name;
  final String details;
  final String amount;
  final String tokenId;
  const JtcCoinContainer({
    Key? key,
    required this.tokens,
    required this.amount,
    required this.tokenId,
    required this.name,
    required this.details,
  }) : super(key: key);

  @override
  State<JtcCoinContainer> createState() => _JtcCoinContainerState();
}

class _JtcCoinContainerState extends State<JtcCoinContainer> {
  var controller = Get.find<SettingsController>();
  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.sizeOf(context).height * 0.45,
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(12.r),
        // border: Border.all(color: Colors.grey),
      ),
      clipBehavior: Clip.none,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Container(
              height: (MediaQuery.sizeOf(context).height * 0.45) / 2,
              decoration: BoxDecoration(
                image: DecorationImage(
                  fit: BoxFit.cover,
                  image: AssetImage("assets/revamped/jtc_token.png"),
                ),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(12.r),
                  topRight: Radius.circular(12.r),
                ),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    '${widget.tokens}',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    widget.name,
                    style: TextStyle(color: Colors.white),
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            top: (MediaQuery.sizeOf(context).height * 0.45) / 2,
            left: 0,
            right: 0,
            child: Container(
              decoration: BoxDecoration(
                color: Color(0XFFF6F6F6),
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(12.r),
                  bottomRight: Radius.circular(12.r),
                ),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 20),
              child: Padding(
                padding: const EdgeInsets.only(bottom: 5),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    20.verticalSpace,
                    Text(
                      widget.details,
                      textAlign: TextAlign.justify,
                      style: TextStyle(fontSize: 16, color: Colors.black),
                    ),
                    20.verticalSpace,
                    GestureDetector(
                      onTap: () {
                        // AppDialogs.showBottomSheetttttt(
                        //   context: context,
                        //   showButton: false,
                        //   image: "assets/images/coinbasket.png",
                        //   firstHeading: "THANK YOU!",
                        //   secondHeading: "Hurrah! You have",
                        //   thirdHeading: "bought JTC Tokens",
                        // );
                        //Saad
                        logData(message: "JTC TOKEN ID: ${widget.tokenId}");
                        showModalBottomSheet(
                          isScrollControlled: true,
                          barrierColor: Colors.black.withOpacity(
                              0.6), // Change this to desired color and opacity
                          // backgroundColor: AppColors.BLACK_COLOR,
                          elevation: 20,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16.0),
                          ),
                          context: context,
                          builder: (BuildContext context) {
                            return contentBox(context, widget.tokenId);
                          },
                        );
                      },
                      child: Container(
                        height: 60.h,
                        decoration: BoxDecoration(
                            color: Colors.red,
                            borderRadius: BorderRadius.circular(12.r)),
                        child: Center(
                          child: Text(
                            "\$ " + widget.amount + " MXN",
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            top: (MediaQuery.sizeOf(context).height * 0.45) / 2 - 30.0,
            left: 0,
            right: 0,
            child: Align(
              alignment: Alignment.center,
              child: Container(
                width: 60.0,
                height: 60.0,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.red,
                  border: Border.all(color: Colors.white, width: 4.0),
                ),
                child: CircleAvatar(
                  radius: 30.r,
                  backgroundColor: Colors.red,
                  child: ColorFiltered(
                    colorFilter: ColorFilter.mode(
                      Colors.white,
                      BlendMode.srcATop,
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Image.asset("assets/images/logo.png"),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget contentBox(BuildContext context, String? tokenId) {
    var controller = Get.find<SettingsController>();
    return BackdropFilter(
      filter:
          ImageFilter.blur(sigmaX: 5.0, sigmaY: 5.0), // Adjust blur intensity

      child: SizedBox(
        height: .7.sh,
        child: Material(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16.0),
          ),
          child: Container(
            padding: EdgeInsets.all(16.0),
            decoration: BoxDecoration(
              shape: BoxShape.rectangle,
              color: Colors.white,
              borderRadius: BorderRadius.circular(16.0),
            ),
            child: Form(
              key: controller.addCardFormKey,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Align(
                      alignment: Alignment.topRight,
                      child: IconButton(
                          alignment: Alignment.topRight,
                          onPressed: () {
                            Get.back();
                          },
                          icon: Icon(Icons.close)),
                    ),
                    Text(
                      // 'Enter Card Information'.tr,
                      tr('Enter_Card_Information'),
                      style: TextStyle(
                          fontSize: 20.0, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 16.0),
                    SizedBox(
                      height: 220.0,
                      child: SingleChildScrollView(
                        child: Column(
                          children: <Widget>[
                            name_on_card_widget(),
                            SizedBox(height: 8.0),
                            card_details_Widget(),
                            SizedBox(height: 8.0),
                            expiry_and_cvv_Widget(context)
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 16.0),
                    saveButtonWidget(context, tokenId ?? ""),
                    SizedBox(
                      height: MediaQuery.of(context).viewInsets.bottom,
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget name_on_card_widget() {
    return CustomTextField(
        // hintText: AppStrings.CARD_HOLDER_TEXT,
        hintText: tr('jtctokenscreen.cardholder_text'),
        textInputFormattors: [LengthLimitingTextInputFormatter(35)],
        textEditingController: controller.account_holder_controller,
        validator: (value) {
          return FieldValidator2.validateEmpty(
              value: value!, label: AppStrings.CARD_HOLDER_TEXT);
        });
  }

  Widget card_details_Widget() {
    return CustomTextField(
        hintText: tr('jtctokenscreen.cardnumber_text'),
        // hintText: AppStrings.CARD_NUMBER_TEXT,
        textInputFormattors: [AppConstant.MASK_TEXT_FORMATTER_CARD_NO],
        keyboardType: TextInputType.phone,
        textEditingController: controller.account_number_controller,
        validator: (value) {
          return FieldValidator2.validateCardNo(
              value: AppConstant.MASK_TEXT_FORMATTER_CARD_NO.unmaskText(value!),
              label: AppStrings.CARD_NUMBER_TEXT);
        });
  }

  Widget expiry_and_cvv_Widget(context) {
    return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Expanded(
        flex: 1,
        child: Column(children: [
          CustomTextField(
            suffixIcon: AssetPaths.CALENDAR_ICON,
            readyOnly: true,
            onTap: () async {
              DatePicker.showPicker(
                context,
                pickerModel: CustomMonthPicker(
                  minTime: DateTime.now(),
                  maxTime: DateTime(2050, 1, 1),
                  currentTime: DateTime.now(),
                ),
                onConfirm: (time) {
                  setState(() {});
                  if (time != null) {
                    String formattedDate = DateFormat('MM/yy').format(time);
                    logData(message: "formattedDate: ${formattedDate}");
                    controller.expiry_controller.text = formattedDate;
                  } else {
                    print("Date is not selected");
                  }
                  // },
                },
              );
            },
            textInputFormattors: [AppConstant.MASK_TEXT_FORMATTER_EXPIRY],
            keyboardType: TextInputType.phone,
            textEditingController: controller.expiry_controller,
            validator: (value) {
              return FieldValidator2.validateEmpty(
                  value: value!, label: AppStrings.EXPIRY_DATE_TEXT);
            },
            // hintText: AppStrings.EXPIRY_DATE_TEXT,
            hintText: tr('jtctokenscreen.expirydate_text'),
          ),
        ]),
      ),
      SizedBox(width: 15.w),
      Expanded(
        flex: 1,
        child: Column(children: [
          CustomTextField(
              // hintText: AppStrings.CVC_TEXT,
              hintText: tr('jtctokenscreen.cvc_text'),
              textInputFormattors: [
                LengthLimitingTextInputFormatter(3),
                FilteringTextInputFormatter.digitsOnly
              ],
              keyboardType: TextInputType.phone,
              textEditingController: controller.cvc_controller,
              validator: (value) {
                return FieldValidator2.validateCVC(
                    value: value!, label: AppStrings.CVC_TEXT);
              }),
        ]),
      ),
    ]);
  }

  Widget saveButtonWidget(context, String tokenId) {
    var controller = Get.find<SettingsController>();
    return CustomButton(
      // buttonText: AppStrings.ADD_TEXT,
      buttonText: tr('jtctokenscreen.buy'),
      onTap: () async {
        final isValid = controller.addCardFormKey.currentState!.validate();
        if (!isValid) {
          return;
        }
        controller.addCardFormKey.currentState!.save();
        //New
        log("Card Number ${controller.account_number_controller.text}");
        log("Exp Month ${controller.expiry_controller.text.split('/').first}");
        log("Exp Year ${controller.expiry_controller.text.split('/').last}");
        log("CVC ${controller.cvc_controller.text}");

        int expMonth =
            int.parse(controller.expiry_controller.text.split('/').first);
        int expYear =
            int.parse(controller.expiry_controller.text.split('/').last);

        // final cardToken = await StripeService.stripeToken(
        //   cardNumber: controller.account_number_controller.text,
        //   expMonth: expMonth,
        //   expYear: expYear,
        //   cvc: controller.cvc_controller.text.trim(),
        // );

        // logData(message: "Card Token: ${cardToken}");

        // if (cardToken != null) {
        //   AddCardBloc().saveAddress(
        //     context: context,
        //     cardToken: cardToken,
        //     setProgressBar: () {
        //       AppDialogs.progressAlertDialog(context: context);
        //     },
        //   );
        // }
        //!Call here
        BuyJtcTokenBloc().saveAddress(
          context: context,
          cardNumber: controller.account_number_controller.text,
          expMonth: expMonth,
          expYear: expYear,
          cvc: controller.cvc_controller.text.trim(),
          jtcTokenId: tokenId,
          setProgressBar: () {
            AppDialogs.progressAlertDialog(context: context);
          },
        );

        // PaymentController.i.addcard(account_number_controller.text);
        // setState(() {
        //    PaymentController.i.cardsList['cardsData'].value.add(
        //   {
        //     "image": AssetPaths.MASTER_CARD_ICON,

        //     "name": "************${account_number_controller.text.substring(15)}",
        //   },
        // );
        // print(PaymentController.i.cardsList['cardsData'].length);
        // });

        FocusScope.of(context).unfocus();
        // Toast_Message(toastmsg: "Card Added Successfully");
        // Get.toNamed(Paths.HOME_SERVICES_REQUEST_SCREEN_ROUTE);
        // Get.offNamed(Paths.SERVICES_DETAILS_SCREEN_ROUTE);
        // Get.offNamed(Paths.PAYMENT_SETTINGS_SCREEN_ROUTE, arguments: false);
        // Get.back();
      },
      buttonColor: AppColors.PRIMARY_COLOR,
    );
  }
}
