import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/widgets/custom_text_field.dart';
import 'package:jtc_ecommerce/settings/blocs/change_password_bloc.dart';
import 'package:jtc_ecommerce/settings/controllers/settings_controller.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';
import 'package:jtc_ecommerce/utils/field_validator.dart';

class ChangePasswordScreen extends GetView<SettingsController> {
  const ChangePasswordScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Form(
          key: controller.formKey,
          child: Column(
            children: [
              Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image:
                        AssetImage("assets/images/loginbackground_image.png"),
                    fit: BoxFit.cover,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Padding(
                          padding: EdgeInsets.only(left: 20.0.w, top: 30.h),
                          child: GestureDetector(
                            onTap: () {
                              AppNavigation.navigatorPop(context);
                            },
                            child: Container(
                              child: Icon(
                                Icons.arrow_back_ios,
                                color: Colors.white,
                                size: 30.sp,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    Center(
                      child: Image.asset('assets/images/logo.png'),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Text(
                      // 'Change Password',
                      tr('ChangePasswordScreen.title'),
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 15,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text(
                      // 'Current Password',
                      tr('ChangePasswordScreen.current_password'),
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 3,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15.0),
                child: Obx(
                  () => CustomTextField(
                    hintText:
                        //  "Password",
                        tr('ChangePasswordScreen.current_password'),
                    isObsCure: controller.current_password_eye.value,
                    textEditingController: controller.current_password,
                    prefixIcon: AssetPaths.PASSWORD_ICON,
                    validator: (value) => value?.validateNewPassword,
                    isLogin: true,
                    onIconTap: () {
                      controller.current_password_eye.value =
                          !controller.current_password_eye.value;
                    },
                  ),
                ),
              ),
              20.verticalSpace,
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text(
                      // 'New Password',
                      tr('ChangePasswordScreen.new_password'),
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 3,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15.0),
                child: Obx(
                  () => CustomTextField(
                    hintText: tr('ChangePasswordScreen.new_password'),
                    isObsCure: controller.new_password_eye.value,
                    textEditingController: controller.new_password,
                    prefixIcon: AssetPaths.PASSWORD_ICON,
                    validator: (value) => value?.validateNewPassword,
                    isLogin: true,
                    onIconTap: () {
                      controller.new_password_eye.value =
                          !controller.new_password_eye.value;
                    },
                  ),
                ),
              ),
              const SizedBox(
                height: 15,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text(
                      // 'Confirm New Password',
                      tr('ChangePasswordScreen.confirm_new_password'),
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 3,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15.0),
                child: Obx(
                  () => CustomTextField(
                    hintText: tr('ChangePasswordScreen.confirm_new_password'),
                    isObsCure: controller.new_password_eye.value,
                    textEditingController: controller.confirm_new_password,
                    prefixIcon: AssetPaths.PASSWORD_ICON,
                    validator: (value) => value?.validateNewPassword,
                    isLogin: true,
                    onIconTap: () {
                      controller.new_password_eye.value =
                          !controller.new_password_eye.value;
                    },
                  ),
                ),
              ),
              const SizedBox(
                height: 35,
              ),
              GestureDetector(
                onTap: () async {
                  if (controller.formKey.currentState!.validate()) {
                    ChangePasswordBloc().changePasswordBlocMethod(
                      context: context,
                      current_password: controller.current_password.text,
                      new_password: controller.new_password.text,
                      confirm_new_password:
                          controller.confirm_new_password.text,
                      setProgressBar: () {
                        AppDialogs.progressAlertDialog(context: context);
                      },
                    );
                  }
                },
                child: Container(
                  width: 223,
                  height: 50,
                  decoration: ShapeDecoration(
                    color: Color(0xFFE0201C),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  child: Center(
                    child: Text(
                      // 'SAVE',
                      tr('ChangePasswordScreen.save_button'),
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                        height: 0,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
