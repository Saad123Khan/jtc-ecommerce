import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/widgets/custom_app_bar.dart';
import 'package:jtc_ecommerce/splash/controllers/splash_controller.dart';
import 'package:jtc_ecommerce/utils/app_fonts.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/widgets/custom_scaffold.dart';

class UserRefferalScreen extends StatelessWidget {
  const UserRefferalScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      isAuthScreen: false,
      appBarTitle: tr('referalscreen.key'),
      onTap: () => AppNavigation.navigatorPop(context),
      child: TextFormField(
        readOnly: true,
        style: TextStyle(
          color: Colors.black,
          fontSize: 16.sp,
          fontFamily: AppFonts.defaultFont,
          height: 1.5,
        ),
        initialValue:
            Get.find<SplashController>().currentUser.value?.referalCode ?? "",
        decoration: InputDecoration(
          filled: true,
          fillColor: Colors.grey[100],
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Color(0xF3F3F3), width: 0),
            borderRadius: BorderRadius.circular(6.0),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Color(0xF3F3F3), width: 1.5),
            borderRadius: BorderRadius.circular(6.0),
          ),
          isDense: true,
          contentPadding: const EdgeInsets.all(18.0),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(6.0),
          ),
          hintStyle: TextStyle(color: Colors.grey[500]),
          suffixIcon: IconButton(
            icon: Icon(Icons.copy),
            onPressed: () {
              Clipboard.setData(ClipboardData(
                  text: Get.find<SplashController>()
                          .currentUser
                          .value
                          ?.referalCode ??
                      ""));
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(tr('copy_to_clipboard')),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
