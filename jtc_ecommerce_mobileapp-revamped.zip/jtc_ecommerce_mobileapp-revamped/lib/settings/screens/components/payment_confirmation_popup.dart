import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';

class PaymentConfirmationPopup extends StatefulWidget {
  const PaymentConfirmationPopup({super.key});

  @override
  State<PaymentConfirmationPopup> createState() =>
      _PaymentConfirmationPopupState();
}

class _PaymentConfirmationPopupState extends State<PaymentConfirmationPopup> {
  GlobalKey<FormState> formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: Material(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Container(
          padding: EdgeInsets.all(12),
          decoration: BoxDecoration(
              color: AppColors.WHITE_COLOR,
              borderRadius: BorderRadius.circular(12)),
          child: Form(
            key: formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Align(
                  alignment: Alignment.topRight,
                  child: GestureDetector(
                      onTap: () {
                        AppNavigation.navigatorPop(context);
                      },
                      child: Icon(Icons.close)),
                ),
                CustomText(
                  text: 'delete_account',
                  fontsize: 20,
                  fontWeight: FontWeight.bold,
                  color: AppColors.GREY_COLOR,
                ),
                6.verticalSpace,
                CustomText(
                  text: 'are_you_sure_you_want_to_delete',
                  fontsize: 15,
                  maxLines: 4,
                  fontWeight: FontWeight.normal,
                  color: AppColors.GREY_COLOR,
                ),
                15.verticalSpace,
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 12),
                  decoration: BoxDecoration(
                      color: AppColors.APP_GREY_COLOR,
                      borderRadius: BorderRadius.circular(10)),
                  child: TextFormField(
                    decoration: InputDecoration(
                        hintText: tr('login_screen.password'),
                        border: InputBorder.none),
                  ),
                ),
                15.verticalSpace,
              ],
            ),
          ),
        ),
      ),
    );
  }
}
