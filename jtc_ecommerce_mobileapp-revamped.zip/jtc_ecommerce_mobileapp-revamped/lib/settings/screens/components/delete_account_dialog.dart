import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:jtc_ecommerce/widgets/custom_button.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/settings/blocs/delete_account_bloc.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';

class DeleteAccountDialog extends StatefulWidget {
  const DeleteAccountDialog({super.key});

  @override
  State<DeleteAccountDialog> createState() => _DeleteAccountDialogState();
}

class _DeleteAccountDialogState extends State<DeleteAccountDialog> {
  GlobalKey<FormState> formKey = GlobalKey<FormState>();
  TextEditingController passwordController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: Material(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12) 
        ),
        child: Container(
          padding: EdgeInsets.all(12),
          decoration: BoxDecoration(
              color: AppColors.WHITE_COLOR,
              borderRadius: BorderRadius.circular(12)),
          child: Form(
            key: formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Align(
                  alignment: Alignment.topRight,
                  child: GestureDetector(
                      onTap: () {
                        AppNavigation.navigatorPop(context);
                      },
                      child: Icon(Icons.close)),
                ),
                CustomText(
                  text: 'delete_account',
                  fontsize: 20,
                  fontWeight: FontWeight.bold,
                  color: AppColors.GREY_COLOR,
                ),
                6.verticalSpace,
                CustomText(
                  text: 'are_you_sure_you_want_to_delete',
                  fontsize: 15,
                  maxLines: 4,
                  fontWeight: FontWeight.normal,
                  color: AppColors.GREY_COLOR,
                ),
                15.verticalSpace,

                Container(
                  padding: EdgeInsets.symmetric(horizontal: 12),
                  decoration: BoxDecoration(
                    color: AppColors.APP_GREY_COLOR,
                    borderRadius: BorderRadius.circular(10)
                  ),
                  child: TextFormField(
                    decoration: InputDecoration(
                      hintText: tr('login_screen.password'),
                      border: InputBorder.none
                    ),
                  ),
                ),
                   15.verticalSpace,
                Row(
                  children: [
                    Expanded(
                      child: CustomButton(
                          buttonColor: AppColors.RED_GMAIL_COLOR,
                          onTap: () {
                            if (formKey.currentState!.validate()) {
                              formKey.currentState?.save();
            
                              DeleteAccountBLOC().deleteAccount(
                                  context: context,
                                  setProgressBar: () {
                                    AppDialogs.progressAlertDialog(context: context);
                                  },
                                  password: passwordController.text.trim());
                            }
                          },
                          height: 45,
                          buttonText: tr('ExitButtonContent.yes')),
                    ),
                    10.horizontalSpace,
                    Expanded(
                      child: CustomButton(
                          buttonColor: AppColors.GREY_COLOR,
                          onTap: () {
                            AppNavigation.navigatorPop(context);
                          },
                          height: 45,
                          buttonText: tr('ExitButtonContent.no')),
                    )
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
