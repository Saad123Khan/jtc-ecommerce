import 'dart:developer';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:jtc_ecommerce/utils/helper_functions.dart';
import 'package:jtc_ecommerce/widgets/custom_extended_image.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/order_summary/screens/prepartion_time_order_screen.dart';
import 'package:jtc_ecommerce/settings/models/my_oders_model.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_constants.dart';
import 'package:jtc_ecommerce/utils/app_strings.dart';

class OrderHistoryCard extends StatelessWidget {
  const OrderHistoryCard({super.key, required this.orderHistory});
  final HistoryData orderHistory;

  String getOrderType() {
    print("ORDER TYPE ${orderHistory.orderType}");
    if (orderHistory.orderType?.toLowerCase().toString() == 'delivery') {
      return tr('delivery_text');
    } else if (orderHistory.orderType?.toLowerCase().toString() ==
        'take-away') {
      return tr('Take_Away');
    } else if (orderHistory.orderType?.toLowerCase().toString() == 'dine-in') {
      return tr('Dine_In');
    } else if (orderHistory.orderType?.toLowerCase().toString() ==
        'curve_side') {
      return tr('Curbside');
    } else if (orderHistory.orderType?.toLowerCase().toString() ==
        'drive-thru') {
      return tr('Drive_Thru');
    } else {
      return orderHistory.orderType ?? "";
    }
  }

  String formatCustomDate(String dateTime) {
    DateTime parseDated = DateTime.parse(dateTime);
    parseDated = parseDated.toLocal();
    // Format the date part
    String daySuffix(int day) {
      if (day >= 11 && day <= 13) {
        return 'th';
      }
      switch (day % 10) {
        case 1:
          return 'st';
        case 2:
          return 'nd';
        case 3:
          return 'rd';
        default:
          return 'th';
      }
    }

    String formattedDate = DateFormat('MMMM d').format(parseDated);
    String suffix = daySuffix(parseDated.day);
    String year = DateFormat('yyyy').format(parseDated);

    // Format the time part
    String formattedTime =
        DateFormat('h:mm:ss a').format(parseDated).toLowerCase();

    // Combine everything
    return '$formattedDate$suffix $year, $formattedTime';
  }

  //  getDeliveryCharges(){
  //     return orderHistory.orderType == "delivery" ? orderHistory.shipping: 0;
  //   }

  getPaymentType() {
    if (orderHistory.type?.toLowerCase().toString() == 'card') {
      return tr('card');
    } else if (orderHistory.type?.toLowerCase().toString() == 'cod') {
      return tr('Cod');
    } else if (orderHistory.type?.toLowerCase().toString() == 'coins') {
      return tr('coin');
    } else {
      return orderHistory.type ?? "";
    }
  }

  @override
  Widget build(BuildContext context) {
    log("The Time coming from backend is : ${orderHistory.createdAt!}");
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 10.h, vertical: 5.w),
      child: Container(
        decoration: BoxDecoration(
            color: Color(0xFFF6F6F6),
            borderRadius: BorderRadius.circular(12.r),
            border: Border.all(color: Colors.grey)),
        child: Padding(
          padding:
              EdgeInsets.only(top: 20.h, bottom: 20.h, left: 15.w, right: 15.w),
          child: Column(
            children: [
              Row(
                children: [
                  Container(
                    width: 50.w,
                    height: 50.h,
                    decoration: BoxDecoration(
                      color: Color(0xFFE0221E),
                      borderRadius: BorderRadius.circular(50.r),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: Image.asset(
                        "assets/images/myorderjtc.png",
                        color: Colors.white,
                      ),
                    ),
                  ),
                  10.horizontalSpace,
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        tr('MyOrderScreen.orderId') + '${orderHistory.id}',
                        style: TextStyle(
                          color: Color(0xFF3D3D3D),
                          fontSize: 14,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(height: 5), // Vertical spacing
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Row(
                            children: [
                              Container(
                                width: 16.w,
                                height: 16.h,
                                decoration: BoxDecoration(
                                  color: Color(0xFFE0221E),
                                  borderRadius: BorderRadius.circular(16.r),
                                ),
                                child:
                                    Image.asset("assets/revamped/calendar.png"),
                              ),
                              SizedBox(width: 8),
                              Text(
                                '${HelperFunctions.changeDateFormat(orderHistory.createdAt!)}',
                                style: TextStyle(
                                  color: Color(0xFF3D3D3D),
                                  fontSize: 12,
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(width: 5),
                          Row(
                            children: [
                              Container(
                                width: 16.w,
                                height: 16.h,
                                decoration: BoxDecoration(
                                  color: Color(0xFFE0221E),
                                  borderRadius: BorderRadius.circular(16.r),
                                ),
                                child: Image.asset("assets/revamped/time.png"),
                              ),
                              SizedBox(width: 8),
                              Text(
                                '${HelperFunctions.convertToTimeFormat(orderHistory.createdAt!)}',
                                style: TextStyle(
                                  color: Color(0xFF3D3D3D),
                                  fontSize: 12,
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      SizedBox(height: 10), // Vertical spacing
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment:
                            CrossAxisAlignment.start, // Adjust for alignment
                        children: [
                          Row(
                            children: [
                              Container(
                                width: 16.w,
                                height: 16.h,
                                decoration: BoxDecoration(
                                  color: Color(0xFFE0221E),
                                  borderRadius: BorderRadius.circular(16.r),
                                ),
                                child:
                                    Image.asset("assets/revamped/dollar.png"),
                              ),
                              SizedBox(width: 8),
                              Text(
                                '${getPaymentType()}',
                                style: TextStyle(
                                  color: Color(0xFF3D3D3D),
                                  fontSize: 12,
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(width: 5),
                          Row(
                            children: [
                              Container(
                                width: 16.w,
                                height: 16.h,
                                decoration: BoxDecoration(
                                  color: Color(0xFFE0221E),
                                  borderRadius: BorderRadius.circular(16.r),
                                ),
                                child:
                                    Image.asset("assets/revamped/delivery.png"),
                              ),
                              SizedBox(width: 8),
                              Text(
                                '${getOrderType()}',
                                style: TextStyle(
                                  color: Color(0xFF3D3D3D),
                                  fontSize: 12,
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),

              5.verticalSpace,
              ...List.generate(orderHistory.saleItemsId?.length ?? 0, (index) {
                final item = orderHistory.saleItemsId?[index];

                print("VARIATION ${item?.productVariation}");
                // print(item?.product?.name);
                return Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            height: 30,
                            width: 30,
                            decoration: BoxDecoration(
                                border:
                                    Border.all(color: AppColors.APP_GREY_COLOR),
                                borderRadius: BorderRadius.circular(8)),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: CustomExtendedImageWidget(
                                imagePlaceholder: 'assets/images/cart.png',
                                imageType: AppStrings.IMAGE_TYPE_NETWORK,
                                imagePath: item!.product?.imageUrl != null &&
                                        item.product!.imageUrl.isNotEmpty
                                    ? item.product!.imageUrl.first
                                    : null,
                              ),
                            ),
                          ),
                          8.horizontalSpace,
                          Expanded(
                            child: Column(
                              children: [
                                CustomText(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontsize: 14.sp,
                                  isLeftAlign: true,
                                  text: context.locale.languageCode
                                              .toLowerCase() ==
                                          "es"
                                      ? item.product?.nameSp
                                      : item.product?.nameEn,
                                ),
                                CustomText(
                                  color: Color(0XFF666666),
                                  fontsize: 11.sp,
                                  isLeftAlign: true,
                                  text: 'QTY ${item.quantity}',
                                ),
                                10.horizontalSpace,
                              ],
                            ),
                          ),
                          CustomText(
                            color: AppColors.PRIMARY_COLOR,
                            fontsize: 18.sp,
                            // fontWeight: FontWeight.bold,
                            isLeftAlign: true,
                            text: orderHistory.type?.toLowerCase().toString() !=
                                    "coins"
                                ? '\$' +
                                    (item.product?.productPrice
                                            .toStringAsFixed(2) ??
                                        "")
                                : "${item.productPrice?.toStringAsFixed(2)}",
                          ),
                        ],
                      ),
                      5.verticalSpace,
                      if (item.productVariation != null &&
                          item.productVariation != "")
                        CustomText(
                          text: 'variations_text',
                          fontsize: 14.sp,
                          isLeftAlign: true,
                          color: AppColors.RED_GMAIL_COLOR,
                        ),
                      if (item.productVariation != null &&
                          item.productVariation != "")
                        Container(
                          // alignment: Alignment.topLeft,
                          width: 90.w,

                          margin: EdgeInsets.only(right: 8, top: 5),
                          padding:
                              EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4.r),
                            color: Colors.black,
                          ),
                          child: CustomText(
                            text: item.productVariation,
                            color: AppColors.WHITE_COLOR,
                            fontsize: 12.sp,
                          ),
                        ),
                      5.verticalSpace,
                      if ((item.saleItemAddons?.length ?? 0) > 0)
                        CustomText(
                          text: 'addons',
                          fontsize: 14.sp,
                          isLeftAlign: true,
                          color: AppColors.RED_GMAIL_COLOR,
                        ),
                      5.verticalSpace,
                      if ((item.saleItemAddons?.length ?? 0) > 0)
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              ...List.generate(item.saleItemAddons?.length ?? 0,
                                  (index) {
                                final addon = item.saleItemAddons?[index];
                                return Container(
                                  // alignment: Alignment.topLeft,
                                  margin: EdgeInsets.only(right: 8),
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 12, vertical: 4),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(4.r),
                                    color: Colors.black,
                                  ),
                                  child: Row(
                                    children: [
                                      CustomText(
                                        text: addon?.value,
                                        color: AppColors.WHITE_COLOR,
                                        fontsize: 12.sp,
                                      ),
                                      5.horizontalSpace,
                                      CustomText(
                                        text: orderHistory.type
                                                    ?.toLowerCase()
                                                    .toString() !=
                                                "coins"
                                            ? '\$${addon?.price}'
                                            : ' ${addon?.price}',

                                        // addon?.price,
                                        color: AppColors.WHITE_COLOR,
                                        fontsize: 12.sp,
                                      ),
                                    ],
                                  ),
                                );
                              })
                            ],
                          ),
                        ),
                    ],
                  ),
                );
              }),

              10.verticalSpace,
              Row(
                children: [
                  Row(
                    children: [
                      CustomText(
                        text: tr('order_total_text') + ":",
                        isLeftAlign: true,
                        fontsize: 14.sp,
                        color: AppColors.RED_GMAIL_COLOR,
                      ),
                      CustomText(
                        text:
                            " ${orderHistory.type?.toLowerCase().toString() != "coins" ? "\$${orderHistory.price}" : orderHistory.price}",
                        isLeftAlign: true,
                        fontsize: 14.sp,
                        color: Colors.black,
                      ),
                    ],
                  ),
                ],
              ),

              5.verticalSpace,
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      CustomText(
                        text: tr('tax_text') + ": ",
                        isLeftAlign: true,
                        fontsize: 14.sp,
                        color: AppColors.GREY_COLOR,
                      ),
                      CustomText(
                        text: "${orderHistory.tax}",
                        // " ${orderHistory.type?.toLowerCase().toString() != "coins" ? "\$${orderHistory.tax}" : orderHistory.taxToken}",
                        isLeftAlign: true,
                        fontsize: 14.sp,
                        color: AppColors.GREY_COLOR,
                      ),
                    ],
                  ),
                  Container(
                    width: 98,
                    height: 24,
                    decoration: ShapeDecoration(
                      color: _getColorBasedOnStatus(
                          orderHistory.orderStatus ?? "pending"),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(5)),
                    ),
                    child: Center(
                      child: Text(
                        _getTextBasedOnStatus(
                            orderHistory.orderStatus ?? "pending",
                            orderHistory.orderType ?? "deliver"),
                        //  orderHistory.orderType ?? "deliver",
                        style: TextStyle(
                          color: _gettextColorBasedOnStatus(
                              orderHistory.orderStatus ?? "pending"),
                          fontSize: 12,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              5.verticalSpace,

              if (orderHistory.shipping != null &&
                  orderHistory.orderType == "delivery") ...[
                CustomText(
                  text: tr('delivery_charges_text') +
                      ": " +
                      (orderHistory.type?.toLowerCase().toString() != "coins"
                          ? "\$${orderHistory.shipping}"
                          : "${orderHistory.shipping}"),
                  isLeftAlign: true,
                  fontsize: 14.sp,
                  color: AppColors.GREY_COLOR,
                ),
                5.verticalSpace,
              ],

              5.verticalSpace,
              Row(
                children: [
                  Row(
                    children: [
                      CustomText(
                        text: tr('grand_total_text') + ":",
                        isLeftAlign: true,
                        fontsize: 14.sp,
                        // fontWeight: FontWeight.bold,
                        color: AppColors.RED_GMAIL_COLOR,
                      ),
                      CustomText(
                        text:
                            " ${orderHistory.type?.toLowerCase().toString() != "coins" ? "\$${orderHistory.grandTotal}" : "${orderHistory.grandTotal} "}",
                        isLeftAlign: true,
                        fontsize: 14.sp,
                        fontWeight: FontWeight.bold,
                        color: AppColors.GREY_COLOR,
                      ),
                    ],
                  ),
                ],
              ),
              // 5.verticalSpace,
              // 8.verticalSpace,

              10.verticalSpace,
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  GestureDetector(
                    onTap: () {
                      // AppNavigation.navigateTo(
                      //   context,
                      //   AppRouteName.PREPARATION_TIME_ORDER_ROUTE, // Assuming an integer constant
                      // );

                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => PrepartionTimeOrderScreen(
                            data: orderHistory.id.toString(),
                            navigatorPOP: true,
                          ),
                        ),
                      );
                    },
                    child: Container(
                      width: MediaQuery.sizeOf(context).width * 0.3,
                      height: MediaQuery.sizeOf(context).height * 0.05,
                      decoration: BoxDecoration(
                        color: Color(0xFFE0221E),
                        borderRadius: BorderRadius.circular(8.r),
                      ),
                      child: Center(
                        child: Text(
                          // '${controller.myorderList[index].orderStatus}',
                          // "View Order",
                          tr('MyOrderScreen.viewOrder'),
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  Color _getColorBasedOnStatus(String orderStatus) {
    switch (orderStatus) {
      case "0":
        return Color(0xFFFFDCDD);
      case "1":
        return Color(0xFFFFDCDD);
      case "2":
        return Color(0xFFFFDCDD);
      case "3":
        return Color(0xFFFFDCDD);
      case "4":
        return Color.fromARGB(255, 211, 204, 204);
      case "5":
        return Color(0xFFFFDCDD);
      case "6":
        return Color(0xFFFFDCDD);
      case "7":
        return Color(0xFFFFDCDD);
      case "8":
        return Color(0xFFFFDCDD);
      case "9":
        return Color(0xFFFFDCDD);
      case "10":
        return Color(0xFFFFDCDD);
      case "11":
        return Color(0xFFFFDCDD);
      default:
        return Color(0xFFFFDCDD);
    }
  }

  Color _gettextColorBasedOnStatus(String orderStatus) {
    switch (orderStatus) {
      case "0":
        return Color(0xFFE0201C);
      case "1":
        return Color(0xFFE0201C);
      case "2":
        return Color(0xFFE0201C);
      case "3":
        return Color(0xFFE0201C);
      case "4":
        return Color.fromARGB(255, 90, 89, 89);
      case "5":
        return Color(0xFFE0201C);
      case "6":
        return Color(0xFFE0201C);
      case "7":
        return Color(0xFFE0201C);
      case "8":
        return Color(0xFFE0201C);
      case "9":
        return Color(0xFFE0201C);
      case "10":
        return Color(0xFFE0201C);
      case "11":
        return Color(0xFFE0201C);
      default:
        return Color(0xFFE0201C);
    }
  }

  String _getTextBasedOnStatus(String orderStatus, String orderType) {
    print(orderType);
    switch (orderStatus) {
      case "0":
        return tr('orderstatusscreen.pending');
      case "1":
        return tr('orderstatusscreen.accepted_by_jtc');
      case "2":
        return tr('orderstatusscreen.preparing');
      case "3":
        return tr('orderstatusscreen.delivered');
      case "4":
        return tr('orderstatusscreen.completed');
      case "5":
        return tr('orderstatusscreen.returned');
      case "6":
        return tr('orderstatusscreen.refunded');
      case "7":
        return tr('orderstatusscreen.cancelled');
      case "8":
        return tr('orderstatusscreen.hold');
      case "9":
        return tr('orderstatusscreen.start_delivery');
      case "10":
        return tr('orderstatusscreen.rider_arrived');
      case "11":
        return tr('orderstatusscreen.rider_pick_up_order');
      case "12":
        return tr('orderstatusscreen.checking');
      default:
        return tr('orderstatusscreen.processing');
    }
  }
}
