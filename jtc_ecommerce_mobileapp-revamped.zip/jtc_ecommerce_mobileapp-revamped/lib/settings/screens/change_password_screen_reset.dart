import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/auth/controllers/auth_controller.dart';
import 'package:jtc_ecommerce/widgets/custom_text_field.dart';
import 'package:jtc_ecommerce/settings/blocs/change_password_bloc.dart';
import 'package:jtc_ecommerce/settings/blocs/change_password_bloc_reset.dart';
import 'package:jtc_ecommerce/settings/controllers/settings_controller.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';
import 'package:jtc_ecommerce/utils/field_validator.dart';

class ChangePasswordScreenReset extends GetView<SettingsController> {
  ChangePasswordScreenReset({super.key});
  final SettingsController controller = Get.put(SettingsController());
  final AuthController authController = Get.find();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Form(
          key: controller.formKey,
          child: Column(
            children: [
              Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image:
                        AssetImage("assets/images/loginbackground_image.png"),
                    fit: BoxFit.cover,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Padding(
                          padding: EdgeInsets.only(left: 20.0.w, top: 30.h),
                          child: GestureDetector(
                            onTap: () {
                              AppNavigation.navigatorPop(context);
                            },
                            child: Container(
                              child: Icon(
                                Icons.arrow_back_ios,
                                color: Colors.white,
                                size: 30.sp,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    Center(
                      child: Image.asset('assets/images/logo.png'),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Text(
                      // 'Reset Password',
                      tr('resetpassscreen.reset_password'),
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                  ],
                ),
              ),
              // const SizedBox(
              //   height: 15,
              // ),
              // Padding(
              //   padding: const EdgeInsets.symmetric(horizontal: 15),
              //   child: Row(
              //     mainAxisAlignment: MainAxisAlignment.start,
              //     children: [
              //       const Text(
              //         'Current Password',
              //         style: TextStyle(
              //           fontSize: 16,
              //           color: Colors.grey,
              //         ),
              //       ),
              //     ],
              //   ),
              // ),
              // const SizedBox(
              //   height: 3,
              // ),
              // Padding(
              //   padding: const EdgeInsets.symmetric(horizontal: 15.0),
              //   child: Obx(
              //     () => CustomTextField(
              //       hintText: "Password",
              //       isObsCure: controller.current_password_eye.value,
              //       textEditingController: controller.current_password,
              //       prefixIcon: AssetPaths.PASSWORD_ICON,
              //       validator: (value) => value?.validateNewPassword,
              //       isLogin: true,
              //       onIconTap: () {
              //         controller.current_password_eye.value =
              //             !controller.current_password_eye.value;
              //       },
              //     ),
              //   ),
              // ),

              20.verticalSpace,
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text(
                      // 'New Password',
                      tr('resetpassscreen.new_password'),
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 3,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15.0),
                child: Obx(
                  () => CustomTextField(
                    hintText:
                        // "Password",
                        tr('resetpassscreen.new_password'),
                    isObsCure: controller.new_password_eye.value,
                    textEditingController: controller.new_password_reset,
                    prefixIcon: AssetPaths.PASSWORD_ICON,
                    validator: (value) => value?.validateNewPassword,
                    isLogin: true,
                    onIconTap: () {
                      controller.new_password_eye.value =
                          !controller.new_password_eye.value;
                    },
                  ),
                ),
              ),
              const SizedBox(
                height: 15,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text(
                      // 'Confirm New Password',
                      tr('resetpassscreen.confirm_new_password'),
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 3,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15.0),
                child: Obx(
                  () => CustomTextField(
                    hintText:
                        // "Password",
                        tr('resetpassscreen.confirm_new_password'),
                    isObsCure: controller.new_password_eye.value,
                    textEditingController: controller.confirm_new_password_rest,
                    prefixIcon: AssetPaths.PASSWORD_ICON,
                    validator: (value) => value?.validateNewPassword,
                    isLogin: true,
                    onIconTap: () {
                      controller.new_password_eye.value =
                          !controller.new_password_eye.value;
                    },
                  ),
                ),
              ),
              const SizedBox(
                height: 35,
              ),
              GestureDetector(
                onTap: () async {
                  if (controller.formKey.currentState!.validate()) {
                    ChangePasswordResetBloc().changePasswordBlocMethod(
                      context: context,
                      // current_password: controller.current_password.text,
                      // email: "uk@yopmail.com",
                      email: authController.reset_password_email.text,
                      new_password: controller.new_password_reset.text,
                      confirm_new_password:
                          controller.confirm_new_password_rest.text,
                      setProgressBar: () {
                        AppDialogs.progressAlertDialog(context: context);
                      },
                    );
                  }
                },
                child: Container(
                  width: 223,
                  height: 50,
                  decoration: ShapeDecoration(
                    color: Color(0xFFE0201C),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  child: Center(
                    child: Text(
                      // 'SAVE',
                      tr('resetpassscreen.save'),
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                        height: 0,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
