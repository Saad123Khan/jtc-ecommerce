import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/widgets/custom_app_bar.dart';
import 'package:jtc_ecommerce/settings/blocs/notification_list_bloc.dart';
import 'package:jtc_ecommerce/settings/controllers/settings_controller.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:jtc_ecommerce/widgets/custom_scaffold.dart';
import 'package:shimmer/shimmer.dart';

class NotificationListView extends StatefulWidget {
  NotificationListView({super.key});

  @override
  State<NotificationListView> createState() => _NotificationListViewState();
}

class _NotificationListViewState extends State<NotificationListView> {
  final SettingsController controller = Get.put(SettingsController());

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.get_Notification_list();
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return NotificationListener<ScrollNotification>(
        onNotification: (ScrollNotification scrollInfo) {
          if (scrollInfo is ScrollEndNotification &&
              scrollInfo.metrics.pixels == scrollInfo.metrics.maxScrollExtent) {
            // Load more data
            _loadMoreNotifications();
          }
          return false;
        },
        child: CustomScaffold(
          appBarTitle: tr('notifications_text'),
          onTap: () => AppNavigation.navigatorPop(context),
          child: SingleChildScrollView(
            child: Obx(
              () => controller.isLoading.value
                  ? NotificationListShimmer()
                  : Column(
                      children: [
                        ListView.separated(
                          separatorBuilder: (context, index) =>
                              SizedBox(height: 10),
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          itemCount: controller.notificationList.length,
                          itemBuilder: (BuildContext context, int index) {
                            return Container(
                              decoration: BoxDecoration(
                                color: Color(0xFFF6F6F6),
                                borderRadius: BorderRadius.circular(12.r),
                                border: Border.all(color: Colors.grey),
                              ),
                              // color: const Color.fromARGB(255, 243, 242, 242),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 10, vertical: 14),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      context.locale.languageCode == 'es'
                                          ? controller.notificationList[index]
                                                  .titleSp ??
                                              ''
                                          : controller.notificationList[index]
                                                  .titleEn ??
                                              '',
                                      style: TextStyle(
                                        fontSize: 15.sp,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    SizedBox(width: 10),
                                    SizedBox(height: 5),
                                    Text(
                                      context.locale.languageCode == 'es'
                                          ? controller.notificationList[index]
                                                  .messageSp ??
                                              ''
                                          : controller.notificationList[index]
                                                  .messageEn ??
                                              '',
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                        // Loader at the bottom
                        if (controller.isLoadingNextPage.value)
                          Padding(
                            padding: EdgeInsets.all(8.0),
                            child: Center(
                              child: CircularProgressIndicator(
                                color: AppColors.PRIMARY_COLOR,
                              ),
                            ),
                          ),
                        // Message when no more data
                        if (!controller.isLoadingNextPage.value &&
                            controller.notificationList.isEmpty)
                          Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Center(
                              child: Text(
                                tr('no_notification_found_text'),
                                style: TextStyle(fontSize: 14.sp),
                              ),
                            ),
                          ),
                      ],
                    ),
            ),
          ),
        ));
  }

  void _loadMoreNotifications() {
    if (!controller.isLoadingNextPage.value) {
      controller.isLoadingNextPage.value = true;
      int nextPage = (controller.notificationList.length ~/ 10) +
          1; // Assuming page size is 10

      NotificationListBloc()
          .notificationListBlocMethod(
        context: Get.context!,
        page: nextPage,
      )
          .then((_) {
        controller.isLoadingNextPage.value = false;
      }).catchError((error) {
        controller.isLoadingNextPage.value = false;
        print("Error loading more notifications: $error");
      });
    }
  }
}

class NotificationListShimmer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      separatorBuilder: (context, index) => SizedBox(height: 10),
      physics: NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      itemCount: 10, // Number of shimmer items to show
      itemBuilder: (BuildContext context, int index) {
        return Shimmer.fromColors(
          baseColor: Colors.grey[300]!,
          highlightColor: Colors.grey[100]!,
          child: Container(
            color: const Color.fromARGB(255, 243, 242, 242),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 14),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 150, // Adjust width as needed
                    height: 20,
                    color: Colors.grey[300],
                  ),
                  SizedBox(height: 5),
                  Container(
                    width: double.infinity,
                    height: 14,
                    color: Colors.grey[300],
                  ),
                  SizedBox(height: 5),
                  Container(
                    width: double.infinity,
                    height: 14,
                    color: Colors.grey[300],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
