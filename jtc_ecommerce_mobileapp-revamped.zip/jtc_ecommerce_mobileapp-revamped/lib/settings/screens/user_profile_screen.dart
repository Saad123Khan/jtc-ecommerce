import 'dart:io';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/auth/blocs/update_profile_bloc.dart';
import 'package:jtc_ecommerce/widgets/custom_scaffold.dart';
import 'package:jtc_ecommerce/widgets/custom_text_field.dart';
import 'package:jtc_ecommerce/widgets/custom_app_bar.dart';
import 'package:jtc_ecommerce/widgets/custom_button.dart';
import 'package:jtc_ecommerce/widgets/custom_profile_image_box.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/settings/controllers/settings_controller.dart';
import 'package:jtc_ecommerce/splash/controllers/splash_controller.dart';
import 'package:jtc_ecommerce/splash/screens/components/store_setup_dialog.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_fonts.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';
import 'package:jtc_ecommerce/utils/app_strings.dart';
import 'package:jtc_ecommerce/utils/assets_paths.dart';
import 'package:jtc_ecommerce/utils/constants.dart';
import 'package:jtc_ecommerce/utils/field_validator.dart';
import 'package:jtc_ecommerce/utils/image_gallery_class.dart';
import 'package:place_picker/place_picker.dart';

class UserProfileScreen extends StatefulWidget {
  UserProfileScreen({Key? key}) : super(key: key);

  @override
  _UserProfileScreenState createState() => _UserProfileScreenState();
}

class _UserProfileScreenState extends State<UserProfileScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final SettingsController controller = Get.find();

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.imagePath.value = null;

      var splashController = Get.find<SplashController>();
      controller.firstName.text =
          splashController.currentUser.value?.firstName ?? "";
      controller.lastName.text =
          splashController.currentUser.value?.lastName ?? "";
      controller.email_register.text =
          splashController.currentUser.value?.email ?? "";
      controller.phoneNo.text =
          splashController.currentUser.value?.phoneNo ?? "";
      controller.user_address.value.text =
          splashController.currentUser.value?.address ?? "";
      controller.nearest_address.value.text =
          splashController.currentUser.value?.nearest_address ?? "";

      if (splashController.currentUser.value?.lat != null &&
          splashController.currentUser.value?.long != null) {
        latLng = LatLng(double.parse(splashController.currentUser.value!.lat),
            double.parse(splashController.currentUser.value!.long));
      }
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    logData(
        message:
            "================================> ${Get.find<SplashController>().currentUser.value?.provider}");
    return CustomScaffold(
      appBarTitle: tr('profilesreen.profile_screen_title'),
      onTap: () => AppNavigation.navigatorPop(context),
      child: SingleChildScrollView(
        child: Column(
          children: [
            30.verticalSpace,
            Stack(
              alignment: Alignment.topCenter,
              children: [
                Padding(
                  padding: EdgeInsets.only(
                    top: 100 / 2.0,
                    // left: 20.0,
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                        color: Color(0xFFF6F6F6),
                        borderRadius: BorderRadius.circular(24.r),
                        border: Border.all(color: Colors.grey)),
                    child: Column(
                      children: [
                        70.verticalSpace,
                        Form(
                          key: _formKey,
                          child: Column(
                            children: [
                              Container(
                                decoration: BoxDecoration(
                                  color: Color(0xFFF6F6F6),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    20.verticalSpace,
                                    // _imageBox(),
                                    20.verticalSpace,
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 15),
                                      child: Text(
                                        // 'Name',
                                        tr('profilesreen.name'),
                                        style: TextStyle(
                                          fontSize: 16,
                                          color: Colors.grey,
                                        ),
                                      ),
                                    ),
                                    3.verticalSpace,

                                    ///Name Textfield
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 15),
                                      child: CustomTextField(
                                        hintText: tr('profilesreen.name_hint'),
                                        prefixIcon: AssetPaths.FNAME_ICON,
                                        textEditingController:
                                            controller.firstName,
                                        validator: (value) =>
                                            value?.validateEmpty(
                                          tr('profilesreen.name'),
                                        ),
                                        keyboardType: TextInputType.name,
                                        textInputFormattors: [
                                          LengthLimitingTextInputFormatter(
                                            Constants.NAME_MAX_LENGTH,
                                          )
                                        ],
                                      ),
                                    ),
                                    20.verticalSpace,
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 15),
                                      child: Text(
                                        // 'Last Name',
                                        tr('profilesreen.last_name'),
                                        style: TextStyle(
                                          fontSize: 16,
                                          color: Colors.grey,
                                        ),
                                      ),
                                    ),
                                    3.verticalSpace,
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 15),
                                      child: CustomTextField(
                                        hintText:
                                            tr('profilesreen.last_name_hint'),
                                        // hintText: "Enter your last name",
                                        prefixIcon: AssetPaths.FNAME_ICON,
                                        textEditingController:
                                            controller.lastName,
                                        validator: (value) =>
                                            value?.validateEmpty(
                                          tr('profilesreen.last_name'),
                                        ),
                                        keyboardType: TextInputType.name,
                                        textInputFormattors: [
                                          LengthLimitingTextInputFormatter(
                                            Constants.NAME_MAX_LENGTH,
                                          )
                                        ],
                                      ),
                                    ),
                                    20.verticalSpace,

                                    /// Email
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 15),
                                      child: Text(
                                        // 'Email',
                                        tr('profilesreen.email'),
                                        style: TextStyle(
                                          fontSize: 16,
                                          color: Colors.grey,
                                        ),
                                      ),
                                    ),
                                    3.verticalSpace,
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 15),
                                      child: CustomTextField(
                                        hintText:
                                            //  "Enter your email",
                                            tr('profilesreen.email_hint'),
                                        prefixIcon: AssetPaths.EMAIL_ICON,
                                        textEditingController:
                                            controller.email_register,
                                        validator: (value) =>
                                            value?.validateEmail,
                                        readyOnly: true,
                                        keyboardType:
                                            TextInputType.emailAddress,
                                        textInputFormattors: [
                                          LengthLimitingTextInputFormatter(
                                            Constants.EMAIL_MAX_LENGTH,
                                          )
                                        ],
                                      ),
                                    ),

                                    20.verticalSpace,

                                    /// Email
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 15),
                                      child: Text(
                                        // 'Phone Number',

                                        tr('profilesreen.phone_number'),
                                        style: TextStyle(
                                          fontSize: 16,
                                          color: Colors.grey,
                                        ),
                                      ),
                                    ),
                                    3.verticalSpace,
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 15),
                                      child: CustomTextField(
                                        hintText:
                                            // 'Phone Number',
                                            tr('profilesreen.phone_number'),
                                        prefixIcon: AssetPaths.PHONE,
                                        textEditingController:
                                            controller.phoneNo,
                                        // validator: (value) => value?.validateEmail,
                                        // readyOnly: true,
                                        keyboardType: TextInputType.number,
                                        textInputFormattors: [
                                          LengthLimitingTextInputFormatter(
                                            Constants.EMAIL_MAX_LENGTH,
                                          )
                                        ],
                                      ),
                                    ),
                                    20.verticalSpace,
                                    // Padding(
                                    //   padding: const EdgeInsets.symmetric(horizontal: 15),
                                    //   child: Row(
                                    //     mainAxisAlignment: MainAxisAlignment.start,
                                    //     children: [
                                    //       const Text(
                                    //         'Phone Number',
                                    //         style: TextStyle(
                                    //           fontSize: 16,
                                    //           color: Colors.grey,
                                    //         ),
                                    //       ),
                                    //     ],
                                    //   ),
                                    // ),
                                    // 3.verticalSpace,
                                    // Padding(
                                    //   padding: const EdgeInsets.symmetric(horizontal: 15),
                                    //   child: IntlPhoneField(
                                    //     readOnly: true,
                                    //     controller: TextEditingController(
                                    //         // text: controller.storedPhone,
                                    //         ),
                                    //     onCountryChanged: (value) {
                                    //       logData(message: "Country Code Changed$value");
                                    //       // countryCode.value = value.dialCode.toString();
                                    //     },
                                    //     decoration: InputDecoration(
                                    //       filled: true,
                                    //       fillColor: Colors.grey[200],
                                    //       enabledBorder: OutlineInputBorder(
                                    //         borderSide: const BorderSide(
                                    //             color: Color(0xF3F3F3), width: 0),
                                    //         borderRadius: BorderRadius.circular(6.0),
                                    //       ),
                                    //       focusedBorder: OutlineInputBorder(
                                    //         borderSide: const BorderSide(
                                    //             color: Color(0xF3F3F3), width: 1.5),
                                    //         borderRadius: BorderRadius.circular(6.0),
                                    //       ),
                                    //       isDense: true,
                                    //       contentPadding: const EdgeInsets.all(18.0),
                                    //       border: OutlineInputBorder(
                                    //         borderRadius: BorderRadius.circular(6.0),
                                    //       ),
                                    //       hintText: 'Phone Number',
                                    //       hintStyle: TextStyle(color: Colors.grey[500]),
                                    //     ),
                                    //     initialCountryCode: 'PK',
                                    //     onChanged: (phone) {
                                    //       print(phone.completeNumber);
                                    //     },
                                    //   ),
                                    // ),

                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 15),
                                      child: Text(
                                        // 'Nearest Address',
                                        tr('profilesreen.nearest_address'),
                                        style: TextStyle(
                                          fontSize: 16,
                                          color: Colors.grey,
                                        ),
                                      ),
                                    ),
                                    3.verticalSpace,

                                    ///Name Textfield
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 15),
                                      child: CustomTextField(
                                        hintText:
                                            tr('profilesreen.nearest_address'),
                                        prefixIcon:
                                            AssetPaths.NEAREASTADDRESS_ICON,
                                        textEditingController:
                                            controller.nearest_address.value,
                                        // validator: (value) =>
                                        //     value?.validateEmpty("First name"),
                                        keyboardType: TextInputType.text,
                                        textInputFormattors: [
                                          LengthLimitingTextInputFormatter(
                                            Constants.NAME_MAX_LENGTH,
                                          )
                                        ],
                                      ),
                                    ),

                                    20.verticalSpace,
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 15),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Text(
                                            // 'Address',
                                            tr('profilesreen.address_text'),
                                            style: TextStyle(
                                              fontSize: 16,
                                              color: Colors.grey,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    3.verticalSpace,
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 15),
                                      child: user_address(),
                                    ),
                                    // 30.verticalSpace,

                                    30.verticalSpace,
                                    Padding(
                                      padding: EdgeInsets.only(
                                          left: 10.w, right: 10.w),
                                      child: CustomButton(
                                        buttonColor: Color(0xFFE02211),
                                        onTap: () {
                                          if (_formKey.currentState!
                                              .validate()) {
                                            UpdateProfileBloc()
                                                .updateProfileBlocMethod(
                                              context: context,
                                              phone_no: controller.phoneNo.text,
                                              nearest_address: controller
                                                  .nearest_address.value.text,
                                              first_name:
                                                  controller.firstName.text,
                                              last_name:
                                                  controller.lastName.text,
                                              lat: latLng?.latitude != null
                                                  ? latLng?.latitude.toString()
                                                  : null,
                                              long: latLng?.longitude != null
                                                  ? latLng?.longitude.toString()
                                                  : null,
                                              current_user_address: controller
                                                  .user_address.value.text,
                                              isFromUpdateProfile: true,
                                              file: controller
                                                          .imagePath.value !=
                                                      null
                                                  ? controller.imagePath.value
                                                  : null,
                                              setProgressBar: () {
                                                AppDialogs.progressAlertDialog(
                                                    context: context);
                                              },
                                            );
                                          }
                                        },
                                        // buttonText: "SAVE",
                                        buttonText:
                                            tr('profilesreen.save_button'),

                                        fontFamily: AppFonts.defaultFont,
                                        fontSize: 16.sp,
                                      ),
                                    ),

                                    20.verticalSpace,

                                    GestureDetector(
                                      onTap: () {
                                        AppDialogs.showAppDialog(
                                            context: context,
                                            child: StoreSetupDialog(
                                              isFromEdit: true,
                                            ));
                                      },
                                      child: Padding(
                                        padding: EdgeInsets.symmetric(
                                            horizontal: 10.w),
                                        child: Container(
                                            height: 60.h,
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(12.r),
                                              color: Colors.black,
                                            ),
                                            child: Center(
                                              child: Text(
                                                // 'Change Password',
                                                tr('store_locator'),
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 16,
                                                  fontFamily: 'Poppins',
                                                  fontWeight: FontWeight.w500,
                                                  height: 0,
                                                ),
                                              ),
                                            )),
                                      ),
                                    ),

                                    20.verticalSpace,
                                    Get.find<SplashController>()
                                                .currentUser
                                                .value
                                                ?.provider ==
                                            "Default"
                                        ? GestureDetector(
                                            onTap: () {
                                              AppNavigation.navigateTo(
                                                  context,
                                                  AppRouteName
                                                      .CHANGE_PASSWORD_SCREEN_ROUTE);
                                            },
                                            child: Padding(
                                              padding: EdgeInsets.symmetric(
                                                  horizontal: 10.w),
                                              child: Container(
                                                  height: 60.h,
                                                  decoration: BoxDecoration(
                                                    color: Color(0xFFF82E2F),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            12.r),
                                                  ),
                                                  child: Center(
                                                    child: Text(
                                                      // 'Change Password',
                                                      tr('profilesreen.change_password'),
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        color: Colors.white,
                                                        fontSize: 16,
                                                        fontFamily: 'Poppins',
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        height: 0,
                                                      ),
                                                    ),
                                                  )),
                                            ),
                                          )
                                        : SizedBox.shrink(),
                                  ],
                                ),
                              ),
                              20.verticalSpace,
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                // Obx(
                //   () => Container(
                //     height: 100.h,
                //     width: 100.w,
                //     decoration: BoxDecoration(
                //       borderRadius: BorderRadius.circular(100.r),
                //       color: Colors.grey[100],
                //       border: Border.all(
                //         color: Colors.white,
                //         width: 4.0,
                //       ),
                //     ),
                //     child: controller.imagePath.value != ""
                //         ? Image.file(
                //             File(controller.imagePath.value.toString()),
                //             fit: BoxFit.cover,
                //           )
                //         : Image.asset("assets/revamped/person.png"),
                //   ),
                // ),
                _imageBox(),
                // Positioned(
                //   top: 70.h,
                //   left: 80.w,
                //   right: 20.w,
                //   child: GestureDetector(
                //     onTap: () {
                //       print("Printing image ...");
                //       ImageGalleryClass().imageGalleryBottomSheet(
                //         context: Get.context!,
                //         onMediaChanged: (value) {
                //           if (value != null) {
                //             controller.imagePath.value = value;

                //             print(controller.imagePath.value);
                //           }
                //         },
                //       );
                //     },
                //     child: Container(
                //       height: 30.h,
                //       width: 30.w,
                //       decoration: BoxDecoration(
                //         shape: BoxShape.circle,
                //         color: Colors.white,
                //         border: Border.all(
                //           color: Colors.grey,
                //           width: 2.0,
                //         ),
                //       ),
                //       child: Icon(
                //         Icons.camera_alt,
                //         color: Colors.grey,
                //         size: 18.sp,
                //       ),
                //     ),
                //   ),
                // ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  LatLng? latLng;

  Widget user_address() {
    return TextField(
      // controller: controller.user_address,
      // readOnly: !_isEditing,
      controller: controller.user_address.value,
      readOnly: true,
      onTap: () async {
        final result = await Constants.showPlacePicker(context);

        if (result != null) {
          controller.user_address.value.text = result.formattedAddress ?? "";
          latLng = result.latLng;
        }
      },
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.grey[200],
        enabledBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Color(0xF3F3F3), width: 0),
          borderRadius: BorderRadius.circular(6.0),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Color(0xF3F3F3), width: 1.5),
          borderRadius: BorderRadius.circular(6.0),
        ),
        isDense: true,
        contentPadding: const EdgeInsets.all(18.0),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(6.0),
        ),
        hintStyle: TextStyle(color: Colors.red),
        prefixIcon: const Padding(
          padding: EdgeInsets.all(8.0),
          child: Icon(
            Icons.location_pin,
            size: 20,
            color: Colors.black,
          ),
        ),
        suffixIcon: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.only(right: 8.0),
              child: GestureDetector(
                onTap: () async {
                  final result = await Constants.showPlacePicker(context);

                  if (result != null) {
                    controller.user_address.value.text =
                        result.formattedAddress ?? "";
                    latLng = result.latLng;
                  }
                },
                child: Text(
                  // 'Edit',
                  tr('profilesreen.edit_text'),
                  style: TextStyle(
                    color: Color(0xFFE0201C),
                    fontSize: 14,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w500,
                    decoration: TextDecoration.underline,
                    height: 0,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _imageBox() {
    return Obx(
      () => Center(
        child: CustomEditProfileImageWidget(
          show_change_picture: true,
          // imageType: controller.imageType,
          imageType: controller.imagePath.value != null ? "file" : "network",
          imagePath: controller.imagePath.value != null
              ? controller.imagePath.value?.path
              : Get.find<SplashController>().currentUser.value?.image,

          // updatingProfile: controller.updatingProfile ? true : false,
          onViewImage: () {
            if (controller.imageType == AppStrings.IMAGE_FILE_TYPE) {}
          },
          onUploadImageTap: () {
            ImageGalleryClass().imageGalleryBottomSheet(
              context: Get.context!,
              onMediaChanged: (value) {
                if (value != null) {
                  controller.imagePath.value = value;

                  print(controller.imagePath.value);
                } else {
                  return null;
                }
              },
            );
          },
        ),
      ),
    );
  }
}
