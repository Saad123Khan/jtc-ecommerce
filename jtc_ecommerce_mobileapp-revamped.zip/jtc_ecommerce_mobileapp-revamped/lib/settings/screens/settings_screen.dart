import 'dart:developer';
import 'dart:ffi';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/widgets/custom_button.dart';
import 'package:jtc_ecommerce/widgets/custom_text.dart';
import 'package:jtc_ecommerce/widgets/user_avatar.dart';
import 'package:jtc_ecommerce/settings/blocs/logout_bloc.dart';
import 'package:jtc_ecommerce/settings/controllers/settings_controller.dart';
import 'package:jtc_ecommerce/settings/widgets/setting_widget.dart';
import 'package:jtc_ecommerce/splash/controllers/splash_controller.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_fonts.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';
// import 'package:url_launcher/url_launcher.dart';

class SettingScreen extends StatefulWidget {
  SettingScreen({Key? key}) : super(key: key);

  @override
  _SettingScreenState createState() => _SettingScreenState();
}

class _SettingScreenState extends State<SettingScreen> {
  final SettingsController controller = Get.put(SettingsController());
  var splashController = Get.find<SplashController>();

  @override
  void initState() {
    var splashController = Get.find<SplashController>();
    controller.firstName.text =
        splashController.currentUser.value?.firstName ?? "";
    controller.lastName.text =
        splashController.currentUser.value?.lastName ?? "";
    controller.email_register.text =
        splashController.currentUser.value?.email ?? "";
    controller.phoneNo.text = splashController.currentUser.value?.phoneNo ?? "";
    controller.user_address.value.text =
        splashController.currentUser.value?.address ?? "";

    controller.nearest_address.value.text =
        splashController.currentUser.value?.nearest_address ?? "";

    print("IMAGE URL 1234 ${splashController.currentUser.value?.imageUrl}");

    log("USER ${splashController.currentUser.value?.toJson().toString()}");
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 20.h),
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(24.r),
            topRight: Radius.circular(24.r),
          )),
      child: SingleChildScrollView(
        child: Column(
          children: [
            30.verticalSpace,
            Stack(
              alignment: Alignment.topCenter,
              children: <Widget>[
                Padding(
                  padding:
                      EdgeInsets.only(top: 100 / 2.0, left: 20.0, right: 20.0),
                  child: Container(
                    // height: MediaQuery.sizeOf(context).height * 0.20,
                    decoration: BoxDecoration(
                        color: Color(0XFFF6F6F6),
                        borderRadius: BorderRadius.circular(24.r),
                        border: Border.all(color: Colors.grey)),
                    child: Column(
                      // mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        70.verticalSpace,
                        Text(
                          "${splashController.currentUser.value?.firstName}"
                                  " " +
                              "${splashController.currentUser.value?.lastName}",
                          style: TextStyle(
                              color: Colors.black,
                              fontFamily: AppFonts.defaultFont,
                              fontSize: 18.sp),
                        ),
                        20.verticalSpace,
                        Text(
                          "${splashController.currentUser.value?.email}",
                          style: TextStyle(
                              color: Color(0XFF666666),
                              fontFamily: AppFonts.defaultFont,
                              fontSize: 12.sp),
                        ),
                        30.verticalSpace,
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 30.w),
                          child: Column(
                            children: [
                              MenuItems(
                                imageIcon: "assets/revamped/order.png",
                                title: tr('my_order'),
                                detail: tr("settingScreen.my_order_detail"),
                                titleTextStyle: TextStyle(
                                  color: Colors.white,
                                  fontSize: 14.sp,
                                  fontFamily: AppFonts.defaultFont,
                                  fontWeight: FontWeight.normal,
                                ),
                                detailTextStyle: TextStyle(
                                  color: Colors.white,
                                  fontSize: 12.sp,
                                  fontWeight: FontWeight.normal,
                                ),
                                onTap: () {
                                  AppNavigation.navigateTo(
                                      context, AppRouteName.MY_ORDERS);
                                  // controller.get_my_orders();
                                },
                                selectedColor: Color(0xFFC81925),
                                imageColor: Color(0xFF670003),
                                titleColor: Colors.white,
                              ),
                              10.verticalSpace,
                              MenuItems(
                                imageIcon: "assets/revamped/profile.png",
                                title: tr('profile'),
                                detail: tr("settingScreen.profile_detail"),
                                titleTextStyle: TextStyle(
                                  color: Colors.black,
                                  fontSize: 14.sp,
                                  fontWeight: FontWeight.bold,
                                ),
                                detailTextStyle: TextStyle(
                                  color: Color(0XFF666666),
                                  fontSize: 12.sp,
                                  fontWeight: FontWeight.normal,
                                ),
                                onTap: () {
                                  AppNavigation.navigateTo(context,
                                      AppRouteName.USER_PROFILE_SCREEN_ROUTE);
                                },
                                selectedColor: Colors.transparent,
                                imageColor: Color(0xFFE0221E),
                                titleColor: Colors.black,
                              ),
                              10.verticalSpace,
                              MenuItems(
                                imageIcon: "assets/revamped/coupon.png",
                                title: tr('coupon'),
                                detail: tr("settingScreen.coupon_detail"),
                                titleTextStyle: TextStyle(
                                  color: Colors.black,
                                  fontSize: 14.sp,
                                  fontWeight: FontWeight.bold,
                                ),
                                detailTextStyle: TextStyle(
                                  color: Color(0XFF666666),
                                  fontSize: 12.sp,
                                  fontWeight: FontWeight.normal,
                                ),
                                onTap: () {
                                  AppNavigation.navigateTo(context,
                                      AppRouteName.COUPON_SCREEN_ROUTE);
                                  controller.get_coupon_list();
                                },
                                selectedColor: Colors.transparent,
                                imageColor: Color(0xFFE0221E),
                                titleColor: Colors.black,
                              ),
                              10.verticalSpace,
                              MenuItems(
                                imageIcon: "assets/revamped/token.png",
                                title: tr('buy_jtc_tokens'),
                                detail: tr("settingScreen.jtc_detail"),
                                titleTextStyle: TextStyle(
                                  color: Colors.black,
                                  fontSize: 14.sp,
                                  fontWeight: FontWeight.bold,
                                ),
                                detailTextStyle: TextStyle(
                                  color: Color(0XFF666666),
                                  fontSize: 12.sp,
                                  fontWeight: FontWeight.normal,
                                ),
                                onTap: () {
                                  AppNavigation.navigateTo(context,
                                      AppRouteName.BUY_JTC_TOKEN_SCREEN_ROUTE);
                                  controller.get_buy_jtc_token();
                                },
                                selectedColor: Colors.transparent,
                                imageColor: Color(0xFFE0221E),
                                titleColor: Colors.black,
                              ),
                              10.verticalSpace,
                              MenuItems(
                                imageIcon: "assets/revamped/refereal.png",
                                title: tr("referals"),
                                detail: tr("settingScreen.referal_detail"),
                                titleTextStyle: TextStyle(
                                  color: Colors.black,
                                  fontSize: 14.sp,
                                  fontWeight: FontWeight.bold,
                                ),
                                detailTextStyle: TextStyle(
                                  color: Color(0XFF666666),
                                  fontSize: 12.sp,
                                  fontWeight: FontWeight.normal,
                                ),
                                onTap: () {
                                  AppNavigation.navigateTo(
                                      context,
                                      AppRouteName
                                          .USER_REFFERAL_CODE_SCREEN_ROUTE);
                                },
                                selectedColor: Colors.transparent,
                                imageColor: Color(0xFFE0221E),
                                titleColor: Colors.black,
                              ),
                              10.verticalSpace,
                              MenuItems(
                                imageIcon: "assets/revamped/language.png",
                                title: tr('change_lang'),
                                detail: tr('settingScreen.change_lang_detail'),
                                titleTextStyle: TextStyle(
                                  color: Colors.black,
                                  fontSize: 14.sp,
                                  fontWeight: FontWeight.bold,
                                ),
                                detailTextStyle: TextStyle(
                                  color: Color(0XFF666666),
                                  fontSize: 12.sp,
                                  fontWeight: FontWeight.normal,
                                ),
                                onTap: () {
                                  AppNavigation.navigateTo(
                                      context, AppRouteName.SettingScreen);
                                },
                                selectedColor: Colors.transparent,
                                imageColor: Color(0xFFE0221E),
                                titleColor: Colors.black,
                              ),
                              10.verticalSpace,
                              MenuItems(
                                imageIcon: "assets/revamped/privacy.png",
                                title: tr('privacy_pol'),
                                detail: tr('settingScreen.privacy_detail'),
                                titleTextStyle: TextStyle(
                                  color: Colors.black,
                                  fontSize: 14.sp,
                                  fontWeight: FontWeight.bold,
                                ),
                                detailTextStyle: TextStyle(
                                  color: Color(0XFF666666),
                                  fontSize: 12.sp,
                                  fontWeight: FontWeight.normal,
                                ),
                                onTap: () {
                                  ///Use here web view flutter instead of this , please see yaml for error detail only on ios
                                  // launchUrl(Uri.parse(
                                  //     'https://javatimescaffe.com/privacy-policy/en'));
                                },
                                selectedColor: Colors.transparent,
                                imageColor: Color(0xFFE0221E),
                                titleColor: Colors.black,
                              ),
                            ],
                          ),
                        ),
                        20.verticalSpace,
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 20.w),
                          child: GestureDetector(
                            onTap: () {
                              logoutBloc().logoutBlocMethod(
                                context: context,
                                setProgressBar: () {
                                  AppDialogs.progressAlertDialog(
                                      context: context);
                                },

                                // setProgressBar: () {
                                //   AppDialogs.progressAlertDialog(context: context);
                                // },
                              );
                            },
                            child: Container(
                              height: 65.h,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(12.r),
                                color: Color(0xFFE02215),
                              ),
                              child: Center(
                                child: Text(
                                  "LOGOUT",
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                            ),
                          ),
                        ),
                        20.verticalSpace,
                      ],
                    ),
                  ),
                ),
                Container(
                  padding: EdgeInsets.all(4.0), // For border effect
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: Colors.white,
                      width: 4.0,
                    ),
                  ),
                  child: CircleAvatar(
                    radius: 50.r, // Adjust the radius as needed
                    backgroundColor: Colors.grey[100],
                    backgroundImage:
                        splashController.currentUser.value?.imageUrl != null &&
                                splashController
                                    .currentUser.value!.imageUrl.isNotEmpty
                            ? NetworkImage(
                                splashController.currentUser.value!.image,
                              )
                            : AssetImage("assets/revamped/person.png")
                                as ImageProvider,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );

    // t76(),
    // Container(
    //   height: 160,
    //   color: Colors.white,
    //   child: Stack(
    //     alignment: Alignment.center,
    //     children: [
    //       Image.asset('assets/images/home/logo_drawerimage2.png'),

    //       splashController.currentUser.value!.image != ""
    //           ? Obx(
    //               () => UserAvatar(
    //                   radius: 60.r,
    //                   userImage:
    //                       splashController.currentUser.value!.image),
    //             )
    //           : CircleAvatar(
    //               radius: 60.r,
    //               backgroundImage:
    //                   AssetImage("assets/images/user_img.png"),
    //               backgroundColor: AppColors.GREY_COLOR,
    //             ),
    //       // controller.userProfileImagePath != null
    //       //     ? Obx(() => UserAvatar(
    //       //           radius: 60.r,
    //       //           isNetworkImage: controller.userProfileImagePath != null
    //       //               ? true
    //       //               : false,
    //       //           userImage: controller.userProfileImagePath != null
    //       //               ?
    //       //               splashController.currentUser.value?.image.toString()

    //       //               // NetworkStrings.NETWORK_IMAGE_BASE_URL +
    //       //               //     controller.userProfileImagePath.toString()
    //       //               : AssetPaths.USER_IMAGE,
    //       //         ))
    //       //     :

    //       // CircleAvatar(
    //       //   radius: 30.r,
    //       //   backgroundColor: AppColors.GREY_COLOR,
    //       // ),

    //       // NetworkImage(controller.userProfileImagePath)
    //     ],
    //   ),
    // ),

    // Obx(
    //   () => CustomText(
    // text: "${splashController.currentUser.value?.firstName}" " " +
    //     "${splashController.currentUser.value?.lastName}",
    //     color: AppColors.BLACK_COLOR,
    //     // fontFamily: AppFonts.robotoMedium,
    //     fontsize: 18.sp,
    //   ),
    // ),
    // CustomText(
    //   text: splashController.currentUser.value?.email,
    //   color: Colors.grey[500],
    //   // fontFamily: AppFonts.robotoligth,
    //   fontsize: 16.sp,
    // ),
    // 20.verticalSpace,
    // GestureDetector(
    //     onTap: () {
    //       AppNavigation.navigateTo(context, AppRouteName.MY_ORDERS);
    //       // controller.get_my_orders();
    //     },
    //     child: my_order()),
    // SettingWidget(
    //   stringImg: 'assets/svg/drawer/profile.svg',
    //   heading: tr('settingscreen.profile'),
    //   description: tr('settingscreen.edit_name_picture_password'),
    //   // description: 'You can edit name, picture & password'.tr,

    //   onTap: () {
    //     AppNavigation.navigateTo(
    //         context, AppRouteName.USER_PROFILE_SCREEN_ROUTE);
    //   },
    // ),
    // SettingWidget(
    //   stringImg: 'assets/svg/drawer/fav.svg',
    //   // heading: 'Coupon'.tr,
    //   // description: 'You can use free coupons and get discounts'.tr,
    //   heading: tr('settingscreen.coupon'),
    //   description: tr('settingscreen.use_free_coupons'),
    //   onTap: () {
    //     AppNavigation.navigateTo(
    //         context, AppRouteName.COUPON_SCREEN_ROUTE);
    //     controller.get_coupon_list();
    //   },
    // ),
    // // SettingWidget(
    // //   stringImg: 'assets/svg/drawer/track.svg',
    // //   heading: 'Reward',
    // //   description: 'You can edit notification',
    // //   onTap: () {},
    // // ),
    // SettingWidget(
    //   stringImg: 'assets/svg/drawer/tokens.svg',
    //   // heading: 'Buy JTC Tokens'.tr,
    //   // description: 'You can buy tokens and pay using the JTC token'.tr,
    //   heading: tr('settingscreen.buy_jtc_tokens'),
    //   description: tr('settingscreen.buy_tokens_description'),
    //   onTap: () {
    //     AppNavigation.navigateTo(
    //         context, AppRouteName.BUY_JTC_TOKEN_SCREEN_ROUTE);
    //     controller.get_buy_jtc_token();
    //   },
    // ),
    // SettingWidget(
    //   stringImg: 'assets/svg/drawer/rider.svg',
    //   // heading: 'Referral'.tr,
    //   // description: 'You can refer your family and friend. '.tr,
    //   heading: tr('settingscreen.referral'),
    //   description: tr('settingscreen.refer_family_friends'),
    //   onTap: () {
    //     AppNavigation.navigateTo(
    //         context, AppRouteName.USER_REFFERAL_CODE_SCREEN_ROUTE);
    //   },
    // ),
    // // SettingWidget(
    // //   stringImg: 'assets/svg/drawer/wallet.svg',
    // //   heading: 'My Wallet',
    // //   description: 'You can check your wallet',
    // //   onTap: () {},
    // // ),

    // SettingWidget(
    //   stringImg: 'assets/svg/drawer/setting.svg',
    //   heading: tr('change_language'),
    //   description: tr('settingscreen.change_app_setting'),
    //   onTap: () {
    //     AppNavigation.navigateTo(context, AppRouteName.SettingScreen);
    //   },
    // ),

    // // SettingWidget(
    // //   stringImg: 'assets/svg/drawer/delete_account.svg',
    // //   heading: tr('delete_account'),
    // //   description: tr('you_can_delete_your_account'),
    // //   onTap: () {
    // //     AppDialogs.showAppDialog(
    // //         context: context, child: DeleteAccountDialog());
    // //   },
    // // ),
    // // SettingWidget(
    // //   stringImg: 'assets/svg/drawer/rider.svg',
    // //   // heading: 'Help Center'.tr,
    // //   // description: 'You can reach out to us.'.tr,
    // //   heading: tr('settingscreen.help_center'),
    // //   description: tr('settingscreen.reach_out_to_us'),
    // //   onTap: () {},
    // // ),

    // SettingWidget(
    //   stringImg: 'assets/svg/drawer/rider.svg',
    //   // heading: 'Help Center'.tr,
    //   // description: 'You can reach out to us.'.tr,
    //   heading: tr('settingscreen.privacy_policy_text'),
    //   description: tr('settingscreen.reach_out_to_us'),
    //   onTap: () {
    //     launchUrl(
    //         Uri.parse('https://javatimescaffe.com/privacy-policy/en'));
    //   },
    // ),
    // 20.verticalSpace,
    // Padding(
    //   padding: EdgeInsets.only(left: 50.w, right: 50.w, bottom: 20.h),
    //   child: CustomButton(
    //     height: 50.h,
    //     buttonColor: AppColors.PRIMARY_COLOR,
    //     onTap: () {
    //       logoutBloc().logoutBlocMethod(
    //         context: context,
    //         setProgressBar: () {
    //           AppDialogs.progressAlertDialog(context: context);
    //         },

    //         // setProgressBar: () {
    //         //   AppDialogs.progressAlertDialog(context: context);
    //         // },
    //       );
    //     },
    //     buttonText: tr('settingscreen.logout_text'),
    //     fontSize: 14.sp,
    //   ),
    // ),
    //   ],
    // ),
  }

  Widget my_order() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment(1.00, 0.00),
          end: Alignment(-1, 0),
          colors: [
            Color(0xFF1D1D1D),
            Color(0xFF3E3E3E),
          ],
        ),
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 55, vertical: 20),
            child: Row(
              children: [
                Column(
                  children: [
                    Image.asset(
                      'assets/images/my_orders.png',
                      height: 20,
                      color: AppColors.WHITE_COLOR,
                    )
                    // SvgPicture.asset('assets/svg/drawer/profile.svg'),
                  ],
                ),
                20.horizontalSpace,
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomText(
                        text: tr('settingscreen.my_order'),
                        isLeftAlign: false,
                        align: Alignment.centerLeft,
                        fontsize: 16.sp,
                        // fontFamily: AppFonts.robotoMedium,
                      ),
                      CustomText(
                        // text: 'Real time check your order'.tr,
                        text: tr('settingscreen.real_time_check_order'),
                        color: Color(0xFFAAAAAA),
                        fontsize: 14.sp,
                        isLeftAlign: false,
                        align: Alignment.centerLeft,
                        fontFamily: AppFonts.defaultFont,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Widget _imageBox() {
  //   return GetBuilder<SettingsController>(builder: (regController) {
  //     return Center(
  //       child: CustomEditProfileImageWidget(
  //         imageType: "network",
  //         imagePath: controller.userProfileImagePath,
  //         updatingProfile: controller.updatingProfile ? true : false,
  //         onViewImage: () {
  //           if (controller.imageType == AppStrings.IMAGE_FILE_TYPE) {}
  //         },
  //         onUploadImageTap: () {
  //           ImageGalleryClass().imageGalleryBottomSheet(
  //             context: Get.context!,
  //             onMediaChanged: (value) {
  //               if (value != null) {
  //                 controller.updateImage(value);
  //               } else {
  //                 return null;
  //               }
  //             },
  //           );
  //         },
  //       ),
  //     );
  //   });
  // }

  Widget t76() {
    return GetBuilder<SplashController>(builder: (regController) {
      // return Center(
      //   child: CustomEditProfileImageWidget(
      //     show_change_picture: true,
      //     // imageType: controller.imageType,
      //     imageType: "Network",
      //     imagePath: controller.userProfileImagePath,
      //     updatingProfile: controller.updatingProfile ? true : false,
      //     onViewImage: () {
      //       if (controller.imageType == AppStrings.IMAGE_FILE_TYPE) {}
      //     },
      //     onUploadImageTap: () {
      //       ImageGalleryClass().imageGalleryBottomSheet(
      //         context: Get.context!,
      //         onMediaChanged: (value) {
      //           if (value != null) {
      //             controller.updateImage(value);
      //           } else {
      //             return null;
      //           }
      //         },
      //       );
      //     },
      //   ),
      // );
      return Container(
        height: 160,
        color: Colors.white,
        child: Stack(
          alignment: Alignment.center,
          children: [
            Image.asset('assets/images/home/logo_drawerimage2.png'),
            Container(
              width: 130,
              height: 130,
              decoration: ShapeDecoration(
                shape: OvalBorder(),
                image: DecorationImage(
                  image: AssetImage('assets/images/home/drawea.png'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            regController.currentUser.value?.image != null &&
                    regController.currentUser.value?.image != ""
                ?
                // Obx(
                //     () =>
                UserAvatar(
                    radius: 60.r,
                    isNetworkImage: true,
                    userImage: regController.currentUser.value!.image,
                  )
                // )
                : CircleAvatar(
                    radius: 60.r,
                    backgroundColor: AppColors.GREY_COLOR,
                  ),

            // NetworkImage(controller.userProfileImagePath)
          ],
        ),
      );
    });
  }
}

class MenuItems extends StatelessWidget {
  final String imageIcon;
  final String title;
  final String detail;
  final Function onTap;
  final Color selectedColor;
  final Color imageColor;
  final Color titleColor;
  final TextStyle titleTextStyle;
  final TextStyle detailTextStyle;

  MenuItems({
    super.key,
    required this.imageIcon,
    required this.title,
    required this.detail,
    required this.onTap,
    required this.selectedColor,
    required this.imageColor,
    required this.titleColor,
    required this.detailTextStyle,
    required this.titleTextStyle,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        onTap();
      },
      child: Container(
        height: 70.h,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12.r),
          color: selectedColor,
        ),
        padding: EdgeInsets.symmetric(horizontal: 30.0),
        child: Row(
          children: [
            Container(
              height: 40.h,
              width: 40.w,
              decoration: BoxDecoration(
                color: imageColor,
                borderRadius: BorderRadius.circular(40.r),
              ),
              child: Image.asset(
                imageIcon,
                color: Colors.white,
              ),
            ),
            10.horizontalSpace,
            // Wrap Column with Expanded to allow proper layout
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: titleTextStyle,
                  ),
                  // Use Flexible to ensure the text wraps properly
                  Flexible(
                    child: Text(
                      detail,
                      maxLines: 2,
                      overflow: TextOverflow
                          .ellipsis, // Ensure ellipsis for overflowing text
                      style: detailTextStyle,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
