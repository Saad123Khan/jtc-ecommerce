import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as Getx;
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/settings/controllers/settings_controller.dart';
import 'package:jtc_ecommerce/settings/models/buy_jtc_token_plan_model.dart';
import 'package:jtc_ecommerce/settings/models/coupon_model.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';

class CouponListBloc {
  Map<String, dynamic>? _queryParameters;
  Response? _response;
  VoidCallback? _onSuccess;
  dynamic contentTypeResponse;
  // GetProductByCategoryModel? _getProductByCategoryModel;
  CouponModel? _couponModel;

  ////////////////////////// Terms and Condition And Privacy Policy //////////////////////////////////
  Future<void> couponListBlocMethod({
    required BuildContext context,
  }) async {
    await _getRequest(
      endPoint: NetworkStrings.COUPON_ENDPOINT,
      context: context,
    );

    _onSuccess = () {
      contentTypeResponse = _response?.data;
    };

    _validateResponse();

    return contentTypeResponse;
  }

  // Get Request
  Future<void> _getRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().getRequest(
      context: context,
      endPoint: endPoint,
      queryParameters: _queryParameters,
      isToast: false,
      isHeaderRequire: true,
    );
  }

//   void _validateResponse() {
//     var homeController = Getx.Get.find<SettingsController>();

//     try {
//       _couponModel = CouponModel.fromJson(_response?.data);
//       logData(
//           message: "_getGoalModel: ${_couponModel?.data?.couponList}");
//       //1

//       List<CouponModel> updatedListForHome =
//           List.from(homeController.couponList);
//       //2
//       updatedListForHome.addAll(_couponModel?.data?.couponList ?? []);
//       //3
//       homeController.couponList.assignAll(updatedListForHome);
//       logData(
//           message: "goalList For home: ${homeController.couponList.length}");
//       Network().validateResponse(
//         response: _response,
//         onSuccess: _onSuccess,
//         isToast: false,
//       );
//     } catch (error, stackTrace) {
//       print("Error in _validateResponse: $error");
//       print("Stack Trace: $stackTrace");
//     }
//   }
// }

  void _validateResponse() {
    var homeController = Getx.Get.find<SettingsController>();

    try {
      _couponModel = CouponModel.fromJson(_response?.data);
      logData(message: "_getGoalModel: ${_couponModel?.data?.couponList}");
      //1

      List<CouponList> updatedListForHome =
          List<CouponList>.from(homeController.couponList);
      //2
      updatedListForHome.addAll(_couponModel?.data?.couponList ?? []);
      //3
      homeController.couponList.assignAll(updatedListForHome);
      logData(
          message: "goalList For home: ${homeController.couponList.length}");
      Network().validateResponse(
        response: _response,
        onSuccess: _onSuccess,
        isToast: false,
      );
    } catch (error, stackTrace) {
      print("Error in _validateResponse: $error");
      print("Stack Trace: $stackTrace");
    }
  }
}
