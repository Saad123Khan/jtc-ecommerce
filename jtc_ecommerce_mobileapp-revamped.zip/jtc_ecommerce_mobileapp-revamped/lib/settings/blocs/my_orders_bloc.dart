import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as Getx;
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/settings/controllers/settings_controller.dart';
import 'package:jtc_ecommerce/settings/models/buy_jtc_token_plan_model.dart';
import 'package:jtc_ecommerce/settings/models/my_oders_model.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';

class MyOrdersBloc {
  Map<String, dynamic>? _queryParameters;
  Response? _response;
  VoidCallback? _onSuccess;
  dynamic contentTypeResponse;
  // GetProductByCategoryModel? _getProductByCategoryModel;
  OrderHistoryModel? _myOrdersModel;

  ////////////////////////// Terms and Condition And Privacy Policy //////////////////////////////////
  Future<void> getMyOrdersyJTCTokenBlocMethod({
    required BuildContext context,
  }) async {
    await _getRequest(
      endPoint: NetworkStrings.MY_ORDERS,
      context: context,
    );

    _onSuccess = () {
      contentTypeResponse = _response?.data;
    };

    _validateResponse();

    return contentTypeResponse;
  }

  // Get Request
  Future<void> _getRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().getRequest(
      context: context,
      endPoint: endPoint,
      queryParameters: _queryParameters,
      isToast: false,
      isHeaderRequire: true,
    );
  }

//   void _validateResponse() {
//     var homeController = Getx.Get.find<SettingsController>();

//     try {
//       // _myOrdersModel = MyOrdersModel.fromJson(_response?.data);
//       // // logData(
//       // //     message: "_getGoalModel: ${_myOrdersModel?.data[index].}");
//       // // //1

//       // List<MyOrdersModel> updatedListForHome =
//       //     List.from(homeController.myorderList);
//       // // updatedListForHome.addAll(MyOrders)
//       // //2
//       // updatedListForHome.addAll(_myOrdersModel?.data!.myorderList ?? []);
//       // // updatedListForHome.addAll(_myOrdersModel?.data?.o ?? []);
//       // //3

//       // // homeController.tokenPlanList.assignAll(updatedListForHome);
//       // homeController.myorderList.assignAll(updatedListForHome.length);
//       // logData(
//       //     message: "goalList For home: ${homeController.myorderList.length}");
//       // Network().validateResponse(
//       //   response: _response,
//       //   onSuccess: _onSuccess,
//       //   isToast: false,
//       // );
//     } catch (error, stackTrace) {
//       print("Error in _validateResponse: $error");
//       print("Stack Trace: $stackTrace");
//     }
//   }
// }

  void _validateResponse() {
    var homeController = Getx.Get.find<SettingsController>();

    try {
      _myOrdersModel = OrderHistoryModel.fromJson(_response?.data);
      // logData(message: "_getGoalModel: ${_myOrdersModel?.data");
      //1

      List<HistoryData> updatedListForHome =
          List<HistoryData>.from(homeController.myorderList);
      //2
      updatedListForHome.addAll(_myOrdersModel?.data ?? []);
      //3
      homeController.myorderList.assignAll(updatedListForHome);
      logData(
          message: "goalList For home: ${homeController.myorderList.length}");
      Network().validateResponse(
        response: _response,
        onSuccess: _onSuccess,
        isToast: false,
      );
    } catch (error, stackTrace) {
      print("Error in _validateResponse: $error");
      print("Stack Trace: $stackTrace");
    }
  }
}
