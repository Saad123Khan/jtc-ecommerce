import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as Getx;
import 'package:get/get_core/src/get_main.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/settings/controllers/settings_controller.dart';
import 'package:jtc_ecommerce/settings/models/buy_jtc_token_plan_model.dart';
import 'package:jtc_ecommerce/settings/models/coupon_model.dart';
import 'package:jtc_ecommerce/settings/models/notification_model.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';

class NotificationListBloc {
  Map<String, dynamic>? _queryParameters;
  Response? _response;
  VoidCallback? _onSuccess;
  dynamic contentTypeResponse;
  NotificationModel? _couponModel;

  int _page = 1;
  int _pageSize = 10;

  Future<void> notificationListBlocMethod({
    required BuildContext context,
    int page = 1,
    int pageSize = 10,
  }) async {
    _queryParameters = {
      'page': page.toString(),
      'page_size': pageSize.toString(),
    };

    await _getRequest(
      endPoint: NetworkStrings.NOTIFICATION_ENDPOINT,
      context: context,
    );

    _onSuccess = () {
      contentTypeResponse = _response?.data;
    };

    _validateResponse();
  }

  Future<void> _getRequest({
    required String endPoint,
    required BuildContext context,
  }) async {
    _response = await Network().getRequest(
      context: context,
      endPoint: endPoint,
      queryParameters: _queryParameters,
      isToast: false,
      isHeaderRequire: true,
    );
  }

  void _validateResponse() {
    var homeController = Get.find<SettingsController>();

    try {
      _couponModel = NotificationModel.fromJson(_response?.data);
      List<NotificationList> updatedListForHome =
          List<NotificationList>.from(homeController.notificationList);
      updatedListForHome.addAll(_couponModel?.data.notifications ?? []);
      homeController.notificationList.assignAll(updatedListForHome);
      // Network().validateResponse(
      //   response: _response,
      //   onSuccess: _onSuccess,
      //   isToast: false,
      // );
    } catch (error, stackTrace) {
      print("Error in _validateResponse: $error");
      print("Stack Trace: $stackTrace");
    }
  }
}
