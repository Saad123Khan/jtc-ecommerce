import 'dart:developer';
import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/services/stripe_service.dart';
import 'package:jtc_ecommerce/settings/controllers/settings_controller.dart';
import 'package:jtc_ecommerce/settings/models/buy_jtc_token_model.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';
import 'package:get/get.dart' as Getx;

class BuyJtcTokenBloc {
  // dynamic _formData;
  Map<String, dynamic>? _formMapData;
  Response? _response;
  VoidCallback? _onSuccess, _onFailure;
  BuyJtcTokenModel? _buyJtcTokenModel;

  void saveAddress({
    required BuildContext context,
    required VoidCallback setProgressBar,
    String? cardNumber,
    int? expMonth,
    int? expYear,
    String? cvc,
    String? jtcTokenId,
  }) async {
    setProgressBar();

    // int expMonth =
    //     int.parse(expMonth.toString().split('/').first);
    // int expYear = int.parse(controller.expiry_controller.text.split('/').last);

    //Stripe
    final cardToken = await StripeService.stripeToken(
      cardNumber: cardNumber,
      expMonth: expMonth,
      expYear: expYear,
      cvc: cvc,
    );
    if (cardToken != null) {
      _onFailure = () {
        Navigator.pop(context);
      };

      _formMapData = {
        "token_id": jtcTokenId,
        'token': cardToken,
      };

      log(_formMapData.toString());

      await _postRequest(
        endPoint: NetworkStrings.BUY_JTC_TOKEN_ENDPOINT,
        context: context,
      );

      _onSuccess = () {
        Navigator.pop(context);
        _validateAddresses(context);
      };

      _validateResponse();
    } else {
      Navigator.pop(context);
    }
  }

  /// Post Request
  Future<void> _postRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().postRequestRawData(
      endPoint: endPoint,
      body: _formMapData,
      context: context,
      onFailure: _onFailure,
      isHeaderRequire: true,
      isToast: false,
    );
  }

  /// Validate Response
  void _validateResponse() {
    if (_response != null) {
      Network().validateResponse(
        response: _response,
        onSuccess: _onSuccess,
        onFailure: _onFailure,
        isToast: false,
      );
    }
  }

  _validateAddresses(BuildContext context) {
    var controller = Getx.Get.find<SettingsController>();
    try {
      _buyJtcTokenModel = BuyJtcTokenModel.fromJson(_response?.data);
      logData(message: "_buyJtcTokenModel: ${_buyJtcTokenModel?.data}");
      AppNavigation.navigatorPop(context);
      AppDialogs.showBottomSheetttttt(
        context: context,
        showButton: false,
        image: "assets/images/coinbasket.png",
        firstHeading: tr('thank_you_text'),
        secondHeading: tr('hurrah_u_have'),
        thirdHeading: tr('bought_jtc_token'),
      );
      controller.account_holder_controller.text = "";
      controller.account_number_controller.text = "";
      controller.expiry_controller.text = "";
      controller.cvc_controller.text = "";
      // Getx.Get.find<PaymentController>().clearTextControllers();
      // Getx.Get.find<PaymentController>().getAllCardList();
    } catch (e) {
      AppDialogs.showToast(message: tr(NetworkStrings.SOMETHING_WENT_WRONG));
    }
  }
}
