import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/src/extension_instance.dart';
import 'package:jtc_ecommerce/services/auth_singleton.dart';
import 'package:jtc_ecommerce/services/local_storage.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/splash/controllers/splash_controller.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';
import 'package:jtc_ecommerce/utils/enums.dart';

class logoutBloc {
  Response? _response;
  VoidCallback? _onSuccess, _onFailure;
  FormData? _formData;
  void logoutBlocMethod({
    required BuildContext context,
   required VoidCallback? setProgressBar,
  }) async {
    setProgressBar?.call();

    _onFailure = () {
      AppNavigation.navigatorPop(context);
    };

    _formData = FormData.fromMap({
      "user_id": Get.find<SplashController>().currentUser.value?.id,
    });

    await _postRequest(
      endPoint: NetworkStrings.LOGOUT_OTP_ENDPOINT,
      context: context,
    );

    _onSuccess = () {
      _logoutResponseMethod(context: context);
    };

    _validateResponse(context: context);
  }

  //! ============> Post Request
  Future<void> _postRequest({
    required String endPoint,
    required BuildContext context,
  }) async {
    _response = await Network().postRequest(
      endPoint: endPoint,
      context: context,
      formData: _formData,
      onFailure: _onFailure,
      isHeaderRequire: true,
    );
  }

  void _validateResponse({required BuildContext context}) {
    if (_response != null) {
      Network().validateResponse(
          response: _response,
          onSuccess: _onSuccess,
          onFailure: _onFailure,
          isToast: false);
      if (_response?.statusMessage == "OK") {
        String? currentLanguage = SharedPreference().getLanguage();

        AppNavigation.navigateToRemovingAll(
          context,
          AppRouteName.LOGIN_SCREEN_ROUTE,
        );

        authSingletonUserRole.userLoggedInUsingEmail = "";
        authSingletonUserRole.userLoggedInUsingPhone = "";
        authSingletonUserRole.countryCode = "";
        authSingletonUserRole.countryNumCode = "";
        authSingletonUserRole.switchValue = SwitchValue.none;
        SharedPreference().clear(); 

        if (currentLanguage != null) {
          SharedPreference().setLanguage(languageCode: currentLanguage);
        }
// Show the logout success message
        AppDialogs.showToast(message: tr('logout_msg'));
      }
      print("data is _signOutResponseMethod" + _response.toString());
      print(
          "data is _signOutResponseMethod" + _response!.statusCode.toString());
    }
  }

  final AuthSingletonUserRole authSingletonUserRole = AuthSingletonUserRole();

  //! ============> Logout Response
  void _logoutResponseMethod({required BuildContext context}) {
    try {} catch (error) {
      AppDialogs.showToast(message: tr(NetworkStrings.SOMETHING_WENT_WRONG));
    }
  }
}
