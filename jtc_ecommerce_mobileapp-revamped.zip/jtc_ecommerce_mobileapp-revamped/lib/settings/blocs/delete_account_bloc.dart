import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as GETX;
import 'package:jtc_ecommerce/services/auth_singleton.dart';
import 'package:jtc_ecommerce/services/local_storage.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/services/translate_service.dart';
import 'package:jtc_ecommerce/splash/controllers/splash_controller.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';
import 'package:jtc_ecommerce/utils/enums.dart';

class DeleteAccountBLOC {
  Response? _response;
  VoidCallback? _onSuccess, _onFailure;
  FormData? _formData;
  void deleteAccount( 
      {required BuildContext context,
      required VoidCallback? setProgressBar, 
      required String password}) async { 
    setProgressBar?.call();

    _onFailure = () async {
      AppNavigation.navigatorPop(context);

      print("STATUSSS CODEE ${_response?.statusCode}");
      final message = _response?.data['message'] ?? "";

      print(message);

      switch (message) {
        case "Invalid Email or Password":
          AppDialogs.showToast(
              message: tr(NetworkStrings.INVALID_EMAIL_OR_PASSWORD));
          break;

        default:
          if (context.locale.languageCode != "en") {
            final _translatedMessage = await GoogleTranslatorService()
                .translate(text: message, context: context);
            AppDialogs.showToast(message: _translatedMessage);
          } else {
            AppDialogs.showToast(message: message);
          }
      }
    };

    _formData = FormData.fromMap({
      "email": GETX.Get.find<SplashController>().currentUser.value?.email,
      "password": password
    });

    await _postRequest(
      endPoint: NetworkStrings.DELETE_ACCOUNT_ENDPOINT,
      context: context,
    );

    _onSuccess = () {
      _logoutResponseMethod(context: context);
    };

    _validateResponse(context: context);
  }

  //! ============> Post Request
  Future<void> _postRequest({
    required String endPoint,
    required BuildContext context,
  }) async {
    _response = await Network().postRequest(
      endPoint: endPoint,
    
      context: context,
      formData: _formData,
      customFailure: true,
      onFailure: _onFailure,
      isHeaderRequire: true,
    );
  }

  void _validateResponse({required BuildContext context}) {
    if (_response != null) {
      Network().validateResponse(
          response: _response,
          onSuccess: _onSuccess,
          onFailure: _onFailure,
          isToast: false);
      if (_response?.statusCode == 200) {
        String? currentLanguage = SharedPreference().getLanguage();

        AppNavigation.navigateToRemovingAll(
          context,
          AppRouteName.LOGIN_SCREEN_ROUTE,
        );

        authSingletonUserRole.userLoggedInUsingEmail = "";
        authSingletonUserRole.userLoggedInUsingPhone = "";
        authSingletonUserRole.countryCode = "";
        authSingletonUserRole.countryNumCode = "";
        authSingletonUserRole.switchValue = SwitchValue.none;
        SharedPreference().clear();
        GETX.Get.find<SplashController>().currentUser.value = null;

        if (currentLanguage != null) {
          SharedPreference().setLanguage(languageCode: currentLanguage);
        }
        AppDialogs.showToast(message: tr('account_deleted_success'));
      }
      print("data is _signOutResponseMethod" + _response.toString());
      print(
          "data is _signOutResponseMethod" + _response!.statusCode.toString());
    }
  }

  final AuthSingletonUserRole authSingletonUserRole = AuthSingletonUserRole();

  //! ============> Logout Response
  void _logoutResponseMethod({required BuildContext context}) {
    try {} catch (error) {
      AppDialogs.showToast(message: tr(NetworkStrings.SOMETHING_WENT_WRONG));
    }
  }
}
