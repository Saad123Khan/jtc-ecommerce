import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as GetxController;
import 'package:jtc_ecommerce/services/firebase_messaging_service.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/services/translate_service.dart';
import 'package:jtc_ecommerce/settings/controllers/settings_controller.dart';
import 'package:jtc_ecommerce/splash/controllers/splash_controller.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';

class ChangePasswordBloc {
  FormData? _formData;
  Response? _response;
  VoidCallback? _onSuccess, _onFailure;
  String? deviceToken;

  void changePasswordBlocMethod({
    required BuildContext context,
    required VoidCallback setProgressBar,
    String? current_password,
    String? new_password,
    String? confirm_new_password,
  }) async {
    setProgressBar();

    //! ============> Get the device token from firebaseservice class
    deviceToken = await FirebaseMessagingService().getToken();

    //! ============> Form Data
    _formData = FormData.fromMap({
      "email":
          GetxController.Get.find<SplashController>().currentUser.value?.email,
      "current_password": current_password,
      "new_password": new_password,
      "confirm_password": confirm_new_password,
    });

    //! ============> Print Form Data
    print({
      "email":
          GetxController.Get.find<SplashController>().currentUser.value?.email,
      "current_password": current_password,
      "new_password": new_password,
      "confirm_password": confirm_new_password,
    });

    //! ============> If Api fails then stop the loader
    _onFailure = () async {
      AppNavigation.navigatorPop(context);
      print("STATUSSS CODEE ${_response?.statusCode}");
      final message = _response?.data['message'] ?? "";

      print(message);

      switch (message) {
        case "Your Current Password":
          AppDialogs.showToast(
              message: tr(NetworkStrings.INVALID_EMAIL_OR_PASSWORD));
          break;

        default:
          if (context.locale.languageCode != "en") {
            final _translatedMessage = await GoogleTranslatorService()
                .translate(text: message, context: context);
            AppDialogs.showToast(message: _translatedMessage);
          } else {
            AppDialogs.showToast(message: message);
          }
      }
    };

    //! ============> Call api
    await _postRequest(
      endPoint: NetworkStrings.CHANGE_PASSWORD_ENDPOINT,
      context: GetxController.Get.context!,
    );

    //! ============> Get the login response
    _onSuccess = () {
      AppNavigation.navigatorPop(context);
      _loginResponseMethod(context: context);
    };

    //! ============> Validate the response
    _validateResponse();
  }

  //! ============> Post Request
  Future<void> _postRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().postRequest(
      endPoint: endPoint,
      formData: _formData,
      context: context,
      onFailure: _onFailure,
      customFailure: true,
      isHeaderRequire: true,
      isToast: true,
    );
  }

  //! ============> Validate Response
  void _validateResponse() {
    if (_response != null) {
      Network().validateResponse(
        isToast: false,
        response: _response,
        onSuccess: _onSuccess,
        onFailure: _onFailure,
      );
    }
  }

  //! ============> Login Response
  void _loginResponseMethod(
      {required BuildContext context, String? userEmail}) async {
    try {
      if (_response?.statusCode == 200) {
        GetxController.Get.find<SettingsController>().current_password.clear();
        GetxController.Get.find<SettingsController>()
            .new_password_reset
            .clear();
        GetxController.Get.find<SettingsController>()
            .confirm_new_password_rest
            .clear();
        GetxController.Get.find<SettingsController>()
            .confirm_new_password
            .clear();
        GetxController.Get.find<SettingsController>().new_password.clear();
        AppNavigation.navigateToRemovingAll(
            context, AppRouteName.BOTTOM_NAVIGATION_SCREEN_ROUTE);
        final message = _response?.data['message'];

        if (context.locale.languageCode != "en") {
          final _translatedMessage = await GoogleTranslatorService()
              .translate(text: message, context: context);
          AppDialogs.showToast(message: _translatedMessage);
        } else {
          AppDialogs.showToast(message: message);
        }
      }
    } catch (error) {
      AppDialogs.showToast(message: tr(NetworkStrings.SOMETHING_WENT_WRONG));
    }
  }
}
