import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as Getx;
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/settings/controllers/settings_controller.dart';
import 'package:jtc_ecommerce/settings/models/buy_jtc_token_plan_model.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';

class BuyJTCTokenBloc {
  Map<String, dynamic>? _queryParameters;
  Response? _response;
  VoidCallback? _onSuccess;
  dynamic contentTypeResponse;
  // GetProductByCategoryModel? _getProductByCategoryModel;
  JtcTokenPlanModel? _jtcTokenPlanModel;

  ////////////////////////// Terms and Condition And Privacy Policy //////////////////////////////////
  Future<void> getBuyJTCTokenBlocMethod({
    required BuildContext context,
  }) async {
    await _getRequest(
      endPoint: NetworkStrings.JTC_TOKEN_ENDPOINT,
      context: context,
    );

    _onSuccess = () {
      contentTypeResponse = _response?.data;
    };

    _validateResponse();

    return contentTypeResponse;
  }

  // Get Request
  Future<void> _getRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().getRequest(
      context: context,
      endPoint: endPoint,
      queryParameters: _queryParameters,
      isToast: false,
      isHeaderRequire: true,
    );
  }

  void _validateResponse() {
    var homeController = Getx.Get.find<SettingsController>();

    try {
      _jtcTokenPlanModel = JtcTokenPlanModel.fromJson(_response?.data);
      logData(
          message: "_getGoalModel: ${_jtcTokenPlanModel?.data?.tokenPlanList}");
      //1

      List<TokenPlanList> updatedListForHome =
          List.from(homeController.tokenPlanList);
      //2
      updatedListForHome.addAll(_jtcTokenPlanModel?.data?.tokenPlanList ?? []);
      //3
      homeController.tokenPlanList.assignAll(updatedListForHome);
      logData(
          message: "goalList For home: ${homeController.tokenPlanList.length}");
      Network().validateResponse(
        response: _response,
        onSuccess: _onSuccess,
        isToast: false,
      );
    } catch (error, stackTrace) {
      print("Error in _validateResponse: $error");
      print("Stack Trace: $stackTrace");
    }
  }
}
