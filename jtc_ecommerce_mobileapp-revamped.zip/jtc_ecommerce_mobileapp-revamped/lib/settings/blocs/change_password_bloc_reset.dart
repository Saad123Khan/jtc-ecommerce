import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart' as GetxController;
import 'package:jtc_ecommerce/auth/models/send_password_model.dart';
import 'package:jtc_ecommerce/auth/models/user_model.dart';
import 'package:jtc_ecommerce/services/firebase_messaging_service.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/splash/controllers/splash_controller.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';

class ChangePasswordResetBloc {
  FormData? _formData;
  Response? _response;
  VoidCallback? _onSuccess, _onFailure;
  String? deviceToken;
  SendPasswordModel? _sendPasswordModel;

  void changePasswordBlocMethod({
    required BuildContext context,
    required VoidCallback setProgressBar,
    // String? current_password,
    String? new_password,
    required String email,
    String? confirm_new_password,
  }) async {
    setProgressBar();

    //! ============> Get the device token from firebaseservice class
    deviceToken = await FirebaseMessagingService().getToken();

    //! ============> Form Data
    _formData = FormData.fromMap({
      "email": email,
      // GetxController.Get.find<SplashController>().currentUser.value?.email,
      // "current_password": current_password,
      "password": new_password,
      "password_confirmation": confirm_new_password,
    });

    //! ============> Print Form Data
    print({
      "email": email,
      // GetxController.Get.find<SplashController>().currentUser.value?.email,
      // "current_password": current_password,
      "password": new_password,
      "password_confirmation": confirm_new_password,
    });

    //! ============> If Api fails then stop the loader
    _onFailure = () {
      AppNavigation.navigatorPop(context);
    };

    //! ============> Call api
    await _postRequest(
      endPoint: NetworkStrings.CHANGE_PASSWORD_RESET_ENDPOINT,
      context: GetxController.Get.context!,
    );

    //! ============> Get the login response
    _onSuccess = () {
      AppNavigation.navigatorPop(context);
      _loginResponseMethod(context: context);
    };

    //! ============> Validate the response
    _validateResponse();
  }

  //! ============> Post Request
  Future<void> _postRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().postRequest(
      endPoint: endPoint,
      formData: _formData,
      context: context,
      onFailure: _onFailure,
      isHeaderRequire: true,
      isToast: true,
    );
  }

  //! ============> Validate Response
  void _validateResponse() {
    if (_response != null) {
      Network().validateResponse(
        isToast: false,
        response: _response,
        onSuccess: _onSuccess,
        onFailure: _onFailure,
      );
    }
  }

  //! ============> Login Response
  void _loginResponseMethod({required BuildContext context}) async {
    try {
      // AppNavigation.navigatorPop(context);
      // if (_response != null) {
      //   // _response.clearTextFieldsLogin();
      //   AppDialogs.showToast(
      //     message: _response!.statusMessage,
      //     toastLength: Toast.LENGTH_LONG,
      //     timeInSecForIosWeb: 5,
      //   );
      // authContorller.when_user_verified.value = true;
      // //! ============> Navigating the user from login to verfication otp screen
      // AppDialogs.showBottomSheetttttt(
      //   context: context,
      //   onTap: () {
      // AppNavigation.navigateToRemovingAll(
      //   context,
      //   AppRouteName.LOGIN_SCREEN_ROUTE,
      // );
      //   },
      // );
      // }
      _sendPasswordModel = SendPasswordModel.fromJson(_response?.data);
      if (_sendPasswordModel != null) {
        print(_sendPasswordModel?.message);
        // AppDialogs.showToast(message: _sendPasswordModel?.message);
        // authContorller.show_pinfield.value = true;

        if (_sendPasswordModel?.message == 'Password reset successfully') {
          AppDialogs.showToast(message: tr('password_Reset_Succesfully_text'));
        } else {
          AppDialogs.showToast(message: _sendPasswordModel?.message);
        }
      }

      //! ============> Navigating the user from send email  to verfication otp screen
      AppNavigation.navigateToRemovingAll(
        context,
        AppRouteName.LOGIN_SCREEN_ROUTE,
      );
    } catch (error) {
      AppDialogs.showToast(message: tr(NetworkStrings.SOMETHING_WENT_WRONG));
    }
  }
}
