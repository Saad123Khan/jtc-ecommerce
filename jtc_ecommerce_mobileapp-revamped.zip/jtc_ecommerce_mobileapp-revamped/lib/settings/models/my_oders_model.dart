import 'package:jtc_ecommerce/home/models/single_product_model.dart';

class OrderHistoryModel {
  bool? status;
  List<HistoryData>? data;

  OrderHistoryModel({this.status, this.data});

  OrderHistoryModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['data'] != null) {
      data = <HistoryData>[];
      json['data'].forEach((v) {
        data!.add(new HistoryData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class HistoryData {
  int? id;
  String? date;
  int? isReturn;
  int? isAccept;
  dynamic acceptTimer;
  int? customerId;
  int? warehouseId;
  dynamic taxRate;
  String? orderType;
  String? orderThrough;
  dynamic taxAmount;
  dynamic discount;
  double shipping = 0.0;
  double grandTotal = 0.0;
  dynamic receivedAmount;
  dynamic paidAmount;
  dynamic paymentType;
  String? type;
  dynamic note;
  String? referenceCode;
  String? createdAt;
  String? updatedAt;
  int? status;
  int? paymentStatus;
  String? address;
  String? latitude;
  String? longitude;
  String? customerInstruction;
  int? ecommerceUserId;
  dynamic riderId;
  String? deliveryMode;
  String? orderStatus;
  String? paymentId;
  String? endTime;
  String? startTime;
  dynamic riderStartLat;
  dynamic riderStartLong;
  dynamic riderEndLat;
  dynamic riderEndLong;
  dynamic riderEarn;
  dynamic riderKmComplete;
  String? nearestAddress;
  String? nearestFlatno;
  dynamic tableNumber;
  dynamic rideStartTime;
  dynamic rideEndTime;
  String? price;
  String? priceToken;
  String? taxToken;

  String? grandtotalToken;
  String? cartId;
  String? couponCode;
  String? maxMakingTime;
  String? message;
  String? nearestFlatNo;
  String? tax;
  String? distance;
  List<SaleItemsId>? saleItemsId;
  List<Cart>? cart;

  HistoryData(
      {this.id,
      this.date,
      this.isReturn,
      this.isAccept,
      this.acceptTimer,
      this.customerId,
      this.warehouseId,
      this.taxRate,
      this.orderType,
      this.orderThrough,
      this.taxAmount,
      this.discount,
      this.shipping = 0.0,
      this.grandTotal = 0.0,
      this.receivedAmount,
      this.paidAmount,
      this.paymentType,
      this.note,
      this.referenceCode,
      this.createdAt,
      this.updatedAt,
      this.status,
      this.paymentStatus,
      this.address,
      this.latitude,
      this.longitude,
      this.customerInstruction,
      this.ecommerceUserId,
      this.type,
      this.riderId,
      this.deliveryMode,
      this.orderStatus,
      this.paymentId,
      this.endTime,
      this.startTime,
      this.riderStartLat,
      this.riderStartLong,
      this.riderEndLat,
      this.riderEndLong,
      this.riderEarn,
      this.riderKmComplete,
      this.nearestAddress,
      this.nearestFlatno,
      this.tableNumber,
      this.rideStartTime,
      this.rideEndTime,
      this.price,
      this.priceToken,
      this.taxToken,
      this.grandtotalToken,
      this.cartId,
      this.couponCode,
      this.maxMakingTime,
      this.message,
      this.nearestFlatNo,
      this.tax,
      this.distance,
      this.saleItemsId,
      this.cart});

  HistoryData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    date = json['date'];
    isReturn = json['is_return'];
    isAccept = json['is_accept'];
    acceptTimer = json['accept_timer'];
    customerId = json['customer_id'];
    warehouseId = json['warehouse_id'];
    taxRate = json['tax_rate'];
    orderType = json['order_type'];
    orderThrough = json['order_through'];
    type = json['type'] ?? "";
    taxAmount = json['tax_amount'];
    discount = json['discount'];
    shipping = json['shipping'] != null ? double.parse(json['shipping'].toString()) :0.0;
    grandTotal = json['grand_total'] != null
        ? double.tryParse(json['grand_total'].toString()) ?? 0.0
        : 0.0;
    receivedAmount = json['received_amount'];
    paidAmount = json['paid_amount'];
    paymentType = json['payment_type'];
    note = json['note'];
    referenceCode = json['reference_code'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    status = json['status'];
    paymentStatus = json['payment_status'];
    address = json['address'];
    latitude = json['latitude'];
    longitude = json['longitude'];
    customerInstruction = json['customer_instruction'];
    ecommerceUserId = json['ecommerce_user_id'];
    riderId = json['rider_id'];
    deliveryMode = json['delivery_mode'];
    orderStatus = json['order_status'];
    paymentId = json['payment_id'];
    endTime = json['end_time'];
    startTime = json['start_time'];
    riderStartLat = json['rider_start_lat'];
    riderStartLong = json['rider_start_long'];
    riderEndLat = json['rider_end_lat'];
    riderEndLong = json['rider_end_long'];
    riderEarn = json['rider_earn'];
    riderKmComplete = json['rider_km_complete'];
    nearestAddress = json['nearest_address'];
    nearestFlatno = json['nearest_flatno'];
    tableNumber = json['table_number'];
    rideStartTime = json['ride_start_time'];
    rideEndTime = json['ride_end_time'];
    price = json['price'];
    priceToken = json['priceToken'];
    taxToken = json['taxToken'];
    grandTotal = json['grand_total'] != null
        ? double.parse(json['grand_total'].toString())
        : 0.0;
    grandtotalToken = json['grandtotalToken'];
    cartId = json['cartId'];
    // orderType = json['orderType'];
    couponCode = json['coupon_code'];
    maxMakingTime = json['max_making_time'];
    message = json['message'];
    nearestFlatNo = json['nearest_flat_no'];
    tax = json['tax'];
    distance = json['distance'];
    if (json['sale_items_id'] != null) {
      saleItemsId = <SaleItemsId>[];
      json['sale_items_id'].forEach((v) {
        saleItemsId!.add(new SaleItemsId.fromJson(v));
      });
    }
    if (json['cart'] != null) {
      cart = <Cart>[];
      json['cart'].forEach((v) {
        cart!.add(new Cart.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['date'] = this.date;
    data['is_return'] = this.isReturn;
    data['is_accept'] = this.isAccept;
    data['accept_timer'] = this.acceptTimer;
    data['customer_id'] = this.customerId;
    data['warehouse_id'] = this.warehouseId;
    data['tax_rate'] = this.taxRate;
    data['order_type'] = this.orderType;
    data['order_through'] = this.orderThrough;
    data['tax_amount'] = this.taxAmount;
    data['discount'] = this.discount;
    data['shipping'] = this.shipping;
    data['grand_total'] = this.grandTotal;
    data['received_amount'] = this.receivedAmount;
    data['paid_amount'] = this.paidAmount;
    data['payment_type'] = this.paymentType;
    data['note'] = this.note;
    data['reference_code'] = this.referenceCode;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['status'] = this.status;
    data['payment_status'] = this.paymentStatus;
    data['address'] = this.address;
    data['latitude'] = this.latitude;
    data['longitude'] = this.longitude;
    data['customer_instruction'] = this.customerInstruction;
    data['ecommerce_user_id'] = this.ecommerceUserId;
    data['rider_id'] = this.riderId;
    data['delivery_mode'] = this.deliveryMode;
    data['order_status'] = this.orderStatus;
    data['payment_id'] = this.paymentId;
    data['end_time'] = this.endTime;
    data['start_time'] = this.startTime;
    data['rider_start_lat'] = this.riderStartLat;
    data['rider_start_long'] = this.riderStartLong;
    data['rider_end_lat'] = this.riderEndLat;
    data['rider_end_long'] = this.riderEndLong;
    data['rider_earn'] = this.riderEarn;
    data['rider_km_complete'] = this.riderKmComplete;
    data['nearest_address'] = this.nearestAddress;
    data['nearest_flatno'] = this.nearestFlatno;
    data['table_number'] = this.tableNumber;
    data['ride_start_time'] = this.rideStartTime;
    data['ride_end_time'] = this.rideEndTime;
    data['price'] = this.price;
    data['priceToken'] = this.priceToken;
    data['taxToken'] = this.taxToken;
    data['grandTotal'] = this.grandTotal;
    data['grandtotalToken'] = this.grandtotalToken;
    data['cartId'] = this.cartId;
    data['orderType'] = this.orderType;
    data['coupon_code'] = this.couponCode;
    data['max_making_time'] = this.maxMakingTime;
    data['message'] = this.message;
    data['nearest_flat_no'] = this.nearestFlatNo;
    data['tax'] = this.tax;
    data['distance'] = this.distance;
    if (this.saleItemsId != null) {
      data['sale_items_id'] = this.saleItemsId!.map((v) => v.toJson()).toList();
    }
    if (this.cart != null) {
      data['cart'] = this.cart!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class SaleItemsId {
  int? id;
  int? saleId;
  int? productId;
  double? productPrice;
  dynamic netUnitPrice;
  String? productVariation;
  dynamic taxType;
  dynamic taxValue;
  double? taxAmount;
  dynamic addonsValue;
  double? addonsPrice;
  dynamic addonsValueJson;
  dynamic discountType;
  dynamic discountValue;
  dynamic discountAmount;
  SaleUnit? saleUnit;
  int? quantity;
  double? subTotal;
  String? createdAt;
  String? updatedAt;
  String? notes;
  int? status;
  dynamic startTime;
  dynamic endTime;
  String? maxTime;
  List<SaleItemAddons>? saleItemAddons;
  SingleProductModel? product;

  SaleItemsId(
      {this.id,
      this.saleId,
      this.productId,
      this.productPrice,
      this.netUnitPrice,
      this.taxType,
      this.taxValue,
      this.taxAmount,
      this.addonsValue,
      this.addonsPrice,
      this.addonsValueJson,
      this.discountType,
      this.discountValue,
      this.discountAmount,
      this.saleUnit,
      this.quantity,
      this.productVariation,
      this.subTotal,
      this.createdAt,
      this.updatedAt,
      this.notes,
      this.status,
      this.startTime,
      this.endTime,
      this.maxTime,
      this.saleItemAddons,
      this.product});

  SaleItemsId.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    saleId = json['sale_id'];
    productId = json['product_id'];
    productPrice = json['product_price'] != null
        ? double.parse(json['product_price'].toString())
        : 0.0;
    // netUnitPrice = json['net_unit_price'];
    taxType = json['tax_type'];
    productVariation = json['product_variation'];
    taxValue = json['tax_value'];
    taxAmount = json['tax_amount'] != null
        ? double.parse(json['tax_amount'].toString())
        : 0.0;
    addonsValue = json['addons_value'];
    addonsPrice = json['addons_price'] != null
        ? double.parse(json['addons_price'].toString())
        : 0.0;
    addonsValueJson = json['addons_value_json'];
    discountType = json['discount_type'];
    discountValue = json['discount_value'];
    discountAmount = json['discount_amount'];
    saleUnit = json['sale_unit'] != null
        ? new SaleUnit.fromJson(json['sale_unit'])
        : null;
    quantity = json['quantity'];
    subTotal = json['sub_total'] != null
        ? double.parse(json['sub_total'].toString())
        : 0.0;
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    notes = json['notes'];
    status = json['status'];
    startTime = json['start_time'];
    endTime = json['end_time'];
    maxTime = json['max_time'];
    if (json['sale_item_addons'] != null) {
      saleItemAddons = <SaleItemAddons>[];
      json['sale_item_addons'].forEach((v) {
        saleItemAddons!.add(new SaleItemAddons.fromJson(v));
      });
    }
    product = json['product'] != null
        ? new SingleProductModel.fromJson(json['product'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['sale_id'] = this.saleId;
    data['product_id'] = this.productId;
    data['product_price'] = this.productPrice;
    data['net_unit_price'] = this.netUnitPrice;
    data['tax_type'] = this.taxType;
    data['tax_value'] = this.taxValue;
    data['tax_amount'] = this.taxAmount;
    data['addons_value'] = this.addonsValue;
    data['addons_price'] = this.addonsPrice;
    data['addons_value_json'] = this.addonsValueJson;
    data['discount_type'] = this.discountType;
    data['product_variation'] = this.productVariation;
    data['discount_value'] = this.discountValue;
    data['discount_amount'] = this.discountAmount;
    if (this.saleUnit != null) {
      data['sale_unit'] = this.saleUnit!.toJson();
    }
    data['quantity'] = this.quantity;
    data['sub_total'] = this.subTotal;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['notes'] = this.notes;
    data['status'] = this.status;
    data['start_time'] = this.startTime;
    data['end_time'] = this.endTime;
    data['max_time'] = this.maxTime;
    if (this.saleItemAddons != null) {
      data['sale_item_addons'] =
          this.saleItemAddons!.map((v) => v.toJson()).toList();
    }
    if (this.product != null) {
      data['product'] = this.product!.toJson();
    }
    return data;
  }
}

class SaleUnit {
  int? id;
  String? name;
  String? shortName;
  int? baseUnit;
  String? createdAt;
  String? updatedAt;

  SaleUnit(
      {this.id,
      this.name,
      this.shortName,
      this.baseUnit,
      this.createdAt,
      this.updatedAt});

  SaleUnit.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    shortName = json['short_name'];
    baseUnit = json['base_unit'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['short_name'] = this.shortName;
    data['base_unit'] = this.baseUnit;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}

class SaleItemAddons {
  int? id;
  int? saleItemId;
  String? name;
  String? value;
  int? quantity;
  dynamic price;
  int? isCoins;
  String? createdAt;
  String? updatedAt;

  SaleItemAddons(
      {this.id,
      this.saleItemId,
      this.name,
      this.value,
      this.quantity,
      this.price,
      this.isCoins,
      this.createdAt,
      this.updatedAt});

  SaleItemAddons.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    saleItemId = json['sale_item_id'];
    name = json['name'];
    value = json['value'];
    quantity = json['quantity'];
    price = json['price'];
    isCoins = json['is_coins'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['sale_item_id'] = this.saleItemId;
    data['name'] = this.name;
    data['value'] = this.value;
    data['quantity'] = this.quantity;
    data['price'] = this.price;
    data['is_coins'] = this.isCoins;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}

class Cart {
  int? id;
  int? productId;
  int? userId;
  int? quantity;
  String? addonItemsId;
  String? createdAt;
  String? updatedAt;
  int? deletedAt;
  dynamic message;
  String? addonId;
  String? productVariation;
  dynamic couponCode;
  dynamic discountToken;

  Cart(
      {this.id,
      this.productId,
      this.userId,
      this.quantity,
      this.addonItemsId,
      this.createdAt,
      this.updatedAt,
      this.deletedAt,
      this.message,
      this.addonId,
      this.productVariation,
      this.couponCode,
      this.discountToken});

  Cart.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    productId = json['product_id'];
    userId = json['user_id'];
    quantity = json['quantity'];
    addonItemsId = json['addon_items_id'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    deletedAt = json['deleted_at'];
    message = json['message'];
    addonId = json['addon_id'];
    productVariation = json['product_variation'];
    couponCode = json['coupon_code'];
    discountToken = json['discount_token'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['product_id'] = this.productId;
    data['user_id'] = this.userId;
    data['quantity'] = this.quantity;
    data['addon_items_id'] = this.addonItemsId;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['deleted_at'] = this.deletedAt;
    data['message'] = this.message;
    data['addon_id'] = this.addonId;
    data['product_variation'] = this.productVariation;
    data['coupon_code'] = this.couponCode;
    data['discount_token'] = this.discountToken;
    return data;
  }
}
