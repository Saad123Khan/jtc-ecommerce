// To parse this JSON data, do
//
//     final buyJtcTokenModel = buyJtcTokenModelFromJson(jsonString);

import 'dart:convert';

BuyJtcTokenModel buyJtcTokenModelFromJson(String str) =>
    BuyJtcTokenModel.fromJson(json.decode(str));

String buyJtcTokenModelToJson(BuyJtcTokenModel data) =>
    json.encode(data.toJson());

class BuyJtcTokenModel {
  String? message;
  BuyJtcTokenData? data;
  bool? status;

  BuyJtcTokenModel({
    this.message,
    this.data,
    this.status,
  });

  factory BuyJtcTokenModel.fromJson(Map<String, dynamic> json) =>
      BuyJtcTokenModel(
        message: json["message"],
        data: json["data"] == null
            ? null
            : BuyJtcTokenData.fromJson(json["data"]),
        status: json["status"],
      );

  Map<String, dynamic> toJson() => {
        "message": message,
        "data": data?.toJson(),
        "status": status,
      };
}

class BuyJtcTokenData {
  String? id;
  int? jtcToken;

  BuyJtcTokenData({
    this.id,
    this.jtcToken,
  });

  factory BuyJtcTokenData.fromJson(Map<String, dynamic> json) =>
      BuyJtcTokenData(
        id: json["_id"],
        jtcToken: json["jtcToken"],
      );

  Map<String, dynamic> toJson() => {
        "_id": id,
        "jtcToken": jtcToken,
      };
}
