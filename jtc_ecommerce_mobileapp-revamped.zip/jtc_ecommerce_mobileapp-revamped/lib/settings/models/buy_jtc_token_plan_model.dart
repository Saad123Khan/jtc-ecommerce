// To parse this JSON data, do
//
//     final jtcTokenPlanModel = jtcTokenPlanModelFromJson(jsonString);

import 'dart:convert';

JtcTokenPlanModel jtcTokenPlanModelFromJson(String str) =>
    JtcTokenPlanModel.fromJson(json.decode(str));

String jtcTokenPlanModelToJson(JtcTokenPlanModel data) =>
    json.encode(data.toJson());

class JtcTokenPlanModel {
  bool? status;
  JtcTokenPlanModelData? data;
  String? message;

  JtcTokenPlanModel({
    this.status,
    this.data,
    this.message,
  });

  factory JtcTokenPlanModel.fromJson(Map<String, dynamic> json) =>
      JtcTokenPlanModel(
        status: json["status"],
        data: json["data"] == null
            ? null
            : JtcTokenPlanModelData.fromJson(json["data"]),
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "status": status,
        "data": data?.toJson(),
        "message": message,
      };
}

class JtcTokenPlanModelData {
  List<TokenPlanList>? tokenPlanList;

  JtcTokenPlanModelData({
    this.tokenPlanList,
  });

  factory JtcTokenPlanModelData.fromJson(Map<String, dynamic> json) =>
      JtcTokenPlanModelData(
        tokenPlanList: json["tokenPlanList"] == null
            ? []
            : List<TokenPlanList>.from(
                json["tokenPlanList"]!.map((x) => TokenPlanList.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "tokenPlanList": tokenPlanList == null
            ? []
            : List<dynamic>.from(tokenPlanList!.map((x) => x.toJson())),
      };
}

class TokenPlanList {
  int? id;
  String? name;
  String? nameEn;
  String? nameSp;
  String? discriprtionEn;
  String? discriprtionSp;
  int? tokens;
  String? amount;
  String? description;
  // DateTime? createdAt;
  // DateTime? updatedAt;

  TokenPlanList({
    this.id,
    this.name,
    this.tokens,
    this.amount,
    this.description,
    this.nameEn,
    this.nameSp,
    this.discriprtionEn,
    this.discriprtionSp,

    // this.createdAt,
    // this.updatedAt,
  });

  factory TokenPlanList.fromJson(Map<String, dynamic> json) => TokenPlanList(
        nameEn: json["name_en"],
        nameSp: json["name_sp"],
        discriprtionEn: json["description_en"],
        discriprtionSp: json["description_sp"],

        id: json["id"],
        name: json["name"],
        tokens: json["tokens"],
        amount: json["amount"],
        description: json["description"],
        // createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
        // updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
      );

  Map<String, dynamic> toJson() => {
        "nameEn": nameEn,
        "nameEn": nameEn,
        "discriprtionEn": discriprtionEn,
        "discriprtionSp": discriprtionSp,

        "id": id,
        "name": name,
        "tokens": tokens,
        "amount": amount,
        "description": description,
        // "created_at": createdAt?.toIso8601String(),
        // "updated_at": updatedAt?.toIso8601String(),
      };
}
