// To parse this JSON data, do
//
//     final notificationModel = notificationModelFromJson(jsonString);

import 'dart:convert';

NotificationModel notificationModelFromJson(String str) =>
    NotificationModel.fromJson(json.decode(str));

String notificationModelToJson(NotificationModel data) =>
    json.encode(data.toJson());

class NotificationModel {
  bool status;
  NotificationData data;
  String message;

  NotificationModel({
    required this.status,
    required this.data,
    required this.message,
  });

  factory NotificationModel.fromJson(Map<String, dynamic> json) =>
      NotificationModel(
        status: json["status"],
        data: NotificationData.fromJson(json["data"]),
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "status": status,
        "data": data.toJson(),
        "message": message,
      };
}

class NotificationData {
  List<NotificationList> notifications;
  Pagination pagination;

  NotificationData({
    required this.notifications,
    required this.pagination,
  });

  factory NotificationData.fromJson(Map<String, dynamic> json) =>
      NotificationData(
        notifications: List<NotificationList>.from(
            json["notifications"].map((x) => NotificationList.fromJson(x))),
        pagination: Pagination.fromJson(json["pagination"]),
      );

  Map<String, dynamic> toJson() => {
        "notifications":
            List<dynamic>.from(notifications.map((x) => x.toJson())),
        "pagination": pagination.toJson(),
      };
}

class NotificationList {
  dynamic id;
  dynamic userId;
  dynamic title;
  dynamic message;
  dynamic type;
  dynamic typeId;
  dynamic senderId;
  dynamic senderRole;
  dynamic isSeen;
  dynamic isRead;
  dynamic isAdminSeen;
  dynamic isAdminRead;
  dynamic userToken;
  DateTime createdAt;
  DateTime updatedAt;
  dynamic userType;
  dynamic sales;
  dynamic titleEn;
  dynamic titleSp;
  dynamic messageEn;
  dynamic messageSp;

  NotificationList({
    required this.id,
    required this.userId,
    required this.title,
    required this.message,
    required this.type,
    required this.typeId,
    required this.senderId,
    required this.senderRole,
    required this.isSeen,
    required this.isRead,
    required this.isAdminSeen,
    required this.isAdminRead,
    required this.userToken,
    required this.createdAt,
    required this.updatedAt,
    required this.userType,
    required this.sales,
    required this.titleEn,
    required this.titleSp,
    required this.messageEn,
    required this.messageSp,
  });

  factory NotificationList.fromJson(Map<String, dynamic> json) =>
      NotificationList(
        titleEn: json["title_en"],
        titleSp: json["title_sp"],
        messageEn: json["message_en"],
        messageSp: json["message_sp"],
        id: json["id"],
        userId: json["user_id"],
        title: json["title"],
        message: json["message"],
        type: json["type"],
        typeId: json["type_id"],
        senderId: json["sender_id"],
        senderRole: json["sender_role"],
        isSeen: json["is_seen"],
        isRead: json["is_read"],
        isAdminSeen: json["is_admin_seen"],
        isAdminRead: json["is_admin_read"],
        userToken: json["user_token"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        userType: json["user_type"],
        sales: json["sales"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "user_id": userId,
        "title": title,
        "message": message,
        "type": type,
        "type_id": typeId,
        "sender_id": senderId,
        "sender_role": senderRole,
        "is_seen": isSeen,
        "is_read": isRead,
        "is_admin_seen": isAdminSeen,
        "is_admin_read": isAdminRead,
        "user_token": userToken,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "user_type": userType,
        "sales": sales,
        "title_en": titleEn,
        "title_sp": titleSp,
        "message_en": messageEn,
        "message_sp": messageSp,
      };
}

class Pagination {
  dynamic total;
  dynamic page;
  dynamic pageSize;
  dynamic totalPages;
  dynamic remaining;
  dynamic nextPage;
  dynamic prevPage;

  Pagination({
    required this.total,
    required this.page,
    required this.pageSize,
    required this.totalPages,
    required this.remaining,
    required this.nextPage,
    required this.prevPage,
  });

  factory Pagination.fromJson(Map<String, dynamic> json) => Pagination(
        total: json["total"],
        page: json["page"],
        pageSize: json["page_size"],
        totalPages: json["total_pages"],
        remaining: json["remaining"],
        nextPage: json["next_page"],
        prevPage: json["prev_page"],
      );

  Map<String, dynamic> toJson() => {
        "total": total,
        "page": page,
        "page_size": pageSize,
        "total_pages": totalPages,
        "remaining": remaining,
        "next_page": nextPage,
        "prev_page": prevPage,
      };
}
