// To parse this JSON data, do
//
//     final couponModel = couponModelFromJson(jsonString);

import 'dart:convert';

CouponModel couponModelFromJson(String str) =>
    CouponModel.fromJson(json.decode(str));

String couponModelToJson(CouponModel data) => json.encode(data.toJson());

class CouponModel {
  CouponData data;
  bool status;
  String message;

  CouponModel({
    required this.data,
    required this.status,
    required this.message,
  });

  factory CouponModel.fromJson(Map<String, dynamic> json) => CouponModel(
        data: CouponData.fromJson(json["data"]),
        status: json["status"],
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "data": data.toJson(),
        "status": status,
        "message": message,
      };
}

class CouponData {
  List<CouponList> couponList;

  CouponData({
    required this.couponList,
  });

  factory CouponData.fromJson(Map<String, dynamic> json) => CouponData(
        couponList: List<CouponList>.from(
            json["coupon"].map((x) => CouponList.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "coupon": List<dynamic>.from(couponList.map((x) => x.toJson())),
      };
}

class CouponList {
  dynamic id;
  dynamic name;
  dynamic code;
  dynamic isAllProduct;
  dynamic isAllUser;
  DateTime createdAt;
  DateTime updatedAt;
  dynamic token;
  dynamic startDate;
  dynamic endDate;
  bool isExpired;
  List<Product> products;
  List<User> users;

  CouponList({
    required this.id,
    required this.name,
    required this.code,
    required this.isAllProduct,
    required this.isAllUser,
    required this.createdAt,
    required this.updatedAt,
    required this.token,
    required this.startDate,
    required this.endDate,
    required this.isExpired,
    required this.products,
    required this.users,
  });

  factory CouponList.fromJson(Map<String, dynamic> json) => CouponList(
        id: json["id"],
        name: json["name"],
        code: json["code"],
        isAllProduct: json["isAllProduct"],
        isAllUser: json["isAllUser"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        token: json["Token"],
        startDate: DateTime.parse(json["startDate"]),
        endDate: json["endDate"],
        // endDate: DateTime.parse(json["endDate"]),
        isExpired: json["is_expired"],
        products: List<Product>.from(
            json["products"].map((x) => Product.fromJson(x))),
        users: List<User>.from(json["users"].map((x) => User.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "code": code,
        "isAllProduct": isAllProduct,
        "isAllUser": isAllUser,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "Token": token,
        "startDate":
            "${startDate.year.toString().padLeft(4, '0')}-${startDate.month.toString().padLeft(2, '0')}-${startDate.day.toString().padLeft(2, '0')}",
        // "endDate":
        //     "${endDate.year.toString().padLeft(4, '0')}-${endDate.month.toString().padLeft(2, '0')}-${endDate.day.toString().padLeft(2, '0')}",
        "endDate": endDate,

        "is_expired": isExpired,
        "products": List<dynamic>.from(products.map((x) => x.toJson())),
        "users": List<dynamic>.from(users.map((x) => x.toJson())),
      };
}

class Product {
  dynamic id;
  dynamic name;
  dynamic code;
  dynamic barcodeSymbol;
  dynamic productCategoryId;
  dynamic productSubcategoryId;
  dynamic brandId;
  dynamic productCost;
  dynamic makingTime;
  dynamic productPrice;
  dynamic productUnit;
  dynamic saleUnit;
  dynamic purchaseUnit;
  dynamic stockAlert;
  dynamic quantityLimit;
  dynamic orderTax;
  dynamic taxType;
  dynamic notes;
  DateTime createdAt;
  DateTime updatedAt;
  dynamic orderCreateBy;
  dynamic description;
  dynamic productInvesters;
  dynamic productJtcToken;
  dynamic totalPrice;
  dynamic totalJtcToken;
  dynamic profitMargin;
  dynamic withoutTaxToken;
  dynamic productJtcTokenMargin;
  dynamic productJtcTokenInvestors;
  dynamic smallPrice;
  dynamic mediumPrice;
  dynamic largePrice;
  dynamic smallToken;
  dynamic mediumToken;
  dynamic largeToken;
  dynamic isVariantCheck;
  List<String> imageUrl;
  String barcodeImageUrl;
  ProductPivot pivot;
  List<Media> media;

  Product({
    required this.id,
    required this.name,
    required this.code,
    required this.barcodeSymbol,
    required this.productCategoryId,
    required this.productSubcategoryId,
    required this.brandId,
    required this.productCost,
    required this.makingTime,
    required this.productPrice,
    required this.productUnit,
    required this.saleUnit,
    required this.purchaseUnit,
    required this.stockAlert,
    required this.quantityLimit,
    required this.orderTax,
    required this.taxType,
    required this.notes,
    required this.createdAt,
    required this.updatedAt,
    required this.orderCreateBy,
    required this.description,
    required this.productInvesters,
    required this.productJtcToken,
    required this.totalPrice,
    required this.totalJtcToken,
    required this.profitMargin,
    required this.withoutTaxToken,
    required this.productJtcTokenMargin,
    required this.productJtcTokenInvestors,
    required this.smallPrice,
    required this.mediumPrice,
    required this.largePrice,
    required this.smallToken,
    required this.mediumToken,
    required this.largeToken,
    required this.isVariantCheck,
    required this.imageUrl,
    required this.barcodeImageUrl,
    required this.pivot,
    required this.media,
  });

  factory Product.fromJson(Map<String, dynamic> json) => Product(
        id: json["id"],
        name: json["name"],
        code: json["code"],
        barcodeSymbol: json["barcode_symbol"],
        productCategoryId: json["product_category_id"],
        productSubcategoryId: json["product_subcategory_id"],
        brandId: json["brand_id"],
        productCost: json["product_cost"],
        makingTime: json["making_time"],
        productPrice: json["product_price"],
        productUnit: json["product_unit"],
        saleUnit: json["sale_unit"],
        purchaseUnit: json["purchase_unit"],
        stockAlert: json["stock_alert"],
        quantityLimit: json["quantity_limit"],
        orderTax: json["order_tax"],
        taxType: json["tax_type"],
        notes: json["notes"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        orderCreateBy: json["order_create_by"],
        description: json["description"],
        productInvesters: json["product_investers"],
        productJtcToken: json["product_jtcToken"],
        totalPrice: json["total_price"],
        totalJtcToken: json["total_jtcToken"],
        profitMargin: json["profit_margin"],
        withoutTaxToken: json["withoutTax_token"],
        productJtcTokenMargin: json["product_jtcToken_margin"],
        productJtcTokenInvestors: json["product_jtcToken_investors"],
        smallPrice: json["small_price"],
        mediumPrice: json["medium_price"],
        largePrice: json["large_price"],
        smallToken: json["small_token"],
        mediumToken: json["medium_token"],
        largeToken: json["large_token"],
        isVariantCheck: json["is_variant_check"],
        imageUrl: List<String>.from(json["image_url"].map((x) => x)),
        barcodeImageUrl: json["barcode_image_url"],
        pivot: ProductPivot.fromJson(json["pivot"]),
        media: List<Media>.from(json["media"].map((x) => Media.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "code": code,
        "barcode_symbol": barcodeSymbol,
        "product_category_id": productCategoryId,
        "product_subcategory_id": productSubcategoryId,
        "brand_id": brandId,
        "product_cost": productCost,
        "making_time": makingTime,
        "product_price": productPrice,
        "product_unit": productUnit,
        "sale_unit": saleUnit,
        "purchase_unit": purchaseUnit,
        "stock_alert": stockAlert,
        "quantity_limit": quantityLimit,
        "order_tax": orderTax,
        "tax_type": taxType,
        "notes": notes,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "order_create_by": orderCreateBy,
        "description": description,
        "product_investers": productInvesters,
        "product_jtcToken": productJtcToken,
        "total_price": totalPrice,
        "total_jtcToken": totalJtcToken,
        "profit_margin": profitMargin,
        "withoutTax_token": withoutTaxToken,
        "product_jtcToken_margin": productJtcTokenMargin,
        "product_jtcToken_investors": productJtcTokenInvestors,
        "small_price": smallPrice,
        "medium_price": mediumPrice,
        "large_price": largePrice,
        "small_token": smallToken,
        "medium_token": mediumToken,
        "large_token": largeToken,
        "is_variant_check": isVariantCheck,
        "image_url": List<dynamic>.from(imageUrl.map((x) => x)),
        "barcode_image_url": barcodeImageUrl,
        "pivot": pivot.toJson(),
        "media": List<dynamic>.from(media.map((x) => x.toJson())),
      };
}

class Media {
  int id;
  ModelType modelType;
  int modelId;
  String uuid;
  CollectionName collectionName;
  String name;
  String fileName;
  MimeType mimeType;
  Disk disk;
  Disk conversionsDisk;
  int size;
  List<dynamic> manipulations;
  List<dynamic> customProperties;
  List<dynamic> generatedConversions;
  List<dynamic> responsiveImages;
  int orderColumn;
  DateTime createdAt;
  DateTime updatedAt;
  String originalUrl;
  String previewUrl;

  Media({
    required this.id,
    required this.modelType,
    required this.modelId,
    required this.uuid,
    required this.collectionName,
    required this.name,
    required this.fileName,
    required this.mimeType,
    required this.disk,
    required this.conversionsDisk,
    required this.size,
    required this.manipulations,
    required this.customProperties,
    required this.generatedConversions,
    required this.responsiveImages,
    required this.orderColumn,
    required this.createdAt,
    required this.updatedAt,
    required this.originalUrl,
    required this.previewUrl,
  });

  factory Media.fromJson(Map<String, dynamic> json) => Media(
        id: json["id"],
        modelType: modelTypeValues.map[json["model_type"]]!,
        modelId: json["model_id"],
        uuid: json["uuid"],
        collectionName: collectionNameValues.map[json["collection_name"]]!,
        name: json["name"],
        fileName: json["file_name"],
        mimeType: mimeTypeValues.map[json["mime_type"]]!,
        disk: diskValues.map[json["disk"]]!,
        conversionsDisk: diskValues.map[json["conversions_disk"]]!,
        size: json["size"],
        manipulations: List<dynamic>.from(json["manipulations"].map((x) => x)),
        customProperties:
            List<dynamic>.from(json["custom_properties"].map((x) => x)),
        generatedConversions:
            List<dynamic>.from(json["generated_conversions"].map((x) => x)),
        responsiveImages:
            List<dynamic>.from(json["responsive_images"].map((x) => x)),
        orderColumn: json["order_column"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        originalUrl: json["original_url"],
        previewUrl: json["preview_url"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "model_type": modelTypeValues.reverse[modelType],
        "model_id": modelId,
        "uuid": uuid,
        "collection_name": collectionNameValues.reverse[collectionName],
        "name": name,
        "file_name": fileName,
        "mime_type": mimeTypeValues.reverse[mimeType],
        "disk": diskValues.reverse[disk],
        "conversions_disk": diskValues.reverse[conversionsDisk],
        "size": size,
        "manipulations": List<dynamic>.from(manipulations.map((x) => x)),
        "custom_properties": List<dynamic>.from(customProperties.map((x) => x)),
        "generated_conversions":
            List<dynamic>.from(generatedConversions.map((x) => x)),
        "responsive_images": List<dynamic>.from(responsiveImages.map((x) => x)),
        "order_column": orderColumn,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "original_url": originalUrl,
        "preview_url": previewUrl,
      };
}

enum CollectionName { PRODUCT, USER_IMAGE }

final collectionNameValues = EnumValues({
  "product": CollectionName.PRODUCT,
  "user_image": CollectionName.USER_IMAGE
});

enum Disk { PUBLIC }

final diskValues = EnumValues({"public": Disk.PUBLIC});

enum MimeType { IMAGE_JPEG, IMAGE_PNG }

final mimeTypeValues = EnumValues(
    {"image/jpeg": MimeType.IMAGE_JPEG, "image/png": MimeType.IMAGE_PNG});

enum ModelType { APP_MODELS_ECOMMERCE_USERS, APP_MODELS_PRODUCT }

final modelTypeValues = EnumValues({
  "App\\Models\\EcommerceUsers": ModelType.APP_MODELS_ECOMMERCE_USERS,
  "App\\Models\\Product": ModelType.APP_MODELS_PRODUCT
});

class ProductPivot {
  int couponId;
  int productId;

  ProductPivot({
    required this.couponId,
    required this.productId,
  });

  factory ProductPivot.fromJson(Map<String, dynamic> json) => ProductPivot(
        couponId: json["coupon_id"],
        productId: json["product_id"],
      );

  Map<String, dynamic> toJson() => {
        "coupon_id": couponId,
        "product_id": productId,
      };
}

class User {
  int id;
  String firstName;
  String lastName;
  String email;
  DateTime emailVerifiedAt;
  String phoneNo;
  DateTime createdAt;
  DateTime updatedAt;
  String referalCode;
  int rewardPoints;
  String language;
  String? firebaseWebToken;
  dynamic firebaseMobileToken;
  String walletId;
  String? address;
  String? lat;
  String? long;
  String? deviceType;
  dynamic countryCode;
  String provider;
  dynamic accessToken;
  String imageUrl;
  UserPivot pivot;
  List<Media> media;

  User({
    required this.id,
    required this.firstName,
    required this.lastName,
    required this.email,
    required this.emailVerifiedAt,
    required this.phoneNo,
    required this.createdAt,
    required this.updatedAt,
    required this.referalCode,
    required this.rewardPoints,
    required this.language,
    required this.firebaseWebToken,
    required this.firebaseMobileToken,
    required this.walletId,
    required this.address,
    required this.lat,
    required this.long,
    required this.deviceType,
    required this.countryCode,
    required this.provider,
    required this.accessToken,
    required this.imageUrl,
    required this.pivot,
    required this.media,
  });

  factory User.fromJson(Map<String, dynamic> json) => User(
        id: json["id"],
        firstName: json["first_name"],
        lastName: json["last_name"],
        email: json["email"],
        emailVerifiedAt: DateTime.parse(json["email_verified_at"]),
        phoneNo: json["phone_no"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        referalCode: json["referal_code"],
        rewardPoints: json["reward_points"],
        language: json["language"],
        firebaseWebToken: json["firebase_web_token"],
        firebaseMobileToken: json["firebase_mobile_token"],
        walletId: json["walletId"],
        address: json["address"],
        lat: json["lat"],
        long: json["long"],
        deviceType: json["device_type"],
        countryCode: json["country_code"],
        provider: json["provider"],
        accessToken: json["access_token"],
        imageUrl: json["image_url"],
        pivot: UserPivot.fromJson(json["pivot"]),
        media: List<Media>.from(json["media"].map((x) => Media.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "first_name": firstName,
        "last_name": lastName,
        "email": email,
        "email_verified_at": emailVerifiedAt.toIso8601String(),
        "phone_no": phoneNo,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "referal_code": referalCode,
        "reward_points": rewardPoints,
        "language": language,
        "firebase_web_token": firebaseWebToken,
        "firebase_mobile_token": firebaseMobileToken,
        "walletId": walletId,
        "address": address,
        "lat": lat,
        "long": long,
        "device_type": deviceType,
        "country_code": countryCode,
        "provider": provider,
        "access_token": accessToken,
        "image_url": imageUrl,
        "pivot": pivot.toJson(),
        "media": List<dynamic>.from(media.map((x) => x.toJson())),
      };
}

class UserPivot {
  int couponId;
  int userId;

  UserPivot({
    required this.couponId,
    required this.userId,
  });

  factory UserPivot.fromJson(Map<String, dynamic> json) => UserPivot(
        couponId: json["coupon_id"],
        userId: json["user_id"],
      );

  Map<String, dynamic> toJson() => {
        "coupon_id": couponId,
        "user_id": userId,
      };
}

class EnumValues<T> {
  Map<String, T> map;
  late Map<T, String> reverseMap;

  EnumValues(this.map);

  Map<T, String> get reverse {
    reverseMap = map.map((k, v) => MapEntry(v, k));
    return reverseMap;
  }
}
