import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/settings/blocs/buy_jtc_tokens_list_bloc.dart';
import 'package:jtc_ecommerce/settings/blocs/coupon_list_bloc.dart';
import 'package:jtc_ecommerce/settings/blocs/my_orders_bloc.dart';
import 'package:jtc_ecommerce/settings/blocs/notification_list_bloc.dart';
import 'package:jtc_ecommerce/settings/models/buy_jtc_token_plan_model.dart';
import 'package:jtc_ecommerce/settings/models/coupon_model.dart';
import 'package:jtc_ecommerce/settings/models/my_oders_model.dart';
import 'package:jtc_ecommerce/settings/models/notification_model.dart';
import 'package:jtc_ecommerce/splash/controllers/splash_controller.dart';
import 'package:jtc_ecommerce/utils/app_strings.dart';

class SettingsController extends GetxController {
  RxBool isLoading = false.obs;
  RxBool isLoadingNextPage = false.obs;
  bool imageChanged = false;
  // Rxn<String> userProfileImagePath = Rxn(null);
  bool updatingProfile = false;
  String imageType = AppStrings.IMAGE_NETWORK_TYPE;

  // void updateImage(value) {
  //   imageChanged = true;
  //   userProfileImagePath.value = value;
  //   updatingProfile = false;
  //   imageType = AppStrings.IMAGE_FILE_TYPE;
  //   update();
  // }

  //! User Profile
  GlobalKey<FormState> registerFormKey = GlobalKey<FormState>();
  TextEditingController firstName = TextEditingController();
  TextEditingController lastName = TextEditingController();
  TextEditingController email_register = TextEditingController();
  TextEditingController phoneNo = TextEditingController();
  TextEditingController password = TextEditingController();
  TextEditingController confrim_password = TextEditingController();
  // TextEditingController user_address = TextEditingController();
  final Rx<TextEditingController> user_address = TextEditingController().obs;
  final Rx<TextEditingController> nearest_address = TextEditingController().obs;
  // TextEditingController nearest_address = TextEditingController();
  var splashController = Get.find<SplashController>();
  Rxn<File> imagePath = Rxn(null);

  @override
  void onInit() {
    // logData(message: "Splash: ${splashController.currentUser.value?.media[0]}");
    firstName.text = splashController.currentUser.value?.firstName ?? "";
    lastName.text = splashController.currentUser.value?.lastName ?? "";
    email_register.text = splashController.currentUser.value?.email ?? "";
    phoneNo.text = splashController.currentUser.value?.phoneNo ?? "";
    // // userProfileImagePath = splashController.currentUser.value?.image;
    // logData(message: "userProfileImagePath: ${userProfileImagePath}");
    // // password.text = splashController.currentUser.value?.firstName ?? "";
    // // confrim_password.text = splashController.currentUser.value?.firstName ?? "";
    user_address.value.text = splashController.currentUser.value?.address ?? "";
    nearest_address.value.text =
        splashController.currentUser.value?.nearest_address ?? "";
    super.onInit();
  }

  //! Change Password
  RxBool current_password_eye = true.obs;
  RxBool new_password_eye = true.obs;
  TextEditingController current_password = TextEditingController();
  TextEditingController new_password = TextEditingController();
  TextEditingController new_password_reset = TextEditingController();
  TextEditingController confirm_new_password = TextEditingController();
  TextEditingController confirm_new_password_rest = TextEditingController();
  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  //! Buy JTC Token Stuff
  RxList<TokenPlanList> tokenPlanList = <TokenPlanList>[].obs;
  ScrollController scrollControllerBuyJtcToken = ScrollController();

  Future<void> get_buy_jtc_token() async {
    try {
      isLoading.value = true;

      if (tokenPlanList.isEmpty) {
        await BuyJTCTokenBloc().getBuyJTCTokenBlocMethod(
          context: Get.context!,
        );
        if (BuyJTCTokenBloc().contentTypeResponse != null) {
          tokenPlanList.addAll(
            List.from(BuyJTCTokenBloc().contentTypeResponse),
          );
        }
      }
    } catch (e) {
    } finally {
      isLoading.value = false;
    }
  }

  RxBool showButton = false.obs;
  RxString formattedTime = ''.obs;

  RxList<CouponList> couponList = <CouponList>[].obs;

  Future<void> get_coupon_list() async {
    try {
      isLoading.value = true;

      if (couponList.isEmpty) {
        await CouponListBloc().couponListBlocMethod(
          context: Get.context!,
        );
        if (CouponListBloc().contentTypeResponse != null) {
          couponList.addAll(
            List.from(CouponListBloc().contentTypeResponse),
          );
        }
      }
    } catch (e) {
    } finally {
      isLoading.value = false;
    }
  }

  // late Timer _timer;

  // void startTimer() {
  //   _timer = Timer.periodic(Duration(seconds: 1), (timer) {
  //     if (myorderList.isNotEmpty) {
  //       updateTime(
  //         myorderList[0].startTime ?? "0.0",
  //         myorderList[0].endTime ?? "0.0",
  //       );
  //     }
  //     // updateTime();
  //   });
  // }

  // void stopTimer() {
  //   _timer.cancel();
  // }

  // void updateTime(String openingTime, String closingTime) {
  //   // Parse openingTime and closingTime strings to extract hours and minutes
  //   List<String> openingParts = openingTime.split(' ');
  //   List<String> closingParts = closingTime.split(' ');

  //   int openingHour = int.parse(openingParts[0].split(':')[0]);
  //   int openingMinute = int.parse(openingParts[0].split(':')[1]);
  //   bool openingPM = openingParts[1] == 'PM';

  //   int closingHour = int.parse(closingParts[0].split(':')[0]);
  //   int closingMinute = int.parse(closingParts[0].split(':')[1]);
  //   bool closingPM = closingParts[1] == 'PM';

  //   // Adjust opening and closing hours if PM
  //   if (openingPM && openingHour != 12) {
  //     openingHour += 12;
  //   }
  //   if (closingPM && closingHour != 12) {
  //     closingHour += 12;
  //   }

  //   DateTime currentTime = DateTime.now();
  //   DateTime startTime = DateTime(
  //     currentTime.year,
  //     currentTime.month,
  //     currentTime.day,
  //     openingHour,
  //     openingMinute,
  //   );

  //   // If the closing time is before the opening time (e.g., closing time is in PM and opening time is in AM), adjust the date
  //   if (closingHour < openingHour ||
  //       (closingHour == openingHour && closingMinute < openingMinute)) {
  //     currentTime = currentTime.add(Duration(days: 1));
  //   }

  //   DateTime endTime = DateTime(
  //     currentTime.year,
  //     currentTime.month,
  //     currentTime.day,
  //     closingHour,
  //     closingMinute,
  //   );
  //   if (currentTime.isAfter(startTime) && currentTime.isBefore(endTime)) {
  //     showButton.value = true;
  //     Duration remainingDuration = endTime.difference(currentTime);

  //     int hours = remainingDuration.inHours.remainder(60);
  //     int minutes = remainingDuration.inMinutes.remainder(60);
  //     int seconds = remainingDuration.inSeconds.remainder(60);
  //     formattedTime.value =
  //         '${hours.toString().padLeft(2, '0')} : ${minutes.toString().padLeft(2, '0')} : ${seconds.toString().padLeft(2, '0')}';

  //     // printCurrentTimeBackwards(currentTime, startTime);
  //   } else {
  //     showButton.value = false;
  //     formattedTime.value = 'Out of Time';
  //   }
  // }

  // void printCurrentTimeBackwards(DateTime currentTime, DateTime startTime) {
  //   while (currentTime.isAfter(startTime)) {
  //     print(
  //         'current time   ${DateFormat('yyyy-MM-dd HH:mm:ss.S').format(currentTime)}');
  //     currentTime = currentTime.subtract(Duration(seconds: 1));
  //   }
  // }

  RxList<NotificationList> notificationList = <NotificationList>[].obs;

  Future<void> get_Notification_list() async {
    try {
      isLoading.value = true;
      notificationList.clear();

      // if (notificationList.isEmpty) {
      await NotificationListBloc().notificationListBlocMethod(
        context: Get.context!,
      );
      if (NotificationListBloc().contentTypeResponse != null) {
        couponList.addAll(
          List.from(NotificationListBloc().contentTypeResponse),
        );
        // }
      }
    } catch (e) {
    } finally {
      isLoading.value = false;
    }
  }

  RxList<HistoryData> myorderList = <HistoryData>[].obs;
  Future<void> get_my_orders() async {
    try {
      myorderList.clear();
      isLoading.value = true;

      if (myorderList.isEmpty) {
        await MyOrdersBloc().getMyOrdersyJTCTokenBlocMethod(
          context: Get.context!,
        );
        if (MyOrdersBloc().contentTypeResponse != null) {
          myorderList.addAll(
            List.from(MyOrdersBloc().contentTypeResponse),
          );
        }
      }
    } catch (e) {
    } finally {
      isLoading.value = false;
    }
  }

  //Buy Jtc Token Stuff

  GlobalKey<FormState> addCardFormKey = GlobalKey<FormState>();
  TextEditingController account_holder_controller = TextEditingController();
  TextEditingController account_number_controller = TextEditingController();
  TextEditingController expiry_controller = TextEditingController();
  TextEditingController cvc_controller = TextEditingController();

  ///Loading Notifications
  ///
  RxBool loadingNotifications = false.obs;
}
