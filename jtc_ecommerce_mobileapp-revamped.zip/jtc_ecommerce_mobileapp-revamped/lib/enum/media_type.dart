enum MediaType{
  image,video
}

class Post{
  final String? url;
  final String? thumbnail;
  final MediaType mediaType;

  Post({this.url,required this.mediaType, this.thumbnail});
}
