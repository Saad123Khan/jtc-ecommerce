enum Variant { small, medium, large }
