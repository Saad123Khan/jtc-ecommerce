import 'package:get/get.dart';
import 'package:jtc_ecommerce/favourite/controllers/favourite_controller.dart';

class FavouriteBinding extends Bindings{
  @override
  void dependencies() {
    Get.lazyPut(() => FavouriteController());
  }
}