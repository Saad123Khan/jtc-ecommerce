import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as GetxController;
import 'package:jtc_ecommerce/favourite/controllers/favourite_controller.dart';
import 'package:jtc_ecommerce/favourite/models/post_favourite_model.dart';
import 'package:jtc_ecommerce/home/controllers/food_categories_list_controller.dart';
import 'package:jtc_ecommerce/home/controllers/home_controller.dart';
import 'package:jtc_ecommerce/home/controllers/product_detail_controller.dart';
import 'package:jtc_ecommerce/home/models/single_product_model.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/services/translate_service.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';

import '../../home/models/get_food_categories_model_product.dart';

class PostFavouriteBloc {
  FormData? _formData;
  Response? _response;
  VoidCallback? _onSuccess, _onFailure;
  PostFavouriteModel? _postFavouriteModel;

  void postFavouriteBlocMethod({
    required BuildContext context,
    required VoidCallback setProgressBar,
    SingleProductModel? singleProductModel,
    String? product_id,
    bool isFromCats = false,
    Product? product,
    bool isFav = false,
    bool fromFavScreen = false,
  }) async {
    setProgressBar();

    //! ============> Form Data
    _formData = FormData.fromMap({
      "product_id": product_id,
    });

    //! ============> Print Form Data
    print({
      "product_id": product_id,
    });

    //! ============> If Api fails then stop the loader
    _onFailure = () async {
      AppNavigation.navigatorPop(context);

      print("STATUSSS CODEE ${_response?.statusCode}");
      final message = _response?.data['message'] ?? "";

      print(message);

      switch (message) {
        default:
          if (context.locale.languageCode != "en") {
            final _translatedMessage = await GoogleTranslatorService()
                .translate(text: message, context: context);
            AppDialogs.showToast(message: _translatedMessage);
          } else {
            AppDialogs.showToast(message: message);
          }
      }
    };

    //! ============> Call api
    await _postRequest(
      endPoint: NetworkStrings.POST_FAV_ENDPOINT,
      context: GetxController.Get.context!,
    );

    //! ============> Get the login response
    _onSuccess = () {
      AppNavigation.navigatorPop(context);
      _loginResponseMethod(
          context: context,
          isFav: isFav,
          product: product,
          product_id: product_id ?? "",
          isFromCats: isFromCats,
          singleProductModel: singleProductModel);
    };

    //! ============> Validate the response
    _validateResponse();
  }

  //! ============> Post Request
  Future<void> _postRequest({
    required String endPoint,
    required BuildContext context,
  }) async {
    _response = await Network().postRequest(
      endPoint: endPoint,
      formData: _formData,
      customFailure: true,
      context: context,
      onFailure: _onFailure,
      isHeaderRequire: true,
      isToast: true,
    );
  }

  //! ============> Validate Response
  void _validateResponse() {
    if (_response != null) {
      Network().validateResponse(
        isToast: false,
        response: _response,
        onSuccess: _onSuccess,
        onFailure: _onFailure,
      );
    }
  }

  //! ============> Login Response

  void _loginResponseMethod({
    required BuildContext context,
    required bool isFav,
    required String product_id,
    Product? product,
    bool isFromCats = false,
    SingleProductModel? singleProductModel,
  }) async {
    try {
      _postFavouriteModel = PostFavouriteModel.fromJson(_response?.data);
      logData(message: "isFav: $isFav");
      var favtoggle = _postFavouriteModel?.data?.product?.isFavorite ?? false;

      if (product != null) {
        HomeController.i.toggleFav(product, favtoggle);
      }

      if (singleProductModel != null) {
        if (isFromCats) {
          FoodCategoriesListController.i
              .toggleFav(singleProductModel, favtoggle);
        } else {
          ProductDetailController.i.toggleFav(singleProductModel, favtoggle);
        }
      }

      logData(message: "favtoggle: ${favtoggle}");
      if (favtoggle) {
        var favController = GetxController.Get.isRegistered()
            ? GetxController.Get.find<FavouriteController>()
            : GetxController.Get.put(FavouriteController());
        favController.favouriteList.removeWhere(
          (element) => element.product?.id.toString() == product_id,
        );
        var homeController = GetxController.Get.isRegistered()
            ? GetxController.Get.find<HomeController>()
            : GetxController.Get.put(HomeController());

        homeController.singleProductModel.forEach((element) {
          if (element.id.toString() == product_id) {
            element.isFavorite = true;
          }
        });
        // homeController.update();

        var categoeriesController = GetxController.Get.isRegistered()
            ? GetxController.Get.find<FoodCategoriesListController>()
            : GetxController.Get.put(FoodCategoriesListController());
        categoeriesController.singleProductModel.forEach((element) {
          if (element.id.toString() == product_id) {
            element.isFavorite = true;
          }
        });

        

        categoeriesController.update();
      } else {
        var favController = GetxController.Get.isRegistered()
            ? GetxController.Get.find<FavouriteController>()
            : GetxController.Get.put(FavouriteController());
        favController.favouriteList.removeWhere(
          (element) => element.product?.id.toString() == product_id,
        );
        var homeController = GetxController.Get.isRegistered()
            ? GetxController.Get.find<HomeController>()
            : GetxController.Get.put(HomeController());

        homeController.singleProductModel.forEach((element) {
          if (element.id.toString() == product_id) {
            element.isFavorite = false;
          }
        });
        // homeController.update();

        var categoeriesController = GetxController.Get.isRegistered()
            ? GetxController.Get.find<FoodCategoriesListController>()
            : GetxController.Get.put(FoodCategoriesListController());
        categoeriesController.singleProductModel.forEach((element) {
          if (element.id.toString() == product_id) {
            element.isFavorite = false;
          }
        });
        categoeriesController.update();
      }

      logData(message: "ProductID2: ${product_id}");
      print(_postFavouriteModel?.message);
      // AppDialogs.showToast(message: _postFavouriteModel?.message);

      if (_postFavouriteModel?.message == 'Favourite Added Successfully!') {
        AppDialogs.showToast(message: tr('fav_Added'));
      } else if (_postFavouriteModel?.message ==
          'Favourite Removed Successfully!') {
        AppDialogs.showToast(message: tr('fav_removed'));
      } else {
        AppDialogs.showToast(message: _postFavouriteModel?.message);
      }
    } catch (error) {
      AppDialogs.showToast(message: tr(NetworkStrings.SOMETHING_WENT_WRONG));
    }
  }
}
