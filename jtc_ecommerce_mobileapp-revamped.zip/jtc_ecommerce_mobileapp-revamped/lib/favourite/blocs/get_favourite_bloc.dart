import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' as Getx;
import 'package:jtc_ecommerce/favourite/controllers/favourite_controller.dart';
import 'package:jtc_ecommerce/favourite/models/get_favourite_model.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/services/network.dart';
import 'package:jtc_ecommerce/utils/app_network_strings.dart';

class GetFavouriteBloc {
  Map<String, dynamic>? _queryParameters;
  Response? _response;
  VoidCallback? _onSuccess;
  dynamic contentTypeResponse;
  // GetFoodCategoriesModel? _getFoodCategoriesModel;
  GetFavouriteModel? _getFavouriteModel;

  ////////////////////////// Terms and Condition And Privacy Policy //////////////////////////////////
  Future<void> getFavouriteBlocMethod({
    required BuildContext context,
  }) async {
    await _getRequest(
      endPoint: NetworkStrings.GET_FAVOURITE_ENDPOINT,
      context: context,
    );

    _onSuccess = () {
      contentTypeResponse = _response?.data;
    };

    _validateResponse();

    return contentTypeResponse;
  }

  // Get Request
  Future<void> _getRequest(
      {required String endPoint, required BuildContext context}) async {
    _response = await Network().getRequest(
      context: context,
      endPoint: endPoint,
      queryParameters: _queryParameters,
      isToast: false,
      isHeaderRequire: true,
    );
  }

  void _validateResponse() {
    var controller = Getx.Get.find<FavouriteController>();

    try {
      _getFavouriteModel = GetFavouriteModel.fromJson(_response?.data);
      logData(message: "_getFavouriteModel: ${_getFavouriteModel?.data}");

      List<FavouriteList> updatedList = List.from(controller.favouriteList);
      updatedList.addAll(_getFavouriteModel?.data?.favourites ?? []);

      controller.favouriteList.assignAll(updatedList.reversed);
      logData(message: "goalList: ${controller.favouriteList.length}");

      // Network().validateResponse(
      //   response: _response,
      //   onSuccess: _onSuccess,
      //   isToast: false,
      // );
    } catch (error, stackTrace) {
      print("Error in _validateResponse: $error");
      print("Stack Trace: $stackTrace");
    }
  }
}
