// // To parse this JSON data, do
// //
// //     final postFavouriteModel = postFavouriteModelFromJson(jsonString);

// import 'dart:convert';

// PostFavouriteModel postFavouriteModelFromJson(String str) =>
//     PostFavouriteModel.fromJson(json.decode(str));

// String postFavouriteModelToJson(PostFavouriteModel data) =>
//     json.encode(data.toJson());

// class PostFavouriteModel {
//   bool? status;
//   List<dynamic>? data;
//   String? message;

//   PostFavouriteModel({
//     this.status,
//     this.data,
//     this.message,
//   });

//   factory PostFavouriteModel.fromJson(Map<String, dynamic> json) =>
//       PostFavouriteModel(
//         status: json["status"],
//         data: json["data"] == null
//             ? []
//             : List<dynamic>.from(json["data"]!.map((x) => x)),
//         message: json["message"],
//       );

//   Map<String, dynamic> toJson() => {
//         "status": status,
//         "data": data == null ? [] : List<dynamic>.from(data!.map((x) => x)),
//         "message": message,
//       };
// }

// To parse this JSON data, do
//
//     final postFavouriteModel = postFavouriteModelFromJson(jsonString);

import 'dart:convert';

import 'package:jtc_ecommerce/home/models/single_product_model.dart';

PostFavouriteModel postFavouriteModelFromJson(String str) =>
    PostFavouriteModel.fromJson(json.decode(str));

String postFavouriteModelToJson(PostFavouriteModel data) =>
    json.encode(data.toJson());

class PostFavouriteModel {
  bool? status;
  Data? data;
  String? message;

  PostFavouriteModel({
    this.status,
    this.data,
    this.message,
  });

  factory PostFavouriteModel.fromJson(Map<String, dynamic> json) =>
      PostFavouriteModel(
        status: json["status"],
        data: json["data"] == null ? null : Data.fromJson(json["data"]),
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "status": status,
        "data": data?.toJson(),
        "message": message,
      };
}

class Data {
  SingleProductModel? product;

  Data({
    this.product,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        product: json["product"] == null
            ? null
            : SingleProductModel.fromJson(json["product"]),
      );

  Map<String, dynamic> toJson() => {
        "product": product?.toJson(),
      };
}

// class Product {
//     int? id;
//     String? name;
//     String? code;
//     int? productCategoryId;
//     int? productSubcategoryId;
//     int? brandId;
//     String? productCost;
//     String? productPrice;
//     String? productUnit;
//     String? saleUnit;
//     String? purchaseUnit;
//     String? stockAlert;
//     String? quantityLimit;
//     int? makingTime;
//     String? orderTax;
//     String? taxType;
//     dynamic notes;
//     String? description;
//     List<String>? images;
//     List<String>? imageUrl;
//     String? productCategoryName;
//     String? productSubcategoryName;
//     String? brandName;
//     String? barcodeImageUrl;
//     int? barcodeSymbol;
//     DateTime? createdAt;
//     String? orderCreateBy;
//     ProductUnitName? productUnitName;
//     EUnitName? purchaseUnitName;
//     EUnitName? saleUnitName;
//     Stock? stock;
//     List<ProductAddon>? productAddons;
//     List<Warehouse>? warehouse;
//     String? barcodeUrl;
//     int? inStock;
//     String? review;
//     bool? isFavourite;
//     int? favouriteCount;
//     String? profitMargin;
//     String? productInvesters;
//     int? productJtcToken;

//     Product({
//         this.id,
//         this.name,
//         this.code,
//         this.productCategoryId,
//         this.productSubcategoryId,
//         this.brandId,
//         this.productCost,
//         this.productPrice,
//         this.productUnit,
//         this.saleUnit,
//         this.purchaseUnit,
//         this.stockAlert,
//         this.quantityLimit,
//         this.makingTime,
//         this.orderTax,
//         this.taxType,
//         this.notes,
//         this.description,
//         this.images,
//         this.imageUrl,
//         this.productCategoryName,
//         this.productSubcategoryName,
//         this.brandName,
//         this.barcodeImageUrl,
//         this.barcodeSymbol,
//         this.createdAt,
//         this.orderCreateBy,
//         this.productUnitName,
//         this.purchaseUnitName,
//         this.saleUnitName,
//         this.stock,
//         this.productAddons,
//         this.warehouse,
//         this.barcodeUrl,
//         this.inStock,
//         this.review,
//         this.isFavourite,
//         this.favouriteCount,
//         this.profitMargin,
//         this.productInvesters,
//         this.productJtcToken,
//     });

//     factory Product.fromJson(Map<String, dynamic> json) => Product(
//         id: json["id"],
//         name: json["name"],
//         code: json["code"],
//         productCategoryId: json["product_category_id"],
//         productSubcategoryId: json["product_subcategory_id"],
//         brandId: json["brand_id"],
//         productCost: json["product_cost"],
//         productPrice: json["product_price"],
//         productUnit: json["product_unit"],
//         saleUnit: json["sale_unit"],
//         purchaseUnit: json["purchase_unit"],
//         stockAlert: json["stock_alert"],
//         quantityLimit: json["quantity_limit"],
//         makingTime: json["making_time"],
//         orderTax: json["order_tax"],
//         taxType: json["tax_type"],
//         notes: json["notes"],
//         description: json["description"],
//         images: json["images"] == null ? [] : List<String>.from(json["images"]!.map((x) => x)),
//         imageUrl: json["image_url"] == null ? [] : List<String>.from(json["image_url"]!.map((x) => x)),
//         productCategoryName: json["product_category_name"],
//         productSubcategoryName: json["product_subcategory_name"],
//         brandName: json["brand_name"],
//         barcodeImageUrl: json["barcode_image_url"],
//         barcodeSymbol: json["barcode_symbol"],
//         createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
//         orderCreateBy: json["order_create_by"],
//         productUnitName: json["product_unit_name"] == null ? null : ProductUnitName.fromJson(json["product_unit_name"]),
//         purchaseUnitName: json["purchase_unit_name"] == null ? null : EUnitName.fromJson(json["purchase_unit_name"]),
//         saleUnitName: json["sale_unit_name"] == null ? null : EUnitName.fromJson(json["sale_unit_name"]),
//         stock: json["stock"] == null ? null : Stock.fromJson(json["stock"]),
//         productAddons: json["product_addons"] == null ? [] : List<ProductAddon>.from(json["product_addons"]!.map((x) => ProductAddon.fromJson(x))),
//         warehouse: json["warehouse"] == null ? [] : List<Warehouse>.from(json["warehouse"]!.map((x) => Warehouse.fromJson(x))),
//         barcodeUrl: json["barcode_url"],
//         inStock: json["in_stock"],
//         review: json["review"],
//         isFavourite: json["is_favourite"],
//         favouriteCount: json["favourite_count"],
//         profitMargin: json["profit_margin"],
//         productInvesters: json["product_investers"],
//         productJtcToken: json["product_jtcToken"],
//     );

//     Map<String, dynamic> toJson() => {
//         "id": id,
//         "name": name,
//         "code": code,
//         "product_category_id": productCategoryId,
//         "product_subcategory_id": productSubcategoryId,
//         "brand_id": brandId,
//         "product_cost": productCost,
//         "product_price": productPrice,
//         "product_unit": productUnit,
//         "sale_unit": saleUnit,
//         "purchase_unit": purchaseUnit,
//         "stock_alert": stockAlert,
//         "quantity_limit": quantityLimit,
//         "making_time": makingTime,
//         "order_tax": orderTax,
//         "tax_type": taxType,
//         "notes": notes,
//         "description": description,
//         "images": images == null ? [] : List<dynamic>.from(images!.map((x) => x)),
//         "image_url": imageUrl == null ? [] : List<dynamic>.from(imageUrl!.map((x) => x)),
//         "product_category_name": productCategoryName,
//         "product_subcategory_name": productSubcategoryName,
//         "brand_name": brandName,
//         "barcode_image_url": barcodeImageUrl,
//         "barcode_symbol": barcodeSymbol,
//         "created_at": createdAt?.toIso8601String(),
//         "order_create_by": orderCreateBy,
//         "product_unit_name": productUnitName?.toJson(),
//         "purchase_unit_name": purchaseUnitName?.toJson(),
//         "sale_unit_name": saleUnitName?.toJson(),
//         "stock": stock?.toJson(),
//         "product_addons": productAddons == null ? [] : List<dynamic>.from(productAddons!.map((x) => x.toJson())),
//         "warehouse": warehouse == null ? [] : List<dynamic>.from(warehouse!.map((x) => x.toJson())),
//         "barcode_url": barcodeUrl,
//         "in_stock": inStock,
//         "review": review,
//         "is_favourite": isFavourite,
//         "favourite_count": favouriteCount,
//         "profit_margin": profitMargin,
//         "product_investers": productInvesters,
//         "product_jtcToken": productJtcToken,
//     };
// }

// class ProductAddon {
//     String? addonName;
//     int? addonId;
//     List<AddonItem>? addonItems;

//     ProductAddon({
//         this.addonName,
//         this.addonId,
//         this.addonItems,
//     });

//     factory ProductAddon.fromJson(Map<String, dynamic> json) => ProductAddon(
//         addonName: json["addon_name"],
//         addonId: json["addon_id"],
//         addonItems: json["addon_items"] == null ? [] : List<AddonItem>.from(json["addon_items"]!.map((x) => AddonItem.fromJson(x))),
//     );

//     Map<String, dynamic> toJson() => {
//         "addon_name": addonName,
//         "addon_id": addonId,
//         "addon_items": addonItems == null ? [] : List<dynamic>.from(addonItems!.map((x) => x.toJson())),
//     };
// }

// class AddonItem {
//     int? itemId;
//     String? itemName;
//     int? itemPrice;
//     int? itemToken;

//     AddonItem({
//         this.itemId,
//         this.itemName,
//         this.itemPrice,
//         this.itemToken,
//     });

//     factory AddonItem.fromJson(Map<String, dynamic> json) => AddonItem(
//         itemId: json["item_id"],
//         itemName: json["item_name"],
//         itemPrice: json["item_price"],
//         itemToken: json["item_token"],
//     );

//     Map<String, dynamic> toJson() => {
//         "item_id": itemId,
//         "item_name": itemName,
//         "item_price": itemPrice,
//         "item_token": itemToken,
//     };
// }

// class ProductUnitName {
//     int? id;
//     String? name;
//     int? isDefault;
//     DateTime? createdAt;
//     DateTime? updatedAt;

//     ProductUnitName({
//         this.id,
//         this.name,
//         this.isDefault,
//         this.createdAt,
//         this.updatedAt,
//     });

//     factory ProductUnitName.fromJson(Map<String, dynamic> json) => ProductUnitName(
//         id: json["id"],
//         name: json["name"],
//         isDefault: json["is_default"],
//         createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
//         updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
//     );

//     Map<String, dynamic> toJson() => {
//         "id": id,
//         "name": name,
//         "is_default": isDefault,
//         "created_at": createdAt?.toIso8601String(),
//         "updated_at": updatedAt?.toIso8601String(),
//     };
// }

// class EUnitName {
//     int? id;
//     String? name;
//     String? shortName;
//     int? baseUnit;
//     DateTime? createdAt;
//     DateTime? updatedAt;

//     EUnitName({
//         this.id,
//         this.name,
//         this.shortName,
//         this.baseUnit,
//         this.createdAt,
//         this.updatedAt,
//     });

//     factory EUnitName.fromJson(Map<String, dynamic> json) => EUnitName(
//         id: json["id"],
//         name: json["name"],
//         shortName: json["short_name"],
//         baseUnit: json["base_unit"],
//         createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
//         updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
//     );

//     Map<String, dynamic> toJson() => {
//         "id": id,
//         "name": name,
//         "short_name": shortName,
//         "base_unit": baseUnit,
//         "created_at": createdAt?.toIso8601String(),
//         "updated_at": updatedAt?.toIso8601String(),
//     };
// }

// class Stock {
//     int? id;
//     int? warehouseId;
//     int? productId;
//     int? quantity;
//     DateTime? createdAt;
//     DateTime? updatedAt;
//     int? alert;

//     Stock({
//         this.id,
//         this.warehouseId,
//         this.productId,
//         this.quantity,
//         this.createdAt,
//         this.updatedAt,
//         this.alert,
//     });

//     factory Stock.fromJson(Map<String, dynamic> json) => Stock(
//         id: json["id"],
//         warehouseId: json["warehouse_id"],
//         productId: json["product_id"],
//         quantity: json["quantity"],
//         createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
//         updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
//         alert: json["alert"],
//     );

//     Map<String, dynamic> toJson() => {
//         "id": id,
//         "warehouse_id": warehouseId,
//         "product_id": productId,
//         "quantity": quantity,
//         "created_at": createdAt?.toIso8601String(),
//         "updated_at": updatedAt?.toIso8601String(),
//         "alert": alert,
//     };
// }

// class Warehouse {
//     int? totalQuantity;
//     String? name;

//     Warehouse({
//         this.totalQuantity,
//         this.name,
//     });

//     factory Warehouse.fromJson(Map<String, dynamic> json) => Warehouse(
//         totalQuantity: json["total_quantity"],
//         name: json["name"],
//     );

//     Map<String, dynamic> toJson() => {
//         "total_quantity": totalQuantity,
//         "name": name,
//     };
// }
