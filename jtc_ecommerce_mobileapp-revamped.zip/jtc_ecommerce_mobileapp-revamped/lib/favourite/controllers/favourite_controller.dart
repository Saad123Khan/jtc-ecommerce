import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/favourite/blocs/get_favourite_bloc.dart';
import 'package:jtc_ecommerce/favourite/models/get_favourite_model.dart';

class FavouriteController extends GetxController {
  @override
  void onInit() {
    get_favourite();
    super.onInit();
  }

  RxList<FavouriteList> favouriteList = <FavouriteList>[].obs;
  RxBool isLoading = false.obs;
  ScrollController scrollController = ScrollController();

  Future<void> get_favourite() async {
    try {
      isLoading.value = true;
      await GetFavouriteBloc().getFavouriteBlocMethod(
        context: Get.context!,
      );

      if (GetFavouriteBloc().contentTypeResponse != null) {
        favouriteList.addAll(
          List.from(GetFavouriteBloc().contentTypeResponse),
        );
      }
    } catch (e) {
    } finally {
      isLoading.value = false;
    }
  }

  bool isFetching = false;
  onRefreshPage() async {
    FocusManager.instance.primaryFocus?.unfocus();
    if (isFetching) {
      // If already fetching, ignore this call
      return;
    }
    isFetching = true;
    //Clear the listings
    favouriteList.value = [];
    // Fetch new data
    await get_favourite(); // Replace with your API call
    isFetching = false;
  }

  
}
