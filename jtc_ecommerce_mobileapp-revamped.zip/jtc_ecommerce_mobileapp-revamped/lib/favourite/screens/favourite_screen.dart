import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:jtc_ecommerce/cart/blocs/add_to_cart_bloc.dart';
import 'package:jtc_ecommerce/favourite/blocs/post_favourite_bloc.dart';
import 'package:jtc_ecommerce/favourite/controllers/favourite_controller.dart';
import 'package:jtc_ecommerce/widgets/custom_food_card.dart';
import 'package:jtc_ecommerce/widgets/no_data_found.dart';
import 'package:jtc_ecommerce/home/screens/components/addpopup_dialog.dart';
import 'package:jtc_ecommerce/services/app_logger.dart';
import 'package:jtc_ecommerce/utils/app_colors.dart';
import 'package:jtc_ecommerce/utils/app_dialogs.dart';
import 'package:jtc_ecommerce/utils/app_navigation.dart';
import 'package:jtc_ecommerce/utils/app_routes_name.dart';
import 'package:jtc_ecommerce/utils/enums.dart';

class FavouriteScreen extends StatelessWidget {
  var controller = Get.put(FavouriteController());
  FavouriteScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // return Scaffold(
    //   body: SizedBox(
    //     height: Get.height,
    //     child: Column(
    //       mainAxisSize: MainAxisSize.min,
    //       children: [
    //         Expanded(
    //           child: Obx(() {
    //             return RefreshIndicator(
    //               onRefresh: () async {
    //                 controller.onRefreshPage();
    //               },
    //               color: AppColors.PRIMARY_COLOR,
    //               child: !controller.isLoading.value &&
    //                       controller.favouriteList.isEmpty
    //                   ? SizedBox(
    //                       height: Get.height,
    //                       width: Get.width,
    //                       child: SingleChildScrollView(
    //                         physics: AlwaysScrollableScrollPhysics(
    //                           parent: BouncingScrollPhysics(),
    //                         ),
    //                         child: Container(
    //                           height: Get.height / 2,
    //                           alignment: Alignment.center,
    //                           child: NoDataPage(
    //                             text: 'No Data Found',
    //                           ),
    //                         ),
    //                       ),
    //                     )
    //                   : RefreshIndicator(
    //                       onRefresh: () async {
    //                         controller.onRefreshPage();
    //                       },
    //                       color: AppColors.PRIMARY_COLOR,
    //                       child: SingleChildScrollView(
    //                         physics: AlwaysScrollableScrollPhysics(
    //                           parent: BouncingScrollPhysics(),
    //                         ),
    //                         child: GridView.builder(
    //                           physics: NeverScrollableScrollPhysics(),
    //                           shrinkWrap: true,
    //                           gridDelegate:
    //                               const SliverGridDelegateWithFixedCrossAxisCount(
    //                             crossAxisCount: 2,
    //                             crossAxisSpacing: 1.0,
    //                             childAspectRatio: 0.7,
    //                           ),
    //                           itemCount: controller.favouriteList.length +
    //                               (controller.isLoading.value ? 1 : 0),
    //                           itemBuilder: (context, index) {
    //                             if (index < controller.favouriteList.length) {
    //                               return Padding(
    //                                 padding: const EdgeInsets.all(8.0),
    //                                 child: GestureDetector(
    //                                   onTap: () => AppNavigation.navigateTo(
    //                                     context,
    //                                     AppRouteName
    //                                         .PRODUCT_DETAIL_SCREEN_ROUTE,
    //                                     arguments: {
    //                                       "product_id": controller
    //                                           .favouriteList[index].id
    //                                           .toString(),
    //                                     },
    //                                   ),
    //                                   child: CustomFoodCard(
    //                                     prodcutName: controller
    //                                         .favouriteList[index].product?.name,
    //                                     productToken: controller
    //                                         .favouriteList[index]
    //                                         .product
    //                                         ?.productJtcToken
    //                                         .toString(),
    //                                     totalPrice: controller
    //                                         .favouriteList[index]
    //                                         .product
    //                                         ?.productPrice,
    //                                     productImage: controller
    //                                             .favouriteList[index]
    //                                             .product!
    //                                             .images
    //                                             .isNotEmpty
    //                                         ? controller.favouriteList[index]
    //                                             .product?.images[0]
    //                                             .toString()
    //                                         : "",
    //                                     isFavourite: controller
    //                                             .favouriteList[index]
    //                                             .product
    //                                             ?.isFavourite ??
    //                                         true,
    //                                   ),
    //                                 ),
    //                               );
    //                             } else {
    //                               if (controller.isLoading.value) {
    //                                 return Padding(
    //                                   padding: const EdgeInsets.all(16.0),
    //                                   child: Center(
    //                                     child: CircularProgressIndicator(
    //                                       color: AppColors.PRIMARY_COLOR,
    //                                     ),
    //                                   ),
    //                                 );
    //                               } else {
    //                                 return Container();
    //                               }
    //                             }
    //                           },
    //                         ),
    //                       ),
    //                     ),
    //             );
    //           }),
    //         ),
    //       ],
    //     ),
    //   ),
    // );
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 20.h),
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(24.r),
            topRight: Radius.circular(24.r),
          )),
      height: Get.height,
      child: Obx(
        () => RefreshIndicator(
          onRefresh: () async {
            controller.onRefreshPage();
          },
          color: AppColors.PRIMARY_COLOR,
          child: controller.isLoading.value
              ? Container(
                  color: Colors.transparent,
                  child: Center(
                    child: CircularProgressIndicator(
                      color: AppColors.PRIMARY_COLOR,
                    ),
                  ),
                )
              : controller.favouriteList.isEmpty
                  ? SizedBox(
                      height: Get.height,
                      width: Get.width,
                      child: SingleChildScrollView(
                        physics: AlwaysScrollableScrollPhysics(
                          parent: BouncingScrollPhysics(),
                        ),
                        child: Container(
                          height: Get.height / 2,
                          alignment: Alignment.center,
                          child: NoDataPage(
                              text:

                                  // 'No Data Found',
                                  tr('data_not_found')),
                        ),
                      ),
                    )
                  : ListView(
                      physics: AlwaysScrollableScrollPhysics(),
                      children: [
                        ListView.builder(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          // gridDelegate:
                          //     const SliverGridDelegateWithFixedCrossAxisCount(
                          //   crossAxisCount: 2,
                          //   crossAxisSpacing: 1.0,
                          //   childAspectRatio: .6,
                          // ),
                          itemCount: controller.favouriteList.length,
                          itemBuilder: (context, index) {
                            return GestureDetector(
                              onTap: () => AppNavigation.navigateTo(
                                context,
                                AppRouteName.PRODUCT_DETAIL_SCREEN_ROUTE,
                                arguments: {
                                  "product_id": controller
                                      .favouriteList[index].product?.id
                                      .toString(),
                                },
                              ),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 4,
                                  vertical: 4,
                                ),
                                child: CustomFoodCard(
                                  prodcutName:
                                      // product.name,

                                      context.locale.languageCode == 'es'
                                          ? controller.favouriteList[index]
                                                  .product?.nameSp ??
                                              ''
                                          : controller.favouriteList[index]
                                                  .product?.nameEn ??
                                              '',
                                  productToken: controller.favouriteList[index]
                                      .product?.smallTokenPrice
                                      .toString(),
                                  totalPrice: controller
                                      .favouriteList[index].product?.small
                                      .toString(),
                                  productImage: controller.favouriteList[index]
                                              .product?.imageUrl.isNotEmpty ??
                                          false
                                      ? controller.favouriteList[index].product
                                          ?.imageUrl[0]
                                          .toString()
                                      : "",
                                  isFavourite: controller.favouriteList[index]
                                          .product?.isFavorite ??
                                      true,
                                  prodcutDescription:

                                      //  controller
                                      //     .favouriteList[index]
                                      //     .product
                                      //     ?.description,

                                      context.locale.languageCode == 'es'
                                          ? controller.favouriteList[index]
                                                  .product?.descriptionSp ??
                                              ''
                                          : controller.favouriteList[index]
                                                  .product?.descriptionEn ??
                                              '',
                                  onTapAddToCart: () {
                                    // AppDialogs.showAppDialog(
                                    //     context: context,
                                    //     child: AddonPopUp(
                                    //         product: controller
                                    //             .favouriteList[index]
                                    //             .product!));
                                    AddToCartBloc().addToCartBlocMethod(
                                      context: context,

                                      // product_id: product_id,
                                      product_id:
                                          //  product.id.toString(),
                                          controller
                                              .favouriteList[index].product?.id
                                              .toString(),

                                      addons: [],
                                      quantity: 1,
                                      message: "",
                                      isFromDetailScreen: false,
                                      setProgressBar: () {
                                        AppDialogs.progressAlertDialog(
                                            context: context);
                                      },
                                    );
                                  },
                                  onTapFav: () {
                                    logData(message: "1");
                                    PostFavouriteBloc().postFavouriteBlocMethod(
                                      context: context,
                                      isFav: true,
                                      fromFavScreen: true,
                                      product_id: controller
                                          .favouriteList[index].product?.id
                                          .toString(),
                                      setProgressBar: () {
                                        AppDialogs.progressAlertDialog(
                                            context: context);
                                      },
                                    );
                                  },
                                ),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
        ),
      ),
    );
  }
}
